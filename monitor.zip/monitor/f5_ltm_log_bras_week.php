
<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta name="description" content="">
    <meta name="author" content="">
    <link rel="icon" href="../../favicon.ico">

    <title>Radius-Monitor</title>

    <?php include("import_lib.php"); ?>
    <link href="css/navbar-top-fixed.css" rel="stylesheet">

<style>
.highcharts-container {
    overflow: visible !important;
}
.MyChartTooltip {
    position: relative;
    z-index: 50;
    /*border: 2px solid rgb(0, 108, 169);  ไว้ใส่กรอบ*/
    border-radius: 5px;
    background-color: #ffffff;
    padding: 5px;
    font-size: 9pt;
    overflow: auto;
    height: 250px; /* กำหนดความสูง */
}
.highcharts-tooltip {
  pointer-events: all !important;
}
</style>


</head>



<!-- start chart ltm log -->
<?php
  date_default_timezone_set('Asia/Bangkok');
  include "connect208.php";

  $name_dropdown = 'Last Week';

//if($_GET['date'] != ""){
if(isset($_GET['date'])){
	$date_from = $_GET['date'];
	$day = $_GET['date'];
  $today = date("Y-m-d");  // Edit
  $name_dropdown = 'Custom';

}else{
  if(isset($_GET['duration'])){
    switch($_GET['duration']){
      case "lastmonth":
        $today = date("Y-m-d");
        $date_from = date('Y-m-d',strtotime($today . "-1 month"));
        //$date_from = date('Y-m-d',strtotime($today . "first day of previous month")); // วันแรกของเดือนก่อนหน้า
        //$date_from = date('Y-m-d',strtotime($today . "first day of this month")); // วันแรกของเดือนนี้
        $day = date("Y-m-d");
        $name_dropdown = 'Last Month';
        break;

      case "prvmonth":
        $today = date("Y-m-d");
        $date_from = date('Y-m-d',strtotime($today . "first day of previous month")); // วันแรกของเดือนก่อนหน้า
        //$date_from = date('Y-m-d',strtotime($today . "first day of this month")); // วันแรกของเดือนนี้
        $day = date("Y-m-d");
        $name_dropdown = 'Previous Month';
        break;

      default: // นอกจากนั้น
        $today = date("Y-m-d");
        $date_from = date('Y-m-d',strtotime($today . "-7 day"));
        $day = date("Y-m-d");
        break;
      }
    }
    else { // duration เมื่อไม่มีค่า
      $today = date("Y-m-d");
      $date_from = date('Y-m-d',strtotime($today . "-7 day"));
      $day = date("Y-m-d");
    }
}

if(isset($_GET['date2'])){
	$date_to = $_GET['date2'];
	$day2 = $_GET['date2'];
  $name_dropdown = 'Custom';
  $date_ptrfixdate_to = date('D',strtotime($date_to));
}else{
  if(isset($_GET['duration'])){
    switch($_GET['duration']){
      case "lastmonth":
        $date_to = date("Y-m-d");
        //$date_to = date('Y-m-d',strtotime($today . "last day of previous month")); // วันสุดท้ายเดือนก่อนหน้า
        //$date_to = date('Y-m-d',strtotime($today . "last day of this month")); // วันสุดท้ายเดือนนี้
        $day2 = date("Y-m-d");
        $date_ptrfixdate_to = date("D");
        break;

      case "prvmonth":
        $date_to = date('Y-m-d',strtotime($today . "last day of previous month")); // วันสุดท้ายเดือนก่อนหน้า
        //$date_to = date('Y-m-d',strtotime($today . "last day of this month")); // วันสุดท้ายเดือนนี้
        $day2 = date("Y-m-d");
        $date_ptrfixdate_to = date('D',strtotime($date_to));
        break;

      default: // นอกจากนั้น
        $date_to = date("Y-m-d");
        $day2 = date("Y-m-d");
        $date_ptrfixdate_to = date("D");
        break;
      }
    }
    else { // duration เมื่อไม่มีค่า
    	$date_to = date("Y-m-d");
    	$day2 = date("Y-m-d");
      $date_ptrfixdate_to = date("D");
    }
}


isset($time) ? : $time = ''; //Edit

$start = date("Y-m-d"); ;
$from = date('Y-m-d',strtotime($today . "-1 days"));

     // การนับวันที่ และ เวลา
     function DateDiff($strDate1,$strDate2) // นับระยะห่างของวัน
     {
          return (strtotime($strDate2) - strtotime($strDate1))/  ( 60 * 60 * 24 );  // 1 day = 60*60*24
     }
     function TimeDiff($strTime1,$strTime2) // นับระยะห่างของเวลา
     {
          return (strtotime($strTime2) - strtotime($strTime1))/  ( 60 * 60 ); // 1 Hour =  60*60
     }
     function DateTimeDiff($strDateTime1,$strDateTime2) // นับระยะห่างของวันที่และเวลา
     {
          return (strtotime($strDateTime2) - strtotime($strDateTime1))/  ( 60 * 60 ); // 1 Hour =  60*60
     }

     $datecnt=DateDiff($date_from,$date_to)."<br>";
     $intcnt=intval($datecnt); // แปลงค่า String เป็น Int

     // เช็คว่า วันห่างกันกี่วัน ถ้าน้อยกว่า 0 ให้แจ้งเตือนแล้วไม่ทำงานส่วนต่าง ๆ
     if ($intcnt < 0) {
       echo"<script language=\"JavaScript\">";
       echo"alert('กรอกข้อมูลไม่วันที่ไม่ถูกต้อง')";
       echo"</script>";
     }
     else { // กรณีกรอกวันที่ถูกต้อง ก็เริ่มทำงานปกติ
       for($i=$intcnt; $i >= 0; $i--)
       {
         //$date[]=date('Y-m-d',strtotime('-'.$i.' days')); // อันนี้ลบแบบวันปัจจุบัน
         $date[]=date("Y-m-d",strtotime('-'.$i.' days',strtotime($date_to))); // อันนี้ลบจากวัน $date_to วันที่กำหนดเองได้
         $date_ptrfixdate[]=date("D",strtotime('-'.$i.' days',strtotime($date_ptrfixdate_to)));

       }
       // เอาค่าที่อยู่ใน Date มาใส่
       //isset($date) ? : $date[] = ''; //Edit // กัน $date ว่าง
       for ($d=0; $d < COUNT($date); $d++) {
         $a_date_start_stop[] = $date[$d];
         $time .= "'".$date_ptrfixdate[$d]." ".$date[$d]."',"; // $time เก็บวันที่ [แบบสะสมต่อกันไปเรื่อยๆ ] นำไปใช้งานจริง
       }
       //echo $time;

    // Query หา nasip ของ 10.11.11.86
    $sql=mysqli_query($con," SELECT f5_data.date , f5_data.bras_name , f5_data.nasipaddress , f5_data.ip_host , f5_data.cnt
      FROM (SELECT date_format(datetime,'%Y-%m-%d') as date, bras.bras_name as bras_name , bras.nasipaddress as nasipaddress ,bras.radius_host as ip_host, COUNT(bras.nasipaddress) as cnt
      from ( SELECT *
      , SUBSTRING(SUBSTRING_INDEX(ltmlog,':',4),-11,11) AS ltmlog_strIP
      , TRIM(REPLACE(SUBSTRING(SUBSTRING_INDEX(ltmlog,':',-1),1,5),':','')) as ltmlog_strPort
      FROM f5_ltm_log as f5_log
      WHERE ltmlog like '%down%'
      ) as f5_log JOIN f5_radius_port as bras
      on (f5_log.ltmlog_strPort = bras.radius_port and f5_log.ltmlog_strIP = bras.radius_host)
			where bras.radius_host = '10.11.11.86' and date_format(datetime,'%Y-%m-%d') between '$date_from' and '$date_to'
      GROUP BY bras.nasipaddress
			) as f5_data join f5_ro
			on (f5_data.nasipaddress = f5_ro.ro_bras_ip)
			ORDER BY f5_ro.ro_id ");

    while ($result=mysqli_fetch_array($sql)) {
      $a_nasip_array[] = $result["nasipaddress"];
    }
    // จบคำสั่ง Query nasip ของ 10.11.11.86

    // Query หา nasip ของ 10.11.11.88
    $sql=mysqli_query($con," SELECT f5_data.date , f5_data.bras_name , f5_data.nasipaddress , f5_data.ip_host , f5_data.cnt
      FROM (SELECT date_format(datetime,'%Y-%m-%d') as date, bras.bras_name as bras_name , bras.nasipaddress as nasipaddress ,bras.radius_host as ip_host, COUNT(bras.nasipaddress) as cnt
      from ( SELECT *
      , SUBSTRING(SUBSTRING_INDEX(ltmlog,':',4),-11,11) AS ltmlog_strIP
      , TRIM(REPLACE(SUBSTRING(SUBSTRING_INDEX(ltmlog,':',-1),1,5),':','')) as ltmlog_strPort
      FROM f5_ltm_log as f5_log
      WHERE ltmlog like '%down%'
      ) as f5_log JOIN f5_radius_port as bras
      on (f5_log.ltmlog_strPort = bras.radius_port and f5_log.ltmlog_strIP = bras.radius_host)
			where bras.radius_host = '10.11.11.88' and date_format(datetime,'%Y-%m-%d') between '$date_from' and '$date_to'
      GROUP BY bras.nasipaddress
			) as f5_data join f5_ro
			on (f5_data.nasipaddress = f5_ro.ro_bras_ip)
			ORDER BY f5_ro.ro_id ");

    while ($result=mysqli_fetch_array($sql)) {
      $a_nasip_array_88[] = $result["nasipaddress"];
      //echo $result["nasipaddress"].'<br>';
    }
    // จบคำสั่ง Query nasip ของ 10.11.11.88

  // start query bras

      // start Query color
      $sql=mysqli_query($con,"select ro_bras_ip as ip_bras ,ro_color from f5_ro");

      while ($result=mysqli_fetch_array($sql)) {
        $a_ipbras = $result["ip_bras"];
        $a_bras_color[$a_ipbras] = $result["ro_color"]; // $data_final[$a_date] เก็บค่า cnt เป็นอ Array [ชี้ตำแหน่งด้วยวันที่]์
      }
      // End Query color

      // start query bras ข้อมูลหลัก

      // ------------------------------------ เริมการทำงานงาน Host 10.11.11.86 -----------------------------------------------------
      $sql=mysqli_query($con,"SELECT f5_data.date , f5_data.bras_name , ro_bras_name , f5_data.nasipaddress , f5_data.ip_host , f5_data.cnt
      FROM (SELECT date_format(datetime,'%Y-%m-%d') as date, bras.bras_name as bras_name , bras.nasipaddress as nasipaddress ,bras.radius_host as ip_host, COUNT(bras.nasipaddress) as cnt
      from ( SELECT *
      , SUBSTRING(SUBSTRING_INDEX(ltmlog,':',4),-11,11) AS ltmlog_strIP
      , TRIM(REPLACE(SUBSTRING(SUBSTRING_INDEX(ltmlog,':',-1),1,5),':','')) as ltmlog_strPort
      FROM f5_ltm_log as f5_log
      WHERE ltmlog like '%down%'
      ) as f5_log JOIN f5_radius_port as bras
      on (f5_log.ltmlog_strPort = bras.radius_port and f5_log.ltmlog_strIP = bras.radius_host)
			where bras.radius_host = '10.11.11.86'
      GROUP BY date , bras.nasipaddress
			) as f5_data join f5_ro
			on (f5_data.nasipaddress = f5_ro.ro_bras_ip)
      where f5_data.date between '$date_from' and '$date_to'
			ORDER BY f5_data.date,f5_ro.ro_id");

      while ($result=mysqli_fetch_array($sql)) {
        $a_date = $result["date"]; // $a_date เก็บวันที่
        $a_nasip = $result["nasipaddress"];
      	$a_value[$a_date][$a_nasip] = $result["cnt"]; // $data_final[$a_date] เก็บค่า cnt เป็นอ Array [ชี้ตำแหน่งด้วยวันที่]์
        $a_bras_name[$a_nasip] = $result["ro_bras_name"]; // $data_final[$a_date] เก็บค่า cnt เป็นอ Array [ชี้ตำแหน่งด้วยวันที่]์
      }

      isset($a_nasip_array) ? : $a_nasip_array[] = ''; //Edit // กัน ipnas ว่าง
      for($d=0; $d<COUNT($a_date_start_stop); $d++) {
        //echo COUNT($a_date_start_stop);

        for($n=0; $n<COUNT($a_nasip_array); $n++) {
          //echo $a_nasip_array[$n].'<br>';
          isset($a_value[$a_date_start_stop[$d]][$a_nasip_array[$n]]) ? : $a_value[$a_date_start_stop[$d]][$a_nasip_array[$n]] = ''; //Edit
          if($a_value[$a_date_start_stop[$d]][$a_nasip_array[$n]] != '') {
            isset($data_value[$a_nasip_array[$n]]) ? : $data_value[$a_nasip_array[$n]] = ''; //Edit
            $data_value[$a_nasip_array[$n]] .= $a_value[$a_date_start_stop[$d]][$a_nasip_array[$n]].",";
          }
          else {
            isset($data_value[$a_nasip_array[$n]]) ? : $data_value[$a_nasip_array[$n]] = ''; //Edit
            $data_value[$a_nasip_array[$n]] .= "null,";
          }
        }
      }

      isset($show_data) ? : $show_data = ''; //Edit
      isset($show_color) ? : $show_color = ''; //Edit

      for ($i=0; $i < count($data_value); $i++) {
            isset($show_color) ? : $show_color = ''; //Edit
            if ($a_nasip_array[$i] != '') {
              $show_data .= " { id: '".TRIM($a_bras_name[$a_nasip_array[$i]])."', name: '".TRIM($a_bras_name[$a_nasip_array[$i]])."', data: [".$data_value[$a_nasip_array[$i]]."], stack: '10.11.11.86' },";
              $show_color .= "'".$a_bras_color[$a_nasip_array[$i]]."', ";
            }
            else { // กรณีไม่มีข้อมูลเลย
              //$show_data .= " { name: '', data: [".$data_value[$a_nasip_array[$i]]."] },";
              //$show_color .= "'red', ";
            }
      }
      // ------------------------------------ เริมการทำงานงาน Host 10.11.11.86 -----------------------------------------------------

      // ------------------------------------ เริมการทำงานงาน Host 10.11.11.88 -----------------------------------------------------
      $sql=mysqli_query($con,"SELECT f5_data.date , f5_data.bras_name , ro_bras_name , f5_data.nasipaddress , f5_data.ip_host , f5_data.cnt
      FROM (SELECT date_format(datetime,'%Y-%m-%d') as date, bras.bras_name as bras_name , bras.nasipaddress as nasipaddress ,bras.radius_host as ip_host, COUNT(bras.nasipaddress) as cnt
      from ( SELECT *
      , SUBSTRING(SUBSTRING_INDEX(ltmlog,':',4),-11,11) AS ltmlog_strIP
      , TRIM(REPLACE(SUBSTRING(SUBSTRING_INDEX(ltmlog,':',-1),1,5),':','')) as ltmlog_strPort
      FROM f5_ltm_log as f5_log
      WHERE ltmlog like '%down%'
      ) as f5_log JOIN f5_radius_port as bras
      on (f5_log.ltmlog_strPort = bras.radius_port and f5_log.ltmlog_strIP = bras.radius_host)
			where bras.radius_host = '10.11.11.88'
      GROUP BY date , bras.nasipaddress
			) as f5_data join f5_ro
			on (f5_data.nasipaddress = f5_ro.ro_bras_ip)
      where f5_data.date between '$date_from' and '$date_to'
			ORDER BY f5_data.date,f5_ro.ro_id");

      while ($result=mysqli_fetch_array($sql)) {
        $a_date = $result["date"]; // $a_date เก็บวันที่
        $a_nasip = $result["nasipaddress"];
      	$a_value_88[$a_date][$a_nasip] = $result["cnt"]; // $data_final[$a_date] เก็บค่า cnt เป็นอ Array [ชี้ตำแหน่งด้วยวันที่]์
        $a_bras_name[$a_nasip] = $result["ro_bras_name"]; // $data_final[$a_date] เก็บค่า cnt เป็นอ Array [ชี้ตำแหน่งด้วยวันที่]์
      }

      isset($a_nasip_array_88) ? : $a_nasip_array_88[] = ''; //Edit // กัน ipnas ว่าง
      for($d=0; $d<COUNT($a_date_start_stop); $d++) {
        //echo COUNT($a_date_start_stop);

        for($n=0; $n<COUNT($a_nasip_array_88); $n++) {
          isset($a_value_88[$a_date_start_stop[$d]][$a_nasip_array_88[$n]]) ? : $a_value_88[$a_date_start_stop[$d]][$a_nasip_array_88[$n]] = ''; //Edit
          if($a_value_88[$a_date_start_stop[$d]][$a_nasip_array_88[$n]] != '') {
            isset($data_value_88[$a_nasip_array_88[$n]]) ? : $data_value_88[$a_nasip_array_88[$n]] = ''; //Edit
            $data_value_88[$a_nasip_array_88[$n]] .= $a_value_88[$a_date_start_stop[$d]][$a_nasip_array_88[$n]].",";
          }
          else {
            isset($data_value_88[$a_nasip_array_88[$n]]) ? : $data_value_88[$a_nasip_array_88[$n]] = ''; //Edit
            $data_value_88[$a_nasip_array_88[$n]] .= "null,";
          }
        }
      }

      isset($show_data_88) ? : $show_data_88 = ''; //Edit
      isset($show_color_88) ? : $show_color_88 = ''; //Edit

      for ($i=0; $i < count($data_value_88); $i++) {
          if ($a_nasip_array_88[$i] != '') {

            $ck_name = 0;
            $msg_linkto = "";
            for ($j=0; $j < count($data_value); $j++) {
              if (TRIM($a_bras_name[$a_nasip_array_88[$i]]) == TRIM($a_bras_name[$a_nasip_array[$j]])) {
                $msg_linkto = "linkedTo: '".TRIM($a_bras_name[$a_nasip_array_88[$i]])."',  ";
              }
            }

            $show_data_88 .= " { ".$msg_linkto."name: '".TRIM($a_bras_name[$a_nasip_array_88[$i]])."', data: [".$data_value_88[$a_nasip_array_88[$i]]."], stack: '10.11.11.88' },";
            $show_color_88 .= "'".$a_bras_color[$a_nasip_array_88[$i]]."', ";
          }
          else { // กรณีไม่มีข้อมูลเลย
            //$show_data_88 .= " { name: '', data: [".$data_value_88[$a_nasip_array_88[$i]]."] },";
            //$show_color_88 .= "'red', ";
          }
      }
      // ------------------------------------ เริมการทำงานงาน Host 10.11.11.86 -----------------------------------------------------

      //echo strlen($show_data_88); // strlen(ตัวแปรสตริง) เช็คว่า String นี้มีข้อความกี่ตัวอักษร
      // หากไม่มีข้อมูลทั้ง 2 เครื่อง ให้แสดงค่าว่าง

      if ( (strlen($show_data) == 0) and (strlen($show_data_88) == 0) ) {
        for ($i=0; $i < count($data_value); $i++) {
          $show_data .= " { name: '', data: [".$data_value[$a_nasip_array[$i]]."] },";
          $show_color .= "'red', ";
          $show_data_88 .= " { name: '', data: [".$data_value_88[$a_nasip_array_88[$i]]."] },";
          $show_color_88 .= "'red', ";
        }
      }
      // ------------------------------------ หาค่า Max ไปใช้้ใน Graph -----------------------------------------------------
      $sql=mysqli_query($con,"SELECT max(f5_data.cnt) as max_value
      FROM (SELECT date_format(datetime,'%Y-%m-%d') as date, bras.bras_name as bras_name ,
      bras.nasipaddress as nasipaddress ,bras.radius_host as ip_host, COUNT(bras.nasipaddress) as cnt
      from ( SELECT *
      , SUBSTRING(SUBSTRING_INDEX(ltmlog,':',4),-11,11) AS ltmlog_strIP
      , TRIM(REPLACE(SUBSTRING(SUBSTRING_INDEX(ltmlog,':',-1),1,5),':','')) as ltmlog_strPort
      FROM f5_ltm_log as f5_log
      WHERE ltmlog like '%down%'
      ) as f5_log JOIN f5_radius_port as bras
      on (f5_log.ltmlog_strPort = bras.radius_port and f5_log.ltmlog_strIP = bras.radius_host)
      where bras.radius_host IN  ('10.11.11.86','10.11.11.88')
      GROUP BY date,bras.radius_host
      ) as f5_data join f5_ro
      on (f5_data.nasipaddress = f5_ro.ro_bras_ip)
      where f5_data.date between '$date_from' and '$date_to'
      ORDER BY f5_data.date,f5_ro.ro_id;");

      while ($result=mysqli_fetch_array($sql)) {
        $graph_max = $result["max_value"]; // $a_date เก็บวันที่
      }
      // ------------------------------------ หาค่า Max ไปใช้้ใน Graph -----------------------------------------------------
      isset($graph_max) ? : $graph_max = 50; //Edit
      ($graph_max > 50) ? : $graph_max = 50; //Edit
      
  // End query bras
  }

 ?>

<script src="js/jquery-3.1.1.min.js"></script>
<script src="code/highcharts.js"></script>
<script src="code/highcharts-3d.js"></script>
<script src="code/modules/exporting.js"></script>
<!-- end chart ltm log  -->
  <body>

<?php include("menu_top.php");?>

<?php include("menu_date.php");?>


</body>

<!-- jQuery first, then Tether, then Bootstrap JS. -->
<script src="js/bootstrap.min2.js" integrity="sha384-vBWWzlZJ8ea9aCX4pEW3rVHjgjt7zpkNpZk+02D9phzyeVkE+jo0ieGizqPLForn" crossorigin="anonymous"></script>

<!-- start chart ltm log -->
<script type="text/javascript">



Highcharts.chart('container', {
    chart: {
        type: 'column',
        borderColor: "#000000",
        borderWidth: 1
        // ทำเป็นกราฟ 3D

        /*options3d: {
            enabled: true,
            alpha: 0,
            beta: 0,
            viewDistance: 30,
            depth: 25
        }*/
    },
    colors: [<?php echo $show_color ?> <?php echo $show_color_88 ?>], // เปลี่ยนแท่งกราฟ
    title: {
        text: 'F5 - 113 LTM LOG (DAILY) : Status Down , Host : 10.11.11.86 , 10.11.11.88'
    },
    subtitle: {
        text: '<?php echo 'Date: '.$date_from.' to '.$date_to; ?>',
        align: 'center',
        x: -20
    },
    xAxis: {
        /*categories: ['Apples', 'Oranges', 'Pears', 'Grapes', 'Bananas']*/
        categories: [<?php echo $time; ?>],
    },
    legend: { // แถบแต่ล่ะ Bras ด้านล่าง
        // align: 'right',
        // x: -30,
        // verticalAlign: 'top',
        // y: 20,
        // floating: true,
        // backgroundColor: (Highcharts.theme && Highcharts.theme.background2) || 'white',
        // borderColor: '#CCC',
        // borderWidth: 1,
        // shadow: false
        enabled : true, //เปิดให้แถบแต่ล่ะ Bras มาอยู่ข้างล่าง
        itemWidth: 140 // กำหนดระยะห่างการแสดงข้อความ (จัดเรียงให้ตรงกัน)
    },
    tooltip: {
      //backgroundColor: '#e6ffff',
      useHTML: true,
      //headerFormat: '<b>{point.x}</b><br/>', // headerFormat การแสดงข้อมูลส่วนหัว
      //pointFormat: '{series.name}: {point.y}<br/>Total: {point.stackTotal}', // pointFormat การแสดงข้อความส่วนข้อมูลแต่ล่ะจุด
      formatter: function () {
         var s = '<b><u>' + this.x + '</u></b></br> <table>';
         var total_1 = 0 , total_2 = 0 , total = 0;
         var text_1 = [] , text_2 = [];
         var i_1 = 0 , i_2 = 0;
         var sum_text = '<div class="MyChartTooltip">';

          $.each(this.points, function () {
              //s += '<br/><b><font color="'+this.series.color+'">' + this.series.name + ': </font>' + this.y + '</b>';
              if(this.series.options.stack == '10.11.11.86') {
                text_1[i_1] = '<td><b><font color="'+this.series.color+'">' + this.series.name + ': </font>' + this.y + '</td>';
                i_1++;
                total_1 += this.y;
              }
              else if(this.series.options.stack == '10.11.11.88') {
                text_2[i_2] = '<td><b><font color="'+this.series.color+'">' + this.series.name + ': </font>' + this.y + '</td>';
                i_2++;
                total_2 += this.y;
              }

              total += this.y;
          });

          sum_text += s; // ใส่หัว Title
          var cnt_loop

          if (text_1.length >= text_2.length) {
            var cnt_loop = text_1.length;
          }
          else {
            var cnt_loop = text_2.length;
          }

          for (var j = 0; j < cnt_loop; j++) {
            sum_text += '<tr>';

            if ( text_1[j] != null) {
              sum_text += text_1[j];
            }
            else {
              sum_text += '<td></td>';
            }
            if ( text_2[j] != null) {
              sum_text += text_2[j];
            }
            else {
              sum_text += '<td></td>';
            }
            //sum_text += '</br>';
            sum_text += '</tr>';
          }

          if( total_1 != 0 ) {
            total_1 = '<td> <b><u>Total 86 : ' + total_1 + '<u></b> </td>';
          }
          else {
              total_1 = '<td></td>';
          }
          if( total_2 != 0 ) {
            total_2 = '<td> <b><u>Total 88 : ' + total_2 + '<u></b> </td>';
          }
          else {
              total_2 = '<td></td>';
          }
          sum_text += '<tr>' + total_1 + total_2 + '</tr>';
          sum_text += '</table>';
          sum_text += '<b><u>Total All: ' + total + '<u></b>';

          //alert(text_1[0]);
          //alert(this.series.options.stack);
          //s += '<br/><b><u>Total: ' + total + '<u></b>';


          sum_text += '<div>';
          return sum_text;
      },
      shared: true,/*, //เปิดแสดงข้อมูลแบบรวม รวมทุกอันในแท่งนั้น
      followPointer: true*/ //แถบมันจะเลื่อนตามเมาส์
      crosshairs: true
    },
    yAxis: {
        min: 0,
        max: <?php echo $graph_max; ?>,
        title: {
            text: 'Total Status Down'
        },
        stackLabels: {
            enabled: true,
            rotation: -50,
            x: 0,
            y: -10,
            style: {
                fontWeight: 'bold',
                color: (Highcharts.theme && Highcharts.theme.textColor) || 'gray'
            }
        }
    },
    plotOptions: {
        column: {
            stacking: 'normal'/*,
            dataLabels: { ปิดการแสดงตัวเลข
                enabled: true,
                color: (Highcharts.theme && Highcharts.theme.dataLabelsColor) || 'white'
            }*/
        }
    },
    series: [ <?php echo $show_data; ?> <?php echo $show_data_88; ?> ]
});

</script>
<!-- end chart ltm log -->


<script type="text/javascript" src="js/bootstrap-datetimepicker.js" charset="UTF-8"></script>

<script type="text/javascript">
    $('.form_datetime').datetimepicker({
        //language:  'fr',
      weekStart: 1,
        todayBtn:  1,
		autoclose: 1,
		todayHighlight: 1,
		startView: 2,
		minView: 2,
		forceParse: 0,
        showMeridian: 1
    });

</script>

</html>
