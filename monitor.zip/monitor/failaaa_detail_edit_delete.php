<meta charset="UTF-8">
<?php
include "connect210.php";
 $hour=$_GET['hour'];
 $datechk=$_GET['date'];

$query_chkre=mysqli_query($con2,"select count(*) cnt from FAILAAA_REMARK where date_remark='".$datechk."' and time_hour='".$hour.":00-".$hour.":59';");
$rowchk=mysqli_fetch_array($query_chkre);
if($rowchk['cnt']>0)
{
	$delete_remark=mysqli_query($con2,"delete from FAILAAA_REMARK where date_remark='".$datechk."'  and time_hour='".$hour.":00-".$hour.":59';");
}
echo "<script>alert('ลบข้อมูลเรียบร้อย');window.close();window.opener.location.reload();</script>";
?>