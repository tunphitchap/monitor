<meta charset="UTF-8">
<?php
      // Connect To DB
      $con = mysqli_connect("10.11.11.208","root","password");
      if (!$con) {
        die("Database connection failed: " . mysqli_error());
      }
      $db_select = mysqli_select_db($con, "monitor");
      if (!$db_select) {
          die("Database selection failed: " . mysqli_error());
      }
      mysqli_set_charset( $con, 'utf8');


$remark_id=$_GET['id'];
$check_remark=mysqli_query($con,"SELECT * FROM checkpoint_not_complete_remark WHERE remark_id=".$remark_id.";");
$result=mysqli_fetch_array($check_remark);

if($result['remark_id']!=null){
	// Delete Remark
	$delete_remark=mysqli_query($con,"DELETE FROM checkpoint_not_complete_remark WHERE remark_id=".$remark_id.";");
	echo "<script>alert('Delete Successfully');window.close();window.opener.location.reload();</script>";
}
else{
	// Remark Not Found
	echo "<script>alert('Cannot Delete (Remark Not Found)');window.close();window.opener.location.reload();</script>";
}

?>