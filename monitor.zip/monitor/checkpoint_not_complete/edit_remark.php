<!DOCTYPE html>
<html lang="en">
  <head>   
    <style>
    table, th, td {
        vertical-align: middle;
    }
    td.b_top {
      border-top:1pt solid black;
    }
    td.b_bottom {
      border-bottom:1pt solid black;
    }
    td.b_left {
      border-left:1pt solid black;
    }
    td.b_right {
      border-right:1pt solid black;
    }
    .date_text{
      line-height:35px
    }
    </style>
    <script src="https://use.fontawesome.com/7201578446.js"></script>
    <script language="javascript">
      function js_popup(theURL,width,height) {
        leftpos = (screen.availWidth - width) / 2;
        toppos = (screen.availHeight - height) / 2;
        window.open(theURL, "viewdetails","width=" + width + ",height=" + height + ",left=" + leftpos + ",top=" + toppos);
      }
    </script>
  </head>
  <body>

<?php

	include('menu_top.php');

	// Connect To DB
	$con = mysqli_connect("10.11.11.208","root","password");

	if (!$con) {
    die("Database connection failed: " . mysqli_error());
	}

	$db_select = mysqli_select_db($con, "monitor");
	if (!$db_select) {
    	die("Database selection failed: " . mysqli_error());
	}
	mysqli_set_charset( $con, 'utf8');
	
?>


<!-- DATE FORM -->
<div class="bootstrap-iso">
  <div class="container-fluid">
    <div class="row">
      <div class="col-md-5"></div>
      <div class="col-md-4 date_text"><font color="black" size="3"><b>Edit Remark (For Daily Report)</b></font></div>
      <div class="col-md-3">
      <a href="" onClick="js_popup('edit_remark_detail.php?id=new',775,325); return false;">
      <button class="btn btn-primary" type="submit">Add New Remark</button></a></div>
    </div>
  </div>    
</div>
<!-- END DATE FORM -->


  <br>
  <table class='table' style="width:1000px" align="center">
      <thead>
      <!-- [1] Header (Server Name & Show Hide Button) -->
      <tr>
        <td bgcolor='#0040ff' width="15%" class="text-center b_top b_bottom b_left b_right">
          <font color="white"><b>Date</b></font></td>
        <td bgcolor='#0040ff' width="12.5%" class="text-center b_top b_bottom b_left b_right">
          <font color="white"><b>Time</b></font></td>
        <td bgcolor='#0040ff' width="67.5%" class="text-center b_top b_bottom b_left b_right">
          <font color="white"><b>Remark</b></font></td>
        <td bgcolor='#0040ff' width="5%" class="text-center b_top b_bottom b_left b_right">
          <font color="white"><b>Edit</b></font></td>
      </tr>
      </thead>
      <tbody>
        <tr>

    <?php
    	// Query Remark
	$sql=mysqli_query($con, "SELECT * FROM checkpoint_not_complete_remark ORDER BY remark_date DESC;");

  while ($result=mysqli_fetch_array($sql)) { ?>
          <td bgcolor='#f2f2f2' class="text-center b_top b_bottom b_left b_right">
            <font color="black"><?php echo date('d/m/Y',strtotime($result['remark_date']));?></font></td>
          <td bgcolor='#f2f2f2' class="text-center b_top b_bottom b_left b_right">
            <font color="black"><?php echo $result['remark_time'];?></font></td>
          <td bgcolor='#f2f2f2' class="text-left b_top b_bottom b_left b_right">
            <font color="black">&nbsp;&nbsp;&nbsp;<?php echo $result['remark_detail'];?></font></td>
          <td bgcolor='#f2f2f2' class="text-center b_left b_bottom b_right">
            <font color="black"> 
            <a href="" onClick="js_popup('edit_remark_detail.php?id=<?php echo $result['remark_id'];?>',775,325); return false;">
          <i class="fa fa-wrench" aria-hidden="true"></i>
          </a></font></a></td>
      	</tr>
      	<?php } ?>
      </tbody>
  </table>
  </body>
  </html>