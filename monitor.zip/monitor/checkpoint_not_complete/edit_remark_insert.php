<meta charset="UTF-8">
<?php
      // Connect To DB
      $con = mysqli_connect("10.11.11.208","root","password");
      if (!$con) {
        die("Database connection failed: " . mysqli_error());
      }
      $db_select = mysqli_select_db($con, "monitor");
      if (!$db_select) {
          die("Database selection failed: " . mysqli_error());
      }
      mysqli_set_charset( $con, 'utf8');


 $remark_date=$_POST['date'];
 $remark_hour=$_POST['time'];
 $remark_detail=$_POST['remark_txt_area'];


$sql=mysqli_query($con, "SELECT * FROM checkpoint_not_complete_remark WHERE date_format(remark_date,'%d-%m-%Y')='".$remark_date."';");
$result=mysqli_fetch_array($sql);

// Check Is Available Data On This Date?
if($result['remark_date']!=null){
	// Found Data => Update Remark 
	$update_db=mysqli_query($con,"UPDATE checkpoint_not_complete_remark SET remark_detail='".$remark_detail."', remark_time='".$remark_hour."' WHERE remark_id='".$result['remark_id']."';");
	echo "<script>alert('Update Successfully');window.close();window.opener.location.reload();</script>";
}
else{
	// No Data => Add New Remark 
	$insert_db=mysqli_query($con,"INSERT INTO checkpoint_not_complete_remark (remark_date,remark_time,remark_detail) VALUES ('".date('Y-m-d',strtotime($remark_date))."','".$remark_hour."','".$remark_detail."')");
	echo "<script>alert('Insert Successfully');window.close();window.opener.location.reload();</script>";
}

?>
