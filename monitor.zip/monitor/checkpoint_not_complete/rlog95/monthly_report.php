     <style>
    td.b_top {
      border-top:1pt solid black;
    }
    td.b_bottom {
      border-bottom:1pt solid black;
    }
    td.b_left {
      border-left:1pt solid black;
    }
    td.b_right {
      border-right:1pt solid black;
    }
    div.header {
    display: table-cell;
    text-align: center;
    border-top: 1px solid black;
    border-right: 1px solid black;
    border-left: 1px solid black;
    background-color: lightblue;
    }
    div.table {
    display: table-cell;
    text-align: center;
    }
    </style>

<?php

	include('menu_top.php');

	// Connect To DB
	$con = mysqli_connect("10.11.30.59","root","1qazxsw2");

	if (!$con) {
    die("Database connection failed: " . mysqli_error());
	}

	$db_select = mysqli_select_db($con, "monitor");
	if (!$db_select) {
    	die("Database selection failed: " . mysqli_error());
	}
	mysqli_set_charset( $con, 'utf8');
	
?>



<!-- เริ่ม From -->

<style type="text/css">
 @media (min-width: 768px) {
   .container {
   width: 500px;
   }
 }
 @media (min-width: 992px) {
   .container {
   width: 800px;
   }
 }
 @media (min-width: 1200px) {
   .container {
   width: 1300px;
   }
 }
 .date_text{
    line-height:35px
 }
 </style>






 <?php 

 $host_ip="10.11.11.95";

  // Get Date
  if(isset($_GET['date'])){
    $select_date=$_GET['date'];
  } 
  else {
  $select_date=date('M-Y',(strtotime('-1 month')));
  }

  // Get Duration
  if(isset($_GET['duration'])){
    // Check Number Format
    if(is_numeric($_GET['duration']) && $_GET['duration']>0 && $_GET['duration']<=12){
      $duration=$_GET['duration'];
    }
    else{
      echo '<script>alert("Please Enter Valid Number! [1-12]\nDefault = Last 1 Month");</script>';
      $duration=1;
    }
    
  } 
  else {
    $duration=1;
  }

 ?>



<!-- DATE FORM -->
<div class="bootstrap-iso">
  <div class="container-fluid">
    <div class="row">
      <div class="col-md-1"></div>
      <div class="col-md-1"><button class="btn btn-danger">RLOG [10.11.11.95]</button></div>
      <div class="col-md-1"></div>
      <div class="col-md-6">
        <form method="get">
          <div class="form-group col-md-1"><label class="control-label date_text" for="date">Date</label></div>
          <div class="form-group col-md-3"> <!-- Date input -->
            <input class="form-control" id="date" name="date" value="<?php echo $select_date;?>" type="text"/>
          </div>
          <div class="form-group col-md-2"> <!-- Submit button -->
            <button class="btn btn-primary" type="submit">Submit</button>
          </div>
        <div class="col-md-2"><label class="control-label date_text" for="date">&nbsp;&nbsp;&nbsp;View Last</label></div>
        <div class="col-md-2"><input style="text-align:center;" class="form-control input-sm" id="duration" name="duration" type="text" value=<?php echo $duration;?>></div>
        <div class="col-md-2"><label class="control-label date_text" for="date">Month</label></div>
        </form>
        <!-- Form code ends --> 
      </div>
      <div class="col-md-3"></div>
    </div>    
  </div>
</div>
<!-- END DATE FORM -->



<!-- QUERY DATA -->
<?php
  function query_data($prv_month,$host_ip){

      //$prv_month="2017-12"; // Use For Test Other Month

      // Query Data Part
      $con = mysqli_connect("10.11.30.59","root","1qazxsw2");
      if (!$con) {
        die("Database connection failed: " . mysqli_error());
      }
      $db_select = mysqli_select_db($con, "monitor");
      if (!$db_select) {
          die("Database selection failed: " . mysqli_error());
      }
      mysqli_set_charset( $con, 'utf8');

      $GLOBALS['first_date']=date("Y-m-01",strtotime($prv_month));
      $GLOBALS['last_date']=date("Y-m-t",strtotime($prv_month));

      //Query Checkpoint Not Complete Data
      $sql=mysqli_query($con, "SELECT * FROM checkpoint_not_complete WHERE date_format(checkpoint_date,'%Y-%m-%d') BETWEEN '".$GLOBALS['first_date']."' AND '".$GLOBALS['last_date']."' AND db_host='".$host_ip."';");


      while ($result=mysqli_fetch_array($sql)) {
        global $db95_count, $max_rowspan, $total_db95;
        $date=$result['checkpoint_date'];
        $total_db95[$date]=$result['db_count'];
        //$total_db2[$date]=$result['db2_count'];

        for($i=0;$i<24;$i++){
          // Loop For Count 24 Hour In 1 Day
          $hr=sprintf('%02d', $i);

          $db95_count[$date][$i]=substr_count($result['db_detail'],date("D M d ".$hr.":",strtotime($result['checkpoint_date'])));
          //$db2_count[$date][$i]=substr_count($result['db2_detail'],date("D M d ".$hr.":",strtotime($result['checkpoint_date'])));
          if($max_rowspan[$date]==null || $max_rowspan[$date] < $db95_count[$date][$i]){
            // Update max_rowspan
            $max_rowspan[$date]=$db95_count[$date][$i];
          }
        }
      } 
  }
?>



<!-- GET DAY COLOR -->
<?php
 function get_day_color($day_abv){
      switch($day_abv){
      case "Sun":
        return "#ff0000";
      case "Mon":
        return "#ffff00";
      case "Tue":
        return "#ff99cc";
      case "Wed":
        return "#92d050";
      case "Thu":
        return "#ffc000";
      case "Fri":
        return "#b8cce4";
      case "Sat":
        return "#b1a0c7";
    }
    }
?>

<!-- GET CELL COLOR -->
<?php
  function get_cell_color($db_count){
    if($db_count>0){
      return "#ffc000";
    }
    else{
      return "#bfbfbf";
    }
  }
?>



<!-- BIG MONTH LOOP --><!-- BIG MONTH LOOP --><!-- BIG MONTH LOOP -->
<!-- BIG MONTH LOOP --><!-- BIG MONTH LOOP --><!-- BIG MONTH LOOP -->
<!-- BIG MONTH LOOP --><!-- BIG MONTH LOOP --><!-- BIG MONTH LOOP -->
<?php 
  for($i_bigloop=0;$i_bigloop<$duration;$i_bigloop++){
?>



<?php
  // MAIN FUNCTION ///  
  $db95_count = array();
  //$db2_count = array();
  $max_rowspan = array(0);
  $total_db95 = array();
  //$total_db2 = array();
  $first_date = '';
  $last_date = '';
  $rowspan_use = array();

  query_data(date("Y-m",strtotime($select_date.'-'.$i_bigloop.' month')),$host_ip); // Query Data By [First Date - Last Date] of Previous Month

?>

<!-- SHOW EMAIL PART -->
<?php
  ////////// WRITE HEADER //////////
$email_body="<html xmlns:v=\"urn:schemas-microsoft-com:vml\" xmlns:o=\"urn:schemas-microsoft-com:office:office\" xmlns:w=\"urn:schemas-microsoft-com:office:word\" xmlns:x=\"urn:schemas-microsoft-com:office:excel\" xmlns:m=\"http://schemas.microsoft.com/office/2004/12/omml\" xmlns=\"http://www.w3.org/TR/REC-html40\">
   <head>
      <META HTTP-EQUIV=\"Content-Type\" CONTENT=\"text/html; charset=us-ascii\">
      <meta name=ProgId content=Word.Document>
      <meta name=Generator content=\"Microsoft Word 14\">
      <meta name=Originator content=\"Microsoft Word 14\">
      <link rel=File-List href=\"cid:filelist.xml@01D37D9A.02CE33A0\">
      <link rel=themeData href=\"~~themedata~~\">
      <link rel=colorSchemeMapping href=\"~~colorschememapping~~\">
      <style>
         <!--
            /* Font Definitions */
            @font-face
              {font-family:\"Cordia New\";
              panose-1:2 11 3 4 2 2 2 2 2 4;
              mso-font-charset:0;
              mso-generic-font-family:swiss;
              mso-font-pitch:variable;
              mso-font-signature:-2130706429 0 0 0 65537 0;}
            @font-face
              {font-family:\"Cordia New\";
              panose-1:2 11 3 4 2 2 2 2 2 4;
              mso-font-charset:0;
              mso-generic-font-family:swiss;
              mso-font-pitch:variable;
              mso-font-signature:-2130706429 0 0 0 65537 0;}
            @font-face
              {font-family:Calibri;
              panose-1:2 15 5 2 2 2 4 3 2 4;
              mso-font-charset:0;
              mso-generic-font-family:swiss;
              mso-font-pitch:variable;
              mso-font-signature:-536859905 -1073732485 9 0 511 0;}
            @font-face
              {font-family:Tahoma;
              panose-1:2 11 6 4 3 5 4 4 2 4;
              mso-font-charset:0;
              mso-generic-font-family:swiss;
              mso-font-pitch:variable;
              mso-font-signature:-520081665 -1073717157 41 0 66047 0;}
            /* Style Definitions */
            p.MsoNormal, li.MsoNormal, div.MsoNormal
              {mso-style-unhide:no;
              mso-style-qformat:yes;
              mso-style-parent:\"\";
              margin:0cm;
              margin-bottom:.0001pt;
              mso-pagination:widow-orphan;
              font-size:11.0pt;
              mso-bidi-font-size:14.0pt;
              font-family:\"Calibri\",\"sans-serif\";
              mso-ascii-font-family:Calibri;
              mso-ascii-theme-font:minor-latin;
              mso-fareast-font-family:Calibri;
              mso-fareast-theme-font:minor-latin;
              mso-hansi-font-family:Calibri;
              mso-hansi-theme-font:minor-latin;
              mso-bidi-font-family:\"Cordia New\";
              mso-bidi-theme-font:minor-bidi;}
            a:visited, span.MsoHyperlinkFollowed
              {mso-style-noshow:yes;
              mso-style-priority:99;
              color:purple;
              mso-themecolor:followedhyperlink;
              text-decoration:underline;
              text-underline:single;}
            span.17
              {mso-style-type:personal-compose;
              mso-style-noshow:yes;
              mso-style-unhide:no;
              mso-ansi-font-size:11.0pt;
              mso-bidi-font-size:14.0pt;
              font-family:\"Calibri\",\"sans-serif\";
              mso-ascii-font-family:Calibri;
              mso-ascii-theme-font:minor-latin;
              mso-fareast-font-family:Calibri;
              mso-fareast-theme-font:minor-latin;
              mso-hansi-font-family:Calibri;
              mso-hansi-theme-font:minor-latin;
              mso-bidi-font-family:\"Cordia New\";
              mso-bidi-theme-font:minor-bidi;
              color:windowtext;}
            .MsoChpDefault
              {mso-style-type:export-only;
              mso-default-props:yes;
              font-family:\"Calibri\",\"sans-serif\";
              mso-ascii-font-family:Calibri;
              mso-ascii-theme-font:minor-latin;
              mso-fareast-font-family:Calibri;
              mso-fareast-theme-font:minor-latin;
              mso-hansi-font-family:Calibri;
              mso-hansi-theme-font:minor-latin;
              mso-bidi-font-family:\"Cordia New\";
              mso-bidi-theme-font:minor-bidi;}
            @page WordSection1
              {size:612.0pt 792.0pt;
              margin:72.0pt 72.0pt 72.0pt 72.0pt;
              mso-header-margin:36.0pt;
              mso-footer-margin:36.0pt;
              mso-paper-source:0;}
            div.WordSection1
              {page:WordSection1;}
            -->
      </style>
   </head>
   <body lang=EN-US link=blue vlink=purple style='tab-interval:36.0pt'>
      <div class=WordSection1>
         <table class=MsoNormalTable border=0 cellspacing=0 cellpadding=0 width=1137 style='width:852.8pt;margin-left:-1.15pt;border-collapse:collapse;mso-yfti-tbllook:1184;mso-padding-alt:0cm 5.4pt 0cm 5.4pt'>
            
            <!-- MONTH HEADER-->
            <tr style='mso-yfti-irow:0;mso-yfti-firstrow:yes;height:30pt'>
              <td colspan=28 style='width:118.0pt;border-top:windowtext;border-left:windowtext;border-bottom:black;border-right:black;border-style:solid;border-width:1.0pt;mso-border-top-alt:windowtext;mso-border-left-alt:windowtext;mso-border-bottom-alt:black;mso-border-right-alt:black;mso-border-style-alt:solid;mso-border-width-alt:.5pt;background:lime;padding:0cm 5.4pt 0cm 5.4pt;height:14.25pt'>
                  <p class=MsoNormal align=center style='text-align:center'>
                     <b>
                        <span style='mso-bidi-font-size:11.0pt;font-family:\"Tahoma\",\"sans-serif\";mso-fareast-font-family:\"Times New Roman\";color:black'>
                           ".date("F Y",strtotime($select_date.'-'.$i_bigloop.' month'))."
                           <o:p></o:p>
                        </span>
                     </b>
                  </p>
               </td>
            </tr>

            <tr style='mso-yfti-irow:0;mso-yfti-firstrow:yes;height:14.25pt'>
            <!-- DATE LABEL-->
               <td width=157 colspan=2 rowspan=2 style='width:118.0pt;border-top:windowtext;border-left:windowtext;border-bottom:black;border-right:black;border-style:solid;border-width:1.0pt;mso-border-top-alt:windowtext;mso-border-left-alt:windowtext;mso-border-bottom-alt:black;mso-border-right-alt:black;mso-border-style-alt:solid;mso-border-width-alt:.5pt;background:#DCE6F1;padding:0cm 5.4pt 0cm 5.4pt;height:14.25pt'>
                  <p class=MsoNormal align=center style='text-align:center'>
                     <b>
                        <span style='mso-bidi-font-size:11.0pt;font-family:\"Tahoma\",\"sans-serif\";mso-fareast-font-family:\"Times New Roman\";color:black'>
                           Date
                           <o:p></o:p>
                        </span>
                     </b>
                  </p>
               </td>

            <!-- TIME HOUR LABEL-->
               <td width=836 colspan=24 style='width:626.8pt;border-top:solid windowtext 1.0pt;border-left:none;border-bottom:solid windowtext 1.0pt;border-right:solid black 1.0pt;mso-border-top-alt:solid windowtext .5pt;mso-border-bottom-alt:solid windowtext .5pt;mso-border-right-alt:solid black .5pt;background:#DCE6F1;padding:0cm 5.4pt 0cm 5.4pt;height:14.25pt'>
                  <p class=MsoNormal align=center style='text-align:center'>
                     <b>
                        <span style='mso-bidi-font-size:11.0pt;font-family:\"Tahoma\",\"sans-serif\";mso-fareast-font-family:\"Times New Roman\";color:black'>
                           Time (Hour)
                           <o:p></o:p>
                        </span>
                     </b>
                  </p>
               </td>

            <!-- TOTAL CHECKPOINT NOT COMPLETE LABEL-->
               <td width=144 colspan=1 style='width:108.0pt;border:solid windowtext 1.0pt;border-left:none;mso-border-top-alt:solid windowtext .5pt;mso-border-bottom-alt:solid windowtext .5pt;mso-border-right-alt:solid windowtext .5pt;background:#DCE6F1;padding:0cm 5.4pt 0cm 5.4pt;height:14.25pt'>
                  <p class=MsoNormal align=center style='text-align:center'>
                     <b>
                        <span style='mso-bidi-font-size:11.0pt;font-family:\"Tahoma\",\"sans-serif\";mso-fareast-font-family:\"Times New Roman\";color:black'>
                           Total Checkpoint Not Complete
                           <o:p></o:p>
                        </span>
                     </b>
                  </p>
               </td>
            </tr>
            <tr style='mso-yfti-irow:1;height:14.25pt'>";

        // WRITE TIME HOUR LABEL [00-23]
        for($i=0;$i<24;$i++){
$email_body.="<td width=35 style='width:26.0pt;border-top:none;border-left:none;border-bottom:solid windowtext 1.0pt;border-right:solid windowtext 1.0pt;mso-border-bottom-alt:solid windowtext .5pt;mso-border-right-alt:solid windowtext .5pt;background:#DCE6F1;padding:0cm 5.4pt 0cm 5.4pt;height:14.25pt'>
                  <p class=MsoNormal align=center style='text-align:center'>
                     <b>
                        <span style='mso-bidi-font-size:11.0pt;font-family:\"Tahoma\",\"sans-serif\";mso-fareast-font-family:\"Times New Roman\";color:black'>
                           ".sprintf('%02d', $i)."
                           <o:p></o:p>
                        </span>
                     </b>
                  </p>
               </td>";
        }

$email_body.="
      <!-- TOTAL CHECKPOINT NOT COMPLETE LABEL [DB95] -->
<td width=72 nowrap style='width:54.0pt;border-top:none;border-left:none;border-bottom:solid windowtext 1.0pt;border-right:solid windowtext 1.0pt;mso-border-bottom-alt:solid windowtext .5pt;mso-border-right-alt:solid windowtext .5pt;background:#DCE6F1;padding:0cm 5.4pt 0cm 5.4pt;height:14.25pt'>
                  <p class=MsoNormal align=center style='text-align:center'>
                     <span style='mso-bidi-font-size:11.0pt;font-family:\"Tahoma\",\"sans-serif\";mso-fareast-font-family:\"Times New Roman\";color:black'>
                        DB95
                        <o:p></o:p>
                     </span>
                  </p>
               </td>
            </tr>";

    // LOOP FOR EACH DAY
    for($day=$last_date; $day >= $first_date; $day=date("Y-m-d", strtotime($day."-1 day")) ){
$email_body.="
      <!-- DAY ABBREVIATION -->
            <tr style='mso-yfti-irow:2;mso-yfti-lastrow:yes;height:14.25pt'>
               <td rowspan=".$max_rowspan[$day]." width=49 nowrap valign=top style='width:36.45pt;border:solid windowtext 1.0pt;border-top:none;mso-border-left-alt:solid windowtext .5pt;mso-border-bottom-alt:solid windowtext .5pt;mso-border-right-alt:solid windowtext .5pt;background:".get_day_color(date("D", strtotime($day))).";padding:0cm 5.4pt 0cm 5.4pt;height:14.25pt'>
                  <p class=MsoNormal>
                     <span style='font-size:10.0pt;font-family:\"Tahoma\",\"sans-serif\";mso-fareast-font-family:\"Times New Roman\";color:black'>
                        ".date("D", strtotime($day))."
                        <o:p></o:p>
                     </span>
                  </p>
               </td>

            <!-- DATE -->
               <td rowspan=".$max_rowspan[$day]." width=109 nowrap valign=top style='width:81.55pt;border-top:none;border-left:none;border-bottom:solid windowtext 1.0pt;border-right:solid windowtext 1.0pt;mso-border-bottom-alt:solid windowtext .5pt;mso-border-right-alt:solid windowtext .5pt;background:".get_day_color(date("D", strtotime($day))).";padding:0cm 5.4pt 0cm 5.4pt;height:14.25pt'>
                  <p class=MsoNormal align=center style='text-align:center'>
                     <span style='font-size:10.0pt;font-family:\"Tahoma\",\"sans-serif\";mso-fareast-font-family:\"Times New Roman\";color:black'>
                        ".date("d-M-y", strtotime($day))."
                        <o:p></o:p>
                     </span>
                  </p>
               </td>";

// LOOP EVERY HOUR [1ST ROUND]
for($i=0;$i<24;$i++){

  // No Checkpoint On This Day
  if($total_db95[$day]==0){
    $email_body.="     
               <td width=35 style='width:26.0pt;border-top:none;border-left:none;border-bottom:solid windowtext 1.0pt;border-right:solid windowtext 1.0pt;mso-border-bottom-alt:solid windowtext .5pt;mso-border-right-alt:solid windowtext .5pt;background:#bfbfbf;padding:0cm 5.4pt 0cm 5.4pt;height:14.25pt'>
                  <p class=MsoNormal align=center style='text-align:center'>
                     <b>
                        <span style='mso-bidi-font-size:11.0pt;font-family:\"Tahoma\",\"sans-serif\";mso-fareast-font-family:\"Times New Roman\";color:black'>
                           &nbsp;
                           <o:p></o:p>
                        </span>
                     </b>
                  </p>
               </td>";
  }

  // Found Checkpoint Not Complete On This Day
  else {
    if($max_rowspan[$day]>1){
      // Max Rowspan > 1

      // Found Checkpoint On DB95 
      if($db95_count[$day][$i]!=0){
        $email_body.="     
               <td rowswidth=35 style='width:26.0pt;border-top:none;border-left:none;border-bottom:solid windowtext 1.0pt;border-right:solid windowtext 1.0pt;mso-border-bottom-alt:solid windowtext .5pt;mso-border-right-alt:solid windowtext .5pt;background:#b8cce4;padding:0cm 5.4pt 0cm 5.4pt;height:14.25pt'>
                  <p class=MsoNormal align=center style='text-align:center'>
                     <b>
                        <span style='mso-bidi-font-size:11.0pt;font-family:\"Tahoma\",\"sans-serif\";mso-fareast-font-family:\"Times New Roman\";color:black'>
                           DB95
                           <o:p></o:p>
                        </span>
                     </b>
                  </p>
               </td>";
                $db95_count[$day][$i]--;
                $rowspan_use[$day][$i]=true;
                goto end_hour_loop;
      }
      


      // No Checkpoint Not Complete [Use Max Rowspan] 
      if($db95_count[$day][$i]==0){
        $email_body.="     
               <td rowspan=".$max_rowspan[$day]." rowswidth=35 style='width:26.0pt;border-top:none;border-left:none;border-bottom:solid windowtext 1.0pt;border-right:solid windowtext 1.0pt;mso-border-bottom-alt:solid windowtext .5pt;mso-border-right-alt:solid windowtext .5pt;padding:0cm 5.4pt 0cm 5.4pt;height:14.25pt'>
                  <p class=MsoNormal align=center style='text-align:center'>
                     <b>
                        <span style='mso-bidi-font-size:11.0pt;font-family:\"Tahoma\",\"sans-serif\";mso-fareast-font-family:\"Times New Roman\";color:black'>
                           &nbsp
                           <o:p></o:p>
                        </span>
                     </b>
                  </p>
               </td>";
               $rowspan_use[$day][$i]=false;
      }
    }
    else{
      // Max Rowspan = 1 [Finish In One Round]

      // Found Checkpoint On DB95 
      if($db95_count[$day][$i]==1){
        $email_body.="     
               <td rowswidth=35 style='width:26.0pt;border-top:none;border-left:none;border-bottom:solid windowtext 1.0pt;border-right:solid windowtext 1.0pt;mso-border-bottom-alt:solid windowtext .5pt;mso-border-right-alt:solid windowtext .5pt;background:#b8cce4;padding:0cm 5.4pt 0cm 5.4pt;height:14.25pt'>
                  <p class=MsoNormal align=center style='text-align:center'>
                     <b>
                        <span style='mso-bidi-font-size:11.0pt;font-family:\"Tahoma\",\"sans-serif\";mso-fareast-font-family:\"Times New Roman\";color:black'>
                           DB95
                           <o:p></o:p>
                        </span>
                     </b>
                  </p>
               </td>";
                $db95_count[$day][$i]--;
                goto end_hour_loop;
      }
      

      // No Checkpoint Not Complete   
      if($db95_count[$day][$i]==0){
        $email_body.="     
               <td rowswidth=35 style='width:26.0pt;border-top:none;border-left:none;border-bottom:solid windowtext 1.0pt;border-right:solid windowtext 1.0pt;mso-border-bottom-alt:solid windowtext .5pt;mso-border-right-alt:solid windowtext .5pt;padding:0cm 5.4pt 0cm 5.4pt;height:14.25pt'>
                  <p class=MsoNormal align=center style='text-align:center'>
                     <b>
                        <span style='mso-bidi-font-size:11.0pt;font-family:\"Tahoma\",\"sans-serif\";mso-fareast-font-family:\"Times New Roman\";color:black'>
                           &nbsp
                           <o:p></o:p>
                        </span>
                     </b>
                  </p>
               </td>";
      }
    }
  }
  end_hour_loop:
} // END LOOP HOUR



  if($total_db95[$day]==0){
    // No Checkpoint Found On DB95
    $email_body.=" 
      <!-- DB95: TOTAL CHECKPOINT NOT COMPLETE -->
               <td rowspan=".$max_rowspan[$day]." width=72 nowrap style='width:54.0pt;border-top:none;border-left:none;border-bottom:solid windowtext 1.0pt;border-right:solid windowtext 1.0pt;mso-border-bottom-alt:solid windowtext .5pt;mso-border-right-alt:solid windowtext .5pt;padding:0cm 5.4pt 0cm 5.4pt;height:14.25pt'>
                  <p class=MsoNormal align=center style='text-align:center'>
                     <span style='font-size:10.0pt;font-family:\"Tahoma\",\"sans-serif\";mso-fareast-font-family:\"Times New Roman\";color:black'>
                        &nbsp;
                        <o:p></o:p>
                     </span>
                  </p>
               </td>";
    }
    else {
    $email_body.=" 
      <!-- DB95: TOTAL CHECKPOINT NOT COMPLETE -->
               <td rowspan=".$max_rowspan[$day]." width=72 nowrap style='width:54.0pt;border-top:none;border-left:none;border-bottom:solid windowtext 1.0pt;border-right:solid windowtext 1.0pt;mso-border-bottom-alt:solid windowtext .5pt;mso-border-right-alt:solid windowtext .5pt;background:#ff6666;padding:0cm 5.4pt 0cm 5.4pt;height:14.25pt'>
                  <p class=MsoNormal align=center style='text-align:center'>
                     <span style='font-size:10.0pt;font-family:\"Tahoma\",\"sans-serif\";mso-fareast-font-family:\"Times New Roman\";color:black'>
                        ".$total_db95[$day]."
                        <o:p></o:p>
                     </span>
                  </p>
               </td>";
    }


  // Close Line
  $email_body.="</tr>";

    // LOOP UNTIL CHECKPOINT NOT COMPLETE EMPTY
    if($max_rowspan[$day]>1){
      $rowspan_count=0;
      while($max_rowspan[$day]!=$rowspan_count+1){
        $email_body.="<tr>";
        for($i=0;$i<24;$i++){
        // Found Checkpoint On DB95
        if($db95_count[$day][$i]!=0 || $db95_count[$day][$i]!=null){
          $email_body.="     
                 <td rowswidth=35 style='width:26.0pt;border-top:none;border-left:none;border-bottom:solid windowtext 1.0pt;border-right:solid windowtext 1.0pt;mso-border-bottom-alt:solid windowtext .5pt;mso-border-right-alt:solid windowtext .5pt;background:#b8cce4;padding:0cm 5.4pt 0cm 5.4pt;height:14.25pt'>
                    <p class=MsoNormal align=center style='text-align:center'>
                       <b>
                          <span style='mso-bidi-font-size:11.0pt;font-family:\"Tahoma\",\"sans-serif\";mso-fareast-font-family:\"Times New Roman\";color:black'>
                             DB95
                             <o:p></o:p>
                          </span>
                       </b>
                    </p>
                 </td>";
                  $db95_count[$day][$i]--;
                  goto end_until_empty_loop;
        }
        
        
        if($db95_count[$day][$i]==0 && $rowspan_use[$day][$i]==true) {
          // Write Empty Cell
          $email_body.="     
                 <td rowswidth=35 style='width:26.0pt;border-top:none;border-left:none;border-bottom:solid windowtext 1.0pt;border-right:solid windowtext 1.0pt;mso-border-bottom-alt:solid windowtext .5pt;mso-border-right-alt:solid windowtext .5pt;padding:0cm 5.4pt 0cm 5.4pt;height:14.25pt'>
                    <p class=MsoNormal align=center style='text-align:center'>
                       <b>
                          <span style='mso-bidi-font-size:11.0pt;font-family:\"Tahoma\",\"sans-serif\";mso-fareast-font-family:\"Times New Roman\";color:black'>
                             &nbsp
                             <o:p></o:p>
                          </span>
                       </b>
                    </p>
                 </td>";
        }
        end_until_empty_loop:
        } // END LOOP UNTIL CHECKPOINT NOT COMPLETE EMPTY
        $email_body.="</tr>";
        $rowspan_count++;
      } // END WHILE
  } // END IF
} // END LOOP FOR EACH DAY


// EMAIL SIGNATURE
$email_body.="
         </table>
      </div>
    </body>
  </html>";

?>

<!-- TABLE PART -->
<div class="row">
  <div style="margin-left:50px" class="col-sm-12"><?php echo $email_body;?></div>
</div>
<br>
<br>


<!-- END TABLE PART -->



<!-- END BIG MONTH LOOP --><!-- END BIG MONTH LOOP --><!-- END BIG MONTH LOOP -->
<!-- END BIG MONTH LOOP --><!-- END BIG MONTH LOOP --><!-- END BIG MONTH LOOP -->
<!-- END BIG MONTH LOOP --><!-- END BIG MONTH LOOP --><!-- END BIG MONTH LOOP -->
<?php 
      }
?>
<!-- END BIG MONTH LOOP --><!-- END BIG MONTH LOOP --><!-- END BIG MONTH LOOP -->
<!-- END BIG MONTH LOOP --><!-- END BIG MONTH LOOP --><!-- END BIG MONTH LOOP -->
<!-- END BIG MONTH LOOP --><!-- END BIG MONTH LOOP --><!-- END BIG MONTH LOOP -->



<script>
    $(document).ready(function(){
      var date_input=$('input[name="date"]'); //our date input has the name "date"
      var container=$('.bootstrap-iso form').length>0 ? $('.bootstrap-iso form').parent() : "body";
      var options={
        format: 'M-yyyy',
        startView: "months", 
        minViewMode: "months",
        container: container,
        todayHighlight: true,
        autoclose: true,
      };
      date_input.datepicker(options);
    })
</script>