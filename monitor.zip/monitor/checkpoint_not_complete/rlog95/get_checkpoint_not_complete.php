<?php

// ini_set('display_errors', 1);
// ini_set('display_startup_errors', 1);
// error_reporting(E_ALL);

date_default_timezone_set("Asia/Bangkok"); 



	include('Net/SSH2.php');

	$checkpoint_count_95=0;
	$checkpoint_detail_95="";
	$time_seq_95="";
	$host_ip="10.11.11.95";
	$file_path="/u01/oracle/diag/rdbms/rlog2/RLOG2/trace/alert_RLOG2.log";

	if(isset($_GET['date'])){

		if($_GET['date']=='today')
			$select_date=date('d-m-Y');
		elseif($_GET['date']=='yesterday')
			$select_date=date('d-m-Y',strtotime(date('d-m-Y')." -1 day"));
		else
			$select_date=$_GET['date'];


		//Show Date
		echo "DATE=".$select_date."<br>";

		if($select_date==date('d-m-Y'))
			echo "LOG FOR TODAY DAY STILL NOT COMPLETE"."<br>";

		echo "<br>";


		// ===== 10.11.11.95 =====
		set_include_path(get_include_path() . PATH_SEPARATOR . 'phpseclib');
		$server = "10.11.11.95";
		$username = "root";
		$password = "@rlogadmin123";


		$ssh = new Net_SSH2($server);
		if (!$ssh->login($username, $password))
			    echo 'Login Failed';


		$start_date=date("Y-m-d", strtotime($select_date));
		$end_date=date("Y-m-d", strtotime($select_date." +1 day"));

		$start_line_number=$ssh->exec('grep -e "'.$start_date.'T" -m 1 -n  '.$file_path)."<br>";
		$start_line_number = substr($start_line_number,0,strpos($start_line_number, ":")); 

		$end_line_number=$ssh->exec('grep -e "'.$end_date.'T" -m 1 -n  '.$file_path)."<br>";
		$end_line_number = substr($end_line_number,0,strpos($end_line_number, ":"))-1; 


		if($start_line_number==null){
			$checkpoint_count_95='Not Found';
			echo "DB95 LOG NOT FOUND"."<br>";
			echo "<br>";
		}
		else {
			// If $end_line_number=-1 => Current Date
			if($end_line_number==-1){
				// Select Date = Current Date
				$get_line=$ssh->exec("sed -n '".$start_line_number.",\$p' ".$file_path)."<br>";
			}
			else {
				$get_line=$ssh->exec('sed -n '.$start_line_number.','.$end_line_number.'p '.$file_path)."<br>";
			}

			$get_line= str_replace("\n","<br>",$get_line);




			if(substr_count($get_line, 'Checkpoint not complete') != 0) {
    			$checkpoint_count_95=substr_count($get_line, 'Checkpoint not complete');
    			// Get Checkpoint Not Complete Detail
    			$get_line_tmp=$get_line;
    			$log_detail='';
    			$checkpoint_detail_95='';

    			while($get_line_tmp!=''){
    				$string_line=str_replace('<br>', '', substr($get_line_tmp,0,strpos($get_line_tmp, "<br>")));

    				/*if (date('Y-m-d H:i:s', substr($string_line,0,10)) !== FALSE) {
  						echo $string_line.'<br>';
					}*/

					$dateline=substr_count($string_line,"-",0);

    				// Check is a date line ?
    				if($dateline==2){
    					$dateformat=substr($string_line,0,10).' '.substr($string_line,11,8);
    					if($log_detail==''){
    						// Start New Log Detail
    						$log_detail="<b>".date('D M d H:i:s Y', strtotime($dateformat))."</b>"."<br>";
    						//echo 'LOG='.substr($string_line,0,10);
    					}
    					else{
    						// Printout Log => Begin New Log Detail
    						// Check is a log contain Checkpoint Not Complete ?
    						if (strpos($log_detail, 'Checkpoint not complete') == true) {
    							// Print Only Line Contain 'Thread 1 cannot allocate new log, sequence XXXXX'
    							$date_log=substr($log_detail,0,strpos($log_detail,'</b><br>'))."</b>";
    							$time_seq_95.=$date_log;
    							$log_part=substr($log_detail,strpos($log_detail,'<br>Thread 1 cannot allocate new log, sequence '),strpos($log_detail,'Checkpoint not complete')-strpos($log_detail,'<br>Thread 1 cannot allocate new log, sequence '));
    							$checkpoint_detail_95.=$date_log.$log_part."#!CNC!#<br>";
    							$checkpoint_detail_95=str_replace("Thread 1 cannot allocate new log, sequence ","#!T1!#",$checkpoint_detail_95);
							}	  							
    						$log_detail="<b>".date('D M d H:i:s Y', strtotime($dateformat))."</b>"."<br>";
    					}
    				}
					else {
						$log_detail.=$string_line."<br>";
					}

					$get_line_tmp=preg_replace('/'.preg_quote($string_line."<br>", '/').'/', '', $get_line_tmp, 1);
				}


			}
			else {
				//Do Nothing
			}


			echo "DB95 COUNT=".$checkpoint_count_95."<br>";
			echo "DB95 DETAIL=".$checkpoint_detail_95."<br>";
			if ($checkpoint_count_95==0)
				echo "<br>";

				
		}




		//Insert To DB & Write Weekly Report Log
		if($checkpoint_count_95!=0){
			insert_to_db($select_date,$checkpoint_count_95,$checkpoint_detail_95,$host_ip);		
			write_weekly_report($select_date,$checkpoint_count_95,$checkpoint_detail_95,$time_seq_95);	
		}
		else{
			write_weekly_report($select_date,0,null,null);
		}
		

    }
    else {
    	// No Date Input
    	echo "NO DATE INPUT"."<br>";
    	echo "EXAMPLE URL: http://10.11.30.59/fifa_script/checkpoint_not_complete/rlog95/get_checkpoint_not_complete.php?date=05-05-2016 OR ?date=today";
    	// End PHP
    }



   		//Write Log File
    	$show_today_yesterday='[User Defined]';
    	if($_GET['date']=='today')
    		$show_today_yesterday='[Today]';
    	if($_GET['date']=='yesterday')
    		$show_today_yesterday='[Yesterday]';

    	$txt="[Timestamp: ".date('d-m-Y H:i:s')."]"."[Select Date: ".$select_date."]".$show_today_yesterday." DB95-Count:".$checkpoint_count_95;
		$log_file = fopen('/var/www/html/fifa_script/checkpoint_not_complete/rlog95/get_checkpoint_not_complete.log', 'a');
		fwrite($log_file,$txt."\n");
		fclose($log_file);



	function write_weekly_report($select_date,$checkpoint_count_95,$checkpoint_detail_95,$time_seq_95){

	//Write Yesterday Log Only!!!
	if($_GET['date']=='yesterday'){
		if($checkpoint_count_95==0&&$checkpoint_detail_95==null&&$time_seq_95==null){
			//No Checkpoint Not Complete [DB1 & DB2]
			$txt="[".$select_date."][DB95=0][null]";
		}
		else{
			//Found Checkpoint Not Complete
			$time_seq_95=str_replace("</b><b>", ",", $time_seq_95);
			$time_seq_95=str_replace("<b>", "", $time_seq_95);
			$time_seq_95=str_replace("</b>", "", $time_seq_95).",";

			$time_seq_95_tmp='';
			
			if($time_seq_95==','){$time_seq_95_tmp="null";}
			else{
				while($time_seq_95!=''){
					$time_seq_95_tmp.=date('G:i',strtotime(substr($time_seq_95,0,strpos($time_seq_95, ",")))).",";
					$time_seq_95=str_replace(substr($time_seq_95,0,strpos($time_seq_95, ",")).",","",$time_seq_95);
				}
			// Remove Last Comma
			$time_seq_95_tmp=substr($time_seq_95_tmp, 0, -1);
			}


			$txt="[".$select_date."][DB95=".$checkpoint_count_95."][".$time_seq_95_tmp."]";
		}

		//Read Old Data From Text File
		$text_tmp='';
		$fh = fopen('/var/www/html/fifa_script/checkpoint_not_complete/rlog95/weekly_report.log','r');
		while ($line = fgets($fh)) {
  			$text_tmp.=$line;
		}
		fclose($fh);

		//Combine New & Old
		$text_tmp=$txt."\n".$text_tmp;

		//Write Log File
		$log_file = fopen('/var/www/html/fifa_script/checkpoint_not_complete/rlog95/weekly_report.log', 'w');
		fwrite($log_file,$text_tmp);
		fclose($log_file);

	}
	}



    function insert_to_db($select_date,$checkpoint_count_95,$checkpoint_detail_95,$host_ip){
    	$select_date=date("Y-m-d", strtotime($select_date));
    	echo "<br>";
    	$con = mysqli_connect("10.11.30.59","root","1qazxsw2@3BB");
			mysqli_set_charset($con, "utf8");
			if (!$con) {
		    die("Database connection failed: " . mysqli_error());
			}

			$db_select = mysqli_select_db($con, "monitor");
			if (!$db_select) {
		    	die("Database selection failed: " . mysqli_error());
			}



            $sql = "INSERT INTO checkpoint_not_complete (checkpoint_date,db_host,db_count,db_detail) VALUES
            ('".$select_date."','".$host_ip."','".$checkpoint_count_95."','".$checkpoint_detail_95."') ON DUPLICATE KEY UPDATE db_count='".$checkpoint_count_95."', db_detail='".$checkpoint_detail_95."',db_host='".$host_ip."';";

			if(mysqli_query($con, $sql)){
    			echo "INSERT OR UPDATE DATA TO DB SUCCESSFULLY";
			} else{
    			echo "INSERT OR UPDATE DATA TO DB FAILED => ".mysqli_error($link);
			} 
    }

    
    // Use This Part For Loop Collect All
    /*$next_date=date('d-m-Y', strtotime($select_date." +1 day"));
    if($next_date==date('16-08-2019')){
    	// Stop Redirect
    	echo "<br>"."FINISHED !!!";
    }
    else{
    	echo "<br>"."GO TO NEXT DATE...";
    	header('Refresh: 8; URL=http://10.11.30.59/fifa_script/checkpoint_not_complete/rlog95/get_checkpoint_not_complete.php?date='.$next_date);
    	exit;
    }*/
    
?>