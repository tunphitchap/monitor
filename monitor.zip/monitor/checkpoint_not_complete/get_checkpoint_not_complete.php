<?php
        include('Net/SSH2.php');

        $checkpoint_count_171=0;
        $checkpoint_count_172=0;
        $checkpoint_detail_171="";
        $checkpoint_detail_172="";
        $time_seq_171="";
        $time_seq_172="";

        if(isset($_GET['date'])){

                if($_GET['date']=='today')
                        $select_date=date('d-m-Y');
                elseif($_GET['date']=='yesterday')
                        $select_date=date('d-m-Y',strtotime(date('d-m-Y')." -1 day"));
                else
                        $select_date=$_GET['date'];


                //Show Date
                echo "DATE=".$select_date."<br>";

                if($select_date==date('d-m-Y'))
                        echo "LOG FOR TODAY DAY STILL NOT COMPLETE"."<br>";

                echo "<br>";

                /* LOG ABV.
                #!T1!# = Thread 1 cannot allocate new log, sequence 
                #!T2!# = Thread 2 cannot allocate new log, sequence 
                #!CNC!# = Checkpoint not complete
                */

                // ===== 10.11.11.171 =====
                set_include_path(get_include_path() . PATH_SEPARATOR . 'phpseclib');
                $server = "10.11.11.171";
                $username = "root";
                $password = "123456";

                $ssh = new Net_SSH2($server);
                if (!$ssh->login($username, $password))
                            exit('Login Failed');

                $start_date=date("D M d", strtotime($select_date));
                $start_date_year=date("Y", strtotime($select_date));
                $end_date=date("D M d", strtotime($select_date." +1 day"));
                $end_date_year=date("Y", strtotime($select_date." +1 day"));

                //$start_line_number=$ssh->exec('grep -e "'.$start_date.'" -m 1 -n  /software/app/oracle/diag/rdbms/radius/radius1/trace/alert_radius1.log | grep "'.$start_date_year.'"')."<br>";
                $start_line_number=$ssh->exec('cat /software/app/oracle/diag/rdbms/radius/radius1/trace/alert_radius1.log | grep -e "'.$start_date.'" -n | grep "'.$start_date_year.'" -m 1')."<br>";

                $start_line_number = substr($start_line_number,0,strpos($start_line_number, ":")); 

                //$end_line_number=$ssh->exec('grep -e "'.$end_date.'" -m 1 -n  /software/app/oracle/diag/rdbms/radius/radius1/trace/alert_radius1.log | grep "'.$end_date_year.'"')."<br>";
                $end_line_number=$ssh->exec('cat /software/app/oracle/diag/rdbms/radius/radius1/trace/alert_radius1.log | grep -e "'.$end_date.'" -n | grep "'.$end_date_year.'" -m 1')."<br>";

                $end_line_number = substr($end_line_number,0,strpos($end_line_number, ":"))-1; 

                if($start_line_number==null){
                        $checkpoint_count_171='Not Found';
                        echo "DB1 LOG NOT FOUND"."<br>";
                        echo "<br>";
                }
                else {
                        // If $end_line_number=-1 => Current Date
                        if($end_line_number==-1){
                                // Select Date = Current Date
                                $get_line=$ssh->exec("sed -n '".$start_line_number.",\$p' /software/app/oracle/diag/rdbms/radius/radius1/trace/alert_radius1.log")."<br>";
                        }
                        else {
                                $get_line=$ssh->exec('sed -n '.$start_line_number.','.$end_line_number.'p /software/app/oracle/diag/rdbms/radius/radius1/trace/alert_radius1.log')."<br>";
                        }

                        $get_line= str_replace("\n","<br>",$get_line);

                        if(substr_count($get_line, 'Checkpoint not complete') != 0) {
                        $checkpoint_count_171=substr_count($get_line, 'Checkpoint not complete');
                        // Get Checkpoint Not Complete Detail
                        $get_line_tmp=$get_line;
                        $log_detail='';
                        $checkpoint_detail_171='';

                        while($get_line_tmp!=''){
                                $string_line=str_replace('<br>', '', substr($get_line_tmp,0,strpos($get_line_tmp, "<br>")));

                                // Check is a date line ?
                                if($string_line == date('D M d H:i:s Y',strtotime($string_line))){
                                        if($log_detail==''){
                                                // Start New Log Detail
                                                $log_detail="<b>".$string_line."</b>"."<br>";
                                        }
                                        else{
                                                // Printout Log => Begin New Log Detail
                                                // Check is a log contain Checkpoint Not Complete ?
                                                if (strpos($log_detail, 'Checkpoint not complete') == true) {
                                                        // Print Only Line Contain 'Thread 1 cannot allocate new log, sequence XXXXX'
    
                                                        $date_log=substr($log_detail,0,strpos($log_detail,'</b><br>'))."</b>";
                                                        $time_seq_171.=$date_log;
                                                        $log_part=substr($log_detail,strpos($log_detail,'<br>Thread 1 cannot allocate new log, sequence '),strpos($log_detail,'Checkpoint not complete')-strpos($log_detail,'<br>Thread 1 cannot allocate new log, sequence '));
                                                        $checkpoint_detail_171.=$date_log.$log_part."#!CNC!#<br>";
                                                        $checkpoint_detail_171=str_replace("Thread 1 cannot allocate new log, sequence ","#!T1!#",$checkpoint_detail_171);
                                                        }         
                                                $log_detail="<b>".$string_line."</b>"."<br>";
                                        }
                                }
                                        else {
                                                $log_detail.=$string_line."<br>";
                                        }

                                        $get_line_tmp=preg_replace('/'.preg_quote($string_line."<br>", '/').'/', '', $get_line_tmp, 1);
                                }
                        }
                        else {
                                //Do Nothing
                        }
                        echo "DB1 COUNT=".$checkpoint_count_171."<br>";
                        echo "DB1 DETAIL=".$checkpoint_detail_171."<br>";
                        if ($checkpoint_count_171==0)
                                echo "<br>";
                }



                // ===== 10.11.11.172 =====
                set_include_path(get_include_path() . PATH_SEPARATOR . 'phpseclib');
                $server = "10.11.11.172";
                $username = "root";
                $password = "123456";

                $ssh = new Net_SSH2($server);
                if (!$ssh->login($username, $password))
                        exit('Login Failed');

                $start_date=date("D M d", strtotime($select_date));
                $start_date_year=date("Y", strtotime($select_date));
                $end_date=date("D M d", strtotime($select_date." +1 day"));
                $end_date_year=date("Y", strtotime($select_date." +1 day"));

                //$start_line_number=$ssh->exec('grep -e "'.$start_date.'" -m 1 -n  /software/app/oracle/diag/rdbms/radius/radius2/trace/alert_radius2.log | grep "'.$start_date_year.'"')."<br>";
                $start_line_number=$ssh->exec('cat /software/app/oracle/diag/rdbms/radius/radius2/trace/alert_radius2.log | grep -e "'.$start_date.'" -n | grep "'.$start_date_year.'" -m 1')."<br>";
                $start_line_number = substr($start_line_number,0,strpos($start_line_number, ":")); 

                //$end_line_number=$ssh->exec('grep -e "'.$end_date.'" -m 1 -n  /software/app/oracle/diag/rdbms/radius/radius2/trace/alert_radius2.log | grep "'.$end_date_year.'"')."<br>";
                $end_line_number=$ssh->exec('cat /software/app/oracle/diag/rdbms/radius/radius2/trace/alert_radius2.log | grep -e "'.$end_date.'" -n | grep "'.$end_date_year.'" -m 1')."<br>";
                $end_line_number = substr($end_line_number,0,strpos($end_line_number, ":"))-1; 


                if($start_line_number==null){
                        $checkpoint_count_172='Not Found';
                        echo "DB2 LOG NOT FOUND"."<br>";
                }
                else {
                        // If $end_line_number=-1 => Current Date
                        if($end_line_number==-1){
                                // Select Date = Current Date
                                $get_line=$ssh->exec("sed -n '".$start_line_number.",\$p' /software/app/oracle/diag/rdbms/radius/radius2/trace/alert_radius2.log")."<br>";
                        }
                        else {
                                $get_line=$ssh->exec('sed -n '.$start_line_number.','.$end_line_number.'p /software/app/oracle/diag/rdbms/radius/radius2/trace/alert_radius2.log')."<br>";
                        }

                        $get_line= str_replace("\n","<br>",$get_line);

                        if(substr_count($get_line, 'Checkpoint not complete') != 0) {
                        $checkpoint_count_172=substr_count($get_line, 'Checkpoint not complete');
                        // Get Checkpoint Not Complete Detail
                        $get_line_tmp=$get_line;
                        $log_detail='';

                        $checkpoint_detail_172='';

                        while($get_line_tmp!=''){
                                $string_line=str_replace('<br>', '', substr($get_line_tmp,0,strpos($get_line_tmp, "<br>")));

                                // Check is a date line ?
                                if($string_line == date('D M d H:i:s Y',strtotime($string_line))){
                                        if($log_detail==''){
                                                // Start New Log Detail
                                                $log_detail="<b>".$string_line."</b>"."<br>";
                                        }
                                        else{
                                                // Printout Log => Begin New Log Detail
                                                // Check is a log contain Checkpoint Not Complete ?
                                                if (strpos($log_detail, 'Checkpoint not complete') == true) {
                                                        // Print Only Line Contain 'Thread 2 cannot allocate new log, sequence XXXXX'
    
                                                        $date_log=substr($log_detail,0,strpos($log_detail,'</b><br>'))."</b>";
                                                        $time_seq_172.=$date_log;
                                                        $log_part=substr($log_detail,strpos($log_detail,'<br>Thread 2 cannot allocate new log, sequence '),strpos($log_detail,'Checkpoint not complete')-strpos($log_detail,'<br>Thread 2 cannot allocate new log, sequence '));
                                                        $checkpoint_detail_172.=$date_log.$log_part."#!CNC!#<br>";
                                                        $checkpoint_detail_172=str_replace("Thread 2 cannot allocate new log, sequence ","#!T2!#",$checkpoint_detail_172);
                                                        }         
                                                $log_detail="<b>".$string_line."</b>"."<br>";
                                        }
                                }
                                        else {
                                                $log_detail.=$string_line."<br>";
                                        }
                                        $get_line_tmp=preg_replace('/'.preg_quote($string_line."<br>", '/').'/', '', $get_line_tmp, 1);
                                }
                        }
                        else {
                                // Do Nothing
                        }
                        echo "DB2 COUNT=".$checkpoint_count_172."<br>";
                        echo "DB2 DETAIL=".$checkpoint_detail_172."<br>";
                }

                //Insert To DB & Write Weekly Report Log
                if($checkpoint_count_171!=0 || $checkpoint_count_172!=0){
                        insert_to_db($select_date,$checkpoint_count_171,$checkpoint_count_172,$checkpoint_detail_171,$checkpoint_detail_172);
                        write_weekly_report($select_date,$checkpoint_count_171,$checkpoint_count_172,$checkpoint_detail_171,$checkpoint_detail_172,$time_seq_171,$time_seq_172);
                }
                else{
                        write_weekly_report($select_date,0,0,null,null,null,null);
                }

    }
    else {
        // No Date Input
        echo "NO DATE INPUT"."<br>";
        echo "EXAMPLE URL: http://10.11.11.206/monitor/checkpoint_not_complete/get_checkpoint_not_complete.php?date=05-05-2016 OR ?date=today";
        // End PHP
    }

                //Write Log File
        $show_today_yesterday='[User Defined]';
        if($_GET['date']=='today')
                $show_today_yesterday='[Today]';
        if($_GET['date']=='yesterday')
                $show_today_yesterday='[Yesterday]';

        $txt="[Timestamp: ".date('d-m-Y H:i:s')."]"."[Select Date: ".$select_date."]".$show_today_yesterday." DB1-Count:".$checkpoint_count_171." DB2-Count:".$checkpoint_count_172;
                $log_file = fopen('/var/www/html/monitor/checkpoint_not_complete/get_checkpoint_not_complete.log', 'a');
                fwrite($log_file,$txt."\n");
                fclose($log_file);



        function write_weekly_report($select_date,$checkpoint_count_171,$checkpoint_count_172,$checkpoint_detail_171,$checkpoint_detail_172,$time_seq_171,$time_seq_172){

        //Write Yesterday Log Only!!!
        if($_GET['date']=='yesterday'){
                if($checkpoint_count_171==0&&$checkpoint_count_172==0&&$checkpoint_detail_171==null&&$checkpoint_detail_171==null&&$time_seq_171==null&$time_seq_172==null){
                        //No Checkpoint Not Complete [DB1 & DB2]
                        $txt="[".$select_date."][DB1=0][null]"."\n";
                        $txt.="[".$select_date."][DB2=0][null]";
                }
                else{
                        //Found Checkpoint Not Complete
                        $time_seq_171=str_replace("</b><b>", ",", $time_seq_171);
                        $time_seq_171=str_replace("<b>", "", $time_seq_171);
                        $time_seq_171=str_replace("</b>", "", $time_seq_171).",";
                        $time_seq_172=str_replace("</b><b>", ",", $time_seq_172);
                        $time_seq_172=str_replace("<b>", "", $time_seq_172);
                        $time_seq_172=str_replace("</b>", "", $time_seq_172).",";

                        $time_seq_171_tmp='';
                        $time_seq_172_tmp='';

                        if($time_seq_171==','){$time_seq_171_tmp="null";}
                        else{
                                while($time_seq_171!=''){
                                        $time_seq_171_tmp.=date('G:i',strtotime(substr($time_seq_171,0,strpos($time_seq_171, ",")))).",";
                                        $time_seq_171=str_replace(substr($time_seq_171,0,strpos($time_seq_171, ",")).",","",$time_seq_171);
                                }
                        // Remove Last Comma
                        $time_seq_171_tmp=substr($time_seq_171_tmp, 0, -1);
                        }
                        if($time_seq_172==','){$time_seq_172_tmp="null";}
                        else{
                                while($time_seq_172!=''){
                                        $time_seq_172_tmp.=date('G:i',strtotime(substr($time_seq_172,0,strpos($time_seq_172, ",")))).",";
                                        $time_seq_172=str_replace(substr($time_seq_172,0,strpos($time_seq_172, ",")).",","",$time_seq_172);
                                }
                        // Remove Last Comma
                        $time_seq_172_tmp=substr($time_seq_172_tmp, 0, -1);
                        }




                        $txt="[".$select_date."][DB1=".$checkpoint_count_171."][".$time_seq_171_tmp."]"."\n";
                        $txt.="[".$select_date."][DB2=".$checkpoint_count_172."][".$time_seq_172_tmp."]";
                }

                //Read Old Data From Text File
                $text_tmp='';
                $fh = fopen('/var/www/html/monitor/checkpoint_not_complete/weekly_report.log','r');
                while ($line = fgets($fh)) {
                        $text_tmp.=$line;
                }
                fclose($fh);

                //Combine New & Old
                $text_tmp=$txt."\n".$text_tmp;

                //Write Log File
                $log_file = fopen('/var/www/html/monitor/checkpoint_not_complete/weekly_report.log', 'w');
                fwrite($log_file,$text_tmp);
                fclose($log_file);

        }
        }



    function insert_to_db($select_date,$checkpoint_count_171,$checkpoint_count_172,$checkpoint_detail_171,$checkpoint_detail_172){
        $select_date=date("Y-m-d", strtotime($select_date));
        echo "<br>";
        $con = mysqli_connect("10.11.11.208","root","password");
                        mysqli_set_charset($con, "utf8");
                        if (!$con) {
                    die("Database connection failed: " . mysqli_error());
                        }

                        $db_select = mysqli_select_db($con, "monitor");
                        if (!$db_select) {
                        die("Database selection failed: " . mysqli_error());
                        }

            $sql = "INSERT INTO checkpoint_not_complete (checkpoint_date,db1_count,db1_detail,db2_count,db2_detail) VALUES
            ('".$select_date."','".$checkpoint_count_171."','".$checkpoint_detail_171."','".$checkpoint_count_172."','".$checkpoint_detail_172."') ON DUPLICATE KEY UPDATE db1_count='".$checkpoint_count_171."', db1_detail='".$checkpoint_detail_171."', db2_count='".$checkpoint_count_172."', db2_detail='".$checkpoint_detail_172."';";

                        if(mysqli_query($con, $sql)){
                        echo "INSERT OR UPDATE DATA TO DB SUCCESSFULLY";
                        } else{
                        echo "INSERT OR UPDATE DATA TO DB FAILED => ".mysqli_error($link);
                        } 
    }

    
    // Use This Part For Loop Collect All
   /*
	 $next_date=date('d-m-Y', strtotime($select_date." +1 day"));
    if($next_date==date('30-11-2017')){
        // Stop Redirect
        echo "<br>"."FINISHED !!!";
    }
    else{
        echo "<br>"."GO TO NEXT DATE...";
        header('Refresh: 5; URL=http://10.11.11.206/monitor/checkpoint_not_complete/get_checkpoint_not_complete.php?date='.$next_date);
        exit;
    }
    */
?>
