<!DOCTYPE html>
<html lang="en">
<meta charset="UTF-8">
  <head>
    <style>
    .date_text{
      line-height:35px
    }
    </style>
    <meta charset="utf-8">
    <meta name="viewport" content="initial-scale=1.0, maximum-scale=2.0">
    <meta name="description" content="">
    <meta name="author" content="">
    
    <!-- Bootstrap core CSS -->
    <link href="//netdna.bootstrapcdn.com/font-awesome/4.0.3/css/font-awesome.css" rel="stylesheet">
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0-alpha.6/css/bootstrap.min.css" integrity="sha384-rwoIResjU2yc3z8GV/NPeZWAv56rSmLldC3R/AZzGRnGxQQKnKkoFVhFQhNUwEyJ" crossorigin="anonymous">
    <link href="css/navbar-top-fixed.css" rel="stylesheet">
    <link rel="stylesheet" href="//code.jquery.com/ui/1.12.1/themes/base/jquery-ui.css">
    <script type="text/javascript" src="https://code.jquery.com/jquery-1.11.3.min.js"></script>
    <link rel="stylesheet" href="https://formden.com/static/cdn/bootstrap-iso.css" />
    <script type="text/javascript" src="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-datepicker/1.4.1/js/bootstrap-datepicker.min.js"></script>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-datepicker/1.4.1/css/bootstrap-datepicker3.css"/>
  </head>

  <?php
    // Query Date & Remark
      // Connect To DB
      $con = mysqli_connect("10.11.11.208","root","password");
      if (!$con) {
        die("Database connection failed: " . mysqli_error());
      }
      $db_select = mysqli_select_db($con, "monitor");
      if (!$db_select) {
          die("Database selection failed: " . mysqli_error());
      }
      mysqli_set_charset( $con, 'utf8');

      // Get Date From DB
      if($_GET['id']!='new'){
        $sql=mysqli_query($con, "SELECT * FROM checkpoint_not_complete_remark WHERE remark_id='".$_GET['id']."';");
        while ($result=mysqli_fetch_array($sql)) {
            $select_date=date('d-m-Y',strtotime($result['remark_date']));
            $remark_time=$result['remark_time'];
            $remark_detail=$result['remark_detail'];
        }
      }
      else{
        $select_date=date('d-m-Y');
      }

  ?>
 
  <body>
    <form action="edit_remark_insert.php" method="post">
      <div class="container" style="margin-top:2%;margin-left: 1%;">
        <div class="container-fluid">

          <div class="row">
            <?php echo write_space(10);?>
            <div class="form-group"><label class="control-label date_text" for="date"><b>Date&nbsp;&nbsp;&nbsp;</b></label></div>
            <div class="form-group"> <!-- Date input -->
              <input class="form-control" id="date" name="date" value="<?php echo $select_date;?>" type="text"/>
            </div>
            <?php echo write_space(10);?>
            <div class="form-group"><label class="control-label date_text" for="date"><b>&nbsp;&nbsp;&nbsp;Time&nbsp;&nbsp;&nbsp;</b></label></div>
            <div class="form-group">
              <input class="form-control" id="time" name="time" value="<?php echo $remark_time;?>" type="text"/>
            </div>
          </div>

          <div class="row">
            <div class="col-md-12 col-sm-12">
              <font size="+0.5"><strong><p><?php echo write_space(45);?>Checkpoint Not Complete Remark</p></strong></font>
            </div>
            </div>
            <div class="col-md-12 col-sm-12" align="center">
              <textarea id="remark_txt_area" name="remark_txt_area" class="form-control" cols="25" rows="5"><?php echo $remark_detail;?></textarea> 
            </div>
          </div>

          <div class="row">&nbsp;&nbsp;&nbsp;</div>

          <div class="row">
            <?php echo write_space(45);?>
              <button class="btn btn-success" type="submit">Add/Update</button>&nbsp;&nbsp;&nbsp;
              <input type="button" class="btn btn-danger btn-md" onclick="delete_remark('<?php echo $_GET['id'];?>');" value="Delete">&nbsp;&nbsp;&nbsp;
              <button class="btn btn-primary" type="button" onclick="window_close();">Cancel</button>
          </div>

      </div>
    </form>

    <script>
    function window_close()
    {
      window.close()
    }
    function delete_remark(id) {
      if (confirm("Delete Confirm?")) {
       document.location = "edit_remark_delete.php?id="+id;
      }
    }
    </script>


 <script type="text/javascript">
    $(document).ready(function(){
      var date_input=$('input[name="date"]'); //our date input has the name "date"
      var container=$('.bootstrap-iso form').length>0 ? $('.bootstrap-iso form').parent() : "body";
      var options={
        format: 'dd-mm-yyyy',
        container: container,
        todayHighlight: true,
        autoclose: true,
      };
      date_input.datepicker(options);
    })
</script>

<?php
function write_space($num){
  for($i=0;$i<$num;$i++)
    echo "&nbsp;";
}
?>


  </body>
</html>