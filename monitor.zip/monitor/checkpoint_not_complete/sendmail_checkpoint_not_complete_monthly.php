<?php
	// MAIN FUNCTION ///	
	$send_date=date('01-m-Y'); // 1st Date of Next Month
	$db1_count = array();
	$db2_count = array();
	$max_rowspan = array(0);
	$total_db1 = array();
	$total_db2 = array();
	$first_date = '';
	$last_date = '';
	$rowspan_use = array();
	$sendmail_status=false;

	echo "<b>Checkpoint Not Complete Report (Monthly) [".date("M Y", strtotime('-1 month'))."]</b><br>";
	
	get_sendmail_date();

	echo "<br>";
	echo "Send Date For This Month [Report Previous Month] = ".$send_date.", Current Date = ".date("d-m-Y")."<br>";

	query_data(date("Y-m",strtotime('-1 month'))); // Query Data By [First Date - Last Date] of Previous Month

	//$send_date="26-12-2017"; // Use For Test

	if($send_date==date("d-m-Y")){
		$sendmail_status=true;
	}
?>



<!-- QUERY DATA -->
<?php
	function query_data($prv_month){
			//$prv_month="2017-12"; // Use For Test Other Month

			// Query Data Part
			$con = mysqli_connect("10.11.11.208","root","password");
			if (!$con) {
		    die("Database connection failed: " . mysqli_error());
			}
			$db_select = mysqli_select_db($con, "monitor");
			if (!$db_select) {
		    	die("Database selection failed: " . mysqli_error());
			}
			mysqli_set_charset( $con, 'utf8');

			$GLOBALS['first_date']=date("Y-m-01",strtotime($prv_month));
			$GLOBALS['last_date']=date("Y-m-t",strtotime($prv_month));

			echo "Query Data From <b>".$GLOBALS['first_date']."</b> To <b>".$GLOBALS['last_date']."</b><br><br>";

			// Query Checkpoint Not Complete Data
			$sql=mysqli_query($con, "SELECT * FROM checkpoint_not_complete WHERE date_format(checkpoint_date,'%Y-%m-%d') BETWEEN '".$GLOBALS['first_date']."' AND '".$GLOBALS['last_date']."';");

		  while ($result=mysqli_fetch_array($sql)) {
		  	 global $db1_count, $db2_count, $max_rowspan, $total_db1, $total_db2;
		    $date=$result['checkpoint_date'];
		    $total_db1[$date]=$result['db1_count'];
		    $total_db2[$date]=$result['db2_count'];

		    for($i=0;$i<24;$i++){
		    	// Loop For Count 24 Hour In 1 Day
		    	$hr=sprintf('%02d', $i);

		    	$db1_count[$date][$i]=substr_count($result['db1_detail'],date("D M d ".$hr.":",strtotime($result['checkpoint_date'])));
		    	$db2_count[$date][$i]=substr_count($result['db2_detail'],date("D M d ".$hr.":",strtotime($result['checkpoint_date'])));
		    	if($max_rowspan[$date]==null || $max_rowspan[$date] < $db1_count[$date][$i]+$db2_count[$date][$i]){
		    		// Update max_rowspan
		    		$max_rowspan[$date]=$db1_count[$date][$i]+$db2_count[$date][$i];
		    	}
		    }
		  }	
	}
?>

<!-- GET SENDMAIL DATE -->
<?php
	function get_sendmail_date(){
		check_date_again:

		$sendmail_status=true;
		echo "Check Date Status [Sat, Sun, Holiday]: ";
		$today=date("D", strtotime($GLOBALS['send_date']));

		// 1. Check Is Day = Sat or Sun
		if($today=="Sat" || $today=="Sun"){
			echo $GLOBALS['send_date']." => Not Send (Weekend)<br>";
			$sendmail_status=false;
		}

		// 2. Check Is Day = Holiday List
		   $con210 = mysqli_connect("10.11.11.210","root","password");
         if (!$con210) {
          die("Database connection failed: " . mysqli_error());
         }
         $db_select = mysqli_select_db($con210, "3bb_standby");
         if (!$db_select) {
            die("Database selection failed: " . mysqli_error());
         }
         mysqli_set_charset($con210, 'utf8');
         $sql=mysqli_query($con210, "SELECT * FROM holiday_calendar WHERE holiday_date='".date("Y-m-d", strtotime($GLOBALS['send_date']))."' LIMIT 1;");
         while ($result=mysqli_fetch_array($sql)) {
              $sendmail_status=false;
              echo $GLOBALS['send_date']." => Not Send (Holiday)<br>";
         }

		if ($sendmail_status==false){
			// Increment Date Until Not Equal Weekend or Holiday
			$GLOBALS['send_date']=date('d-m-Y', strtotime($GLOBALS['send_date']."+ 1 day"));
			goto check_date_again; // Go Back To Check Date Again
		}
		else{
			echo " OK";
		}
	}
?>



<!-- GET DAY COLOR -->
<?php
 function get_day_color($day_abv){
    	switch($day_abv){
			case "Sun":
				return "#ff0000";
			case "Mon":
				return "#ffff00";
			case "Tue":
				return "#ff99cc";
			case "Wed":
				return "#92d050";
			case "Thu":
				return "#ffc000";
			case "Fri":
				return "#b8cce4";
			case "Sat":
				return "#b1a0c7";
		}
    }
?>



<!-- GET CELL COLOR -->
<?php
	function get_cell_color($db_count){
		if($db_count>0){
			return "#ffc000";
		}
		else{
			return "#bfbfbf";
		}
	}
?>



<!-- SHOW EMAIL PART -->
<?php

	////////// WRITE HEADER //////////
$email_body="<html xmlns:v=\"urn:schemas-microsoft-com:vml\" xmlns:o=\"urn:schemas-microsoft-com:office:office\" xmlns:w=\"urn:schemas-microsoft-com:office:word\" xmlns:x=\"urn:schemas-microsoft-com:office:excel\" xmlns:m=\"http://schemas.microsoft.com/office/2004/12/omml\" xmlns=\"http://www.w3.org/TR/REC-html40\">
   <head>
      <META HTTP-EQUIV=\"Content-Type\" CONTENT=\"text/html; charset=us-ascii\">
      <meta name=ProgId content=Word.Document>
      <meta name=Generator content=\"Microsoft Word 14\">
      <meta name=Originator content=\"Microsoft Word 14\">
      <link rel=File-List href=\"cid:filelist.xml@01D37D9A.02CE33A0\">
      <link rel=themeData href=\"~~themedata~~\">
      <link rel=colorSchemeMapping href=\"~~colorschememapping~~\">
      <style>
         <!--
            /* Font Definitions */
            @font-face
            	{font-family:\"Cordia New\";
            	panose-1:2 11 3 4 2 2 2 2 2 4;
            	mso-font-charset:0;
            	mso-generic-font-family:swiss;
            	mso-font-pitch:variable;
            	mso-font-signature:-2130706429 0 0 0 65537 0;}
            @font-face
            	{font-family:\"Cordia New\";
            	panose-1:2 11 3 4 2 2 2 2 2 4;
            	mso-font-charset:0;
            	mso-generic-font-family:swiss;
            	mso-font-pitch:variable;
            	mso-font-signature:-2130706429 0 0 0 65537 0;}
            @font-face
            	{font-family:Calibri;
            	panose-1:2 15 5 2 2 2 4 3 2 4;
            	mso-font-charset:0;
            	mso-generic-font-family:swiss;
            	mso-font-pitch:variable;
            	mso-font-signature:-536859905 -1073732485 9 0 511 0;}
            @font-face
            	{font-family:Tahoma;
            	panose-1:2 11 6 4 3 5 4 4 2 4;
            	mso-font-charset:0;
            	mso-generic-font-family:swiss;
            	mso-font-pitch:variable;
            	mso-font-signature:-520081665 -1073717157 41 0 66047 0;}
            /* Style Definitions */
            p.MsoNormal, li.MsoNormal, div.MsoNormal
            	{mso-style-unhide:no;
            	mso-style-qformat:yes;
            	mso-style-parent:\"\";
            	margin:0cm;
            	margin-bottom:.0001pt;
            	mso-pagination:widow-orphan;
            	font-size:11.0pt;
            	mso-bidi-font-size:14.0pt;
            	font-family:\"Calibri\",\"sans-serif\";
            	mso-ascii-font-family:Calibri;
            	mso-ascii-theme-font:minor-latin;
            	mso-fareast-font-family:Calibri;
            	mso-fareast-theme-font:minor-latin;
            	mso-hansi-font-family:Calibri;
            	mso-hansi-theme-font:minor-latin;
            	mso-bidi-font-family:\"Cordia New\";
            	mso-bidi-theme-font:minor-bidi;}
            a:link, span.MsoHyperlink
            	{mso-style-noshow:yes;
            	mso-style-priority:99;
            	color:blue;
            	mso-themecolor:hyperlink;
            	text-decoration:underline;
            	text-underline:single;}
            a:visited, span.MsoHyperlinkFollowed
            	{mso-style-noshow:yes;
            	mso-style-priority:99;
            	color:purple;
            	mso-themecolor:followedhyperlink;
            	text-decoration:underline;
            	text-underline:single;}
            span.17
            	{mso-style-type:personal-compose;
            	mso-style-noshow:yes;
            	mso-style-unhide:no;
            	mso-ansi-font-size:11.0pt;
            	mso-bidi-font-size:14.0pt;
            	font-family:\"Calibri\",\"sans-serif\";
            	mso-ascii-font-family:Calibri;
            	mso-ascii-theme-font:minor-latin;
            	mso-fareast-font-family:Calibri;
            	mso-fareast-theme-font:minor-latin;
            	mso-hansi-font-family:Calibri;
            	mso-hansi-theme-font:minor-latin;
            	mso-bidi-font-family:\"Cordia New\";
            	mso-bidi-theme-font:minor-bidi;
            	color:windowtext;}
            .MsoChpDefault
            	{mso-style-type:export-only;
            	mso-default-props:yes;
            	font-family:\"Calibri\",\"sans-serif\";
            	mso-ascii-font-family:Calibri;
            	mso-ascii-theme-font:minor-latin;
            	mso-fareast-font-family:Calibri;
            	mso-fareast-theme-font:minor-latin;
            	mso-hansi-font-family:Calibri;
            	mso-hansi-theme-font:minor-latin;
            	mso-bidi-font-family:\"Cordia New\";
            	mso-bidi-theme-font:minor-bidi;}
            @page WordSection1
            	{size:612.0pt 792.0pt;
            	margin:72.0pt 72.0pt 72.0pt 72.0pt;
            	mso-header-margin:36.0pt;
            	mso-footer-margin:36.0pt;
            	mso-paper-source:0;}
            div.WordSection1
            	{page:WordSection1;}
            -->
      </style>
   </head>
   <body lang=EN-US link=blue vlink=purple style='tab-interval:36.0pt'>
      <div class=WordSection1>

      	<!-- INTRO -->
       	<p>
            <b><span lang=TH style='font-size:12.0pt;font-family:\"Tahoma\",\"sans-serif\";color:#1F497D'>เรียน</span></b><b><span style='font-size:12.0pt;font-family:\"Tahoma\",\"sans-serif\";color:#1F497D'>&nbsp;<span lang=TH>ทุกท่านครับ</span></span></b>
            <span style='font-size:12.0pt;font-family:\"Tahoma\",\"sans-serif\";color:#1F497D'>
               <o:p></o:p>
            </span>
        </p>
        <p class=MsoNormal>
            <span style='font-size:12.0pt;font-family:\"Tahoma\",\"sans-serif\";color:#1F497D'><span style='mso-tab-count:1'>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </span><span lang=TH>Monthly Report Checkpoint Not Complete ประจำเดือน&nbsp;".date("M Y", strtotime('-1 month'))."&nbsp;<span lang=TH>รายละเอียดดังตารางครับ</span><br style='mso-special-character:line-break'><![if !supportLineBreakNewLine]><br style='mso-special-character:line-break'><![endif]>
               <o:p></o:p>
            </span>
        </p>

         <table class=MsoNormalTable border=0 cellspacing=0 cellpadding=0 width=1137 style='width:852.8pt;margin-left:-1.15pt;border-collapse:collapse;mso-yfti-tbllook:1184;mso-padding-alt:0cm 5.4pt 0cm 5.4pt'>
            <tr style='mso-yfti-irow:0;mso-yfti-firstrow:yes;height:14.25pt'>

            <!-- DATE LABEL-->
               <td width=157 colspan=2 rowspan=2 style='width:118.0pt;border-top:windowtext;border-left:windowtext;border-bottom:black;border-right:black;border-style:solid;border-width:1.0pt;mso-border-top-alt:windowtext;mso-border-left-alt:windowtext;mso-border-bottom-alt:black;mso-border-right-alt:black;mso-border-style-alt:solid;mso-border-width-alt:.5pt;background:#DCE6F1;padding:0cm 5.4pt 0cm 5.4pt;height:14.25pt'>
                  <p class=MsoNormal align=center style='text-align:center'>
                     <b>
                        <span style='mso-bidi-font-size:11.0pt;font-family:\"Tahoma\",\"sans-serif\";mso-fareast-font-family:\"Times New Roman\";color:black'>
                           Date
                           <o:p></o:p>
                        </span>
                     </b>
                  </p>
               </td>

            <!-- TIME HOUR LABEL-->
               <td width=836 colspan=24 style='width:626.8pt;border-top:solid windowtext 1.0pt;border-left:none;border-bottom:solid windowtext 1.0pt;border-right:solid black 1.0pt;mso-border-top-alt:solid windowtext .5pt;mso-border-bottom-alt:solid windowtext .5pt;mso-border-right-alt:solid black .5pt;background:#DCE6F1;padding:0cm 5.4pt 0cm 5.4pt;height:14.25pt'>
                  <p class=MsoNormal align=center style='text-align:center'>
                     <b>
                        <span style='mso-bidi-font-size:11.0pt;font-family:\"Tahoma\",\"sans-serif\";mso-fareast-font-family:\"Times New Roman\";color:black'>
                           Time (Hour)
                           <o:p></o:p>
                        </span>
                     </b>
                  </p>
               </td>

            <!-- TOTAL CHECKPOINT NOT COMPLETE LABEL-->
               <td width=144 colspan=2 style='width:108.0pt;border:solid windowtext 1.0pt;border-left:none;mso-border-top-alt:solid windowtext .5pt;mso-border-bottom-alt:solid windowtext .5pt;mso-border-right-alt:solid windowtext .5pt;background:#DCE6F1;padding:0cm 5.4pt 0cm 5.4pt;height:14.25pt'>
                  <p class=MsoNormal align=center style='text-align:center'>
                     <b>
                        <span style='mso-bidi-font-size:11.0pt;font-family:\"Tahoma\",\"sans-serif\";mso-fareast-font-family:\"Times New Roman\";color:black'>
                           Total Checkpoint Not Complete
                           <o:p></o:p>
                        </span>
                     </b>
                  </p>
               </td>
            </tr>
            <tr style='mso-yfti-irow:1;height:14.25pt'>";

        // WRITE TIME HOUR LABEL [00-23]
        for($i=0;$i<24;$i++){
$email_body.="<td width=35 style='width:26.0pt;border-top:none;border-left:none;border-bottom:solid windowtext 1.0pt;border-right:solid windowtext 1.0pt;mso-border-bottom-alt:solid windowtext .5pt;mso-border-right-alt:solid windowtext .5pt;background:#DCE6F1;padding:0cm 5.4pt 0cm 5.4pt;height:14.25pt'>
                  <p class=MsoNormal align=center style='text-align:center'>
                     <b>
                        <span style='mso-bidi-font-size:11.0pt;font-family:\"Tahoma\",\"sans-serif\";mso-fareast-font-family:\"Times New Roman\";color:black'>
                           ".sprintf('%02d', $i)."
                           <o:p></o:p>
                        </span>
                     </b>
                  </p>
               </td>";
        }

$email_body.="
			<!-- TOTAL CHECKPOINT NOT COMPLETE LABEL [DB1] -->
<td width=72 nowrap style='width:54.0pt;border-top:none;border-left:none;border-bottom:solid windowtext 1.0pt;border-right:solid windowtext 1.0pt;mso-border-bottom-alt:solid windowtext .5pt;mso-border-right-alt:solid windowtext .5pt;background:#DCE6F1;padding:0cm 5.4pt 0cm 5.4pt;height:14.25pt'>
                  <p class=MsoNormal align=center style='text-align:center'>
                     <span style='mso-bidi-font-size:11.0pt;font-family:\"Tahoma\",\"sans-serif\";mso-fareast-font-family:\"Times New Roman\";color:black'>
                        DB1
                        <o:p></o:p>
                     </span>
                  </p>
               </td>

            <!-- TOTAL CHECKPOINT NOT COMPLETE LABEL [DB2] -->
               <td width=72 nowrap style='width:54.0pt;border-top:none;border-left:none;border-bottom:solid windowtext 1.0pt;border-right:solid windowtext 1.0pt;mso-border-bottom-alt:solid windowtext .5pt;mso-border-right-alt:solid windowtext .5pt;background:#DCE6F1;padding:0cm 5.4pt 0cm 5.4pt;height:14.25pt'>
                  <p class=MsoNormal align=center style='text-align:center'>
                     <span style='mso-bidi-font-size:11.0pt;font-family:\"Tahoma\",\"sans-serif\";mso-fareast-font-family:\"Times New Roman\";color:black'>
                        DB2
                        <o:p></o:p>
                     </span>
                  </p>
               </td>
            </tr>";

    // LOOP FOR EACH DAY
    for($day=$last_date; $day >= $first_date; $day=date("Y-m-d", strtotime($day."-1 day")) ){
$email_body.="
			<!-- DAY ABBREVIATION -->
            <tr style='mso-yfti-irow:2;mso-yfti-lastrow:yes;height:14.25pt'>
               <td rowspan=".$max_rowspan[$day]." width=49 nowrap valign=top style='width:36.45pt;border:solid windowtext 1.0pt;border-top:none;mso-border-left-alt:solid windowtext .5pt;mso-border-bottom-alt:solid windowtext .5pt;mso-border-right-alt:solid windowtext .5pt;background:".get_day_color(date("D", strtotime($day))).";padding:0cm 5.4pt 0cm 5.4pt;height:14.25pt'>
                  <p class=MsoNormal>
                     <span style='font-size:10.0pt;font-family:\"Tahoma\",\"sans-serif\";mso-fareast-font-family:\"Times New Roman\";color:black'>
                        ".date("D", strtotime($day))."
                        <o:p></o:p>
                     </span>
                  </p>
               </td>

            <!-- DATE -->
               <td rowspan=".$max_rowspan[$day]." width=109 nowrap valign=top style='width:81.55pt;border-top:none;border-left:none;border-bottom:solid windowtext 1.0pt;border-right:solid windowtext 1.0pt;mso-border-bottom-alt:solid windowtext .5pt;mso-border-right-alt:solid windowtext .5pt;background:".get_day_color(date("D", strtotime($day))).";padding:0cm 5.4pt 0cm 5.4pt;height:14.25pt'>
                  <p class=MsoNormal align=center style='text-align:center'>
                     <span style='font-size:10.0pt;font-family:\"Tahoma\",\"sans-serif\";mso-fareast-font-family:\"Times New Roman\";color:black'>
                        ".date("d-M-y", strtotime($day))."
                        <o:p></o:p>
                     </span>
                  </p>
               </td>";

// LOOP EVERY HOUR [1ST ROUND]
for($i=0;$i<24;$i++){

	// No Checkpoint On This Day
	if($total_db1[$day]+$total_db2[$day]==0){
		$email_body.="     
               <td width=35 style='width:26.0pt;border-top:none;border-left:none;border-bottom:solid windowtext 1.0pt;border-right:solid windowtext 1.0pt;mso-border-bottom-alt:solid windowtext .5pt;mso-border-right-alt:solid windowtext .5pt;background:#bfbfbf;padding:0cm 5.4pt 0cm 5.4pt;height:14.25pt'>
                  <p class=MsoNormal align=center style='text-align:center'>
                     <b>
                        <span style='mso-bidi-font-size:11.0pt;font-family:\"Tahoma\",\"sans-serif\";mso-fareast-font-family:\"Times New Roman\";color:black'>
                           &nbsp;
                           <o:p></o:p>
                        </span>
                     </b>
                  </p>
               </td>";
	}

	// Found Checkpoint Not Complete On This Day
	else {
		if($max_rowspan[$day]>1){
			// Max Rowspan > 1

			// Found Checkpoint On DB1 
			if($db1_count[$day][$i]!=0){
				$email_body.="     
               <td rowswidth=35 style='width:26.0pt;border-top:none;border-left:none;border-bottom:solid windowtext 1.0pt;border-right:solid windowtext 1.0pt;mso-border-bottom-alt:solid windowtext .5pt;mso-border-right-alt:solid windowtext .5pt;background:#b8cce4;padding:0cm 5.4pt 0cm 5.4pt;height:14.25pt'>
                  <p class=MsoNormal align=center style='text-align:center'>
                     <b>
                        <span style='mso-bidi-font-size:11.0pt;font-family:\"Tahoma\",\"sans-serif\";mso-fareast-font-family:\"Times New Roman\";color:black'>
                           DB1
                           <o:p></o:p>
                        </span>
                     </b>
                  </p>
               </td>";
               	$db1_count[$day][$i]--;
               	$rowspan_use[$day][$i]=true;
               	goto end_hour_loop;
			}
			
			// Found Checkpoint On DB2
			if($db2_count[$day][$i]!=0){
				$email_body.="     
               <td rowswidth=35 style='width:26.0pt;border-top:none;border-left:none;border-bottom:solid windowtext 1.0pt;border-right:solid windowtext 1.0pt;mso-border-bottom-alt:solid windowtext .5pt;mso-border-right-alt:solid windowtext .5pt;background:#00b0f0;padding:0cm 5.4pt 0cm 5.4pt;height:14.25pt'>
                  <p class=MsoNormal align=center style='text-align:center'>
                     <b>
                        <span style='mso-bidi-font-size:11.0pt;font-family:\"Tahoma\",\"sans-serif\";mso-fareast-font-family:\"Times New Roman\";color:black'>
                           DB2
                           <o:p></o:p>
                        </span>
                     </b>
                  </p>
               </td>";
               $db2_count[$day][$i]--;
               $rowspan_use[$day][$i]=true;
               goto end_hour_loop;
			}

			// No Checkpoint Not Complete [Use Max Rowspan]	
			if($db1_count[$day][$i]==0&&$db2_count[$day][$i]==0){
				$email_body.="     
               <td rowspan=".$max_rowspan[$day]." rowswidth=35 style='width:26.0pt;border-top:none;border-left:none;border-bottom:solid windowtext 1.0pt;border-right:solid windowtext 1.0pt;mso-border-bottom-alt:solid windowtext .5pt;mso-border-right-alt:solid windowtext .5pt;padding:0cm 5.4pt 0cm 5.4pt;height:14.25pt'>
                  <p class=MsoNormal align=center style='text-align:center'>
                     <b>
                        <span style='mso-bidi-font-size:11.0pt;font-family:\"Tahoma\",\"sans-serif\";mso-fareast-font-family:\"Times New Roman\";color:black'>
                           &nbsp
                           <o:p></o:p>
                        </span>
                     </b>
                  </p>
               </td>";
               $rowspan_use[$day][$i]=false;
			}
		}
		else{
			// Max Rowspan = 1 [Finish In One Round]

			// Found Checkpoint On DB1 
			if($db1_count[$day][$i]==1){
				$email_body.="     
               <td rowswidth=35 style='width:26.0pt;border-top:none;border-left:none;border-bottom:solid windowtext 1.0pt;border-right:solid windowtext 1.0pt;mso-border-bottom-alt:solid windowtext .5pt;mso-border-right-alt:solid windowtext .5pt;background:#b8cce4;padding:0cm 5.4pt 0cm 5.4pt;height:14.25pt'>
                  <p class=MsoNormal align=center style='text-align:center'>
                     <b>
                        <span style='mso-bidi-font-size:11.0pt;font-family:\"Tahoma\",\"sans-serif\";mso-fareast-font-family:\"Times New Roman\";color:black'>
                           DB1
                           <o:p></o:p>
                        </span>
                     </b>
                  </p>
               </td>";
               	$db1_count[$day][$i]--;
               	goto end_hour_loop;
			}
			
			// Found Checkpoint On DB2
			if($db2_count[$day][$i]==1){
				$email_body.="     
               <td rowswidth=35 style='width:26.0pt;border-top:none;border-left:none;border-bottom:solid windowtext 1.0pt;border-right:solid windowtext 1.0pt;mso-border-bottom-alt:solid windowtext .5pt;mso-border-right-alt:solid windowtext .5pt;background:#00b0f0;padding:0cm 5.4pt 0cm 5.4pt;height:14.25pt'>
                  <p class=MsoNormal align=center style='text-align:center'>
                     <b>
                        <span style='mso-bidi-font-size:11.0pt;font-family:\"Tahoma\",\"sans-serif\";mso-fareast-font-family:\"Times New Roman\";color:black'>
                           DB2
                           <o:p></o:p>
                        </span>
                     </b>
                  </p>
               </td>";
               $db2_count[$day][$i]--;
               goto end_hour_loop;
			}

			// No Checkpoint Not Complete		
			if($db1_count[$day][$i]==0&&$db2_count[$day][$i]==0){
				$email_body.="     
               <td rowswidth=35 style='width:26.0pt;border-top:none;border-left:none;border-bottom:solid windowtext 1.0pt;border-right:solid windowtext 1.0pt;mso-border-bottom-alt:solid windowtext .5pt;mso-border-right-alt:solid windowtext .5pt;padding:0cm 5.4pt 0cm 5.4pt;height:14.25pt'>
                  <p class=MsoNormal align=center style='text-align:center'>
                     <b>
                        <span style='mso-bidi-font-size:11.0pt;font-family:\"Tahoma\",\"sans-serif\";mso-fareast-font-family:\"Times New Roman\";color:black'>
                           &nbsp
                           <o:p></o:p>
                        </span>
                     </b>
                  </p>
               </td>";
			}
		}
	}
	end_hour_loop:
} // END LOOP HOUR



	if($total_db1[$day]==0){
		// No Checkpoint Found On DB1
		$email_body.=" 
			<!-- DB1: TOTAL CHECKPOINT NOT COMPLETE -->
               <td rowspan=".$max_rowspan[$day]." width=72 nowrap style='width:54.0pt;border-top:none;border-left:none;border-bottom:solid windowtext 1.0pt;border-right:solid windowtext 1.0pt;mso-border-bottom-alt:solid windowtext .5pt;mso-border-right-alt:solid windowtext .5pt;padding:0cm 5.4pt 0cm 5.4pt;height:14.25pt'>
                  <p class=MsoNormal align=center style='text-align:center'>
                     <span style='font-size:10.0pt;font-family:\"Tahoma\",\"sans-serif\";mso-fareast-font-family:\"Times New Roman\";color:black'>
                        &nbsp;
                        <o:p></o:p>
                     </span>
                  </p>
               </td>";
    }
    else {
		$email_body.=" 
			<!-- DB1: TOTAL CHECKPOINT NOT COMPLETE -->
               <td rowspan=".$max_rowspan[$day]." width=72 nowrap style='width:54.0pt;border-top:none;border-left:none;border-bottom:solid windowtext 1.0pt;border-right:solid windowtext 1.0pt;mso-border-bottom-alt:solid windowtext .5pt;mso-border-right-alt:solid windowtext .5pt;background:#ff6666;padding:0cm 5.4pt 0cm 5.4pt;height:14.25pt'>
                  <p class=MsoNormal align=center style='text-align:center'>
                     <span style='font-size:10.0pt;font-family:\"Tahoma\",\"sans-serif\";mso-fareast-font-family:\"Times New Roman\";color:black'>
                        ".$total_db1[$day]."
                        <o:p></o:p>
                     </span>
                  </p>
               </td>";
    }

	if($total_db2[$day]==0){
		// No Checkpoint Found On DB2
		$email_body.=" 
			<!-- DB2: TOTAL CHECKPOINT NOT COMPLETE -->
               <td rowspan=".$max_rowspan[$day]." width=72 nowrap style='width:54.0pt;border-top:none;border-left:none;border-bottom:solid windowtext 1.0pt;border-right:solid windowtext 1.0pt;mso-border-bottom-alt:solid windowtext .5pt;mso-border-right-alt:solid windowtext .5pt;padding:0cm 5.4pt 0cm 5.4pt;height:14.25pt'>
                  <p class=MsoNormal align=center style='text-align:center'>
                     <span style='font-size:10.0pt;font-family:\"Tahoma\",\"sans-serif\";mso-fareast-font-family:\"Times New Roman\";color:black'>
                        &nbsp;
                        <o:p></o:p>
                     </span>
                  </p>
               </td>";
    }
    else {
		$email_body.=" 
			<!-- DB2: TOTAL CHECKPOINT NOT COMPLETE -->
               <td rowspan=".$max_rowspan[$day]." width=72 nowrap style='width:54.0pt;border-top:none;border-left:none;border-bottom:solid windowtext 1.0pt;border-right:solid windowtext 1.0pt;mso-border-bottom-alt:solid windowtext .5pt;mso-border-right-alt:solid windowtext .5pt;background:#ff6666;padding:0cm 5.4pt 0cm 5.4pt;height:14.25pt'>
                  <p class=MsoNormal align=center style='text-align:center'>
                     <span style='font-size:10.0pt;font-family:\"Tahoma\",\"sans-serif\";mso-fareast-font-family:\"Times New Roman\";color:black'>
                        ".$total_db2[$day]."
                        <o:p></o:p>
                     </span>
                  </p>
               </td>";
    }

	// Close Line
	$email_body.="</tr>";

    // LOOP UNTIL CHECKPOINT NOT COMPLETE EMPTY
    if($max_rowspan[$day]>1){
    	$rowspan_count=0;
    	while($max_rowspan[$day]!=$rowspan_count+1){
	    	$email_body.="<tr>";
	    	for($i=0;$i<24;$i++){
	    	// Found Checkpoint On DB1 
				if($db1_count[$day][$i]!=0 || $db1_count[$day][$i]!=null){
					$email_body.="     
	               <td rowswidth=35 style='width:26.0pt;border-top:none;border-left:none;border-bottom:solid windowtext 1.0pt;border-right:solid windowtext 1.0pt;mso-border-bottom-alt:solid windowtext .5pt;mso-border-right-alt:solid windowtext .5pt;background:#b8cce4;padding:0cm 5.4pt 0cm 5.4pt;height:14.25pt'>
	                  <p class=MsoNormal align=center style='text-align:center'>
	                     <b>
	                        <span style='mso-bidi-font-size:11.0pt;font-family:\"Tahoma\",\"sans-serif\";mso-fareast-font-family:\"Times New Roman\";color:black'>
	                           DB1
	                           <o:p></o:p>
	                        </span>
	                     </b>
	                  </p>
	               </td>";
	               	$db1_count[$day][$i]--;
	               	goto end_until_empty_loop;
				}
				
				// Found Checkpoint On DB2
				if($db2_count[$day][$i]!=0 || $db2_count[$day][$i]!=null){
					$email_body.="     
	               <td rowswidth=35 style='width:26.0pt;border-top:none;border-left:none;border-bottom:solid windowtext 1.0pt;border-right:solid windowtext 1.0pt;mso-border-bottom-alt:solid windowtext .5pt;mso-border-right-alt:solid windowtext .5pt;background:#00b0f0;padding:0cm 5.4pt 0cm 5.4pt;height:14.25pt'>
	                  <p class=MsoNormal align=center style='text-align:center'>
	                     <b>
	                        <span style='mso-bidi-font-size:11.0pt;font-family:\"Tahoma\",\"sans-serif\";mso-fareast-font-family:\"Times New Roman\";color:black'>
	                           DB2
	                           <o:p></o:p>
	                        </span>
	                     </b>
	                  </p>
	               </td>";
	               $db2_count[$day][$i]--;
	               goto end_until_empty_loop;
				}
				
				if($db1_count[$day][$i]==0 && $db2_count[$day][$i]==0 && $rowspan_use[$day][$i]==true) {
					// Write Empty Cell
					$email_body.="     
	               <td rowswidth=35 style='width:26.0pt;border-top:none;border-left:none;border-bottom:solid windowtext 1.0pt;border-right:solid windowtext 1.0pt;mso-border-bottom-alt:solid windowtext .5pt;mso-border-right-alt:solid windowtext .5pt;padding:0cm 5.4pt 0cm 5.4pt;height:14.25pt'>
	                  <p class=MsoNormal align=center style='text-align:center'>
	                     <b>
	                        <span style='mso-bidi-font-size:11.0pt;font-family:\"Tahoma\",\"sans-serif\";mso-fareast-font-family:\"Times New Roman\";color:black'>
	                           &nbsp
	                           <o:p></o:p>
	                        </span>
	                     </b>
	                  </p>
	               </td>";
				}
				end_until_empty_loop:
	    	} // END LOOP UNTIL CHECKPOINT NOT COMPLETE EMPTY
	    	$email_body.="</tr>";
	    	$rowspan_count++;
    	} // END WHILE
	} // END IF
} // END LOOP FOR EACH DAY


// EMAIL SIGNATURE
$email_body.="
         </table>
    <p class=MsoNormal>
            <span lang=TH style='font-size:14.0pt;mso-ansi-font-size:11.0pt;font-family:\"Cordia New\",\"sans-serif\";mso-ascii-font-family:Calibri;mso-ascii-theme-font:minor-latin;mso-hansi-font-family:Calibri;mso-hansi-theme-font:minor-latin;mso-bidi-font-family:\"Cordia New\";mso-bidi-theme-font:minor-bidi;color:#1F497D'><br></span><span lang=TH style='font-size:12.0pt;font-family:\"Tahoma\",\"sans-serif\";color:#1F497D'><span style='mso-tab-count:1'>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </span>*หมายเหตุ : </span>
            <span lang=TH style='font-size:12.0pt;font-family:\"Tahoma\",\"sans-serif\";color:red'>
               เป็นระบบส่งอี<span class=SpellE>เมลล์</span>อัตโนมัติ<br><br style='mso-special-character:line-break'><![if !supportLineBreakNewLine]><br style='mso-special-character:line-break'><![endif]>
            </span>
            <span style='color:#1F497D'>
               <o:p></o:p>
            </span>
         </p>
        <p class=MsoNormal>
            <a name=\"_MailAutoSig\"><b><span lang=TH style='font-size:14.0pt;font-family:\"Leelawadee\",\"sans-serif\";mso-fareast-font-family:\"Times New Roman\";mso-fareast-theme-font:minor-fareast;color:#002060;mso-no-proof:yes'>ขอแสดงความนับถือ</span></b></a>
            <span style='mso-bookmark:_MailAutoSig'>
               <b>
                  <span style='font-size:14.0pt;font-family:\"Leelawadee\",\"sans-serif\";mso-fareast-font-family:\"Times New Roman\";mso-fareast-theme-font:minor-fareast;color:#002060;mso-no-proof:yes'>
                     <o:p></o:p>
                  </span>
               </b>
            </span>
        </p>
        <p class=MsoNormal>
            <span style='mso-bookmark:_MailAutoSig'><b><span style='font-size:8.0pt;font-family:\"Leelawadee\",\"sans-serif\";mso-fareast-font-family:\"Times New Roman\";mso-fareast-theme-font:minor-fareast;color:gray;mso-themecolor:background1;mso-themeshade:128;mso-no-proof:yes'>o</span></b></span><span style='mso-bookmark:_MailAutoSig'><b><span style='font-size:8.0pt;font-family:\"Leelawadee\",\"sans-serif\";mso-fareast-font-family:\"Times New Roman\";mso-fareast-theme-font:minor-fareast;color:gray;mso-no-proof:yes'>-o-o-o-o-o-o-o-o-o-o-o-o-o-o-o-o-o-o-o-o-o-o-o-o-o-o-o-o</span></b></span>
            <span style='mso-bookmark:_MailAutoSig'>
               <span style='font-size:8.0pt;font-family:\"Leelawadee\",\"sans-serif\";mso-fareast-font-family:\"Times New Roman\";mso-fareast-theme-font:minor-fareast;mso-no-proof:yes'>
                  <o:p></o:p>
               </span>
            </span>
        </p>
        <p class=MsoNormal>
            <span style='mso-bookmark:_MailAutoSig'><b><span lang=TH style='font-size:14.0pt;font-family:\"Leelawadee UI\",\"sans-serif\";mso-fareast-font-family:\"Times New Roman\";mso-fareast-theme-font:minor-fareast;color:#31849B;mso-no-proof:yes'><span style='mso-spacerun:yes'>&nbsp;&nbsp;&nbsp;&nbsp; </span></span></b></span><span style='mso-bookmark:_MailAutoSig'><b><span lang=TH style='font-size:12.0pt;font-family:\"Leelawadee UI\",\"sans-serif\";mso-fareast-font-family:\"Times New Roman\";mso-fareast-theme-font:minor-fareast;color:#E36C0A;mso-themecolor:accent6;mso-themeshade:191;mso-no-proof:yes'>เสริมชัย ลุประสิทธิวร</span></b></span>
            <span style='mso-bookmark:_MailAutoSig'>
               <b>
                  <span style='font-size:12.0pt;font-family:\"Leelawadee UI\",\"sans-serif\";mso-fareast-font-family:\"Times New Roman\";mso-fareast-theme-font:minor-fareast;color:#E36C0A;mso-themecolor:accent6;mso-themeshade:191;mso-no-proof:yes'>
                     <o:p></o:p>
                  </span>
               </b>
            </span>
        </p>
        <p class=MsoNormal>
            <span style='mso-bookmark:_MailAutoSig'>
               <b>
                  <span style='font-family:\"Leelawadee UI\",\"sans-serif\";mso-fareast-font-family:\"Times New Roman\";mso-fareast-theme-font:minor-fareast;color:#31849B;mso-no-proof:yes'>
                     <span style='mso-spacerun:yes'>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </span>E-Mail<span style='mso-spacerun:yes'>&nbsp;&nbsp; </span>:<span style='mso-spacerun:yes'>&nbsp;&nbsp; </span>sermchai.l@jasmine.com
                     <o:p></o:p>
                  </span>
               </b>
            </span>
        </p>
        <p class=MsoNormal>
            <span style='mso-bookmark:_MailAutoSig'>
               <b>
                  <span style='font-family:\"Leelawadee UI\",\"sans-serif\";mso-fareast-font-family:\"Times New Roman\";mso-fareast-theme-font:minor-fareast;color:#31849B;mso-no-proof:yes'>
                     <span style='mso-spacerun:yes'>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </span>Triple T Broadband PCL. [9th Floor]
                     <o:p></o:p>
                  </span>
               </b>
            </span>
        </p>
        <p class=MsoNormal>
            <span style='mso-bookmark:_MailAutoSig'><b><span style='font-size:8.0pt;font-family:\"Leelawadee\",\"sans-serif\";mso-fareast-font-family:\"Times New Roman\";mso-fareast-theme-font:minor-fareast;color:gray;mso-no-proof:yes'>o-o-o-o-o-o-o-o-o-o-o-o-o-o-o-o-o-o-o-o-o-o-o-o-o-o-o-o-o</span></b></span><span style='mso-bookmark:_MailAutoSig'></span>
            <b>
               <span style='mso-fareast-font-family:\"Times New Roman\";mso-fareast-theme-font:minor-fareast;color:gray;mso-no-proof:yes'>
                  <o:p></o:p>
               </span>
            </b>
        </p>
      </div>
   	</body>
	</html>";

echo "<b>**********[START EMAIL PART]**********</b><br>";
echo $email_body;
echo "<br><b>**********[END EMAIL PART]**********</b><br>"; 

?>



<?php
	/// Send Email Part ///
	if($sendmail_status==true){
		$subject_mail="Monthly Report Checkpoint Not Complete ประจำเดือน ".date("M Y", strtotime('-1 month'));
		if($_GET['sendmail']==1){

		   //$mailto = 'sahapab.p@jasmine.com';
			$mailto = 'sermchai.l@jasmine.com,kwannaphat.f@jasmine.com,pathumthip.p@jasmine.com,thanet.c@ccs.jasmine.com';
			$subject = "=?UTF-8?B?".base64_encode($subject_mail)."?=";

			// Header
			$header = "From: Sermchai Luprasitthiworn <sermchai.l@jasmine.com>\r\n";
		   $header .= "Cc: radmin@3bbmail.com,aoi.n@jasmine.com\n";
			$header .= "MIME-Version: 1.0\r\n";
			$header .= "Content-Type: text/html; charset=UTF-8\r\n";
		   $header .= "Content-Transfer-Encoding: base64\r\n\r\n";

			$main_message .= chunk_split(base64_encode($email_body))."\r\n";

			// Execute
			mail($mailto, $subject, $main_message, $header);
			echo "<b>**********[SENDING EMAIL SUCCESSFULLY]**********</b><br>";
		}
	}
?>