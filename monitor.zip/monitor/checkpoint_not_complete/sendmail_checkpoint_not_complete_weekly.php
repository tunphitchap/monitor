<?php

	$start_date='';
	$end_date='';

	echo "<b>Checkpoint Not Complete Report (Weekly)</b><br>";
	echo "This Script Will Send Mail If [<i>weekly_report.log</i>] Contains Log = 15 Days<br>";
	
	//Count Line [weekly_report.log]
	if (!file_exists('/var/www/html/monitor/checkpoint_not_complete/weekly_report.log')) {
    exit("Error: [<i>weekly_report.log</i>] doesn't exist");
	}

	$linecount = 0;
	$handle = fopen('/var/www/html/monitor/checkpoint_not_complete/weekly_report.log', "r");
	while(!feof($handle)){
  		$line = fgets($handle);
  		$linecount++;
	}
	fclose($handle);
	$linecount--;
	echo "Day Count [<i>weekly_report.log</i>] = ".($linecount/2)."/15 Day"."<br><br>";

	if($linecount/2<15){
		//Show Only Don't Send Email
		echo "Status: Show Table Only (Not Sending Email)<br><br>";
	}
	elseif($linecount/2>=15){
		//Send Email
		$sendmail_status=true;
		echo "Check Date Status [Sat, Sun, Holiday]: ";

		$today=date("D");

		// 1. Check Is Day = Sat or Sun
		if($today=="Sat" || $today=="Sun"){
			echo "Not Send (Weekend)<br><br>";
			$sendmail_status=false;
		}

		// 2. Check Is Day = Holiday List
		 $con210 = mysqli_connect("10.11.11.210","root","password");
         if (!$con210) {
          die("Database connection failed: " . mysqli_error());
         }
         $db_select = mysqli_select_db($con210, "3bb_standby");
         if (!$db_select) {
            die("Database selection failed: " . mysqli_error());
         }
         mysqli_set_charset($con210, 'utf8');
         $sql=mysqli_query($con210, "SELECT * FROM holiday_calendar WHERE holiday_date='".date("Y-m-d", strtotime($GLOBALS['send_date']))."' LIMIT 1;");
         while ($result=mysqli_fetch_array($sql)) {
              $sendmail_status=false;
              echo $GLOBALS['send_date']." => Not Send (Holiday)<br>";
         }

		// If Status OK Set sendemail_status=true And Clear Log
		if($sendmail_status==true){
			echo "OK (Weekday)<br>";
			echo "Status: Clear <i>weekly_report.log</i> Successfully<br><br>";

		}
	}

	//Read Data From [weekly_report.log] And Write Table
	$table_body='';

	$fh = fopen('/var/www/html/monitor/checkpoint_not_complete/weekly_report.log','r');

	//Loop get only last 15 Days
	for($day_i=0;$day_i<15*2;$day_i++) {

		if($line = fgets($fh)){
		// Get 1st Line Date [Last Date]
		if($end_date==''){
			$end_date=substr($line, find_str_position($line,"[",1)+strlen("["),find_str_position($line,"]",1)-find_str_position($line,"[",1)-1);
			$end_date=date("d M Y",strtotime($end_date));
		}

  		if (strpos($line, 'DB1') == true) {
    		write_db1_row($line);
		}
		elseif (strpos($line, 'DB2') == true) {
    		write_db2_row($line);
		}

		// Collect Last Line Date [First Date]
		$start_date=substr($line, find_str_position($line,"[",1)+strlen("["),find_str_position($line,"]",1)-find_str_position($line,"[",1)-1);
		$start_date=date("d M Y",strtotime($start_date));
	}
  	}
	fclose($fh);

	$table_body_tmp=$table_body;
	write_table_header();
	$table_body=$table_body.$table_body_tmp;
	write_table_tail();
	write_email_signature();

	echo "<b>**********[START EMAIL PART]**********</b><br>";
	echo $table_body;
	echo "<br><b>**********[END EMAIL PART]**********</b><br>"; 
?>

<?php
	/// Send Email Part ///
	if($sendmail_status==true){
		$subject_mail="Weekly Report Checkpoint Not Complete ประจำวันที่ ".$start_date." – ".$end_date;
		if($_GET['sendmail']==1){
		   	// Mail To
		   	//$mailto = 'sahapab.p@jasmine.com';
			$mailto = 'sermchai.l@jasmine.com,kwannaphat.f@jasmine.com,pathumthip.p@jasmine.com,thanet.c@ccs.jasmine.com';

			$subject = "=?UTF-8?B?".base64_encode($subject_mail)."?=";

			// Header
			$header = "From: Sermchai Luprasitthiworn <sermchai.l@jasmine.com>\r\n";
		   	$header .= "Cc: radmin@3bbmail.com,aoi.n@jasmine.com\n";
			$header .= "MIME-Version: 1.0\r\n";
			$header .= "Content-Type: text/html; charset=UTF-8\r\n";
		   	$header .= "Content-Transfer-Encoding: base64\r\n\r\n";

			$main_message .= chunk_split(base64_encode($table_body))."\r\n";

			// Execute
			mail($mailto, $subject, $main_message, $header);
			echo "<b>**********[SENDING EMAIL SUCCESSFULLY]**********</b><br>";

			//Truncate Log File
			$handle = fopen ("/var/www/html/monitor/checkpoint_not_complete/weekly_report.log", "w+");
			fclose($handle);
		}
	}
?>

<!-- OTHER USEFUL FUNCTION -->
<?php
	function find_str_position($haystack, $needle, $number){
	    if($number == '1'){
	        return strpos($haystack, $needle);
	    }elseif($number > '1'){
	        return strpos($haystack, $needle, find_str_position($haystack, $needle, $number - 1) + strlen($needle));
	    }else{
	        return error_log('Error: Value for parameter $number is out of range');
	    }
	}
	function get_bg_cell($color){
		switch($color){
			case "grey":
				return "#bfbfbf";
			case "white":
				return "#ffffff";
		}
	}
    function get_day_color($day_abv){
    	switch($day_abv){
			case "Sun":
				return "#ff0000";
			case "Mon":
				return "#ffff00";
			case "Tue":
				return "#ff99cc";
			case "Wed":
				return "#92d050";
			case "Thu":
				return "#ffc000";
			case "Fri":
				return "#b8cce4";
			case "Sat":
				return "#b1a0c7";
		}
    }
    function str_replace_first($from, $to, $subject)
	{
    	$from = '/'.preg_quote($from, '/').'/';
    	return preg_replace($from, $to, $subject, 1);
	}
?>

<?php
	function write_email_intro(){
		$intro="    	
         <p>
            <b><span lang=TH style='font-size:12.0pt;font-family:\"Tahoma\",\"sans-serif\";color:#1F497D'>เรียน</span></b><b><span style='font-size:12.0pt;font-family:\"Tahoma\",\"sans-serif\";color:#1F497D'>&nbsp;<span lang=TH>ทุกท่านครับ</span></span></b>
            <span style='font-size:12.0pt;font-family:\"Tahoma\",\"sans-serif\";color:#1F497D'>
               <o:p></o:p>
            </span>
         </p>
         <p class=MsoNormal style='margin-bottom:14.0pt'>
            <span style='font-size:12.0pt;font-family:\"Tahoma\",\"sans-serif\";color:#1F497D'>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; <span lang=TH>Weekly Report </span>Checkpoint Not Complete <span lang=TH>ประจำ</span></span><span lang=TH style='font-size:12.0pt;font-family:\"Tahoma\",\"sans-serif\";color:#44546A'>วันที่ </span><span style='font-size:12.0pt;font-family:\"Tahoma\",\"sans-serif\";color:#44546A'>".$GLOBALS['start_date']." – ".$GLOBALS['end_date']."</span><span style='font-size:12.0pt;font-family:\"Tahoma\",\"sans-serif\";color:#1F497D'> <span lang=TH>รายละเอียดดังตารางครับ</span></span>
            <span style='font-size:14.0pt;font-family:\"Cordia New\",\"sans-serif\"'>
               <o:p></o:p>
            </span>
         </p>";
		return $intro;
	}

	function write_email_signature(){
		$GLOBALS['table_body'].="
       <p class=MsoNormal>
            <span lang=TH style='font-size:14.0pt;mso-ansi-font-size:11.0pt;font-family:\"Cordia New\",\"sans-serif\";mso-ascii-font-family:Calibri;mso-ascii-theme-font:minor-latin;mso-hansi-font-family:Calibri;mso-hansi-theme-font:minor-latin;mso-bidi-font-family:\"Cordia New\";mso-bidi-theme-font:minor-bidi;color:#1F497D'><br></span><span lang=TH style='font-size:12.0pt;font-family:\"Tahoma\",\"sans-serif\";color:#1F497D'><span style='mso-tab-count:1'>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </span>*หมายเหตุ : </span>
            <span lang=TH style='font-size:12.0pt;font-family:\"Tahoma\",\"sans-serif\";color:red'>
               เป็นระบบส่งอี<span class=SpellE>เมลล์</span>อัตโนมัติ<br><br style='mso-special-character:line-break'><![if !supportLineBreakNewLine]><br style='mso-special-character:line-break'><![endif]>
            </span>
            <span style='color:#1F497D'>
               <o:p></o:p>
            </span>
         </p>
        <p class=MsoNormal>
            <a name=\"_MailAutoSig\"><b><span lang=TH style='font-size:14.0pt;font-family:\"Leelawadee\",\"sans-serif\";mso-fareast-font-family:\"Times New Roman\";mso-fareast-theme-font:minor-fareast;color:#002060;mso-no-proof:yes'>ขอแสดงความนับถือ</span></b></a>
            <span style='mso-bookmark:_MailAutoSig'>
               <b>
                  <span style='font-size:14.0pt;font-family:\"Leelawadee\",\"sans-serif\";mso-fareast-font-family:\"Times New Roman\";mso-fareast-theme-font:minor-fareast;color:#002060;mso-no-proof:yes'>
                     <o:p></o:p>
                  </span>
               </b>
            </span>
        </p>
        <p class=MsoNormal>
            <span style='mso-bookmark:_MailAutoSig'><b><span style='font-size:8.0pt;font-family:\"Leelawadee\",\"sans-serif\";mso-fareast-font-family:\"Times New Roman\";mso-fareast-theme-font:minor-fareast;color:gray;mso-themecolor:background1;mso-themeshade:128;mso-no-proof:yes'>o</span></b></span><span style='mso-bookmark:_MailAutoSig'><b><span style='font-size:8.0pt;font-family:\"Leelawadee\",\"sans-serif\";mso-fareast-font-family:\"Times New Roman\";mso-fareast-theme-font:minor-fareast;color:gray;mso-no-proof:yes'>-o-o-o-o-o-o-o-o-o-o-o-o-o-o-o-o-o-o-o-o-o-o-o-o-o-o-o-o</span></b></span>
            <span style='mso-bookmark:_MailAutoSig'>
               <span style='font-size:8.0pt;font-family:\"Leelawadee\",\"sans-serif\";mso-fareast-font-family:\"Times New Roman\";mso-fareast-theme-font:minor-fareast;mso-no-proof:yes'>
                  <o:p></o:p>
               </span>
            </span>
        </p>
        <p class=MsoNormal>
            <span style='mso-bookmark:_MailAutoSig'><b><span lang=TH style='font-size:14.0pt;font-family:\"Leelawadee UI\",\"sans-serif\";mso-fareast-font-family:\"Times New Roman\";mso-fareast-theme-font:minor-fareast;color:#31849B;mso-no-proof:yes'><span style='mso-spacerun:yes'>&nbsp;&nbsp;&nbsp;&nbsp; </span></span></b></span><span style='mso-bookmark:_MailAutoSig'><b><span lang=TH style='font-size:12.0pt;font-family:\"Leelawadee UI\",\"sans-serif\";mso-fareast-font-family:\"Times New Roman\";mso-fareast-theme-font:minor-fareast;color:#E36C0A;mso-themecolor:accent6;mso-themeshade:191;mso-no-proof:yes'>เสริมชัย ลุประสิทธิวร</span></b></span>
            <span style='mso-bookmark:_MailAutoSig'>
               <b>
                  <span style='font-size:12.0pt;font-family:\"Leelawadee UI\",\"sans-serif\";mso-fareast-font-family:\"Times New Roman\";mso-fareast-theme-font:minor-fareast;color:#E36C0A;mso-themecolor:accent6;mso-themeshade:191;mso-no-proof:yes'>
                     <o:p></o:p>
                  </span>
               </b>
            </span>
        </p>
        <p class=MsoNormal>
            <span style='mso-bookmark:_MailAutoSig'>
               <b>
                  <span style='font-family:\"Leelawadee UI\",\"sans-serif\";mso-fareast-font-family:\"Times New Roman\";mso-fareast-theme-font:minor-fareast;color:#31849B;mso-no-proof:yes'>
                     <span style='mso-spacerun:yes'>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </span>E-Mail<span style='mso-spacerun:yes'>&nbsp;&nbsp; </span>:<span style='mso-spacerun:yes'>&nbsp;&nbsp; </span>sermchai.l@jasmine.com
                     <o:p></o:p>
                  </span>
               </b>
            </span>
        </p>
        <p class=MsoNormal>
            <span style='mso-bookmark:_MailAutoSig'>
               <b>
                  <span style='font-family:\"Leelawadee UI\",\"sans-serif\";mso-fareast-font-family:\"Times New Roman\";mso-fareast-theme-font:minor-fareast;color:#31849B;mso-no-proof:yes'>
                     <span style='mso-spacerun:yes'>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </span>Triple T Broadband PCL. [9th Floor]
                     <o:p></o:p>
                  </span>
               </b>
            </span>
        </p>
        <p class=MsoNormal>
            <span style='mso-bookmark:_MailAutoSig'><b><span style='font-size:8.0pt;font-family:\"Leelawadee\",\"sans-serif\";mso-fareast-font-family:\"Times New Roman\";mso-fareast-theme-font:minor-fareast;color:gray;mso-no-proof:yes'>o-o-o-o-o-o-o-o-o-o-o-o-o-o-o-o-o-o-o-o-o-o-o-o-o-o-o-o-o</span></b></span><span style='mso-bookmark:_MailAutoSig'></span>
            <b>
               <span style='mso-fareast-font-family:\"Times New Roman\";mso-fareast-theme-font:minor-fareast;color:gray;mso-no-proof:yes'>
                  <o:p></o:p>
               </span>
            </b>
        </p>
      </div>
   	</body>
	</html>";
	}

	function write_db1_row($line){
		//Get Date
		$date=substr($line,find_str_position($line,"[",1)+1,find_str_position($line,"]",1)-find_str_position($line,"[",1)-1);		

		//Format Date
		$day_abv=date("D", strtotime(str_replace("/","-",$date)));
		$date=getdate_format(str_replace("-","/",$date));

		//Get db1_count
		if (strpos($line, '[null]') == true) {
    		$db1_count='-';
		}
		else{
			$db1_count="<b>".substr($line,find_str_position($line,"[DB1=",1)+5,find_str_position($line,"]",2)-find_str_position($line,"[DB1=",1)-5)."</b>";
		}

		//Get Cell Background Color
		if($db1_count=='-')
			$bg_cell="grey";
		else
			$bg_cell="white";


		//Find Rowspan Value
		$time_series=substr($line,find_str_position($line,"[",3)+1,find_str_position($line,"]",3)-find_str_position($line,"[",3)-1);
		if($time_series=='null'){
			//No Checkpoint Not Complete [Rowspan = 1]
			$max_rowspan=1;
		}
		else{
			//Find Rowspan Value
			if($db1_count=='<b>1</b>'){
				//Checkpoint Not Complete Count == 1 [Rowspan = 1]
				$max_rowspan=1;
			}
			else{
				$time_series.=",";
				$time_array= array();
				//Checkpoint Not Complete Count > 1 [Find Max Rowspan]
				$db1_count_tmp=str_replace("<b>","",$db1_count);
				$db1_count_tmp=str_replace("</b>","",$db1_count_tmp);

				for($i=0;$i<$db1_count_tmp;$i++){
					$time=date("G",strtotime(substr($time_series,0,find_str_position($time_series,",",1))));
					$time_array[]=$time;

					//Remove And Goto Next Time
					$time_series=substr($time_series,find_str_position($time_series,",",1)+1);
				}
				$max_rowspan=max(array_count_values($time_array));
			}		
		}

			//Table Body
			$GLOBALS['table_body'].="<tr style='mso-yfti-irow:1;height:14.25pt'>
            	<!-- ROW 1: DATE ABV. -->
               	<td nowrap rowspan=".$max_rowspan." valign=top style='width:35.0pt;border-top:none;border-left:solid windowtext 1.0pt;border-bottom:solid black 1.0pt;border-right:solid windowtext 1.0pt;mso-border-left-alt:solid windowtext .5pt;mso-border-bottom-alt:solid black .5pt;mso-border-right-alt:solid windowtext .5pt;background:".get_day_color($day_abv).";padding:0cm 5.4pt 0cm 5.4pt;height:14.25pt'>
                  <p class=MsoNormal>
                     <span style='font-size:10.0pt;font-family:\"Tahoma\",\"sans-serif\";mso-fareast-font-family:\"Times New Roman\";color:black'>
                        ".$day_abv."
                        <o:p></o:p>
                     </span>
                  </p>
               </td>

               <!-- ROW 1: DATE [01-01-2017] -->
               <td nowrap rowspan=".$max_rowspan." valign=top style='width:65.0pt;border-top:none;border-left:none;border-bottom:solid black 1.0pt;border-right:solid windowtext 1.0pt;mso-border-left-alt:solid windowtext .5pt;mso-border-left-alt:solid windowtext .5pt;mso-border-bottom-alt:solid black .5pt;mso-border-right-alt:solid windowtext .5pt;background:".get_day_color($day_abv).";padding:0cm 5.4pt 0cm 5.4pt;height:14.25pt'>
                  <p class=MsoNormal align=center style='text-align:center'>
                     <span style='font-size:10.0pt;font-family:\"Tahoma\",\"sans-serif\";mso-fareast-font-family:\"Times New Roman\";color:black'>
                        ".$date."
                        <o:p></o:p>
                     </span>
                  </p>
               </td>

               <!-- ROW 1: DB1 CHECKPOINT COUNT -->
               <td nowrap rowspan=".$max_rowspan." style='border-top:none;border-left:none;border-bottom:solid black 1.0pt;border-right:solid windowtext 1.0pt;mso-border-left-alt:solid windowtext .5pt;mso-border-left-alt:solid windowtext .5pt;mso-border-bottom-alt:solid black .5pt;mso-border-right-alt:solid windowtext .5pt;background:".get_bg_cell($bg_cell).";padding:0cm 5.4pt 0cm 5.4pt;height:14.25pt'>
                  <p class=MsoNormal align=center style='text-align:center'>
                     <b>
                        <span style='font-size:10.0pt;font-family:\"Tahoma\",\"sans-serif\";mso-fareast-font-family:\"Times New Roman\";color:black'>
                           ".$db1_count."
                           <o:p></o:p>
                        </span>
                     </b>
                  </p>
               </td>

               <!-- ROW 1: DB1 LABEL -->
               <td nowrap rowspan=".$max_rowspan." style='border-top:none;border-left:none;border-bottom:solid black 1.0pt;border-right:solid windowtext 1.0pt;mso-border-left-alt:solid windowtext .5pt;mso-border-left-alt:solid windowtext .5pt;mso-border-bottom-alt:solid black .5pt;mso-border-right-alt:solid windowtext .5pt;background:".get_bg_cell($bg_cell).";padding:0cm 5.4pt 0cm 5.4pt;height:14.25pt'>
                  <p class=MsoNormal align=center style='text-align:center'>
                     <b>
                        <span style='font-size:10.0pt;font-family:\"Tahoma\",\"sans-serif\";mso-fareast-font-family:\"Times New Roman\";color:black'>
                           DB1
                           <o:p></o:p>
                        </span>
                     </b>
                  </p>
               </td>";

        	// ROW 1: CHECKPOINT AREA [00-23]
        	if($db1_count=='-'){
        	//No Checkpoint Not Complete
        	for($i=0;$i<24;$i++){
        		$GLOBALS['table_body'].="
               <td nowrap style='border-top:none;border-left:none;border-bottom:solid windowtext 1.0pt;border-right:solid windowtext 1.0pt;mso-border-bottom-alt:solid windowtext .5pt;mso-border-right-alt:solid windowtext .5pt;background:".get_bg_cell($bg_cell).";padding:0cm 5.4pt 0cm 5.4pt;height:14.25pt'>
                  <p class=MsoNormal align=center style='text-align:center'>
                     <span style='font-size:8.5pt;font-family:\"Tahoma\",\"sans-serif\";mso-fareast-font-family:\"Times New Roman\";color:black'>
                        &nbsp;
                        <o:p></o:p>
                     </span>
                  </p>
               </td>";
           		}
           		// Close Line
           		$GLOBALS['table_body'].="</tr>";
           		goto end_write_db1;
        	}


        	if($db_count!='-'){
        		//Found Checkpoint Not Complete
        		if($max_rowspan==1){
        			for($i=0;$i<24;$i++){
        				if (strpos($line, '['.$i.':') == true) {
        					// Assign Checkpoint Time
    					$GLOBALS['table_body'].="
               		<td nowrap style='border-top:none;border-left:none;border-bottom:solid windowtext 1.0pt;border-right:solid windowtext 1.0pt;mso-border-bottom-alt:solid windowtext .5pt;mso-border-right-alt:solid windowtext .5pt;background:".get_day_color($day_abv).";padding:0cm 5.4pt 0cm 5.4pt;height:14.25pt'>
                  	<p class=MsoNormal align=center style='text-align:center'>
                     <span style='font-size:8.5pt;font-family:\"Tahoma\",\"sans-serif\";mso-fareast-font-family:\"Times New Roman\";color:black'>
                        ".$i.":".substr($line,find_str_position($line,$i.":",1)+1+strlen($i),2)."
                        <o:p></o:p>
                     </span>
                  	</p>
               		</td>";
						}
						else{
							// Blank
						$GLOBALS['table_body'].="
               		<td nowrap style='border-top:none;border-left:none;border-bottom:solid windowtext 1.0pt;border-right:solid windowtext 1.0pt;mso-border-bottom-alt:solid windowtext .5pt;mso-border-right-alt:solid windowtext .5pt;background:".get_day_color("white").";padding:0cm 5.4pt 0cm 5.4pt;height:14.25pt'>
                  	<p class=MsoNormal align=center style='text-align:center'>
                     <span style='font-size:8.5pt;font-family:\"Tahoma\",\"sans-serif\";mso-fareast-font-family:\"Times New Roman\";color:black'>
                        &nbsp
                        <o:p></o:p>
                     </span>
                  	</p>
               		</td>";
						}
           			}
           				// Close Line
           				$GLOBALS['table_body'].="</tr>";
        		}
        		else{
        			// Use For Fill Rowspan On Last Timeseries For These Hour
        			$rowspan_use=array();

        			$duplicate_hour_item=array();
        			// Count Duplicate Hour Value If Duplicate == 1 Use rowspan = max_span 
        			$line_tmp=str_replace("[","[,",$line);
        			for($i=0;$i<24;$i++){
        				$duplicate_hour_item[$i]=substr_count($line_tmp, ','.$i.':');
        			}

        			//1st Loop
        			for($i=0;$i<24;$i++){
        				if($duplicate_hour_item[$i]==0){
        					// Blank And Rowspan = MAX
        					$GLOBALS['table_body'].="
               		<td nowrap rowspan=".$max_rowspan." style='border-top:none;border-left:none;border-bottom:solid windowtext 1.0pt;border-right:solid windowtext 1.0pt;mso-border-bottom-alt:solid windowtext .5pt;mso-border-right-alt:solid windowtext .5pt;background:".get_day_color("white").";padding:0cm 5.4pt 0cm 5.4pt;height:14.25pt'>
                  	<p class=MsoNormal align=center style='text-align:center'>
                     <span style='font-size:8.5pt;font-family:\"Tahoma\",\"sans-serif\";mso-fareast-font-family:\"Times New Roman\";color:black'>
                        &nbsp
                        <o:p></o:p>
                     </span>
                  	</p>
               		</td>";
        				}
        				else{
        					if($duplicate_hour_item[$i]!=0){
        						if($duplicate_hour_item[$i]==1){$rs=$max_rowspan;}
        						else{$rs=1;}

        				$GLOBALS['table_body'].="
               		<td nowrap rowspan=".$rs." style='border-top:none;border-left:none;border-bottom:solid windowtext 1.0pt;border-right:solid windowtext 1.0pt;mso-border-bottom-alt:solid windowtext .5pt;mso-border-right-alt:solid windowtext .5pt;background:".get_day_color($day_abv).";padding:0cm 5.4pt 0cm 5.4pt;height:14.25pt'>
                  	<p class=MsoNormal align=center style='text-align:center'>
                     <span style='font-size:8.5pt;font-family:\"Tahoma\",\"sans-serif\";mso-fareast-font-family:\"Times New Roman\";color:black'>
                        ".$i.":".substr($line_tmp,find_str_position($line_tmp,$i.":",1)+1+strlen($i),2)."
                        <o:p></o:p>
                     </span>
                  	</p>
               		</td>";

               		// Increment Rowspan Use
               		$rowspan_use[$i]++;

               		//Remove From time_series
 					$line_tmp=str_replace_first(",".$i.":".substr($line_tmp,find_str_position($line_tmp,",".$i.":",1)+strlen(",:")+strlen($i),2), '', $line_tmp); 
        					}

        				}
        			}
        				// Close Line
           				$GLOBALS['table_body'].="</tr>";


        			//Loop Until Time Series Empty [Try With Rowspan = 1]
        			while(strpos($line_tmp, ':') == true) {
        				$GLOBALS['table_body'].="<tr style='mso-yfti-irow:1;mso-yfti-lastrow:yes;height:14.25pt'>";
        				for($i=0;$i<24;$i++){
        					if (strpos($line_tmp, ",".$i.":") == true) {

        					//Check Rowspan Space
        					if($rowspan_use[$i]+1==$duplicate_hour_item[$i]){
        						// The Last One => Fill Rowspan
        						$rowspan=$max_rowspan-$rowspan_use[$i];
        					}
        					else{
        						// Not the Last One => Do Nothing And Increment $rowspan_use
        						$rowspan=1;
        						$rowspan_use[$i]++;
        					}

        					$GLOBALS['table_body'].="
               		<td nowrap rowspan=".$rowspan." style='border-top:none;border-left:none;border-bottom:solid windowtext 1.0pt;border-right:solid windowtext 1.0pt;mso-border-bottom-alt:solid windowtext .5pt;mso-border-right-alt:solid windowtext .5pt;background:".get_day_color($day_abv).";padding:0cm 5.4pt 0cm 5.4pt;height:14.25pt'>
                  	<p class=MsoNormal align=center style='text-align:center'>
                     <span style='font-size:8.5pt;font-family:\"Tahoma\",\"sans-serif\";mso-fareast-font-family:\"Times New Roman\";color:black'>
                        ".$i.":".substr($line_tmp,find_str_position($line_tmp,",".$i.":",1)+strlen(",:")+strlen($i),2)."
                        <o:p></o:p>
                     </span>
                  	</p>
               		</td>";

               				//Remove From time_series
 							$line_tmp=str_replace_first(",".$i.":".substr($line_tmp,find_str_position($line_tmp,",".$i.":",1)+strlen(",:")+strlen($i),2), '', $line_tmp);			
        					}
        				}
        				//End For Loop
        				$GLOBALS['table_body'].="</tr>";
        			}
        		}
        	}
       	end_write_db1:
        
	}

	function write_db2_row($line){
		//Get Date
		$date=substr($line,find_str_position($line,"[",1)+1,find_str_position($line,"]",1)-find_str_position($line,"[",1)-1);		

		//Format Date
		$day_abv=date("D", strtotime(str_replace("/","-",$date)));
		$date=getdate_format(str_replace("-","/",$date));

		//Get db2_count
		if (strpos($line, '[null]') == true) {
    		$db2_count='-';
		}
		else{
			$db2_count="<b>".substr($line,find_str_position($line,"[DB2=",1)+5,find_str_position($line,"]",2)-find_str_position($line,"[DB2=",1)-5)."</b>";
		}

		//Get Cell Background Color
		if($db2_count=='-')
			$bg_cell="grey";
		else
			$bg_cell="white";


		//Find Rowspan Value
		$time_series=substr($line,find_str_position($line,"[",3)+1,find_str_position($line,"]",3)-find_str_position($line,"[",3)-1);
		if($time_series=='null'){
			//No Checkpoint Not Complete [Rowspan = 1]
			$max_rowspan=1;
		}
		else{
			//Find Rowspan Value
			if($db2_count=='<b>1</b>'){
				//Checkpoint Not Complete Count == 1 [Rowspan = 1]
				$max_rowspan=1;
			}
			else{
				$time_series.=",";
				$time_array= array();
				//Checkpoint Not Complete Count > 1 [Find Max Rowspan]
				$db2_count_tmp=str_replace("<b>","",$db2_count);
				$db2_count_tmp=str_replace("</b>","",$db2_count_tmp);

				for($i=0;$i<$db2_count_tmp;$i++){
					$time=date("G",strtotime(substr($time_series,0,find_str_position($time_series,",",1))));
					$time_array[]=$time;

					//Remove And Goto Next Time
					$time_series=substr($time_series,find_str_position($time_series,",",1)+1);
				}
				$max_rowspan=max(array_count_values($time_array));
			}		
		}

		//Table Body
		$GLOBALS['table_body'].="<tr style='mso-yfti-irow:1;height:14.25pt'>
            	<!-- ROW 2: DATE ABV. [BLANK]-->
               	<td nowrap rowspan=".$max_rowspan." valign=top style='width:35.0pt;border-top:none;border-left:solid windowtext 1.0pt;border-bottom:solid black 1.0pt;border-right:solid windowtext 1.0pt;mso-border-left-alt:solid windowtext .5pt;mso-border-bottom-alt:solid black .5pt;mso-border-right-alt:solid windowtext .5pt;background:".get_day_color("white").";padding:0cm 5.4pt 0cm 5.4pt;height:14.25pt'>
                  <p class=MsoNormal>
                     <span style='font-size:10.0pt;font-family:\"Tahoma\",\"sans-serif\";mso-fareast-font-family:\"Times New Roman\";color:black'>
                        &nbsp
                        <o:p></o:p>
                     </span>
                  </p>
               </td>

               <!-- ROW 2: DATE [01-01-2017] [BLANK]-->
               <td nowrap rowspan=".$max_rowspan." valign=top style='width:65.0pt;border-top:none;border-left:none;border-bottom:solid black 1.0pt;border-right:solid windowtext 1.0pt;mso-border-left-alt:solid windowtext .5pt;mso-border-left-alt:solid windowtext .5pt;mso-border-bottom-alt:solid black .5pt;mso-border-right-alt:solid windowtext .5pt;background:".get_day_color("white").";padding:0cm 5.4pt 0cm 5.4pt;height:14.25pt'>
                  <p class=MsoNormal align=center style='text-align:center'>
                     <span style='font-size:10.0pt;font-family:\"Tahoma\",\"sans-serif\";mso-fareast-font-family:\"Times New Roman\";color:black'>
                        &nbsp
                        <o:p></o:p>
                     </span>
                  </p>
               </td>

               <!-- ROW 2: DB2 CHECKPOINT COUNT -->
               <td nowrap rowspan=".$max_rowspan." style='border-top:none;border-left:none;border-bottom:solid black 1.0pt;border-right:solid windowtext 1.0pt;mso-border-left-alt:solid windowtext .5pt;mso-border-left-alt:solid windowtext .5pt;mso-border-bottom-alt:solid black .5pt;mso-border-right-alt:solid windowtext .5pt;background:".get_bg_cell($bg_cell).";padding:0cm 5.4pt 0cm 5.4pt;height:14.25pt'>
                  <p class=MsoNormal align=center style='text-align:center'>
                     <b>
                        <span style='font-size:10.0pt;font-family:\"Tahoma\",\"sans-serif\";mso-fareast-font-family:\"Times New Roman\";color:black'>
                           ".$db2_count."
                           <o:p></o:p>
                        </span>
                     </b>
                  </p>
               </td>

       		<!-- ROW 2: DB2 LABEL -->
               <td nowrap rowspan=".$max_rowspan." style='border-top:none;border-left:none;border-bottom:solid black 1.0pt;border-right:solid windowtext 1.0pt;mso-border-left-alt:solid windowtext .5pt;mso-border-left-alt:solid windowtext .5pt;mso-border-bottom-alt:solid black .5pt;mso-border-right-alt:solid windowtext .5pt;background:".get_bg_cell($bg_cell).";padding:0cm 5.4pt 0cm 5.4pt;height:14.25pt'>
                  <p class=MsoNormal align=center style='text-align:center'>
                     <b>
                        <span style='font-size:10.0pt;font-family:\"Tahoma\",\"sans-serif\";mso-fareast-font-family:\"Times New Roman\";color:black'>
                           DB2
                           <o:p></o:p>
                        </span>
                     </b>
                  </p>
               </td>";

        // ROW 2: CHECKPOINT AREA [00-23]
        	if($db2_count=='-'){
        	//No Checkpoint Not Complete
        	for($i=0;$i<24;$i++){
        		$GLOBALS['table_body'].="
               <td nowrap style='border-top:none;border-left:none;border-bottom:solid windowtext 1.0pt;border-right:solid windowtext 1.0pt;mso-border-bottom-alt:solid windowtext .5pt;mso-border-right-alt:solid windowtext .5pt;background:".get_bg_cell($bg_cell).";padding:0cm 5.4pt 0cm 5.4pt;height:14.25pt'>
                  <p class=MsoNormal align=center style='text-align:center'>
                     <span style='font-size:8.5pt;font-family:\"Tahoma\",\"sans-serif\";mso-fareast-font-family:\"Times New Roman\";color:black'>
                        &nbsp;
                        <o:p></o:p>
                     </span>
                  </p>
               </td>";
           		}
           		// Close Line
           		$GLOBALS['table_body'].="</tr>";
           		goto end_write_db2;
        	}


        	if($db_count!='-'){
        		//Found Checkpoint Not Complete
        		if($max_rowspan==1){
        			for($i=0;$i<24;$i++){
        				if (strpos($line, '['.$i.':') == true) {
        					// Assign Checkpoint Time
    					$GLOBALS['table_body'].="
               		<td nowrap style='border-top:none;border-left:none;border-bottom:solid windowtext 1.0pt;border-right:solid windowtext 1.0pt;mso-border-bottom-alt:solid windowtext .5pt;mso-border-right-alt:solid windowtext .5pt;background:".get_day_color($day_abv).";padding:0cm 5.4pt 0cm 5.4pt;height:14.25pt'>
                  	<p class=MsoNormal align=center style='text-align:center'>
                     <span style='font-size:8.5pt;font-family:\"Tahoma\",\"sans-serif\";mso-fareast-font-family:\"Times New Roman\";color:black'>
                        ".$i.":".substr($line,find_str_position($line,$i.":",1)+strlen(":")+strlen($i),2)."
                        <o:p></o:p>
                     </span>
                  	</p>
               		</td>";
						}
						else{
							// Blank
						$GLOBALS['table_body'].="
               		<td nowrap style='border-top:none;border-left:none;border-bottom:solid windowtext 1.0pt;border-right:solid windowtext 1.0pt;mso-border-bottom-alt:solid windowtext .5pt;mso-border-right-alt:solid windowtext .5pt;background:".get_day_color("white").";padding:0cm 5.4pt 0cm 5.4pt;height:14.25pt'>
                  	<p class=MsoNormal align=center style='text-align:center'>
                     <span style='font-size:8.5pt;font-family:\"Tahoma\",\"sans-serif\";mso-fareast-font-family:\"Times New Roman\";color:black'>
                        &nbsp
                        <o:p></o:p>
                     </span>
                  	</p>
               		</td>";
						}
           			}
           				// Close Line
           				$GLOBALS['table_body'].="</tr>";
        		}
        		else{
        			// Use For Fill Rowspan On Last Timeseries For These Hour
        			$rowspan_use=array();

        			$duplicate_hour_item=array();
        			// Count Duplicate Hour Value If Duplicate == 1 Use rowspan = max_span 
        			$line_tmp=str_replace("[","[,",$line);
        			for($i=0;$i<24;$i++){
        				$duplicate_hour_item[$i]=substr_count($line_tmp, ','.$i.':');
        			}

        			//1st Loop
        			for($i=0;$i<24;$i++){
        				if($duplicate_hour_item[$i]==0){
        					// Blank And Rowspan = MAX
        					$GLOBALS['table_body'].="
               		<td nowrap rowspan=".$max_rowspan." style='border-top:none;border-left:none;border-bottom:solid windowtext 1.0pt;border-right:solid windowtext 1.0pt;mso-border-bottom-alt:solid windowtext .5pt;mso-border-right-alt:solid windowtext .5pt;background:".get_day_color("white").";padding:0cm 5.4pt 0cm 5.4pt;height:14.25pt'>
                  	<p class=MsoNormal align=center style='text-align:center'>
                     <span style='font-size:8.5pt;font-family:\"Tahoma\",\"sans-serif\";mso-fareast-font-family:\"Times New Roman\";color:black'>
                        &nbsp
                        <o:p></o:p>
                     </span>
                  	</p>
               		</td>";
        				}
        				else{
        					if($duplicate_hour_item[$i]!=0){
        						if($duplicate_hour_item[$i]==1){$rs=$max_rowspan;}
        						else{$rs=1;}

        				$GLOBALS['table_body'].="
               		<td nowrap rowspan=".$rs." style='border-top:none;border-left:none;border-bottom:solid windowtext 1.0pt;border-right:solid windowtext 1.0pt;mso-border-bottom-alt:solid windowtext .5pt;mso-border-right-alt:solid windowtext .5pt;background:".get_day_color($day_abv).";padding:0cm 5.4pt 0cm 5.4pt;height:14.25pt'>
                  	<p class=MsoNormal align=center style='text-align:center'>
                     <span style='font-size:8.5pt;font-family:\"Tahoma\",\"sans-serif\";mso-fareast-font-family:\"Times New Roman\";color:black'>
                        ".$i.":".substr($line_tmp,find_str_position($line_tmp,$i.":",1)+1+strlen($i),2)."
                        <o:p></o:p>
                     </span>
                  	</p>
               		</td>";

               		// Increment Rowspan Use
               		$rowspan_use[$i]++;

               		//Remove From time_series
 					$line_tmp=str_replace_first(",".$i.":".substr($line_tmp,find_str_position($line_tmp,",".$i.":",1)+strlen(",:")+strlen($i),2), '', $line_tmp); 
        					}

        				}
        			}
        				// Close Line
           				$GLOBALS['table_body'].="</tr>";


        			//Loop Until Time Series Empty [Try With Rowspan = 1]
        			while(strpos($line_tmp, ':') == true) {
        				$GLOBALS['table_body'].="<tr style='mso-yfti-irow:1;mso-yfti-lastrow:yes;height:14.25pt'>";
        				for($i=0;$i<24;$i++){
        					if (strpos($line_tmp, ",".$i.":") == true) {

        					//Check Rowspan Space
        					if($rowspan_use[$i]+1==$duplicate_hour_item[$i]){
        						// The Last One => Fill Rowspan
        						$rowspan=$max_rowspan-$rowspan_use[$i];
        					}
        					else{
        						// Not the Last One => Do Nothing And Increment $rowspan_use
        						$rowspan=1;
        						$rowspan_use[$i]++;
        					}

        					$GLOBALS['table_body'].="
               		<td nowrap rowspan=".$rowspan." style='border-top:none;border-left:none;border-bottom:solid windowtext 1.0pt;border-right:solid windowtext 1.0pt;mso-border-bottom-alt:solid windowtext .5pt;mso-border-right-alt:solid windowtext .5pt;background:".get_day_color($day_abv).";padding:0cm 5.4pt 0cm 5.4pt;height:14.25pt'>
                  	<p class=MsoNormal align=center style='text-align:center'>
                     <span style='font-size:8.5pt;font-family:\"Tahoma\",\"sans-serif\";mso-fareast-font-family:\"Times New Roman\";color:black'>
                        ".$i.":".substr($line_tmp,find_str_position($line_tmp,",".$i.":",1)+strlen(",:")+strlen($i),2)."
                        <o:p></o:p>
                     </span>
                  	</p>
               		</td>";

               				//Remove From time_series
 							$line_tmp=str_replace_first(",".$i.":".substr($line_tmp,find_str_position($line_tmp,",".$i.":",1)+strlen(",:")+strlen($i),2), '', $line_tmp);			
        					}
        				}
        				//End For Loop
        				$GLOBALS['table_body'].="</tr>";
        			}
        		}
        	}
        end_write_db2:
	}

	function write_table_header(){
		$GLOBALS['table_body']="<!-- TABLE PART -->
		<!-- INTRO & DEFINITIONS PART -->
		<html xmlns:v=\"urn:schemas-microsoft-com:vml\" xmlns:o=\"urn:schemas-microsoft-com:office:office\" xmlns:w=\"urn:schemas-microsoft-com:office:word\" xmlns:x=\"urn:schemas-microsoft-com:office:excel\" xmlns:m=\"http://schemas.microsoft.com/office/2004/12/omml\" xmlns=\"http://www.w3.org/TR/REC-html40\">
	<head>
    	<meta http-equiv=Content-Type content=\"text/html; charset=windows-874\">
    	<meta name=ProgId content=Word.Document>
    	<meta name=Generator content=\"Microsoft Word 14\">
    	<meta name=Originator content=\"Microsoft Word 14\">
    	<link rel=File-List href=\"cid:filelist.xml@01D37807.55E854F0\">
    	<link rel=themeData href=\"~~themedata~~\">
    	<link rel=colorSchemeMapping href=\"~~colorschememapping~~\">
    	<style>
        	<!--
            /* Font Definitions */
            @font-face
            	{font-family:\"Cordia New\";
            	panose-1:2 11 3 4 2 2 2 2 2 4;
            	mso-font-charset:0;
            	mso-generic-font-family:swiss;
            	mso-font-pitch:variable;
            	mso-font-signature:-2130706429 0 0 0 65537 0;}
            @font-face
            	{font-family:\"Cordia New\";
            	panose-1:2 11 3 4 2 2 2 2 2 4;
            	mso-font-charset:0;
            	mso-generic-font-family:swiss;
            	mso-font-pitch:variable;
            	mso-font-signature:-2130706429 0 0 0 65537 0;}
            @font-face
            	{font-family:Calibri;
            	panose-1:2 15 5 2 2 2 4 3 2 4;
            	mso-font-charset:0;
            	mso-generic-font-family:swiss;
            	mso-font-pitch:variable;
            	mso-font-signature:-536859905 -1073732485 9 0 511 0;}
            @font-face
            	{font-family:Tahoma;
            	panose-1:2 11 6 4 3 5 4 4 2 4;
            	mso-font-charset:0;
            	mso-generic-font-family:swiss;
            	mso-font-pitch:variable;
            	mso-font-signature:-520081665 -1073717157 41 0 66047 0;}
            /* Style Definitions */
            p.MsoNormal, li.MsoNormal, div.MsoNormal
            	{mso-style-unhide:no;
            	mso-style-qformat:yes;
            	mso-style-parent:\"\";
            	margin:0cm;
            	margin-bottom:.0001pt;
            	mso-pagination:widow-orphan;
            	font-size:11.0pt;
            	mso-bidi-font-size:14.0pt;
            	font-family:\"Calibri\",\"sans-serif\";
            	mso-ascii-font-family:Calibri;
            	mso-ascii-theme-font:minor-latin;
            	mso-fareast-font-family:Calibri;
            	mso-fareast-theme-font:minor-latin;
            	mso-hansi-font-family:Calibri;
            	mso-hansi-theme-font:minor-latin;
            	mso-bidi-font-family:\"Cordia New\";
            	mso-bidi-theme-font:minor-bidi;}
            a:link, span.MsoHyperlink
            	{mso-style-noshow:yes;
            	mso-style-priority:99;
            	color:blue;
            	mso-themecolor:hyperlink;
            	text-decoration:underline;
            	text-underline:single;}
            a:visited, span.MsoHyperlinkFollowed
            	{mso-style-noshow:yes;
            	mso-style-priority:99;
            	color:purple;
            	mso-themecolor:followedhyperlink;
            	text-decoration:underline;
            	text-underline:single;}
            span.17
            	{mso-style-type:personal-compose;
            	mso-style-noshow:yes;
            	mso-style-unhide:no;
            	mso-ansi-font-size:11.0pt;
            	mso-bidi-font-size:14.0pt;
            	font-family:\"Calibri\",\"sans-serif\";
            	mso-ascii-font-family:Calibri;
            	mso-ascii-theme-font:minor-latin;
            	mso-fareast-font-family:Calibri;
            	mso-fareast-theme-font:minor-latin;
            	mso-hansi-font-family:Calibri;
            	mso-hansi-theme-font:minor-latin;
            	mso-bidi-font-family:\"Cordia New\";
            	mso-bidi-theme-font:minor-bidi;
            	color:windowtext;}
            .MsoChpDefault
            	{mso-style-type:export-only;
            	mso-default-props:yes;
            	font-family:\"Calibri\",\"sans-serif\";
            	mso-ascii-font-family:Calibri;
            	mso-ascii-theme-font:minor-latin;
            	mso-fareast-font-family:Calibri;
            	mso-fareast-theme-font:minor-latin;
            	mso-hansi-font-family:Calibri;
            	mso-hansi-theme-font:minor-latin;
            	mso-bidi-font-family:\"Cordia New\";
            	mso-bidi-theme-font:minor-bidi;}
            @page WordSection1
            	{size:612.0pt 792.0pt;
            	margin:72.0pt 72.0pt 72.0pt 72.0pt;
            	mso-header-margin:36.0pt;
            	mso-footer-margin:36.0pt;
            	mso-paper-source:0;}
            div.WordSection1
            	{page:WordSection1;}
            -->
      	</style>
   	</head>
   	<body lang=EN-US link=blue vlink=purple style='tab-interval:36.0pt'>
    	<div class=WordSection1>
    	".write_email_intro()."
        <table class=MsoNormalTable border=0 cellspacing=0 cellpadding=0 style='width:940.0pt;margin-left:-1.15pt;border-collapse:collapse;mso-yfti-tbllook:1184;mso-padding-alt:0cm 5.4pt 0cm 5.4pt'>
            <tr style='mso-yfti-irow:0;mso-yfti-firstrow:yes;height:25.5pt'>
            	<!-- HEADER: DATE -->
               	<td colspan=2 valign=top style='border:solid windowtext 1.0pt;mso-border-alt:solid windowtext .5pt;background:#DCE6F1;padding:0cm 5.4pt 0cm 5.4pt;height:25.5pt'>
                  <p class=MsoNormal align=center style='text-align:center'>
                     <b>
                        <span style='font-size:10.0pt;font-family:\"Tahoma\",\"sans-serif\";mso-fareast-font-family:\"Times New Roman\";color:black'>
                           Date
                           <o:p></o:p>
                        </span>
                     </b>
                  </p>
               	</td>

               	<!-- HEADER: TOTAL CHECKPOINT NOT COMPLETE -->
               	<td valign=top style='width:90.0pt;border:solid windowtext 1.0pt;border-left:none;mso-border-top-alt:solid windowtext .5pt;mso-border-bottom-alt:solid windowtext .5pt;mso-border-right-alt:solid windowtext .5pt;background:#DCE6F1;padding:0cm 5.4pt 0cm 5.4pt;height:25.5pt'>
                  <p class=MsoNormal align=center style='text-align:center'>
                     <b>
                        <span style='font-size:10.0pt;font-family:\"Tahoma\",\"sans-serif\";mso-fareast-font-family:\"Times New Roman\";color:black'>
                           Total Checkpoint Not Complete
                           <o:p></o:p>
                        </span>
                     </b>
                  </p>
               	</td>

            	<!-- HEADER: DB -->
               	<td valign=top style='width:30.0pt;border:solid windowtext 1.0pt;border-left:none;mso-border-top-alt:solid windowtext .5pt;mso-border-bottom-alt:solid windowtext .5pt;mso-border-right-alt:solid windowtext .5pt;background:#DCE6F1;padding:0cm 5.4pt 0cm 5.4pt;height:25.5pt'>
                  <p class=MsoNormal align=center style='text-align:center'>
                     <b>
                        <span style='font-size:10.0pt;font-family:\"Tahoma\",\"sans-serif\";mso-fareast-font-family:\"Times New Roman\";color:black'>
                           DB
                           <o:p></o:p>
                        </span>
                     </b>
                  </p>
               </td>
            	<!-- HEADER: HOURS [00-23] -->";

            for ($i=0;$i<24;$i++){
            	$GLOBALS['table_body'].="
               	<td valign=top style='width:30.0pt;border:solid windowtext 1.0pt;border-left:none;mso-border-top-alt:solid windowtext .5pt;mso-border-bottom-alt:solid windowtext .5pt;mso-border-right-alt:solid windowtext .5pt;background:#DCE6F1;padding:0cm 5.4pt 0cm 5.4pt;height:25.5pt'>
                  <p class=MsoNormal align=center style='text-align:center'>
                     <b>
                        <span style='font-size:10.0pt;font-family:\"Tahoma\",\"sans-serif\";mso-fareast-font-family:\"Times New Roman\";color:black'>
                           ".sprintf( '%02d', $i )."
                           <o:p></o:p>
                        </span>
                     </b>
                  </p>
               	</td>";
            }	
            $GLOBALS['table_body'].="</tr>";
	}

	function write_table_tail(){
		$GLOBALS['table_body'].="
            </tr>
			</table>
      </div>";
	}

	function getdate_format($date){	
		//Example Return "27-พ.ค.-16";
		$month_abv=intval(date("m", strtotime(str_replace("/","-",$date))));
		switch($month_abv){
			case 1:
				$month_abv='ม.ค.';
				break;
			case 2:
				$month_abv='ก.พ.';
				break;
			case 3:
				$month_abv='มี.ค.';
				break;
			case 4:
				$month_abv='เม.ย.';
				break;
			case 5:
				$month_abv='พ.ค.';
				break;
			case 6:
				$month_abv='มิ.ย.';
				break;
			case 7:
				$month_abv='ก.ค.';
				break;
			case 8:
				$month_abv='ส.ค.';
				break;
			case 9:
				$month_abv='ก.ย.';
				break;
			case 10:
				$month_abv='ต.ค.';
				break;
			case 11:
				$month_abv='พ.ย.';
				break;
			case 12:
				$month_abv='ธ.ค.';
				break;
			default:
				// It's Impossible !
		}

		return intval(date("d", strtotime(str_replace("/","-",$date))))."-".$month_abv."-".date("y", strtotime(str_replace("/","-",$date)));
	}

	function day_name_thai($name){
		switch($name){
			case 'Sun':
				// Not Send
				return 'อาทิตย์';
				break;
			case 'Mon':
				return 'จันทร์';
				break;
			case 'Tue':
				return 'อังคาร';
				break;
			case 'Wed':
				return 'พุธ';
				break;
			case 'Thu':
				return 'พฤหัสบดี';
				break;
			case 'Fri':
				return 'ศุกร์';
				break;
			case 'Sat':
				// Not Send
				return 'เสาร์';
				break;
			default:
				// It's Impossible !
		}
	}
?>