<!DOCTYPE html>
<html>
	<head>
		<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
		<!-- Include jQuery -->
		<link rel="stylesheet" media="all" type="text/css" href="jquery-ui.css" />
		<link rel="stylesheet" media="all" type="text/css" href="jquery-ui-timepicker-addon.css" />
		<script type="text/javascript" src="jquery-1.10.2.min.js"></script>
		<script type="text/javascript" src="jquery-ui.min.js"></script>
		<script type="text/javascript" src="jquery-ui-timepicker-addon.js"></script>
		<script type="text/javascript" src="jquery-ui-sliderAccess.js"></script>
		<title>Checkpoint Not Complete</title>
	</head>
	<body>	
		<?php
			echo "<b>Checkpoint Not Complete Checker [From DB1-RAC [10.11.11.171], DB2-RAC [10.11.11.172]]</b>"."<br><br>";
			echo "Select Date : ";
		?>

		<!-- Datepicker -->
		<script type="text/javascript">
		$(function(){
			$("#dateInput").datepicker({
				dateFormat: 'dd/mm/yy'
			});
		});
		</script>
		<input type="text" name="dateInput" id="dateInput" value="<?php 
			if(isset($_GET['date']))
				echo $_GET['date'];
			else
				echo date('d/m/Y');
		?>"/> 

	<!-- Submit Button -->
	<button onclick="getCheckpointNotComplete()">Submit</button>
	<script>
	function getCheckpointNotComplete() {
		window.location = "index.php?date="+document.getElementById("dateInput").value;
	}
	</script>



	<!-- Connect To Server -->
	<?php
			echo "<br><br>*ตาราง Day จะทำการแสดงผลย้อนหลัง 15 วันจากวันที่เลือก<br>";

			// Data For Table
			$checkpoint_count_171=[0];
			$checkpoint_count_172=[0];
			$checkpoint_detail_171=[];
			$checkpoint_detail_172=[];

		if(isset($_GET['date'])){

			// Loop For 15 Days Back
			if($_GET['date']=='today'){
			$select_date=date('d-m-Y');
			}
			else {
			$select_date=$_GET['date'];
			}

			// ===== 10.11.11.171 =====
    		//echo "<br><br><b>[10.11.11.171]</b>";
    		// Initial Connection
			set_include_path(get_include_path() . PATH_SEPARATOR . 'phpseclib');
			include('Net/SSH2.php');
			$server = "10.11.11.171";
			$username = "root";
			$password = "123456";

			$ssh = new Net_SSH2($server);
			if (!$ssh->login($username, $password)) {
			    exit('Login Failed');
			}

			// ========== MAIN LOOP 171 ==========
			//echo "<br>";
			for($i=0;$i<15;$i++){

			$start_date=date("D M d", strtotime(str_replace("/","-",$select_date)." -".$i." day"));
			$start_date_year=date("Y", strtotime(str_replace("/","-",$select_date)." -".$i." day"));
			$end_date=date("D M d", strtotime(str_replace("/","-",$select_date)." -".$i." day +1 day"));
			$end_date_year=date("Y", strtotime(str_replace("/","-",$select_date)." -".$i." day +1 day"));

			$start_line_number=$ssh->exec('grep -e "'.$start_date.'" -m 1 -n  /software/app/oracle/diag/rdbms/radius/radius1/trace/alert_radius1.log | grep "'.$start_date_year.'"')."<br>";
			$start_line_number = substr($start_line_number,0,strpos($start_line_number, ":")); 

			$end_line_number=$ssh->exec('grep -e "'.$end_date.'" -m 1 -n  /software/app/oracle/diag/rdbms/radius/radius1/trace/alert_radius1.log | grep "'.$end_date_year.'"')."<br>";
			$end_line_number = substr($end_line_number,0,strpos($end_line_number, ":"))-1; 


			if($start_line_number==null)
				echo "<br><b>[".date("d-m-Y", strtotime(str_replace("/","-",$select_date)." -".$i." day"))."] Log Not Found!</b>&nbsp;";
			else {
				// If $end_line_number=-1 => Current Date
				if($end_line_number==-1){
					// Select Date = Current Date
					echo "<br><b><i>*Log For ".date("d-m-Y", strtotime(str_replace("/","-",$select_date)." -".$i." day"))." Still Not Complete</i></b>&nbsp;";
					$get_line=$ssh->exec("sed -n '".$start_line_number.",\$p' /software/app/oracle/diag/rdbms/radius/radius1/trace/alert_radius1.log")."<br>";
				}
				else {
					$get_line=$ssh->exec('sed -n '.$start_line_number.','.$end_line_number.'p /software/app/oracle/diag/rdbms/radius/radius1/trace/alert_radius1.log')."<br>";
				}

				$get_line= str_replace("\n","<br>",$get_line);

				if(substr_count($get_line, 'Checkpoint not complete') != 0) {
    				$checkpoint_count_171[$start_date." ".$start_date_year]=substr_count($get_line, 'Checkpoint not complete');
    				// Get Checkpoint Not Complete Detail
    				$get_line_tmp=$get_line;
    				$log_detail='';

    				$checkpoint_detail_171[$start_date." ".$start_date_year]='';

    				while($get_line_tmp!=''){
    					$string_line=str_replace('<br>', '', substr($get_line_tmp,0,strpos($get_line_tmp, "<br>")));

    					// Check is a date line ?
    					if($string_line == date('D M d H:i:s Y',strtotime($string_line))){
    						if($log_detail==''){
    							// Start New Log Detail
    							$log_detail="<b>".$string_line."</b>"."<br>";
    						}
    						else{
    							// Printout Log => Begin New Log Detail
    							// Check is a log contain Checkpoint Not Complete ?
    							if (strpos($log_detail, 'Checkpoint not complete') == true) {
    								// Print Only Line Contain 'Thread 1 cannot allocate new log, sequence XXXXX'
    								
    								$date_log=substr($log_detail,0,strpos($log_detail,'</b><br>'))."</b>";
    								$log_part=substr($log_detail,strpos($log_detail,'<br>Thread'),strpos($log_detail,'Checkpoint not complete')-strpos($log_detail,'<br>Thread'));

    								$checkpoint_detail_171[$start_date." ".$start_date_year].=$date_log.$log_part."Checkpoint not complete<br>";
								}	  							
    							$log_detail="<b>".$string_line."</b>"."<br>";
    						}
    					}
						else {
							$log_detail.=$string_line."<br>";
						}
						$get_line_tmp=preg_replace('/'.preg_quote($string_line."<br>", '/').'/', '', $get_line_tmp, 1);
					}
				}
				else {
					//echo '<font color="green"><b>[RAC DB1 .171] Checkpoint Not Complete Not Found!</b></font><br>';
				}
			}

			//echo "DATE=".$start_date." ".$start_date_year." COUNT=".$checkpoint_count_171[$start_date." ".$start_date_year]." DETAIL=".$checkpoint_detail_171[$start_date." ".$start_date_year]."<br>";

		}	// END LOOP 171



			echo "<br>";
			// ===== 10.11.11.172 =====
    		// Initial Connection
    		//echo "<br><br><b>[10.11.11.172]</b>";
			set_include_path(get_include_path() . PATH_SEPARATOR . 'phpseclib');
			$server = "10.11.11.172";
			$username = "root";
			$password = "123456";

			$ssh = new Net_SSH2($server);
			if (!$ssh->login($username, $password)) {
			    exit('Login Failed');
			}

			// ========== MAIN LOOP 172 ==========
			for($i=0;$i<15;$i++){

			$start_date=date("D M d", strtotime(str_replace("/","-",$select_date)." -".$i." day"));
			$start_date_year=date("Y", strtotime(str_replace("/","-",$select_date)." -".$i." day"));
			$end_date=date("D M d", strtotime(str_replace("/","-",$select_date)." -".$i." day +1 day"));
			$end_date_year=date("Y", strtotime(str_replace("/","-",$select_date)." -".$i." day +1 day"));

			$start_line_number=$ssh->exec('grep -e "'.$start_date.'" -m 1 -n  /software/app/oracle/diag/rdbms/radius/radius2/trace/alert_radius2.log | grep "'.$start_date_year.'"')."<br>";
			$start_line_number = substr($start_line_number,0,strpos($start_line_number, ":")); 

			$end_line_number=$ssh->exec('grep -e "'.$end_date.'" -m 1 -n  /software/app/oracle/diag/rdbms/radius/radius2/trace/alert_radius2.log | grep "'.$end_date_year.'"')."<br>";
			$end_line_number = substr($end_line_number,0,strpos($end_line_number, ":"))-1; 


			if($start_line_number==null){
				//echo "<br><b>Log Not Found!</b>&nbsp;";
			}
			else {
				// If $end_line_number=-1 => Current Date
				if($end_line_number==-1){
					// Select Date = Current Date
					//echo "<br><b><i>*Log For Current Day Still Not Complete</i></b>&nbsp;";
					$get_line=$ssh->exec("sed -n '".$start_line_number.",\$p' /software/app/oracle/diag/rdbms/radius/radius2/trace/alert_radius2.log")."<br>";
				}
				else {
					$get_line=$ssh->exec('sed -n '.$start_line_number.','.$end_line_number.'p /software/app/oracle/diag/rdbms/radius/radius2/trace/alert_radius2.log')."<br>";
				}

				$get_line= str_replace("\n","<br>",$get_line);

				if(substr_count($get_line, 'Checkpoint not complete') != 0) {
    				//echo '<font color="red"><b>[RAC DB2 .172] Found '.substr_count($get_line, 'Checkpoint not complete').' Checkpoint Not Complete!</b></font><br>';
    				$checkpoint_count_172[$start_date." ".$start_date_year]=substr_count($get_line, 'Checkpoint not complete');
    				// Get Checkpoint Not Complete Detail
    				$get_line_tmp=$get_line;
    				$log_detail='';

    				$checkpoint_detail_172[$start_date." ".$start_date_year]='';

    				while($get_line_tmp!=''){
    					$string_line=str_replace('<br>', '', substr($get_line_tmp,0,strpos($get_line_tmp, "<br>")));

    					// Check is a date line ?
    					if($string_line == date('D M d H:i:s Y',strtotime($string_line))){
    						if($log_detail==''){
    							// Start New Log Detail
    							$log_detail="<b>".$string_line."</b>"."<br>";
    						}
    						else{
    							// Printout Log => Begin New Log Detail
    							// Check is a log contain Checkpoint Not Complete ?
    							if (strpos($log_detail, 'Checkpoint not complete') == true) {
    								// Print Only Line Contain 'Thread 2 cannot allocate new log, sequence XXXXX'
    								
    								$date_log=substr($log_detail,0,strpos($log_detail,'</b><br>'))."</b>";
    								$log_part=substr($log_detail,strpos($log_detail,'<br>Thread'),strpos($log_detail,'Checkpoint not complete')-strpos($log_detail,'<br>Thread'));

    								$checkpoint_detail_172[$start_date." ".$start_date_year].=$date_log.$log_part."Checkpoint not complete<br>";
								}	  							
    							$log_detail="<b>".$string_line."</b>"."<br>";
    						}
    					}
						else {
							$log_detail.=$string_line."<br>";
						}
						$get_line_tmp=preg_replace('/'.preg_quote($string_line."<br>", '/').'/', '', $get_line_tmp, 1);
					}
				}
				else {
					//echo '<font color="green"><b>[RAC DB2 .172] Checkpoint Not Complete Not Found!</b></font><br>';
				}
			}
			//echo "DATE=".$start_date." ".$start_date_year." COUNT=".$checkpoint_count_172[$start_date." ".$start_date_year]." DETAIL=".$checkpoint_detail_172[$start_date." ".$start_date_year]."<br>";

			}	// END LOOP 172

    	}
    	else{
    		die();
    	}
	?>



	<!-- Query Remark -->
	<?php
		header('Content-Type: text/html; charset=utf-8');
		function query_remark($date){
			// Query Remark	
			$con = mysqli_connect("10.11.11.208","root","password");
			mysqli_set_charset($con, "utf8");
			if (!$con) {
		    die("Database connection failed: " . mysqli_error());
			}

			$db_select = mysqli_select_db($con, "monitor");
			if (!$db_select) {
		    	die("Database selection failed: " . mysqli_error());
			}
			mysqli_set_charset( $con, 'utf8');

			$sql=mysqli_query($con, "SELECT * FROM checkpoint_not_complete_remark WHERE date<='".$date."' ORDER BY date DESC;");
				$remark='';
			  while ($result=mysqli_fetch_array($sql)) {
			    $date=date("d/m/Y", strtotime($result['date']));
			    if($result['time']==null){
			    	$remark.="[".$date."] ".$result['remark']."<br>";
			    }
			    else{
			    	$remark.="[".$date." ".$result['time']."] ".$result['remark']."<br>";
			    }
			  }
			  return $remark;
		}
	?>
	</body>



<!-- Other PHP Function -->
<?php
	function getdate_format($date){	
		//Example Return "27-พ.ค.-16";
		$month_abv=intval(date("m", strtotime(str_replace("/","-",$date))));
		switch($month_abv){
			case 1:
				$month_abv='ม.ค.';
				break;
			case 2:
				$month_abv='ก.พ.';
				break;
			case 3:
				$month_abv='มี.ค.';
				break;
			case 4:
				$month_abv='เม.ย.';
				break;
			case 5:
				$month_abv='พ.ค.';
				break;
			case 6:
				$month_abv='มิ.ย.';
				break;
			case 7:
				$month_abv='ก.ค.';
				break;
			case 8:
				$month_abv='ส.ค.';
				break;
			case 9:
				$month_abv='ก.ย.';
				break;
			case 10:
				$month_abv='ต.ค.';
				break;
			case 11:
				$month_abv='พ.ย.';
				break;
			case 12:
				$month_abv='ธ.ค.';
				break;
			default:
				// It's Impossible !
		}

		return intval(date("d", strtotime(str_replace("/","-",$date))))."-".$month_abv."-".date("y", strtotime(str_replace("/","-",$date)));
	}
	function day_name_thai($name){
		switch($name){
			case 'Sun':
				// Not Send
				return 'อาทิตย์';
				break;
			case 'Mon':
				return 'จันทร์';
				break;
			case 'Tue':
				return 'อังคาร';
				break;
			case 'Wed':
				return 'พุธ';
				break;
			case 'Thu':
				return 'พฤหัสบดี';
				break;
			case 'Fri':
				return 'ศุกร์';
				break;
			case 'Sat':
				// Not Send
				return 'เสาร์';
				break;
			default:
				// It's Impossible !
		}
	}
?>

</html>










<?php
	echo "<b>**********[START EMAIL PART]**********</b><br>";

	//Create Email Body
	$day_name_thai=date("D", strtotime(str_replace("/","-",$select_date)));
	$day_name_thai=day_name_thai($day_name_thai);
	$day_header=date("j M Y", strtotime(str_replace("/","-",$select_date)));
	$subject_mail="รายงาน Checkpoint Not Complete ประจำวัน".$day_name_thai."ที่ ".$day_header;

$email_body="
<!-- 1. HEADER PART -->
<html xmlns:v=\"urn:schemas-microsoft-com:vml\" xmlns:o=\"urn:schemas-microsoft-com:office:office\" xmlns:w=\"urn:schemas-microsoft-com:office:word\" xmlns:x=\"urn:schemas-microsoft-com:office:excel\" xmlns:m=\"http://schemas.microsoft.com/office/2004/12/omml\" xmlns=\"http://www.w3.org/TR/REC-html40\">
   <head>
      <meta http-equiv=Content-Type content=\"text/html; charset=windows-874\">
      <meta name=ProgId content=Word.Document>
      <meta name=Generator content=\"Microsoft Word 14\">
      <meta name=Originator content=\"Microsoft Word 14\">
      <link rel=File-List href=\"cid:filelist.xml@01D3643B.E153CD10\">
      <link rel=themeData href=\"~~themedata~~\">
      <link rel=colorSchemeMapping href=\"~~colorschememapping~~\">
      <style>
         <!--
            /* Font Definitions */
            @font-face
            	{font-family:\"Angsana New\";
            	panose-1:2 2 6 3 5 4 5 2 3 4;
            	mso-font-charset:0;
            	mso-generic-font-family:roman;
            	mso-font-pitch:variable;
            	mso-font-signature:-2130706429 0 0 0 65537 0;}
            @font-face
            	{font-family:\"Cordia New\";
            	panose-1:2 11 3 4 2 2 2 2 2 4;
            	mso-font-charset:0;
            	mso-generic-font-family:swiss;
            	mso-font-pitch:variable;
            	mso-font-signature:-2130706429 0 0 0 65537 0;}
            @font-face
            	{font-family:\"Cordia New\";
            	panose-1:2 11 3 4 2 2 2 2 2 4;
            	mso-font-charset:0;
            	mso-generic-font-family:swiss;
            	mso-font-pitch:variable;
            	mso-font-signature:-2130706429 0 0 0 65537 0;}
            @font-face
            	{font-family:Calibri;
            	panose-1:2 15 5 2 2 2 4 3 2 4;
            	mso-font-charset:0;
            	mso-generic-font-family:swiss;
            	mso-font-pitch:variable;
            	mso-font-signature:-536859905 -1073732485 9 0 511 0;}
            @font-face
            	{font-family:Tahoma;
            	panose-1:2 11 6 4 3 5 4 4 2 4;
            	mso-font-charset:0;
            	mso-generic-font-family:swiss;
            	mso-font-pitch:variable;
            	mso-font-signature:-520081665 -1073717157 41 0 66047 0;}
            @font-face
            	{font-family:\"Leelawadee UI\";
            	panose-1:2 11 5 2 4 2 4 2 2 3;
            	mso-font-charset:0;
            	mso-generic-font-family:swiss;
            	mso-font-pitch:variable;
            	mso-font-signature:-1560281085 0 65536 0 65793 0;}
            @font-face
            	{font-family:Leelawadee;
            	panose-1:2 11 5 2 4 2 4 2 2 3;
            	mso-font-charset:0;
            	mso-generic-font-family:swiss;
            	mso-font-pitch:variable;
            	mso-font-signature:-2130706429 0 0 0 65537 0;}
            /* Style Definitions */
            p.MsoNormal, li.MsoNormal, div.MsoNormal
            	{mso-style-unhide:no;
            	mso-style-qformat:yes;
            	mso-style-parent:\"\";
            	margin:0cm;
            	margin-bottom:.0001pt;
            	mso-pagination:widow-orphan;
            	font-size:11.0pt;
            	mso-bidi-font-size:14.0pt;
            	font-family:\"Calibri\",\"sans-serif\";
            	mso-ascii-font-family:Calibri;
            	mso-ascii-theme-font:minor-latin;
            	mso-fareast-font-family:Calibri;
            	mso-fareast-theme-font:minor-latin;
            	mso-hansi-font-family:Calibri;
            	mso-hansi-theme-font:minor-latin;
            	mso-bidi-font-family:\"Cordia New\";
            	mso-bidi-theme-font:minor-bidi;}
            a:link, span.MsoHyperlink
            	{mso-style-noshow:yes;
            	mso-style-priority:99;
            	color:blue;
            	mso-themecolor:hyperlink;
            	text-decoration:underline;
            	text-underline:single;}
            a:visited, span.MsoHyperlinkFollowed
            	{mso-style-noshow:yes;
            	mso-style-priority:99;
            	color:purple;
            	mso-themecolor:followedhyperlink;
            	text-decoration:underline;
            	text-underline:single;}
            p
            	{mso-style-noshow:yes;
            	mso-style-priority:99;
            	mso-margin-top-alt:auto;
            	margin-right:0cm;
            	mso-margin-bottom-alt:auto;
            	margin-left:0cm;
            	mso-pagination:widow-orphan;
            	font-size:14.0pt;
            	font-family:\"Angsana New\",\"serif\";
            	mso-fareast-font-family:Calibri;
            	mso-fareast-theme-font:minor-latin;}
            span.17
            	{mso-style-type:personal-compose;
            	mso-style-noshow:yes;
            	mso-style-unhide:no;
            	mso-ansi-font-size:11.0pt;
            	mso-bidi-font-size:14.0pt;
            	font-family:\"Calibri\",\"sans-serif\";
            	mso-ascii-font-family:Calibri;
            	mso-ascii-theme-font:minor-latin;
            	mso-fareast-font-family:Calibri;
            	mso-fareast-theme-font:minor-latin;
            	mso-hansi-font-family:Calibri;
            	mso-hansi-theme-font:minor-latin;
            	mso-bidi-font-family:\"Cordia New\";
            	mso-bidi-theme-font:minor-bidi;
            	color:windowtext;}
            span.SpellE
            	{mso-style-name:\"\";
            	mso-spl-e:yes;}
            .MsoChpDefault
            	{mso-style-type:export-only;
            	mso-default-props:yes;
            	mso-ascii-font-family:Calibri;
            	mso-ascii-theme-font:minor-latin;
            	mso-fareast-font-family:Calibri;
            	mso-fareast-theme-font:minor-latin;
            	mso-hansi-font-family:Calibri;
            	mso-hansi-theme-font:minor-latin;
            	mso-bidi-font-family:\"Cordia New\";
            	mso-bidi-theme-font:minor-bidi;}
            @page WordSection1
            	{size:612.0pt 792.0pt;
            	margin:72.0pt 72.0pt 72.0pt 72.0pt;
            	mso-header-margin:36.0pt;
            	mso-footer-margin:36.0pt;
            	mso-paper-source:0;}
            div.WordSection1
            	{page:WordSection1;}
            -->
      </style>
   </head>
   <body lang=EN-US link=blue vlink=purple style='tab-interval:36.0pt'>
      <div class=WordSection1>
         <p>
            <b><span lang=TH style='font-size:12.0pt;font-family:\"Tahoma\",\"sans-serif\";color:#1F497D'>เรียน</span></b><b><span style='font-size:12.0pt;font-family:\"Tahoma\",\"sans-serif\";color:#1F497D'>&nbsp;<span lang=TH>ทุกท่านครับ</span></span></b>
            <span style='font-size:12.0pt;font-family:\"Tahoma\",\"sans-serif\";color:#1F497D'>
               <o:p></o:p>
            </span>
         </p>
         <p class=MsoNormal>
            <span style='font-size:12.0pt;font-family:\"Tahoma\",\"sans-serif\";color:#1F497D'><span style='mso-tab-count:1'>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </span><span lang=TH>รายงาน Checkpoint Not Complete ประจำวัน".$day_name_thai."ที่ ".$day_header."&nbsp;<span lang=TH>รายละเอียดดังตารางครับ</span><br><br><span style='mso-tab-count:1'>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </span>*<span lang=TH>หมายเหตุ : </span></span><span lang=TH style='font-size:12.0pt;font-family:\"Tahoma\",\"sans-serif\";color:red'>เป็นระบบส่งอี<span class=SpellE>เมลล์</span>อัตโนมัติ</span><br style='mso-special-character:line-break'><![if !supportLineBreakNewLine]><br style='mso-special-character:line-break'><![endif]>
            <o:p></o:p>
         </p>
         <table class=MsoNormalTable border=0 cellspacing=0 cellpadding=0 width=1324 style='width:993.0pt;margin-left:-1.15pt;border-collapse:collapse;mso-yfti-tbllook:1184;mso-padding-alt:0cm 5.4pt 0cm 5.4pt'>


		<!-- TABLE HEADER -->

		<!-- 1ST LINE -->
        <tr style='mso-yfti-irow:0;height:14.25pt'>
               <td nowrap colspan=2 rowspan=2 style='width:75.0pt;border-top:windowtext;border-left:windowtext;border-bottom:black;border-right:black;border-style:solid;border-width:1.0pt;mso-border-top-alt:windowtext;mso-border-left-alt:windowtext;mso-border-bottom-alt:black;mso-border-right-alt:black;mso-border-style-alt:solid;mso-border-width-alt:.5pt;background:#B8CCE4;padding:0cm 5.4pt 0cm 5.4pt;height:14.25pt'>
                  <p class=MsoNormal align=center style='text-align:center'>
                     <b>
                        <span style='font-size:10.0pt;font-family:\"Tahoma\",\"sans-serif\";mso-fareast-font-family:\"Times New Roman\";color:#002060'>
                           &nbsp;
                           <o:p></o:p>
                        </span>
                     </b>
                  </p>
               </td>

               <td nowrap colspan=2 style='width:460.0pt;border-top:solid windowtext 1.0pt;border-left:none;border-bottom:solid windowtext 1.0pt;border-right:solid black 1.0pt;mso-border-top-alt:solid windowtext .5pt;mso-border-bottom-alt:solid windowtext .5pt;mso-border-right-alt:solid black .5pt;background:#B8CCE4;padding:0cm 5.4pt 0cm 5.4pt;height:14.25pt'>
                  <p class=MsoNormal align=center style='text-align:center'>
                     <b>
                        <span style='font-size:10.0pt;font-family:\"Tahoma\",\"sans-serif\";mso-fareast-font-family:\"Times New Roman\";color:#002060'>
                           Checkpoint Not Complete
                           <o:p></o:p>
                        </span>
                     </b>
                  </p>
               </td>

               <td nowrap rowspan=2 style='width:380.0pt;border-top:solid windowtext 1.0pt;border-left:none;border-bottom:solid black 1.0pt;border-right:solid windowtext 1.0pt;mso-border-left-alt:solid windowtext .5pt;mso-border-alt:solid windowtext .5pt;mso-border-bottom-alt:solid black .5pt;background:#B8CCE4;padding:0cm 5.4pt 0cm 5.4pt;height:14.25pt'>
                  <p class=MsoNormal align=center style='text-align:center'>
                     <b>
                        <span style='font-size:10.0pt;font-family:\"Tahoma\",\"sans-serif\";mso-fareast-font-family:\"Times New Roman\";color:#002060'>
                           Remark
                           <o:p></o:p>
                        </span>
                     </b>
                  </p>
               </td>
            </tr>

            <!-- 2ND LINE -->
            <tr style='mso-yfti-irow:1;height:14.25pt'>
               <td nowrap style='width:230.0pt;border-top:none;border-left:none;border-bottom:solid windowtext 1.0pt;border-right:solid windowtext 1.0pt;mso-border-bottom-alt:solid windowtext .5pt;mso-border-right-alt:solid windowtext .5pt;background:#C5D9F1;padding:0cm 5.4pt 0cm 5.4pt;height:14.25pt'>
                  <p class=MsoNormal align=center style='text-align:center'>
                     <b>
                        <span style='font-size:10.0pt;font-family:\"Tahoma\",\"sans-serif\";mso-fareast-font-family:\"Times New Roman\";color:#002060'>
                           DB1: 4 Groups
                           <o:p></o:p>
                        </span>
                     </b>
                  </p>
               </td>

               <td nowrap style='width:230.0pt;border-top:none;border-left:none;border-bottom:solid windowtext 1.0pt;border-right:solid windowtext 1.0pt;mso-border-bottom-alt:solid windowtext .5pt;mso-border-right-alt:solid windowtext .5pt;background:#C5D9F1;padding:0cm 5.4pt 0cm 5.4pt;height:14.25pt'>
                  <p class=MsoNormal align=center style='text-align:center'>
                     <b>
                        <span style='font-size:10.0pt;font-family:\"Tahoma\",\"sans-serif\";mso-fareast-font-family:\"Times New Roman\";color:#002060'>
                           DB2: 4 Groups 
                           <o:p></o:p>
                        </span>
                     </b>
                  </p>
               </td>
            </tr>";

// Loop 15 Day Back
for($i=0;$i<15;$i++){

		$start_date=date("D M d", strtotime(str_replace("/","-",$select_date)." -".$i." day"));
		$start_date_year=date("Y", strtotime(str_replace("/","-",$select_date)." -".$i." day"));

		$cp_db1='';
		$cp_db2='';

		if($checkpoint_count_171[$start_date." ".$start_date_year]!=null){$cp_db1= "<b>".$checkpoint_count_171[$start_date." ".$start_date_year]."</b>";} else{$cp_db1= "-";}
		if($checkpoint_count_172[$start_date." ".$start_date_year]!=null){$cp_db2= "<b>".$checkpoint_count_172[$start_date." ".$start_date_year]."</b>";} else{$cp_db2= "-";}

	$email_body.="
			<!-- 2. BODY PART -->
			<!-- YELLOW ZONE -->
            <tr style='mso-yfti-irow:2;height:14.25pt'>
            	<!-- DAY ABREVIATION Ex. Mon -->
               <td nowrap valign=bottom style='width:15.0pt;border:none;border-left:solid windowtext 1.0pt;mso-border-left-alt:solid windowtext .5pt;background:yellow;padding:0cm 5.4pt 0cm 5.4pt;height:14.25pt'>
                  <p class=MsoNormal>
                     <span style='font-size:10.0pt;font-family:\"Tahoma\",\"sans-serif\";mso-fareast-font-family:\"Times New Roman\";color:black'>".date("D", strtotime(str_replace("/","-",$select_date)." -".$i." day"))."<o:p></o:p>
                     </span>
                  </p>
               </td>

               <!-- DATE Ex. 23-พ.ย.-17 -->
               <td nowrap valign=bottom style='width:60.0pt;border:none;border-right:solid windowtext 1.0pt;mso-border-right-alt:solid windowtext .5pt;background:yellow;padding:0cm 5.4pt 0cm 5.4pt;height:14.25pt'>
                  <p class=MsoNormal>
                     <span style='font-size:10.0pt;font-family:\"Tahoma\",\"sans-serif\";mso-fareast-font-family:\"Times New Roman\";color:black'>".getdate_format(date("d/m/Y", strtotime(str_replace("/","-",$select_date)." -".$i." day")))."<o:p></o:p>
                     </span>
                  </p>
               </td>

               <!-- Checkpoint Count [171] -->
               <td nowrap valign=bottom style='border:none;border-right:solid windowtext 1.0pt;mso-border-right-alt:solid windowtext .5pt;background:yellow;padding:0cm 5.4pt 0cm 5.4pt;height:14.25pt'>
                  <p class=MsoNormal align=center style='text-align:center'>
                     <b>
                        <span style='font-size:10.0pt;font-family:\"Tahoma\",\"sans-serif\";mso-fareast-font-family:\"Times New Roman\";color:red'>".$cp_db1."<o:p></o:p>
                     </span>
                  </p>
               </td>

               <!-- Checkpoint Count [172] -->
               <td nowrap valign=bottom style='border:none;border-right:solid windowtext 1.0pt;mso-border-right-alt:solid windowtext .5pt;background:yellow;padding:0cm 5.4pt 0cm 5.4pt;height:14.25pt'>
                  <p class=MsoNormal align=center style='text-align:center'>
                     <b>
                        <span style='font-size:10.0pt;font-family:\"Tahoma\",\"sans-serif\";mso-fareast-font-family:\"Times New Roman\";color:red'>".$cp_db2."<o:p></o:p>
                     </span>
                  </p>
               </td>

               <!-- Below Remark Header-->
               <td nowrap valign=bottom style='border:none;border-right:solid windowtext 1.0pt;mso-border-right-alt:solid windowtext .5pt;background:yellow;padding:0cm 5.4pt 0cm 5.4pt;height:14.25pt'>
                  <p class=MsoNormal>
                     <span style='font-size:10.0pt;font-family:\"Tahoma\",\"sans-serif\";mso-fareast-font-family:\"Times New Roman\";color:red'>
                        &nbsp;
                        <o:p></o:p>
                     </span>
                  </p>
               </td>
               </tr>

               <!-- White Area-->
               <tr style='mso-yfti-irow:3'>
               <td nowrap valign=bottom style='border-top:none;border-left:solid windowtext 1.0pt;border-bottom:solid windowtext 1.0pt;border-right:none;mso-border-left-alt:solid windowtext .5pt;mso-border-bottom-alt:solid windowtext .5pt;padding:0cm 5.4pt 0cm 5.4pt'>
                  <p class=MsoNormal align=center style='text-align:center'>
                     <b>
                        <span style='font-size:10.0pt;font-family:\"Tahoma\",\"sans-serif\";mso-fareast-font-family:\"Times New Roman\";color:#002060'>
                           &nbsp;
                           <o:p></o:p>
                        </span>
                     </b>
                  </p>
               </td>
               <td nowrap valign=bottom style='border-top:none;border-left:none;border-bottom:solid windowtext 1.0pt;border-right:solid windowtext 1.0pt;mso-border-bottom-alt:solid windowtext .5pt;mso-border-right-alt:solid windowtext .5pt;padding:0cm 5.4pt 0cm 5.4pt'>
                  <p class=MsoNormal align=center style='text-align:center'>
                     <b>
                        <span style='font-size:10.0pt;font-family:\"Tahoma\",\"sans-serif\";mso-fareast-font-family:\"Times New Roman\";color:#002060'>
                           &nbsp;
                           <o:p></o:p>
                        </span>
                     </b>
                  </p>
               </td>

                <!-- Checkpoint Detail [171]-->
               <td valign=top style='border-top:none;border-left:none;border-bottom:solid windowtext 1.0pt;border-right:solid windowtext 1.0pt;mso-border-bottom-alt:solid windowtext .5pt;mso-border-right-alt:solid windowtext .5pt;padding:0cm 5.4pt 0cm 5.4pt'>
                  <p class=MsoNormal>
                     <span style='font-size:10.0pt;font-family:\"Tahoma\",\"sans-serif\";mso-fareast-font-family:\"Times New Roman\";color:black'>
                        <o:p></o:p>".$checkpoint_detail_171[$start_date." ".$start_date_year]."
                     </span>
                  </p>
               </td>
               <!-- Checkpoint Detail [172]-->
               <td valign=top style='border-top:none;border-left:none;border-bottom:solid windowtext 1.0pt;border-right:solid windowtext 1.0pt;mso-border-bottom-alt:solid windowtext .5pt;mso-border-right-alt:solid windowtext .5pt;padding:0cm 5.4pt 0cm 5.4pt'>
                  <p class=MsoNormal>
                     <span style='font-size:10.0pt;font-family:\"Tahoma\",\"sans-serif\";mso-fareast-font-family:\"Times New Roman\";color:black'>
                        <o:p></o:p>".$checkpoint_detail_172[$start_date." ".$start_date_year]."
                     </span>
                  </p>
               </td>

               <!-- Remark Area -->
               <td valign=top style='border-top:none;border-left:none;border-bottom:solid windowtext 1.0pt;border-right:solid windowtext 1.0pt;mso-border-bottom-alt:solid windowtext .5pt;mso-border-right-alt:solid windowtext .5pt;padding:0cm 5.4pt 0cm 5.4pt'>
                  <p class=MsoNormal><span style='font-size:10.0pt;font-family:\"Tahoma\",\"sans-serif\";mso-fareast-font-family:\"Times New Roman\"'>".query_remark(date("Y-m-d", strtotime(str_replace("/","-",$select_date)." -".$i." day")))."<o:p></o:p></span>
                  </p>
               </td>
            </tr>";
}

$email_body.="
		<!-- 3. SIGNATURE PART -->
		</table>
        <p class=MsoNormal>
            <o:p>&nbsp;</o:p>
        </p>
        <p class=MsoNormal>
            <a name=\"_MailAutoSig\"><b><span lang=TH style='font-size:14.0pt;font-family:\"Leelawadee\",\"sans-serif\";mso-fareast-font-family:\"Times New Roman\";mso-fareast-theme-font:minor-fareast;color:#002060;mso-no-proof:yes'>ขอแสดงความนับถือ</span></b></a>
            <span style='mso-bookmark:_MailAutoSig'>
               <b>
                  <span style='font-size:14.0pt;font-family:\"Leelawadee\",\"sans-serif\";mso-fareast-font-family:\"Times New Roman\";mso-fareast-theme-font:minor-fareast;color:#002060;mso-no-proof:yes'>
                     <o:p></o:p>
                  </span>
               </b>
            </span>
        </p>
        <p class=MsoNormal>
            <span style='mso-bookmark:_MailAutoSig'><b><span style='font-size:8.0pt;font-family:\"Leelawadee\",\"sans-serif\";mso-fareast-font-family:\"Times New Roman\";mso-fareast-theme-font:minor-fareast;color:gray;mso-themecolor:background1;mso-themeshade:128;mso-no-proof:yes'>o</span></b></span><span style='mso-bookmark:_MailAutoSig'><b><span style='font-size:8.0pt;font-family:\"Leelawadee\",\"sans-serif\";mso-fareast-font-family:\"Times New Roman\";mso-fareast-theme-font:minor-fareast;color:gray;mso-no-proof:yes'>-o-o-o-o-o-o-o-o-o-o-o-o-o-o-o-o-o-o-o-o-o-o-o-o-o-o-o-o</span></b></span>
            <span style='mso-bookmark:_MailAutoSig'>
               <span style='font-size:8.0pt;font-family:\"Leelawadee\",\"sans-serif\";mso-fareast-font-family:\"Times New Roman\";mso-fareast-theme-font:minor-fareast;mso-no-proof:yes'>
                  <o:p></o:p>
               </span>
            </span>
        </p>
        <p class=MsoNormal>
            <span style='mso-bookmark:_MailAutoSig'><b><span lang=TH style='font-size:14.0pt;font-family:\"Leelawadee UI\",\"sans-serif\";mso-fareast-font-family:\"Times New Roman\";mso-fareast-theme-font:minor-fareast;color:#31849B;mso-no-proof:yes'><span style='mso-spacerun:yes'>&nbsp;&nbsp;&nbsp;&nbsp; </span></span></b></span><span style='mso-bookmark:_MailAutoSig'><b><span lang=TH style='font-size:12.0pt;font-family:\"Leelawadee UI\",\"sans-serif\";mso-fareast-font-family:\"Times New Roman\";mso-fareast-theme-font:minor-fareast;color:#E36C0A;mso-themecolor:accent6;mso-themeshade:191;mso-no-proof:yes'>สหภาพ โพธิคำ (ฟีฟ่า)</span></b></span>
            <span style='mso-bookmark:_MailAutoSig'>
               <b>
                  <span style='font-size:12.0pt;font-family:\"Leelawadee UI\",\"sans-serif\";mso-fareast-font-family:\"Times New Roman\";mso-fareast-theme-font:minor-fareast;color:#E36C0A;mso-themecolor:accent6;mso-themeshade:191;mso-no-proof:yes'>
                     <o:p></o:p>
                  </span>
               </b>
            </span>
        </p>
        <p class=MsoNormal>
            <span style='mso-bookmark:_MailAutoSig'>
               <b>
                  <span style='font-family:\"Leelawadee UI\",\"sans-serif\";mso-fareast-font-family:\"Times New Roman\";mso-fareast-theme-font:minor-fareast;color:#31849B;mso-no-proof:yes'>
                     <span style='mso-spacerun:yes'>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </span>E-Mail<span style='mso-spacerun:yes'>&nbsp;&nbsp; </span>:<span style='mso-spacerun:yes'>&nbsp;&nbsp; </span>sahapab.p@jasmine.com
                     <o:p></o:p>
                  </span>
               </b>
            </span>
        </p>
        <p class=MsoNormal>
            <span style='mso-bookmark:_MailAutoSig'><b><span style='font-family:\"Leelawadee UI\",\"sans-serif\";mso-fareast-font-family:\"Times New Roman\";mso-fareast-theme-font:minor-fareast;color:#31849B;mso-no-proof:yes'><span style='mso-spacerun:yes'>&nbsp;&nbsp;&nbsp;&nbsp; </span></span></b></span>
            <span style='mso-bookmark:_MailAutoSig'>
               <b>
                  <span style='font-family:\"Leelawadee UI\",\"sans-serif\";mso-fareast-font-family:\"Times New Roman\";mso-fareast-theme-font:minor-fareast;color:#E36C0A;mso-themecolor:accent6;mso-themeshade:191;mso-no-proof:yes'>
                     <span style='mso-spacerun:yes'>&nbsp;</span>Tel.<span style='mso-spacerun:yes'>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </span>:<span style='mso-spacerun:yes'>&nbsp;&nbsp; </span>02-100-8965
                     <o:p></o:p>
                  </span>
               </b>
            </span>
        </p>
        <p class=MsoNormal>
            <span style='mso-bookmark:_MailAutoSig'>
               <b>
                  <span style='font-family:\"Leelawadee UI\",\"sans-serif\";mso-fareast-font-family:\"Times New Roman\";mso-fareast-theme-font:minor-fareast;color:#31849B;mso-no-proof:yes'>
                     <span style='mso-spacerun:yes'>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </span>Triple T Broadband PCL. [9th Floor]
                     <o:p></o:p>
                  </span>
               </b>
            </span>
        </p>
        <p class=MsoNormal>
            <span style='mso-bookmark:_MailAutoSig'><b><span style='font-size:8.0pt;font-family:\"Leelawadee\",\"sans-serif\";mso-fareast-font-family:\"Times New Roman\";mso-fareast-theme-font:minor-fareast;color:gray;mso-no-proof:yes'>o-o-o-o-o-o-o-o-o-o-o-o-o-o-o-o-o-o-o-o-o-o-o-o-o-o-o-o-o</span></b></span><span style='mso-bookmark:_MailAutoSig'></span>
            <b>
               <span style='mso-fareast-font-family:\"Times New Roman\";mso-fareast-theme-font:minor-fareast;color:gray;mso-no-proof:yes'>
                  <o:p></o:p>
               </span>
            </b>
        </p>
      </div>
   </body>
</html>";

 echo $email_body; 
 echo "<br><b>**********[END EMAIL PART]**********</b><br>"; 
 ?>



<!-- Send E-Mail -->
<?php 
	if($_GET['sendmail']==1){
		echo "<b>**********[SENDING EMAIL SUCCESSFULLY]**********</b><br>";

	$strTo = 'sahapab.p@jasmine.com';
	$strSubject = "=?UTF-8?B?".base64_encode($subject_mail)."?=";
	$uid = md5(uniqid(time()));

	$strMessage = $email_body;

	// header
	$header = "From: Sahapab Photikum <sahapab.p@jasmine.com>\r\n";
	//$header .= "Cc: radmin@3bbmail.com,isnetwork@3bbmail.com\n";
	//$header .= "Cc: fifa1412@gmail.com\n";
	$header .= "MIME-Version: 1.0\r\n";
	$header .= "Content-Type: multipart/mixed; boundary=\"".$uid."\"\r\n\r\n";

	// message & attachment
	$nmessage = "--".$uid."\r\n";
	$nmessage .= "Content-type:text/html; charset=utf-8\r\n";
	$nmessage .= "Content-Transfer-Encoding: 7bit\r\n\r\n";
	$nmessage .= $strMessage."\r\n\r\n";

	// Execute
	mail($strTo, $strSubject, $nmessage, $header);

	}
?>