<?php
	$table_body='';


	$table_body_tmp=$table_body;
	write_table_header();
	$table_body=$table_body.$table_body_tmp;
	write_table_tail();
	write_email_signature();




		// Send Email
		$sendmail_status=true;
		echo "Check Date Status [Sat, Sun, Holiday]: ";

		$today=date("D");

		// 1. Check Is Day = Sat or Sun
		if($today=="Sat" || $today=="Sun"){
			echo "Not Send (Weekend)<br><br>";
			$sendmail_status=false;
		}

		// 2. Check Is Day = Holiday List
		 $con210 = mysqli_connect("10.11.11.210","root","password");
         if (!$con210) {
          die("Database connection failed: " . mysqli_error());
         }
         $db_select = mysqli_select_db($con210, "3bb_standby");
         if (!$db_select) {
            die("Database selection failed: " . mysqli_error());
         }
         mysqli_set_charset($con210, 'utf8');
         $sql=mysqli_query($con210, "SELECT * FROM holiday_calendar WHERE holiday_date='".date("Y-m-d", strtotime($GLOBALS['send_date']))."' LIMIT 1;");
         while ($result=mysqli_fetch_array($sql)) {
              $sendmail_status=false;
              echo $GLOBALS['send_date']." => Not Send (Holiday)<br>";
         }

		// If Status OK Set sendemail_status=true And Clear Log
		if($sendmail_status==true){
			echo "OK (Weekday)<br>";

		}





	echo "<b>**********[START EMAIL PART]**********</b><br>";
	echo $table_body;
	echo "<br><b>**********[END EMAIL PART]**********</b><br>"; 
?>

<?php
	/// Send Email Part ///
	if($sendmail_status==true){
		$subject_mail="รายงานการ Drop Partition RLOG ประจำเดือน Feb 2018 - Succeeded";
		if($_GET['sendmail']==1){
		   	// Mail To
		   	$mailto = 'sahapab.p@jasmine.com';
			//$mailto = 'sahapab.p@jasmine.com,kwannaphat.f@jasmine.com,pathumthip.p@jasmine.com,thanet.c@ccs.jasmine.com';

			$subject = "=?UTF-8?B?".base64_encode($subject_mail)."?=";

			// Header
			$header = "From: Sahapab Photikum <sahapab.p@jasmine.com>\r\n";
		   	//$header .= "Cc: radmin@3bbmail.com,aoi.n@jasmine.com\n";
			$header .= "MIME-Version: 1.0\r\n";
			$header .= "Content-Type: text/html; charset=UTF-8\r\n";
		   	$header .= "Content-Transfer-Encoding: base64\r\n\r\n";

			$main_message .= chunk_split(base64_encode($table_body))."\r\n";

			// Execute
			mail($mailto, $subject, $main_message, $header);
			echo "<b>**********[SENDING EMAIL SUCCESSFULLY]**********</b><br>";

		}
	}
?>


<?php
	function write_email_intro(){
		$intro="    	
         <p>
            <b><span lang=TH style='font-size:12.0pt;font-family:\"Tahoma\",\"sans-serif\";color:#1F497D'>เรียน</span></b><b><span style='font-size:12.0pt;font-family:\"Tahoma\",\"sans-serif\";color:#1F497D'>&nbsp;<span lang=TH>ทุกท่านครับ</span></span></b>
            <span style='font-size:12.0pt;font-family:\"Tahoma\",\"sans-serif\";color:#1F497D'>
               <o:p></o:p>
            </span>
         </p>
         <p class=MsoNormal>
            <span style='font-size:14.0pt;font-family:\"Tahoma\",\"sans-serif\";color:#1F497D'>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<span lang=TH> </span></span><span lang=TH style='font-family:\"Tahoma\",\"sans-serif\";color:#1F497D'>รายงานการ </span><span style='font-family:\"Tahoma\",\"sans-serif\";color:#1F497D'>DROP PARTITION <span lang=TH>ประจำเดือน </span></span><span style='font-family:\"Tahoma\",\"sans-serif\";color:#1F497D'>Feb</span>
            <span style='font-family:\"Tahoma\",\"sans-serif\";color:#1F497D'>
               2018 
               <span lang=TH>
                  รายละเอียดดังนี้ครับ
                  <o:p></o:p>
               </span>
            </span>
         </p>";
		return $intro;
	}

	function write_email_signature(){
		$GLOBALS['table_body'].="
       <p class=MsoNormal>
            <span lang=TH style='font-size:14.0pt;mso-ansi-font-size:11.0pt;font-family:\"Cordia New\",\"sans-serif\";mso-ascii-font-family:Calibri;mso-ascii-theme-font:minor-latin;mso-hansi-font-family:Calibri;mso-hansi-theme-font:minor-latin;mso-bidi-font-family:\"Cordia New\";mso-bidi-theme-font:minor-bidi;color:#1F497D'><br></span><span lang=TH style='font-size:12.0pt;font-family:\"Tahoma\",\"sans-serif\";color:#1F497D'><span style='mso-tab-count:1'>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </span>*หมายเหตุ : </span>
            <span lang=TH style='font-size:12.0pt;font-family:\"Tahoma\",\"sans-serif\";color:red'>
               เป็นระบบส่งอี<span class=SpellE>เมลล์</span>อัตโนมัติ<br><br style='mso-special-character:line-break'><![if !supportLineBreakNewLine]><br style='mso-special-character:line-break'><![endif]>
            </span>
            <span style='color:#1F497D'>
               <o:p></o:p>
            </span>
         </p>
        <p class=MsoNormal>
            <a name=\"_MailAutoSig\"><b><span lang=TH style='font-size:14.0pt;font-family:\"Leelawadee\",\"sans-serif\";mso-fareast-font-family:\"Times New Roman\";mso-fareast-theme-font:minor-fareast;color:#002060;mso-no-proof:yes'>ขอแสดงความนับถือ</span></b></a>
            <span style='mso-bookmark:_MailAutoSig'>
               <b>
                  <span style='font-size:14.0pt;font-family:\"Leelawadee\",\"sans-serif\";mso-fareast-font-family:\"Times New Roman\";mso-fareast-theme-font:minor-fareast;color:#002060;mso-no-proof:yes'>
                     <o:p></o:p>
                  </span>
               </b>
            </span>
        </p>
        <p class=MsoNormal>
            <span style='mso-bookmark:_MailAutoSig'><b><span style='font-size:8.0pt;font-family:\"Leelawadee\",\"sans-serif\";mso-fareast-font-family:\"Times New Roman\";mso-fareast-theme-font:minor-fareast;color:gray;mso-themecolor:background1;mso-themeshade:128;mso-no-proof:yes'>o</span></b></span><span style='mso-bookmark:_MailAutoSig'><b><span style='font-size:8.0pt;font-family:\"Leelawadee\",\"sans-serif\";mso-fareast-font-family:\"Times New Roman\";mso-fareast-theme-font:minor-fareast;color:gray;mso-no-proof:yes'>-o-o-o-o-o-o-o-o-o-o-o-o-o-o-o-o-o-o-o-o-o-o-o-o-o-o-o-o</span></b></span>
            <span style='mso-bookmark:_MailAutoSig'>
               <span style='font-size:8.0pt;font-family:\"Leelawadee\",\"sans-serif\";mso-fareast-font-family:\"Times New Roman\";mso-fareast-theme-font:minor-fareast;mso-no-proof:yes'>
                  <o:p></o:p>
               </span>
            </span>
        </p>
        <p class=MsoNormal>
            <span style='mso-bookmark:_MailAutoSig'><b><span lang=TH style='font-size:14.0pt;font-family:\"Leelawadee UI\",\"sans-serif\";mso-fareast-font-family:\"Times New Roman\";mso-fareast-theme-font:minor-fareast;color:#31849B;mso-no-proof:yes'><span style='mso-spacerun:yes'>&nbsp;&nbsp;&nbsp;&nbsp; </span></span></b></span><span style='mso-bookmark:_MailAutoSig'><b><span lang=TH style='font-size:12.0pt;font-family:\"Leelawadee UI\",\"sans-serif\";mso-fareast-font-family:\"Times New Roman\";mso-fareast-theme-font:minor-fareast;color:#E36C0A;mso-themecolor:accent6;mso-themeshade:191;mso-no-proof:yes'>สหภาพ โพธิคำ (ฟีฟ่า)</span></b></span>
            <span style='mso-bookmark:_MailAutoSig'>
               <b>
                  <span style='font-size:12.0pt;font-family:\"Leelawadee UI\",\"sans-serif\";mso-fareast-font-family:\"Times New Roman\";mso-fareast-theme-font:minor-fareast;color:#E36C0A;mso-themecolor:accent6;mso-themeshade:191;mso-no-proof:yes'>
                     <o:p></o:p>
                  </span>
               </b>
            </span>
        </p>
        <p class=MsoNormal>
            <span style='mso-bookmark:_MailAutoSig'>
               <b>
                  <span style='font-family:\"Leelawadee UI\",\"sans-serif\";mso-fareast-font-family:\"Times New Roman\";mso-fareast-theme-font:minor-fareast;color:#31849B;mso-no-proof:yes'>
                     <span style='mso-spacerun:yes'>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </span>E-Mail<span style='mso-spacerun:yes'>&nbsp;&nbsp; </span>:<span style='mso-spacerun:yes'>&nbsp;&nbsp; </span>sahapab.p@jasmine.com
                     <o:p></o:p>
                  </span>
               </b>
            </span>
        </p>
        <p class=MsoNormal>
            <span style='mso-bookmark:_MailAutoSig'><b><span style='font-family:\"Leelawadee UI\",\"sans-serif\";mso-fareast-font-family:\"Times New Roman\";mso-fareast-theme-font:minor-fareast;color:#31849B;mso-no-proof:yes'><span style='mso-spacerun:yes'>&nbsp;&nbsp;&nbsp;&nbsp; </span></span></b></span>
            <span style='mso-bookmark:_MailAutoSig'>
               <b>
                  <span style='font-family:\"Leelawadee UI\",\"sans-serif\";mso-fareast-font-family:\"Times New Roman\";mso-fareast-theme-font:minor-fareast;color:#E36C0A;mso-themecolor:accent6;mso-themeshade:191;mso-no-proof:yes'>
                     <span style='mso-spacerun:yes'>&nbsp;</span>Tel.<span style='mso-spacerun:yes'>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </span>:<span style='mso-spacerun:yes'>&nbsp;&nbsp; </span>02-100-8965
                     <o:p></o:p>
                  </span>
               </b>
            </span>
        </p>
        <p class=MsoNormal>
            <span style='mso-bookmark:_MailAutoSig'>
               <b>
                  <span style='font-family:\"Leelawadee UI\",\"sans-serif\";mso-fareast-font-family:\"Times New Roman\";mso-fareast-theme-font:minor-fareast;color:#31849B;mso-no-proof:yes'>
                     <span style='mso-spacerun:yes'>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </span>Triple T Broadband PCL. [9th Floor]
                     <o:p></o:p>
                  </span>
               </b>
            </span>
        </p>
        <p class=MsoNormal>
            <span style='mso-bookmark:_MailAutoSig'><b><span style='font-size:8.0pt;font-family:\"Leelawadee\",\"sans-serif\";mso-fareast-font-family:\"Times New Roman\";mso-fareast-theme-font:minor-fareast;color:gray;mso-no-proof:yes'>o-o-o-o-o-o-o-o-o-o-o-o-o-o-o-o-o-o-o-o-o-o-o-o-o-o-o-o-o</span></b></span><span style='mso-bookmark:_MailAutoSig'></span>
            <b>
               <span style='mso-fareast-font-family:\"Times New Roman\";mso-fareast-theme-font:minor-fareast;color:gray;mso-no-proof:yes'>
                  <o:p></o:p>
               </span>
            </b>
        </p>
      </div>
   	</body>
	</html>";
	}

	

	function write_table_header(){
		$GLOBALS['table_body']="<!-- TABLE PART -->
		<!-- INTRO & DEFINITIONS PART -->
		<html xmlns:v=\"urn:schemas-microsoft-com:vml\" xmlns:o=\"urn:schemas-microsoft-com:office:office\" xmlns:w=\"urn:schemas-microsoft-com:office:word\" xmlns:x=\"urn:schemas-microsoft-com:office:excel\" xmlns:m=\"http://schemas.microsoft.com/office/2004/12/omml\" xmlns=\"http://www.w3.org/TR/REC-html40\">
	<head>
    	<meta http-equiv=Content-Type content=\"text/html; charset=windows-874\">
    	<meta name=ProgId content=Word.Document>
    	<meta name=Generator content=\"Microsoft Word 14\">
    	<meta name=Originator content=\"Microsoft Word 14\">
    	<link rel=File-List href=\"cid:filelist.xml@01D37807.55E854F0\">
    	<link rel=themeData href=\"~~themedata~~\">
    	<link rel=colorSchemeMapping href=\"~~colorschememapping~~\">
    	<style>
        	<!--
            /* Font Definitions */
            @font-face
            	{font-family:\"Cordia New\";
            	panose-1:2 11 3 4 2 2 2 2 2 4;
            	mso-font-charset:0;
            	mso-generic-font-family:swiss;
            	mso-font-pitch:variable;
            	mso-font-signature:-2130706429 0 0 0 65537 0;}
            @font-face
            	{font-family:\"Cordia New\";
            	panose-1:2 11 3 4 2 2 2 2 2 4;
            	mso-font-charset:0;
            	mso-generic-font-family:swiss;
            	mso-font-pitch:variable;
            	mso-font-signature:-2130706429 0 0 0 65537 0;}
            @font-face
            	{font-family:Calibri;
            	panose-1:2 15 5 2 2 2 4 3 2 4;
            	mso-font-charset:0;
            	mso-generic-font-family:swiss;
            	mso-font-pitch:variable;
            	mso-font-signature:-536859905 -1073732485 9 0 511 0;}
            @font-face
            	{font-family:Tahoma;
            	panose-1:2 11 6 4 3 5 4 4 2 4;
            	mso-font-charset:0;
            	mso-generic-font-family:swiss;
            	mso-font-pitch:variable;
            	mso-font-signature:-520081665 -1073717157 41 0 66047 0;}
            /* Style Definitions */
            p.MsoNormal, li.MsoNormal, div.MsoNormal
            	{mso-style-unhide:no;
            	mso-style-qformat:yes;
            	mso-style-parent:\"\";
            	margin:0cm;
            	margin-bottom:.0001pt;
            	mso-pagination:widow-orphan;
            	font-size:11.0pt;
            	mso-bidi-font-size:14.0pt;
            	font-family:\"Calibri\",\"sans-serif\";
            	mso-ascii-font-family:Calibri;
            	mso-ascii-theme-font:minor-latin;
            	mso-fareast-font-family:Calibri;
            	mso-fareast-theme-font:minor-latin;
            	mso-hansi-font-family:Calibri;
            	mso-hansi-theme-font:minor-latin;
            	mso-bidi-font-family:\"Cordia New\";
            	mso-bidi-theme-font:minor-bidi;}
            a:link, span.MsoHyperlink
            	{mso-style-noshow:yes;
            	mso-style-priority:99;
            	color:blue;
            	mso-themecolor:hyperlink;
            	text-decoration:underline;
            	text-underline:single;}
            a:visited, span.MsoHyperlinkFollowed
            	{mso-style-noshow:yes;
            	mso-style-priority:99;
            	color:purple;
            	mso-themecolor:followedhyperlink;
            	text-decoration:underline;
            	text-underline:single;}
            span.17
            	{mso-style-type:personal-compose;
            	mso-style-noshow:yes;
            	mso-style-unhide:no;
            	mso-ansi-font-size:11.0pt;
            	mso-bidi-font-size:14.0pt;
            	font-family:\"Calibri\",\"sans-serif\";
            	mso-ascii-font-family:Calibri;
            	mso-ascii-theme-font:minor-latin;
            	mso-fareast-font-family:Calibri;
            	mso-fareast-theme-font:minor-latin;
            	mso-hansi-font-family:Calibri;
            	mso-hansi-theme-font:minor-latin;
            	mso-bidi-font-family:\"Cordia New\";
            	mso-bidi-theme-font:minor-bidi;
            	color:windowtext;}
            .MsoChpDefault
            	{mso-style-type:export-only;
            	mso-default-props:yes;
            	font-family:\"Calibri\",\"sans-serif\";
            	mso-ascii-font-family:Calibri;
            	mso-ascii-theme-font:minor-latin;
            	mso-fareast-font-family:Calibri;
            	mso-fareast-theme-font:minor-latin;
            	mso-hansi-font-family:Calibri;
            	mso-hansi-theme-font:minor-latin;
            	mso-bidi-font-family:\"Cordia New\";
            	mso-bidi-theme-font:minor-bidi;}
            @page WordSection1
            	{size:612.0pt 792.0pt;
            	margin:72.0pt 72.0pt 72.0pt 72.0pt;
            	mso-header-margin:36.0pt;
            	mso-footer-margin:36.0pt;
            	mso-paper-source:0;}
            div.WordSection1
            	{page:WordSection1;}
            -->
      	</style>
   	</head>
   	<body lang=EN-US link=blue vlink=purple style='tab-interval:36.0pt'>
    	<div class=WordSection1>
    	".write_email_intro()."
        <table class=MsoNormalTable border=0 cellspacing=0 cellpadding=0 style='width:940.0pt;margin-left:-1.15pt;border-collapse:collapse;mso-yfti-tbllook:1184;mso-padding-alt:0cm 5.4pt 0cm 5.4pt'>
            <tr style='mso-yfti-irow:0;mso-yfti-firstrow:yes;height:25.5pt'>
            	<!-- HEADER: DATE -->
               	<td colspan=2 valign=top style='border:solid windowtext 1.0pt;mso-border-alt:solid windowtext .5pt;background:#DCE6F1;padding:0cm 5.4pt 0cm 5.4pt;height:25.5pt'>
                  <p class=MsoNormal align=center style='text-align:center'>
                     <b>
                        <span style='font-size:10.0pt;font-family:\"Tahoma\",\"sans-serif\";mso-fareast-font-family:\"Times New Roman\";color:black'>
                           Date
                           <o:p></o:p>
                        </span>
                     </b>
                  </p>
               	</td>

               	<!-- HEADER: TOTAL CHECKPOINT NOT COMPLETE -->
               	<td valign=top style='width:90.0pt;border:solid windowtext 1.0pt;border-left:none;mso-border-top-alt:solid windowtext .5pt;mso-border-bottom-alt:solid windowtext .5pt;mso-border-right-alt:solid windowtext .5pt;background:#DCE6F1;padding:0cm 5.4pt 0cm 5.4pt;height:25.5pt'>
                  <p class=MsoNormal align=center style='text-align:center'>
                     <b>
                        <span style='font-size:10.0pt;font-family:\"Tahoma\",\"sans-serif\";mso-fareast-font-family:\"Times New Roman\";color:black'>
                           Total Checkpoint Not Complete
                           <o:p></o:p>
                        </span>
                     </b>
                  </p>
               	</td>

            	<!-- HEADER: DB -->
               	<td valign=top style='width:30.0pt;border:solid windowtext 1.0pt;border-left:none;mso-border-top-alt:solid windowtext .5pt;mso-border-bottom-alt:solid windowtext .5pt;mso-border-right-alt:solid windowtext .5pt;background:#DCE6F1;padding:0cm 5.4pt 0cm 5.4pt;height:25.5pt'>
                  <p class=MsoNormal align=center style='text-align:center'>
                     <b>
                        <span style='font-size:10.0pt;font-family:\"Tahoma\",\"sans-serif\";mso-fareast-font-family:\"Times New Roman\";color:black'>
                           DB
                           <o:p></o:p>
                        </span>
                     </b>
                  </p>
               </td>
            	<!-- HEADER: HOURS [00-23] -->";

            for ($i=0;$i<24;$i++){
            	$GLOBALS['table_body'].="
               	<td valign=top style='width:30.0pt;border:solid windowtext 1.0pt;border-left:none;mso-border-top-alt:solid windowtext .5pt;mso-border-bottom-alt:solid windowtext .5pt;mso-border-right-alt:solid windowtext .5pt;background:#DCE6F1;padding:0cm 5.4pt 0cm 5.4pt;height:25.5pt'>
                  <p class=MsoNormal align=center style='text-align:center'>
                     <b>
                        <span style='font-size:10.0pt;font-family:\"Tahoma\",\"sans-serif\";mso-fareast-font-family:\"Times New Roman\";color:black'>
                           ".sprintf( '%02d', $i )."
                           <o:p></o:p>
                        </span>
                     </b>
                  </p>
               	</td>";
            }	
            $GLOBALS['table_body'].="</tr>";
	}

	function write_table_tail(){
		$GLOBALS['table_body'].="
            </tr>
			</table>
      </div>";
	}

	
?>