<?php 
	include('daily_report.php');
?>




