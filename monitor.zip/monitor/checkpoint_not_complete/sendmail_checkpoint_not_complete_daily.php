<?php 
   $sendmail_status=true;

	/// [1] Connect To DB For Query Checkpoint Not Complete [.208] ///
	$con = mysqli_connect("10.11.11.208","root","password");
	if (!$con) {
    die("Database connection failed: ".mysqli_error());
	}
	$db_select = mysqli_select_db($con,"monitor");
	if (!$db_select) {
    	die("Database selection failed: ".mysqli_error());
	}
	mysqli_set_charset($con,'utf8');
   /// End [1] Connect To DB For Query Checkpoint Not Complete [.208] ///



   /// [2] Assign Date (If Available From Parameter) ///
	if(isset($_GET['date'])){
		if($_GET['date']=='today')
			$select_date=date('d-m-Y');
		elseif($_GET['date']=='yesterday')
			$select_date=date('d-m-Y',strtotime(date('d-m-Y')." -1 day"));
		else
			$select_date=$_GET['date'];

      echo "<b>Checkpoint Not Complete Report (Daily) [".$select_date."]</b><br>";
      echo "Check Date Status [Sat, Sun, Holiday]: ";

      // Check Date Is Equal Holiday Or Sat & Sun
      $today=date("D", strtotime($select_date));

      // 1. Check Is Day = Sat or Sun
      if($today=="Sat" || $today=="Sun"){
         echo $select_date." => Not Send (Weekend)<br>";
         $sendmail_status=false;
      }

      // 2. Check Is Day = Holiday List
      $con210 = mysqli_connect("10.11.11.210","root","password");
      if (!$con210) {
         die("Database connection failed: " . mysqli_error());
      }
      $db_select = mysqli_select_db($con210, "3bb_standby");
      if (!$db_select) {
         die("Database selection failed: " . mysqli_error());
      }
      mysqli_set_charset($con210, 'utf8');
      $sql=mysqli_query($con210, "SELECT * FROM holiday_calendar WHERE holiday_date='".date("Y-m-d", strtotime($select_date))."' LIMIT 1;");
      while ($result=mysqli_fetch_array($sql)) {
         $sendmail_status=false;
         echo $select_date." => Not Send (Holiday)<br>";
      }

      if ($sendmail_status==true){echo "OK<br>";}


   	// Total Checkpoint Count DB1 & DB2
   	$total_cp=0; 


   	// Query Checkpoint Not Complete Data
   	$sql=mysqli_query($con, "SELECT * FROM checkpoint_not_complete WHERE date_format(checkpoint_date,'%Y-%m-%d') BETWEEN '".date("Y-m-d",strtotime($select_date." -15 day"))."' AND '".date("Y-m-d",strtotime($select_date))."';");

     while ($result=mysqli_fetch_array($sql)) {
         $date=$result['checkpoint_date'];
         $db1_count[$date]=$result['db1_count'];
     	   $db1_detail[$date]=str_replace("#!T1!#","Thread 1 cannot allocate new log, sequence ",$result['db1_detail']);
     	   $db1_detail[$date]=str_replace("#!CNC!#","Checkpoint not complete",$db1_detail[$date]);
         $db2_count[$date]=$result['db2_count'];
     	   $db2_detail[$date]=str_replace("#!T2!#","Thread 2 cannot allocate new log, sequence ",$result['db2_detail']);
     	   $db2_detail[$date]=str_replace("#!CNC!#","Checkpoint not complete",$db2_detail[$date]);
     	   $total_cp+=$db1_count[$date];
     	   $total_cp+=$db2_count[$date];
     }

   }
   else{
   	// No Date Input
      echo "<b>NO DATE INPUT</b>"."<br>";
      echo "<b>EXAMPLE URL:</b> http://10.11.11.206/monitor/checkpoint_not_complete/sendmail_checkpoint_not_complete_daily.php?date=05-05-2016&sendmail=1 <b>OR</b> ?date=today&sendmail=1";
      die();
      // End PHP
   }

   echo "Total Checkpoint = ".$total_cp."<br><br>";

   if($total_cp==0){
   	// No Checkpoint Not Complete
   	$col_cp_width=350;
   }
   else{
   	$col_cp_width=460;
   }
?>


<!-- Query Remark -->
	<?php
		header('Content-Type: text/html; charset=utf-8');
		function query_remark($date){
			// Query Remark	
			$con = mysqli_connect("10.11.11.208","root","password");
			mysqli_set_charset($con, "utf8");
			if (!$con) {
		    die("Database connection failed: " . mysqli_error());
			}
			$db_select = mysqli_select_db($con, "monitor");
			if (!$db_select) {
		    	die("Database selection failed: " . mysqli_error());
			}
			mysqli_set_charset( $con, 'utf8');

			$sql=mysqli_query($con, "SELECT * FROM checkpoint_not_complete_remark WHERE remark_date<='".$date."' ORDER BY remark_date DESC;");
				$remark='';
			  while ($result=mysqli_fetch_array($sql)) {
			    $date=date("d/m/Y", strtotime($result['remark_date']));
			    if($result['remark_time']==null){
			    	$remark.="[".$date."] ".$result['remark_detail']."<br>";
			    }
			    else{
			    	$remark.="[".$date." ".$result['remark_time']."] ".$result['remark_detail']."<br>";
			    }
			  }
			  return $remark;
		}
	?>



<!-- Other PHP Function -->
<?php
	function getdate_format($date){	
		// Example Return "27-พ.ค.-16";
		$month_abv=intval(date("m", strtotime(str_replace("/","-",$date))));
		switch($month_abv){
			case 1:
				$month_abv='ม.ค.';
				break;
			case 2:
				$month_abv='ก.พ.';
				break;
			case 3:
				$month_abv='มี.ค.';
				break;
			case 4:
				$month_abv='เม.ย.';
				break;
			case 5:
				$month_abv='พ.ค.';
				break;
			case 6:
				$month_abv='มิ.ย.';
				break;
			case 7:
				$month_abv='ก.ค.';
				break;
			case 8:
				$month_abv='ส.ค.';
				break;
			case 9:
				$month_abv='ก.ย.';
				break;
			case 10:
				$month_abv='ต.ค.';
				break;
			case 11:
				$month_abv='พ.ย.';
				break;
			case 12:
				$month_abv='ธ.ค.';
				break;
			default:
				// It's Impossible !
		}

		return intval(date("d", strtotime(str_replace("/","-",$date))))."-".$month_abv."-".date("y", strtotime(str_replace("/","-",$date)));
	}
	function day_name_thai($name){
		switch($name){
			case 'Sun':
				// Not Send
				return 'อาทิตย์';
				break;
			case 'Mon':
				return 'จันทร์';
				break;
			case 'Tue':
				return 'อังคาร';
				break;
			case 'Wed':
				return 'พุธ';
				break;
			case 'Thu':
				return 'พฤหัสบดี';
				break;
			case 'Fri':
				return 'ศุกร์';
				break;
			case 'Sat':
				// Not Send
				return 'เสาร์';
				break;
			default:
				// It's Impossible !
		}
	}
?>



<?php
	echo "<b>**********[START EMAIL PART]**********</b><br>";

	// Create Email Body
	$day_name_thai=date("D", strtotime(str_replace("/","-",$select_date)));
	$day_name_thai=day_name_thai($day_name_thai);
   $day_name_thai='';
	//$day_header=date("j M Y", strtotime(str_replace("/","-",$select_date)));
   $day_header=date("Y-m-d", strtotime(str_replace("/","-",$select_date)));
	$subject_mail="Daily Report Checkpoint Not Complete ประจำวัน".$day_name_thai."ที่ ".$day_header;


$email_body="
<!-- 1. HEADER PART -->
<html xmlns:v=\"urn:schemas-microsoft-com:vml\" xmlns:o=\"urn:schemas-microsoft-com:office:office\" xmlns:w=\"urn:schemas-microsoft-com:office:word\" xmlns:x=\"urn:schemas-microsoft-com:office:excel\" xmlns:m=\"http://schemas.microsoft.com/office/2004/12/omml\" xmlns=\"http://www.w3.org/TR/REC-html40\">
   <head>
      <meta http-equiv=Content-Type content=\"text/html; charset=windows-874\">
      <meta name=ProgId content=Word.Document>
      <meta name=Generator content=\"Microsoft Word 14\">
      <meta name=Originator content=\"Microsoft Word 14\">
      <link rel=File-List href=\"cid:filelist.xml@01D3643B.E153CD10\">
      <link rel=themeData href=\"~~themedata~~\">
      <link rel=colorSchemeMapping href=\"~~colorschememapping~~\">
      <style>
         <!--
            /* Font Definitions */
            @font-face
            	{font-family:\"Angsana New\";
            	panose-1:2 2 6 3 5 4 5 2 3 4;
            	mso-font-charset:0;
            	mso-generic-font-family:roman;
            	mso-font-pitch:variable;
            	mso-font-signature:-2130706429 0 0 0 65537 0;}
            @font-face
            	{font-family:\"Cordia New\";
            	panose-1:2 11 3 4 2 2 2 2 2 4;
            	mso-font-charset:0;
            	mso-generic-font-family:swiss;
            	mso-font-pitch:variable;
            	mso-font-signature:-2130706429 0 0 0 65537 0;}
            @font-face
            	{font-family:\"Cordia New\";
            	panose-1:2 11 3 4 2 2 2 2 2 4;
            	mso-font-charset:0;
            	mso-generic-font-family:swiss;
            	mso-font-pitch:variable;
            	mso-font-signature:-2130706429 0 0 0 65537 0;}
            @font-face
            	{font-family:Calibri;
            	panose-1:2 15 5 2 2 2 4 3 2 4;
            	mso-font-charset:0;
            	mso-generic-font-family:swiss;
            	mso-font-pitch:variable;
            	mso-font-signature:-536859905 -1073732485 9 0 511 0;}
            @font-face
            	{font-family:Tahoma;
            	panose-1:2 11 6 4 3 5 4 4 2 4;
            	mso-font-charset:0;
            	mso-generic-font-family:swiss;
            	mso-font-pitch:variable;
            	mso-font-signature:-520081665 -1073717157 41 0 66047 0;}
            @font-face
            	{font-family:\"Leelawadee UI\";
            	panose-1:2 11 5 2 4 2 4 2 2 3;
            	mso-font-charset:0;
            	mso-generic-font-family:swiss;
            	mso-font-pitch:variable;
            	mso-font-signature:-1560281085 0 65536 0 65793 0;}
            @font-face
            	{font-family:Leelawadee;
            	panose-1:2 11 5 2 4 2 4 2 2 3;
            	mso-font-charset:0;
            	mso-generic-font-family:swiss;
            	mso-font-pitch:variable;
            	mso-font-signature:-2130706429 0 0 0 65537 0;}
            /* Style Definitions */
            p.MsoNormal, li.MsoNormal, div.MsoNormal
            	{mso-style-unhide:no;
            	mso-style-qformat:yes;
            	mso-style-parent:\"\";
            	margin:0cm;
            	margin-bottom:.0001pt;
            	mso-pagination:widow-orphan;
            	font-size:11.0pt;
            	mso-bidi-font-size:14.0pt;
            	font-family:\"Calibri\",\"sans-serif\";
            	mso-ascii-font-family:Calibri;
            	mso-ascii-theme-font:minor-latin;
            	mso-fareast-font-family:Calibri;
            	mso-fareast-theme-font:minor-latin;
            	mso-hansi-font-family:Calibri;
            	mso-hansi-theme-font:minor-latin;
            	mso-bidi-font-family:\"Cordia New\";
            	mso-bidi-theme-font:minor-bidi;}
            a:link, span.MsoHyperlink
            	{mso-style-noshow:yes;
            	mso-style-priority:99;
            	color:blue;
            	mso-themecolor:hyperlink;
            	text-decoration:underline;
            	text-underline:single;}
            a:visited, span.MsoHyperlinkFollowed
            	{mso-style-noshow:yes;
            	mso-style-priority:99;
            	color:purple;
            	mso-themecolor:followedhyperlink;
            	text-decoration:underline;
            	text-underline:single;}
            p
            	{mso-style-noshow:yes;
            	mso-style-priority:99;
            	mso-margin-top-alt:auto;
            	margin-right:0cm;
            	mso-margin-bottom-alt:auto;
            	margin-left:0cm;
            	mso-pagination:widow-orphan;
            	font-size:14.0pt;
            	font-family:\"Angsana New\",\"serif\";
            	mso-fareast-font-family:Calibri;
            	mso-fareast-theme-font:minor-latin;}
            span.17
            	{mso-style-type:personal-compose;
            	mso-style-noshow:yes;
            	mso-style-unhide:no;
            	mso-ansi-font-size:11.0pt;
            	mso-bidi-font-size:14.0pt;
            	font-family:\"Calibri\",\"sans-serif\";
            	mso-ascii-font-family:Calibri;
            	mso-ascii-theme-font:minor-latin;
            	mso-fareast-font-family:Calibri;
            	mso-fareast-theme-font:minor-latin;
            	mso-hansi-font-family:Calibri;
            	mso-hansi-theme-font:minor-latin;
            	mso-bidi-font-family:\"Cordia New\";
            	mso-bidi-theme-font:minor-bidi;
            	color:windowtext;}
            span.SpellE
            	{mso-style-name:\"\";
            	mso-spl-e:yes;}
            .MsoChpDefault
            	{mso-style-type:export-only;
            	mso-default-props:yes;
            	mso-ascii-font-family:Calibri;
            	mso-ascii-theme-font:minor-latin;
            	mso-fareast-font-family:Calibri;
            	mso-fareast-theme-font:minor-latin;
            	mso-hansi-font-family:Calibri;
            	mso-hansi-theme-font:minor-latin;
            	mso-bidi-font-family:\"Cordia New\";
            	mso-bidi-theme-font:minor-bidi;}
            @page WordSection1
            	{size:612.0pt 792.0pt;
            	margin:72.0pt 72.0pt 72.0pt 72.0pt;
            	mso-header-margin:36.0pt;
            	mso-footer-margin:36.0pt;
            	mso-paper-source:0;}
            div.WordSection1
            	{page:WordSection1;}
            -->
      </style>
   </head>
   <body lang=EN-US link=blue vlink=purple style='tab-interval:36.0pt'>
      <div class=WordSection1>
         <p>
            <b><span lang=TH style='font-size:12.0pt;font-family:\"Tahoma\",\"sans-serif\";color:#1F497D'>เรียน</span></b><b><span style='font-size:12.0pt;font-family:\"Tahoma\",\"sans-serif\";color:#1F497D'>&nbsp;<span lang=TH>ทุกท่านครับ</span></span></b>
            <span style='font-size:12.0pt;font-family:\"Tahoma\",\"sans-serif\";color:#1F497D'>
               <o:p></o:p>
            </span>
         </p>
         <p class=MsoNormal>
            <span style='font-size:12.0pt;font-family:\"Tahoma\",\"sans-serif\";color:#1F497D'><span style='mso-tab-count:1'>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </span><span lang=TH>Daily Report Checkpoint Not Complete ประจำวัน".$day_name_thai."ที่ ".$day_header."&nbsp;<span lang=TH>รายละเอียดดังตารางครับ</span><br style='mso-special-character:line-break'><![if !supportLineBreakNewLine]><br style='mso-special-character:line-break'><![endif]>
               <o:p></o:p>
            </span>
         </p>
         <table class=MsoNormalTable border=0 cellspacing=0 cellpadding=0 width=1324 style='width:993.0pt;margin-left:-1.15pt;border-collapse:collapse;mso-yfti-tbllook:1184;mso-padding-alt:0cm 5.4pt 0cm 5.4pt'>


		<!-- TABLE HEADER -->

		<!-- 1ST LINE -->
        <tr style='mso-yfti-irow:0;height:14.25pt'>
               <td nowrap colspan=2 rowspan=2 style='width:75.0pt;border-top:windowtext;border-left:windowtext;border-bottom:black;border-right:black;border-style:solid;border-width:1.0pt;mso-border-top-alt:windowtext;mso-border-left-alt:windowtext;mso-border-bottom-alt:black;mso-border-right-alt:black;mso-border-style-alt:solid;mso-border-width-alt:.5pt;background:#B8CCE4;padding:0cm 5.4pt 0cm 5.4pt;height:14.25pt'>
                  <p class=MsoNormal align=center style='text-align:center'>
                     <b>
                        <span style='font-size:10.0pt;font-family:\"Tahoma\",\"sans-serif\";mso-fareast-font-family:\"Times New Roman\";color:#002060'>
                           &nbsp;
                           <o:p></o:p>
                        </span>
                     </b>
                  </p>
               </td>

               <td nowrap colspan=2 style='width:".$col_cp_width.".0pt;border-top:solid windowtext 1.0pt;border-left:none;border-bottom:solid windowtext 1.0pt;border-right:solid black 1.0pt;mso-border-top-alt:solid windowtext .5pt;mso-border-bottom-alt:solid windowtext .5pt;mso-border-right-alt:solid black .5pt;background:#B8CCE4;padding:0cm 5.4pt 0cm 5.4pt;height:14.25pt'>
                  <p class=MsoNormal align=center style='text-align:center'>
                     <b>
                        <span style='font-size:10.0pt;font-family:\"Tahoma\",\"sans-serif\";mso-fareast-font-family:\"Times New Roman\";color:#002060'>
                           Checkpoint Not Complete
                           <o:p></o:p>
                        </span>
                     </b>
                  </p>
               </td>

               <td nowrap rowspan=2 style='width:380.0pt;border-top:solid windowtext 1.0pt;border-left:none;border-bottom:solid black 1.0pt;border-right:solid windowtext 1.0pt;mso-border-left-alt:solid windowtext .5pt;mso-border-alt:solid windowtext .5pt;mso-border-bottom-alt:solid black .5pt;background:#B8CCE4;padding:0cm 5.4pt 0cm 5.4pt;height:14.25pt'>
                  <p class=MsoNormal align=center style='text-align:center'>
                     <b>
                        <span style='font-size:10.0pt;font-family:\"Tahoma\",\"sans-serif\";mso-fareast-font-family:\"Times New Roman\";color:#002060'>
                           Remark
                           <o:p></o:p>
                        </span>
                     </b>
                  </p>
               </td>
            </tr>

            <!-- 2ND LINE -->
            <tr style='mso-yfti-irow:1;height:14.25pt'>
               <td nowrap style='width:".($col_cp_width/2).".0pt;border-top:none;border-left:none;border-bottom:solid windowtext 1.0pt;border-right:solid windowtext 1.0pt;mso-border-bottom-alt:solid windowtext .5pt;mso-border-right-alt:solid windowtext .5pt;background:#C5D9F1;padding:0cm 5.4pt 0cm 5.4pt;height:14.25pt'>
                  <p class=MsoNormal align=center style='text-align:center'>
                     <b>
                        <span style='font-size:10.0pt;font-family:\"Tahoma\",\"sans-serif\";mso-fareast-font-family:\"Times New Roman\";color:#002060'>
                           DB1: 4 Groups
                           <o:p></o:p>
                        </span>
                     </b>
                  </p>
               </td>

               <td nowrap style='width:".($col_cp_width/2).".0pt;border-top:none;border-left:none;border-bottom:solid windowtext 1.0pt;border-right:solid windowtext 1.0pt;mso-border-bottom-alt:solid windowtext .5pt;mso-border-right-alt:solid windowtext .5pt;background:#C5D9F1;padding:0cm 5.4pt 0cm 5.4pt;height:14.25pt'>
                  <p class=MsoNormal align=center style='text-align:center'>
                     <b>
                        <span style='font-size:10.0pt;font-family:\"Tahoma\",\"sans-serif\";mso-fareast-font-family:\"Times New Roman\";color:#002060'>
                           DB2: 4 Groups 
                           <o:p></o:p>
                        </span>
                     </b>
                  </p>
               </td>
            </tr>";



// Loop 15 Day Back
for($i=0;$i<15;$i++){

		$cp_db1='';
		$cp_db2='';

		if($db1_count[date("Y-m-d",strtotime($select_date." -".$i." day"))]!=null && $db1_count[date("Y-m-d",strtotime($select_date." -".$i." day"))]!=0){$cp_db1= "<b>".$db1_count[date("Y-m-d",strtotime($select_date." -".$i." day"))]."</b>";} else{$cp_db1= "-";}
		if($db2_count[date("Y-m-d",strtotime($select_date." -".$i." day"))]!=null && $db2_count[date("Y-m-d",strtotime($select_date." -".$i." day"))]!=0){$cp_db2= "<b>".$db2_count[date("Y-m-d",strtotime($select_date." -".$i." day"))]."</b>";} else{$cp_db2= "-";}


	$email_body.="
			<!-- 2. BODY PART -->
			<!-- YELLOW ZONE -->
            <tr style='mso-yfti-irow:2;height:14.25pt'>
            	<!-- DAY ABREVIATION Ex. Mon -->
               <td nowrap valign=bottom style='width:15.0pt;border:none;border-left:solid windowtext 1.0pt;mso-border-left-alt:solid windowtext .5pt;background:yellow;padding:0cm 5.4pt 0cm 5.4pt;height:14.25pt'>
                  <p class=MsoNormal>
                     <span style='font-size:10.0pt;font-family:\"Tahoma\",\"sans-serif\";mso-fareast-font-family:\"Times New Roman\";color:black'>".date("D", strtotime(str_replace("/","-",$select_date)." -".$i." day"))."<o:p></o:p>
                     </span>
                  </p>
               </td>

               <!-- DATE Ex. 23-พ.ย.-17 -->
               <td nowrap valign=bottom style='width:60.0pt;border:none;border-right:solid windowtext 1.0pt;mso-border-right-alt:solid windowtext .5pt;background:yellow;padding:0cm 5.4pt 0cm 5.4pt;height:14.25pt'>
                  <p class=MsoNormal>
                     <span style='font-size:10.0pt;font-family:\"Tahoma\",\"sans-serif\";mso-fareast-font-family:\"Times New Roman\";color:black'>".getdate_format(date("d/m/Y", strtotime(str_replace("/","-",$select_date)." -".$i." day")))."<o:p></o:p>
                     </span>
                  </p>
               </td>

               <!-- Checkpoint Count [171] -->
               <td nowrap valign=bottom style='border:none;border-right:solid windowtext 1.0pt;mso-border-right-alt:solid windowtext .5pt;background:yellow;padding:0cm 5.4pt 0cm 5.4pt;height:14.25pt'>
                  <p class=MsoNormal align=center style='text-align:center'>
                     <b>
                        <span style='font-size:10.0pt;font-family:\"Tahoma\",\"sans-serif\";mso-fareast-font-family:\"Times New Roman\";color:red'>".$cp_db1."<o:p></o:p>
                     </span>
                  </p>
               </td>

               <!-- Checkpoint Count [172] -->
               <td nowrap valign=bottom style='border:none;border-right:solid windowtext 1.0pt;mso-border-right-alt:solid windowtext .5pt;background:yellow;padding:0cm 5.4pt 0cm 5.4pt;height:14.25pt'>
                  <p class=MsoNormal align=center style='text-align:center'>
                     <b>
                        <span style='font-size:10.0pt;font-family:\"Tahoma\",\"sans-serif\";mso-fareast-font-family:\"Times New Roman\";color:red'>".$cp_db2."<o:p></o:p>
                     </span>
                  </p>
               </td>

               <!-- Below Remark Header-->
               <td nowrap valign=bottom style='border:none;border-right:solid windowtext 1.0pt;mso-border-right-alt:solid windowtext .5pt;background:yellow;padding:0cm 5.4pt 0cm 5.4pt;height:14.25pt'>
                  <p class=MsoNormal>
                     <span style='font-size:10.0pt;font-family:\"Tahoma\",\"sans-serif\";mso-fareast-font-family:\"Times New Roman\";color:red'>
                        &nbsp;
                        <o:p></o:p>
                     </span>
                  </p>
               </td>
               </tr>

               <!-- White Area-->
               <tr style='mso-yfti-irow:3'>
               <td nowrap valign=bottom style='border-top:none;border-left:solid windowtext 1.0pt;border-bottom:solid windowtext 1.0pt;border-right:none;mso-border-left-alt:solid windowtext .5pt;mso-border-bottom-alt:solid windowtext .5pt;padding:0cm 5.4pt 0cm 5.4pt'>
                  <p class=MsoNormal align=center style='text-align:center'>
                     <b>
                        <span style='font-size:10.0pt;font-family:\"Tahoma\",\"sans-serif\";mso-fareast-font-family:\"Times New Roman\";color:#002060'>
                           &nbsp;
                           <o:p></o:p>
                        </span>
                     </b>
                  </p>
               </td>
               <td nowrap valign=bottom style='border-top:none;border-left:none;border-bottom:solid windowtext 1.0pt;border-right:solid windowtext 1.0pt;mso-border-bottom-alt:solid windowtext .5pt;mso-border-right-alt:solid windowtext .5pt;padding:0cm 5.4pt 0cm 5.4pt'>
                  <p class=MsoNormal align=center style='text-align:center'>
                     <b>
                        <span style='font-size:10.0pt;font-family:\"Tahoma\",\"sans-serif\";mso-fareast-font-family:\"Times New Roman\";color:#002060'>
                           &nbsp;
                           <o:p></o:p>
                        </span>
                     </b>
                  </p>
               </td>

                <!-- Checkpoint Detail [171]-->
               <td valign=top style='border-top:none;border-left:none;border-bottom:solid windowtext 1.0pt;border-right:solid windowtext 1.0pt;mso-border-bottom-alt:solid windowtext .5pt;mso-border-right-alt:solid windowtext .5pt;padding:0cm 5.4pt 0cm 5.4pt'>
                  <p class=MsoNormal>
                     <span style='font-size:10.0pt;font-family:\"Tahoma\",\"sans-serif\";mso-fareast-font-family:\"Times New Roman\";color:black'>
                        <o:p></o:p>".$db1_detail[date("Y-m-d",strtotime($select_date." -".$i." day"))]."
                     </span>
                  </p>
               </td>
               <!-- Checkpoint Detail [172]-->
               <td valign=top style='border-top:none;border-left:none;border-bottom:solid windowtext 1.0pt;border-right:solid windowtext 1.0pt;mso-border-bottom-alt:solid windowtext .5pt;mso-border-right-alt:solid windowtext .5pt;padding:0cm 5.4pt 0cm 5.4pt'>
                  <p class=MsoNormal>
                     <span style='font-size:10.0pt;font-family:\"Tahoma\",\"sans-serif\";mso-fareast-font-family:\"Times New Roman\";color:black'>
                        <o:p></o:p>".$db2_detail[date("Y-m-d",strtotime($select_date." -".$i." day"))]."
                     </span>
                  </p>
               </td>

               <!-- Remark Area -->
               <td valign=top style='border-top:none;border-left:none;border-bottom:solid windowtext 1.0pt;border-right:solid windowtext 1.0pt;mso-border-bottom-alt:solid windowtext .5pt;mso-border-right-alt:solid windowtext .5pt;padding:0cm 5.4pt 0cm 5.4pt'>
                  <p class=MsoNormal><span style='font-size:10.0pt;font-family:\"Tahoma\",\"sans-serif\";mso-fareast-font-family:\"Times New Roman\"'>".query_remark(date("Y-m-d", strtotime(str_replace("/","-",$select_date)." -".$i." day")))."<o:p></o:p></span>
                  </p>
               </td>
            </tr>";
}

$email_body.="
		<!-- 3. SIGNATURE PART -->
		</table>
       <p class=MsoNormal>
            <span lang=TH style='font-size:14.0pt;mso-ansi-font-size:11.0pt;font-family:\"Cordia New\",\"sans-serif\";mso-ascii-font-family:Calibri;mso-ascii-theme-font:minor-latin;mso-hansi-font-family:Calibri;mso-hansi-theme-font:minor-latin;mso-bidi-font-family:\"Cordia New\";mso-bidi-theme-font:minor-bidi;color:#1F497D'><br></span><span lang=TH style='font-size:12.0pt;font-family:\"Tahoma\",\"sans-serif\";color:#1F497D'><span style='mso-tab-count:1'>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </span>*หมายเหตุ : </span>
            <span lang=TH style='font-size:12.0pt;font-family:\"Tahoma\",\"sans-serif\";color:red'>
               เป็นระบบส่งอี<span class=SpellE>เมลล์</span>อัตโนมัติ<br><br style='mso-special-character:line-break'><![if !supportLineBreakNewLine]><br style='mso-special-character:line-break'><![endif]>
            </span>
            <span style='color:#1F497D'>
               <o:p></o:p>
            </span>
         </p>
        <p class=MsoNormal>
            <a name=\"_MailAutoSig\"><b><span lang=TH style='font-size:14.0pt;font-family:\"Leelawadee\",\"sans-serif\";mso-fareast-font-family:\"Times New Roman\";mso-fareast-theme-font:minor-fareast;color:#002060;mso-no-proof:yes'>ขอแสดงความนับถือ</span></b></a>
            <span style='mso-bookmark:_MailAutoSig'>
               <b>
                  <span style='font-size:14.0pt;font-family:\"Leelawadee\",\"sans-serif\";mso-fareast-font-family:\"Times New Roman\";mso-fareast-theme-font:minor-fareast;color:#002060;mso-no-proof:yes'>
                     <o:p></o:p>
                  </span>
               </b>
            </span>
        </p>
        <p class=MsoNormal>
            <span style='mso-bookmark:_MailAutoSig'><b><span style='font-size:8.0pt;font-family:\"Leelawadee\",\"sans-serif\";mso-fareast-font-family:\"Times New Roman\";mso-fareast-theme-font:minor-fareast;color:gray;mso-themecolor:background1;mso-themeshade:128;mso-no-proof:yes'>o</span></b></span><span style='mso-bookmark:_MailAutoSig'><b><span style='font-size:8.0pt;font-family:\"Leelawadee\",\"sans-serif\";mso-fareast-font-family:\"Times New Roman\";mso-fareast-theme-font:minor-fareast;color:gray;mso-no-proof:yes'>-o-o-o-o-o-o-o-o-o-o-o-o-o-o-o-o-o-o-o-o-o-o-o-o-o-o-o-o</span></b></span>
            <span style='mso-bookmark:_MailAutoSig'>
               <span style='font-size:8.0pt;font-family:\"Leelawadee\",\"sans-serif\";mso-fareast-font-family:\"Times New Roman\";mso-fareast-theme-font:minor-fareast;mso-no-proof:yes'>
                  <o:p></o:p>
               </span>
            </span>
        </p>
        <p class=MsoNormal>
            <span style='mso-bookmark:_MailAutoSig'><b><span lang=TH style='font-size:14.0pt;font-family:\"Leelawadee UI\",\"sans-serif\";mso-fareast-font-family:\"Times New Roman\";mso-fareast-theme-font:minor-fareast;color:#31849B;mso-no-proof:yes'><span style='mso-spacerun:yes'>&nbsp;&nbsp;&nbsp;&nbsp; </span></span></b></span><span style='mso-bookmark:_MailAutoSig'><b><span lang=TH style='font-size:12.0pt;font-family:\"Leelawadee UI\",\"sans-serif\";mso-fareast-font-family:\"Times New Roman\";mso-fareast-theme-font:minor-fareast;color:#E36C0A;mso-themecolor:accent6;mso-themeshade:191;mso-no-proof:yes'>เสริมชัย ลุประสิทธิวร</span></b></span>
            <span style='mso-bookmark:_MailAutoSig'>
               <b>
                  <span style='font-size:12.0pt;font-family:\"Leelawadee UI\",\"sans-serif\";mso-fareast-font-family:\"Times New Roman\";mso-fareast-theme-font:minor-fareast;color:#E36C0A;mso-themecolor:accent6;mso-themeshade:191;mso-no-proof:yes'>
                     <o:p></o:p>
                  </span>
               </b>
            </span>
        </p>
        <p class=MsoNormal>
            <span style='mso-bookmark:_MailAutoSig'>
               <b>
                  <span style='font-family:\"Leelawadee UI\",\"sans-serif\";mso-fareast-font-family:\"Times New Roman\";mso-fareast-theme-font:minor-fareast;color:#31849B;mso-no-proof:yes'>
                     <span style='mso-spacerun:yes'>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </span>E-Mail<span style='mso-spacerun:yes'>&nbsp;&nbsp; </span>:<span style='mso-spacerun:yes'>&nbsp;&nbsp; </span>sermchai.l@jasmine.com
                     <o:p></o:p>
                  </span>
               </b>
            </span>
        </p>
        <p class=MsoNormal>
            <span style='mso-bookmark:_MailAutoSig'>
               <b>
                  <span style='font-family:\"Leelawadee UI\",\"sans-serif\";mso-fareast-font-family:\"Times New Roman\";mso-fareast-theme-font:minor-fareast;color:#31849B;mso-no-proof:yes'>
                     <span style='mso-spacerun:yes'>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </span>Triple T Broadband PCL. [9th Floor]
                     <o:p></o:p>
                  </span>
               </b>
            </span>
        </p>
        <p class=MsoNormal>
            <span style='mso-bookmark:_MailAutoSig'><b><span style='font-size:8.0pt;font-family:\"Leelawadee\",\"sans-serif\";mso-fareast-font-family:\"Times New Roman\";mso-fareast-theme-font:minor-fareast;color:gray;mso-no-proof:yes'>o-o-o-o-o-o-o-o-o-o-o-o-o-o-o-o-o-o-o-o-o-o-o-o-o-o-o-o-o</span></b></span><span style='mso-bookmark:_MailAutoSig'></span>
            <b>
               <span style='mso-fareast-font-family:\"Times New Roman\";mso-fareast-theme-font:minor-fareast;color:gray;mso-no-proof:yes'>
                  <o:p></o:p>
               </span>
            </b>
        </p>
      </div>
   </body>
</html>";

 echo $email_body; 
 echo "<br><b>**********[END EMAIL PART]**********</b><br>"; 

 ?>



<!-- Send E-Mail -->
<?php 
   if($sendmail_status==true){
   	if($_GET['sendmail']==1){

   	echo "<b>**********[SENDING EMAIL SUCCESSFULLY]**********</b><br>";

      // Mail To
      //$mailto = 'sahapab.p@jasmine.com';
   	$mailto = 'sermchai.l@jasmine.com,kwannaphat.f@jasmine.com,pathumthip.p@jasmine.com,thanet.c@ccs.jasmine.com';

   	$subject = "=?UTF-8?B?".base64_encode($subject_mail)."?=";

   	// Header
   	$header = "From: Sermchai Luprasitthiworn <sermchai.l@jasmine.com>\r\n";
      $header .= "Cc: radmin@3bbmail.com,aoi.n@jasmine.com\n";
   	$header .= "MIME-Version: 1.0\r\n";
   	$header .= "Content-Type: text/html; charset=UTF-8\r\n";
      $header .= "Content-Transfer-Encoding: base64\r\n\r\n";

   	$main_message .= chunk_split(base64_encode($email_body))."\r\n";

   	// Execute
   	mail($mailto, $subject, $main_message, $header);
   	}
   }
?>
