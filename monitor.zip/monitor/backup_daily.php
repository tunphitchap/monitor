
<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta name="description" content="">
    <meta name="author" content="">
    <link rel="icon" href="../../favicon.ico">

    <title>Radius-Monitor</title>

    <?php include("import_lib.php"); ?>
    <link href="css/navbar-top-fixed.css" rel="stylesheet">

     <style type="text/css">
       .textAlignVer{
       font-size:12px;
       }
       .textAlignVerRotate{
       display:block;
       -webkit-transform: rotate(-90deg);
       -moz-transform: rotate(-90deg);
       font-size:12px;
       }
       a:hover{
       text-decoration: none;
       }
     </style>

     <style>
       .highcharts-container {
           overflow: visible !important;
       }
       .MyChartTooltip {
           position: relative;
           z-index: 50;
           border-radius: 5px;
           background-color: #ffffff;
           padding: 5px;
           font-size: 9pt;
           y: -1;
           overflow: auto;

       }
       .highcharts-tooltip {
         pointer-events: all !important;
       }
    </style>
</head>



<!-- [0] Initialize - BY FIFAZ// -->
<?php
  date_default_timezone_set('Asia/Bangkok');
  include "connect208.php";
?>

<!-- Policy Color Code HERE!!!-->
<?php
  function getPolicyColor($policy){

    // BAR 60% - LINE 80% 

    switch ($policy) {
      case "Catalog_Pol-bar": // Sky ok
          return "#00cccc";
          break;
      case "Catalog_Pol-line": // Sky ok
          return "#66ffff";
          break;
      case "File_System_Full_New_DB1-bar": // Red ok
          return "#ff5c33";
          break;
      case "File_System_Full_New_DB1-line": // Red ok
          return "#ff9980";
          break;
      case "File_System_Full_New_DB2-bar": // Pink ok
          return "#ff4d88";
          break;
      case "File_System_Full_New_DB2-line": // Pink ok
          return "#ff99bb";
          break;
      case "File_System_Full_New_RLOG2-bar": // Purple ok
          return "#b84dff";
          break;
      case "File_System_Full_New_RLOG2-line": // Purple ok
          return "#d699ff";
          break;
      case "New_Daily_Database_New_RLOG2-bar": // Green ok
          return "#4dff4d"; 
          break;
      case "New_Daily_Database_New_RLOG2-line": // Green ok
          return "#b3ffb3"; 
          break;
      case "File_System_Full_New_RLOG2_Backup-bar": // Brown ok
          return "#ac7339";
          break;
      case "File_System_Full_New_RLOG2_Backup-line": // Brown ok
          return "#d2a679";
          break;
      case "File_System_Full_Wlogich_Radius-bar": // Purple ok
          return "#ff8533";
          break;
      case "File_System_Full_Wlogich_Radius-line": // Purple ok
          return "#ffb380";
          break;
      case "New_Daily_Database_RAC_11G-bar": // Red ok
          return "#3399ff";
          break;
      case "New_Daily_Database_RAC_11G-line": // Red ok
          return "#80bfff";
          break;
      default:
          return "";
    }
    ;
  }
?>


<!-- [1] Assign $daily_start And $daily_end For [2] - BY FIFAZ// -->
<?php
  $duration='';
  $dropdown_name = 'Last Week'; // --> Default

  // Set $daily_start [Start Date]
  if(isset($_GET['start'])){
    $dropdown_name = 'Custom';
    $daily_start = $_GET['start'];
  } 
  else {
    if(isset($_GET['duration'])){
      switch($_GET['duration']){
        case "lastmonth":
          $dropdown_name = 'Last Month';
          $daily_start = date('Y-m-d',strtotime(date("Y-m-d") . "-1 month"));
          break;
        case "prvmonth":
          $dropdown_name = 'Previous Month';
          $daily_start = date('Y-m-d',strtotime(date("Y-m-d") . "first day of previous month"));
          break;
        default:
          $daily_start = date('Y-m-d',strtotime(date("Y-m-d"). "-1 week"));
      }
    }
    else {
      $daily_start = date('Y-m-d',strtotime(date("Y-m-d"). "-1 week"));
    }
  }

  // Set $daily_end [End Date]
  if(isset($_GET['end'])){
    $dropdown_name = 'Custom';
    $daily_end = $_GET['end'];
  } 
  else {
    if(isset($_GET['duration'])){
      switch($_GET['duration']){
        case "lastmonth":
          $dropdown_name = 'Last Month';
          $daily_end = date("Y-m-d");
          break;
        case "prvmonth":
          $dropdown_name = 'Previous Month';
          $daily_end = date('Y-m-d',strtotime(date("Y-m-d") . "last day of previous month"));
          break;
        default:
          $daily_end = date("Y-m-d");
      }
    }
    else {
      $daily_end = date("Y-m-d");
    }
  }
?>



<!-- [2] Check Input Date & Generate TimeSeries [Categories For Highchart] - BY FIFAZ// -->
<?php
  $time_series='';
  if(strtotime($daily_end) - strtotime($daily_start) < 0){
    echo"<script language=\"JavaScript\">";
    echo"alert('เลือกช่วงเวลาไม่ถูกต้อง')";
    echo"</script>";    
  }
  else {
    $daily_start_tmp=$daily_start;
    while(date("D Y-m-d",strtotime($daily_start_tmp))!=date("D Y-m-d",strtotime($daily_end))){
      $time_series.="'".date("D Y-m-d",strtotime($daily_start_tmp))."',";
      $daily_start_tmp=date("D Y-m-d",strtotime( "+1 day", strtotime($daily_start_tmp)));
    }
    $time_series.="'".date("D Y-m-d",strtotime($daily_start_tmp))."',";
  }    
?>

<!-- Policy Count [For 1st Highchart Legend Alignment] -->
<?php $policy_count_1st_graph=0; $policy_count_2nd_graph=0;?>

<!-- [3.1.1] Query Data From Server [Size]  [Only 'New_Daily_Database_RAC_11G']-->
<?php
  $all_policy_name="#";
  $sql=mysqli_query($con, "SELECT date_format(start_time,'%a %Y-%m-%d') AS date, policy, SUM(size_kb)/1000/1000 AS size_mb FROM bp_imageslist WHERE policy='New_Daily_Database_RAC_11G' AND date_format(start_time,'%Y-%m-%d') BETWEEN '".$daily_start."' AND '".$daily_end."' GROUP BY date_format(start_time,'%a %Y-%m-%d'), policy ORDER BY date_format(start_time,'%a %Y-%m-%d') DESC;");
  while ($result=mysqli_fetch_array($sql)) {
    $policy = $result["policy"];
    $date = $result["date"];
    $size = $result["size_mb"];
    $result_set[$policy][$date] = $size;
    if (stripos($all_policy_name,$policy."#")==false) //IF FOUND NEW POLICY. ADD IT!
      $all_policy_name.=$policy."#";
  }
?>


<!-- [3.1.2] Query Data From Server [Size]  [NOT Include 'New_Daily_Database_RAC_11G']-->
<?php
  $sql=mysqli_query($con, "SELECT date_format(start_time,'%a %Y-%m-%d') AS date, policy, SUM(size_kb)/1000/1000 AS size_mb, client FROM bp_imageslist WHERE policy!='New_Daily_Database_RAC_11G' AND date_format(start_time,'%Y-%m-%d') BETWEEN '".$daily_start."' AND '".$daily_end."' GROUP BY date_format(start_time,'%a %Y-%m-%d'), policy,client ORDER BY date_format(start_time,'%a %Y-%m-%d') DESC;");
  while ($result=mysqli_fetch_array($sql)) {
   

    if($result["policy"]=='File_System_Full_New_DB'){
        if($result["client"]=='new-db1')
          $policy = 'File_System_Full_New_DB1';
        else
          $policy = 'File_System_Full_New_DB2';
    }
    else{
       $policy = $result["policy"];
    }

    $date = $result["date"];
    $size = $result["size_mb"];
    $result_set[$policy][$date] = $size;
    if (stripos($all_policy_name,$policy."#")==false) //IF FOUND NEW POLICY. ADD IT!
      $all_policy_name.=$policy."#";

  }
?>


<!-- [3.2.1] Query Data From Server [Duration] [Only 'New_Daily_Database_RAC_11G']-->
<?php
  $all_policy_name2="#";
  $sql=mysqli_query($con, "SELECT date_format(start_time,'%a %Y-%m-%d') AS date, policy, size_kb, duration/60 
AS duration FROM bp_imageslist WHERE policy='New_Daily_Database_RAC_11G' AND size_kb=0
AND date_format(start_time,'%Y-%m-%d') BETWEEN '".$daily_start."' AND '".$daily_end."'
ORDER BY date_format(start_time,'%a %Y-%m-%d') DESC;");

  while ($result=mysqli_fetch_array($sql)) {
    $policy = $result["policy"];
    $date = $result["date"];
    $duration = $result["duration"];
    $result_set_duration[$policy][$date] = $duration;
    if (stripos($all_policy_name2,$policy."#")==false){ //IF FOUND NEW POLICY. ADD IT!
      $all_policy_name2.=$policy."#";
    }
  }
?>



<!-- [3.2.2] Query Data From Server [Duration] [NOT Include 'New_Daily_Database_RAC_11G']-->
<?php
  $sql=mysqli_query($con, "SELECT date_format(start_time,'%a %Y-%m-%d') AS date, policy, SUM(duration)/60 AS duration, client FROM bp_imageslist WHERE policy!='New_Daily_Database_RAC_11G' AND date_format(start_time,'%Y-%m-%d') BETWEEN '".$daily_start."' AND '".$daily_end."' GROUP BY date_format(start_time,'%a %Y-%m-%d'), policy,client ORDER BY date_format(start_time,'%a %Y-%m-%d') DESC;");

  while ($result=mysqli_fetch_array($sql)) {
    if($result["policy"]=='File_System_Full_New_DB'){
        if($result["client"]=='new-db1')
          $policy = 'File_System_Full_New_DB1';
        else
          $policy = 'File_System_Full_New_DB2';
    }
    else{
       $policy = $result["policy"];
    }

    $date = $result["date"];
    $duration = $result["duration"];
    $result_set_duration[$policy][$date] = $duration;
    if (stripos($all_policy_name2,$policy."#")==false){ //IF FOUND NEW POLICY. ADD IT!
      $all_policy_name2.=$policy."#";
    }

  }
?>



<!-- [4.1] Convert RESULT_SET To Highchart Series -->
<?php
    $highcharts_series='';
    $highcharts_series_2='';
        $highcharts_series_duration='';
        $highcharts_series_duration_2='';

    //LOOP EVERY UNIQUE POLICY NAME
  while($all_policy_name!=='#'){
    $policy_name_tmp=substr($all_policy_name,1,(int)strpos($all_policy_name, "#", strpos($all_policy_name, "#") + strlen("#"))-1);

            if($policy_name_tmp=='File_System_Full_New_RLOG2_Backup'||$policy_name_tmp=='File_System_Full_Wlogich_Radius'||$policy_name_tmp=='Catalog_Pol'){

            $policy_count_2nd_graph++;

            $highcharts_series_2.="{id: '".$policy_name_tmp." [Size]', name: '".$policy_name_tmp." [Size]', color: '".getPolicyColor($policy_name_tmp."-bar")."', data: [";

            //LOOP EVERY UNIQUE POLICY
            $time_series_tmp= $time_series;
            while ($time_series_tmp!==''){
              $date_tmp=substr($time_series_tmp,1,strpos($time_series_tmp, "',")-1);
              
              //CHECK IS [POLICY][DATE] AVALABLE?
              if(isset($result_set[$policy_name_tmp][$date_tmp])) //VALUE AVALABLE
                $highcharts_series_2.=$result_set[$policy_name_tmp][$date_tmp].",";

              else //VALUE UNAVALABLE
                $highcharts_series_2.="null,";

              //REMOVE FROM ALL_TIME [GO TO NEXT TIME]
              $time_series_tmp=str_replace("'".(string)$date_tmp."',", "", $time_series_tmp);
            }

            //REMOVE FROM ALL_POLICY_NAME [GO TO NEXT POLICY NAME]
            $all_policy_name=preg_replace('/#'.(string)$policy_name_tmp.'/', '', $all_policy_name, 1);
             $highcharts_series_2.="], stack: 'bar'},";

            }
  else{

            $policy_count_1st_graph++;

            $highcharts_series.="{id: '".$policy_name_tmp." [Size]', name: '".$policy_name_tmp." [Size]', color: '".getPolicyColor($policy_name_tmp."-bar")."', data: [";

            //LOOP EVERY UNIQUE POLICY
            $time_series_tmp= $time_series;
            while ($time_series_tmp!==''){
              $date_tmp=substr($time_series_tmp,1,strpos($time_series_tmp, "',")-1);
              
              //CHECK IS [POLICY][DATE] AVALABLE?
              if(isset($result_set[$policy_name_tmp][$date_tmp])) //VALUE AVALABLE
                $highcharts_series.=$result_set[$policy_name_tmp][$date_tmp].",";

              else //VALUE UNAVALABLE2
                $highcharts_series.="null,";

              //REMOVE FROM ALL_TIME [GO TO NEXT TIME]
              $time_series_tmp=str_replace("'".(string)$date_tmp."',", "", $time_series_tmp);
            }

            //REMOVE FROM ALL_POLICY_NAME [GO TO NEXT POLICY NAME]
            $all_policy_name=preg_replace('/#'.(string)$policy_name_tmp.'/', '', $all_policy_name, 1);
            if($policy_name_tmp=='File_System_Full_New_DB1'||$policy_name_tmp=='File_System_Full_New_DB2'){
              $highcharts_series.="], stack: 'DB'},";
            }else{
              $highcharts_series.="], stack: 'LINE-".$policy_name_tmp."'},";
            }
             

             }
  }
?>



<!-- [4.2] Convert RESULT_SET_DURATION To Highchart Series -->
<?php


    //LOOP EVERY UNIQUE POLICY NAME
  while($all_policy_name2!=='#'){
    $policy_name_tmp=substr($all_policy_name2,1,(int)strpos($all_policy_name2, "#", strpos($all_policy_name2, "#") + strlen("#"))-1);

            if($policy_name_tmp=='File_System_Full_New_RLOG2_Backup'||$policy_name_tmp=='File_System_Full_Wlogich_Radius'||$policy_name_tmp=='Catalog_Pol'){


    $highcharts_series_duration_2.="{id: '".$policy_name_tmp." [Time]', name: '".$policy_name_tmp." [Time]', color: '".getPolicyColor($policy_name_tmp."-line")."',type: 'spline', yAxis: 1 , data: [";

    //LOOP EVERY UNIQUE POLICY
    $time_series_tmp= $time_series;
    while ($time_series_tmp!==''){
      $date_tmp=substr($time_series_tmp,1,strpos($time_series_tmp, "',")-1);
      
      //CHECK IS [POLICY][DATE] AVALABLE?
      if(isset($result_set_duration[$policy_name_tmp][$date_tmp])) //VALUE AVALABLE
        $highcharts_series_duration_2.=$result_set_duration[$policy_name_tmp][$date_tmp].",";

      else //VALUE UNAVALABLE
        $highcharts_series_duration_2.="null,";

      //REMOVE FROM ALL_TIME [GO TO NEXT TIME]
      $time_series_tmp=str_replace("'".(string)$date_tmp."',", "", $time_series_tmp);
    }

    //REMOVE FROM ALL_POLICY_NAME [GO TO NEXT POLICY NAME]
    $all_policy_name2=preg_replace('/#'.(string)$policy_name_tmp.'/', '', $all_policy_name2, 1);
     $highcharts_series_duration_2.="], stack: 'LINE-$policy_name_tmp'},";

            }

            else{




    $highcharts_series_duration.="{id: '".$policy_name_tmp." [Time]', name: '".$policy_name_tmp." [Time]', color: '".getPolicyColor($policy_name_tmp."-line")."',type: 'spline', yAxis: 1 , data: [";

    //LOOP EVERY UNIQUE POLICY
    $time_series_tmp= $time_series;
    while ($time_series_tmp!==''){
      $date_tmp=substr($time_series_tmp,1,strpos($time_series_tmp, "',")-1);
      
      //CHECK IS [POLICY][DATE] AVALABLE?
      if(isset($result_set_duration[$policy_name_tmp][$date_tmp])) //VALUE AVALABLE
        $highcharts_series_duration.=($result_set_duration[$policy_name_tmp][$date_tmp]/60).",";

      else //VALUE UNAVALABLE
        $highcharts_series_duration.="null,";

      //REMOVE FROM ALL_TIME [GO TO NEXT TIME]
      $time_series_tmp=str_replace("'".(string)$date_tmp."',", "", $time_series_tmp);
    }

    //REMOVE FROM ALL_POLICY_NAME [GO TO NEXT POLICY NAME]
    $all_policy_name2=preg_replace('/#'.(string)$policy_name_tmp.'/', '', $all_policy_name2, 1);
     $highcharts_series_duration.="], stack: 'LINE-$policy_name_tmp'},";

}



  }
?>






<script src="js/jquery-3.1.1.min.js"></script>
<script src="code/highcharts.js"></script>
<script src="code/highcharts-3d.js"></script>
<script src="code/modules/exporting.js"></script>
<!-- end chart ltm log  -->

<body>
<?php include("menu_top.php");?>


<!-- MENU DATE TIME -->
<style type="text/css">
 @media (min-width: 768px) {
   .container {
   width: 500px;
   }
 }
 @media (min-width: 992px) {
   .container {
   width: 800px;
   }
 }
 @media (min-width: 1200px) {
   .container {
   width: 1300px;
   }
 }
 .form-inline {
    width: 1300px;
 }
 </style>
<div class="container">
<div class="col-md-12">
      <div style="line-height: 10px;">BACKUP > <font color="blue">BACKUP DAILY</font></div>
    </div></div><br>

<!-- MENU DATE TIME -->
<div class="container">
  <div class="row">
  <form action="#" method='get' class="form-inline" role="form">

    <div align="left" class="col-lg-2">
      <!-- <button type="button" class="btn btn-success">BACKUP</button> -->
      </div>

    <div>Start Date </div>
    <div class="input-group date form_datetime col-lg-2" data-date="" data-date-format="yyyy-mm-dd" data-link-field="dtp_input1">
    <input name='start' class="form-control" size="7" type="text" value="<?php if(isset($_GET['date'])){echo $_GET['date'];}else{echo $daily_start;}?>" readonly>
    <span class="input-group-addon"><span class="glyphicon glyphicon-calendar"><i class="fa fa-th" aria-hidden="true"></i></span></span></div>

    <div>End Date </div>
    <div class="input-group date form_datetime col-lg-2" data-date="" data-date-format="yyyy-mm-dd" data-link-field="dtp_input1">
    <input name='end' class="form-control" size="7" type="text" value="<?php if(isset($_GET['date2'])){echo $_GET['date2'];}else{echo $daily_end;}?>" readonly>
    <span class="input-group-addon"><span class="glyphicon glyphicon-calendar"><i class="fa fa-th" aria-hidden="true"></i></span></span></div>

    <div class="col-lg-1"></div>

    <div class="col-lg-3">
    <div class="btn-group">
    <button type="button" class="btn btn-secondary"><?php echo $dropdown_name; ?></button> 
    <button type="button" class="btn btn-danger dropdown-toggle dropdown-toggle-split" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
    <span class="sr-only">Toggle Dropdown</span></button>
    <div class="dropdown-menu">
    <a class="dropdown-item" href="backup_daily.php">Last Week</a>
    <a class="dropdown-item" href="backup_daily.php?duration=lastmonth">Last Month</a>
    <a class="dropdown-item" href="backup_daily.php?duration=prvmonth">Previous Month</a>
    </div><div class="col-lg-1"></div>
    <button type="submit" class="btn btn-default col-lg-5">Submit</button>
    </div>


    </form>

  </div>
</div>

<br>
<!-- TABLE -->
<div id="container" style="width: 1280px; height: 430px; margin: 0 auto"></div>
<div id="container2" style="width: 1280px; height: 430px; margin: 0 auto"></div>

<!-- END MENU DATE TIME -->

<!-- HIGHCHART -->
<script type="text/javascript">
Highcharts.setOptions({
    lang: {
        thousandsSep: ','
    }
});
Highcharts.chart('container', {
      chart: {
        zoomType: 'xy',
        type: 'column',
        borderColor: "#000000",
        borderWidth: 1
    },

    title: {
        text: 'Backup (DAILY)'
    },

    subtitle: {
        text: '<?php echo 'Date: '.$daily_start.' to '.$daily_end; ?>',
        align: 'center',
        x: -20
    },
    xAxis: {
        categories: [<?php echo $time_series; ?>],
    },
      yAxis: [{
        labels: {
            format: '{value:,.0f} GB',
            style: {
                color: Highcharts.getOptions().colors[0]
            }
        },
        title: {
            text: 'Size',
            style: {
                color: Highcharts.getOptions().colors[0]
            }
        }

    }, {
        gridLineWidth: 0,
        title: {
            text: 'Time',
            style: {
                color: Highcharts.getOptions().colors[3]
            }
        },
        labels: {
            format: '{value:,.0f} Hr',
            style: {
                color: Highcharts.getOptions().colors[3]
            }
        },        opposite: true

    }],
     plotOptions: {
      series: {
                stacking: 'normal'
            },
        column: {
          minPointLength: 3,
            dataLabels: {
                enabled: true,
                crop: false,
                rotation: -50,
                x: 10,
                y: -15,
                formatter: function () {
                  return Highcharts.numberFormat(this.y,2);
                }
            }
        },
        spline: {
          minPointLength: 3,
            dataLabels: {
                enabled: true,
                crop: false,
                formatter: function () {
                  return Highcharts.numberFormat(this.y,2);
                }
            }
        }
    },
    legend: {
        enabled : true,
        <?php 
        switch($policy_count_1st_graph){
          case 4: 
            echo "x: 25, width: 1200, itemWidth: 300,";
            break;
          case 3: 
            echo "x: 75, width: 1050, itemWidth: 350,";
            break;
          case 2: 
            echo "x: 125, width: 1050, itemWidth: 525,";
            break;
          case 1: 
            echo "x: 100, width: 500, itemWidth: 500,";
            break;
          }
        ?>
    },
tooltip: {
    useHTML: true,
      formatter: function () {
        var total_size = 0; total_time = 0;
        var policy_name = [], size_txt = [] , duration_txt = [];
        var policy_name_i = 0 , size_txt_i = 0 , duration_txt_i = 0;
        var sum_text = '<div class="MyChartTooltip">';

        $.each(this.points, function () {
          policy_name[policy_name_i] = '<td><b><font color="'+this.series.color+'">' + this.series.name.substring(0,this.series.name.indexOf(" [")) + '</font></td>';
          policy_name_i++;
           if(this.series.name=='New_Daily_Database_RAC_11G [Time]'||this.series.name=='New_Daily_Database_New_RLOG2 [Time]'
           ||this.series.name=='File_System_Full_New_DB1 [Time]'||this.series.name=='File_System_Full_New_DB2 [Time]') {
            duration_txt[duration_txt_i] = '<td>&nbsp&nbsp&nbsp<b>'+ Highcharts.numberFormat(this.y,2) + ' Hr<b></td>';
            duration_txt_i++;
            total_time += this.y;
          } else {
            size_txt[size_txt_i] = '<td>&nbsp&nbsp&nbsp<b>'+ Highcharts.numberFormat(this.y,2) + ' GB<b></td>';
            size_txt_i++;
            total_size += this.y;
          }
        });

        // Header
        sum_text += '<b><u>' + this.x + '</u></b></br><table>';
        sum_text +='<td><b><u>Policy<u></b></td>';
        sum_text +='<td>&nbsp&nbsp&nbsp<b><u>Size<u></b></td>';
        sum_text +='<td>&nbsp&nbsp&nbsp<b><u>Time<u></b></td>';

        // Loop For Text
        for (var i=0; i<size_txt.length; i++) {
          sum_text += '<tr>';
            
          if (policy_name[i] != null)
             sum_text += policy_name[i];
          else
             sum_text += '<td></td>';

          if (size_txt[i] != null)
             sum_text += size_txt[i];
          else
             sum_text += '<td></td>';
           
          if (duration_txt[i] != null)
             sum_text += duration_txt[i];
          else
             sum_text += '<td></td>';
          
          sum_text += '</tr>';
        }

        sum_text+= '<tr><td><b><u>Total</u></b></td>';
        sum_text+= '<td>&nbsp&nbsp&nbsp<b><u>'+Highcharts.numberFormat(total_size,2)+' GB</u></b></td>';
        sum_text+= '<td>&nbsp&nbsp&nbsp<b><u>'+Highcharts.numberFormat(total_time,2)+' Hr</u></b></td>';

        sum_text += '</tr></table><div>';
        return sum_text;
      },

      shared: true,
      crosshairs: true
    },

    series: [<?php echo $highcharts_series; echo $highcharts_series_duration;?>]

});

function addCommas(nStr)
{
    nStr += '';
    x = nStr.split('.');
    x1 = x[0];
    x2 = x.length > 1 ? '.' + x[1] : '';
    var rgx = /(\d+)(\d{3})/;
    while (rgx.test(x1)) {
        x1 = x1.replace(rgx, '$1' + ',' + '$2');
    }
    return x1 + x2;
}

</script>
<!-- END HIGHCHART -->



<!-- HIGHCHART -->
<script type="text/javascript">
Highcharts.setOptions({
    lang: {
        thousandsSep: ','
    }
});
Highcharts.chart('container2', {
      chart: {
        zoomType: 'xy',
        type: 'column',
        borderColor: "#000000",
        borderWidth: 1
    },

    title: {
        text: 'Backup (DAILY)'
    },

    subtitle: {
        text: '<?php echo 'Date: '.$daily_start.' to '.$daily_end; ?>',
        align: 'center',
        x: -20
    },
    xAxis: {
        categories: [<?php echo $time_series; ?>],
    },
      yAxis: [{
        labels: {
            format: '{value:,.0f} GB',
            style: {
                color: Highcharts.getOptions().colors[0]
            }
        },
        title: {
            text: 'Size',
            style: {
                color: Highcharts.getOptions().colors[0]
            }
        }

    }, {
        gridLineWidth: 0,
        title: {
            text: 'Time',
            style: {
                color: Highcharts.getOptions().colors[3]
            }
        },
        labels: {
            format: '{value:,.0f} Min',
            style: {
                color: Highcharts.getOptions().colors[3]
            }
        },        opposite: true

    }],
     plotOptions: {
        column: {
          minPointLength: 3,
            dataLabels: {
                enabled: true,
                crop: false,
                rotation: -50,
                x: 10,
                y: -15,
                formatter: function () {
                  return Highcharts.numberFormat(this.y,2);
                }
            }
        },
        spline: {
          minPointLength: 3,
            dataLabels: {
                enabled: true,
                crop: false,
                formatter: function () {
                  return Highcharts.numberFormat(this.y,2);
                }
            }
        }
    },
 legend: {
        enabled : true,
        <?php 
        switch($policy_count_2nd_graph){
          case 3: 
            echo "x: 75, width: 1050, itemWidth: 350,";
            break;
          case 2: 
            echo "x: 125, width: 1050, itemWidth: 525,";
            break;
          case 1: 
            echo "x: 100, width: 500, itemWidth: 500,";
            break;
          }
        ?>
    },
tooltip: {
    useHTML: true,
      formatter: function () {
        var total_size = 0; total_time = 0;
        var policy_name = [], size_txt = [] , duration_txt = [];
        var policy_name_i = 0 , size_txt_i = 0 , duration_txt_i = 0;
        var sum_text = '<div class="MyChartTooltip">';

        $.each(this.points, function () {
          policy_name[policy_name_i] = '<td><b><font color="'+this.series.color+'">' + this.series.name.substring(0,this.series.name.indexOf(" ["))+ '</font></td>';
          policy_name_i++;

          if(this.series.options.stack == 'bar') {
            size_txt[size_txt_i] = '<td>&nbsp&nbsp&nbsp<b>'+ Highcharts.numberFormat(this.y,2) + ' GB<b></td>';
            size_txt_i++;
            total_size += this.y;
          }

          else if(this.series.options.stack == 'LINE-Catalog_Pol'||this.series.options.stack == 'LINE-File_System_Full_New_DB2'
          || this.series.options.stack == 'LINE-File_System_Full_Wlogich_Radius' ) {
            duration_txt[duration_txt_i] = '<td>&nbsp&nbsp&nbsp<b>'+ Highcharts.numberFormat(this.y,2) + ' Min<b></td>';
            duration_txt_i++;
            total_time += this.y;
          } 
        });

        // Header
        sum_text += '<b><u>' + this.x + '</u></b></br><table>';
        sum_text +='<td><b><u>Policy<u></b></td>';
        sum_text +='<td>&nbsp&nbsp&nbsp<b><u>Size<u></b></td>';
        sum_text +='<td>&nbsp&nbsp&nbsp<b><u>Time<u></b></td>';

        // Loop For Text
        for (var i=0; i<size_txt.length; i++) {
          sum_text += '<tr>';
            
          if (policy_name[i] != null)
             sum_text += policy_name[i];
          else
             sum_text += '<td></td>';

          if (size_txt[i] != null)
             sum_text += size_txt[i];
          else
             sum_text += '<td></td>';
           
          if (duration_txt[i] != null)
             sum_text += duration_txt[i];
          else
             sum_text += '<td></td>';
          
          sum_text += '</tr>';
        }

        sum_text+= '<tr><td><b><u>Total</u></b></td>';
        sum_text+= '<td>&nbsp&nbsp&nbsp<b><u>'+Highcharts.numberFormat(total_size,2)+' GB</u></b></td>';
        sum_text+= '<td>&nbsp&nbsp&nbsp<b><u>'+Highcharts.numberFormat(total_time,2)+' Min</u></b></td>';

        sum_text += '</tr></table><div>';
        return sum_text;
      },

      shared: true,
      crosshairs: true
    },

    series: [<?php echo $highcharts_series_2; echo $highcharts_series_duration_2;?>]

});

function addCommas(nStr)
{
    nStr += '';
    x = nStr.split('.');
    x1 = x[0];
    x2 = x.length > 1 ? '.' + x[1] : '';
    var rgx = /(\d+)(\d{3})/;
    while (rgx.test(x1)) {
        x1 = x1.replace(rgx, '$1' + ',' + '$2');
    }
    return x1 + x2;
}

</script>
<!-- END HIGHCHART -->


<!-- jQuery first, then Tether, then Bootstrap JS. -->
<script src="js/bootstrap.min2.js" integrity="sha384-vBWWzlZJ8ea9aCX4pEW3rVHjgjt7zpkNpZk+02D9phzyeVkE+jo0ieGizqPLForn" crossorigin="anonymous"></script>

<script type="text/javascript" src="js/bootstrap-datetimepicker.js" charset="UTF-8"></script>

<script type="text/javascript">
    $('.form_datetime').datetimepicker({
      weekStart: 1,
      todayBtn:  1,
  		autoclose: 1,
  		todayHighlight: 1,
  		startView: 2,
  		minView: 2,
  		forceParse: 0,
      showMeridian: 1,
    });

    $(function () {
      $('#datetimepicker1').datetimepicker({
        startDate: '<?php echo $daily_end.' 00:00'; ?>',
        minuteStep: 5,
        format: 'hh:ii',
        language:  'fr',
        weekStart: 1,
        todayBtn:  1,
    		autoclose: 1,
    		todayHighlight: 1,
    		startView: 1,
    		minView: 1,
    		maxView: 1,
    		forceParse: 0,
      });
      $('#datetimepicker2').datetimepicker({
        startDate: '<?php echo $daily_end.' 00:00'; ?>',
        minuteStep: 5,
        format: 'hh:ii',
        language:  'fr',
        weekStart: 1,
        todayBtn:  1,
    		autoclose: 1,
    		todayHighlight: 1,
    		startView: 1,
    		minView: 0,
    		maxView: 1,
    		forceParse: 0
      });
    });

</script>

<br>

  </body>
</html>
