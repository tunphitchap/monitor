<?php
date_default_timezone_set('Asia/Bangkok');
include "connect210.php";
include "connect208.php";

?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta name="description" content="">
    <meta name="author" content="">
    <link rel="icon" href="../../favicon.ico">

    <title>Radius-Monitor</title>

    <!-- Bootstrap core CSS -->
    <link href="css/bootstrap-datetimepicker.min.css" rel="stylesheet" media="screen">
    <link href="//netdna.bootstrapcdn.com/font-awesome/4.0.3/css/font-awesome.css" rel="stylesheet">
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0-alpha.6/css/bootstrap.min.css" integrity="sha384-rwoIResjU2yc3z8GV/NPeZWAv56rSmLldC3R/AZzGRnGxQQKnKkoFVhFQhNUwEyJ" crossorigin="anonymous">
    <!-- <link href="css/navbar-top-fixed.css" rel="stylesheet"> -->

    <!-- _____________________________________________ Oat _______________________________________ -->

    <style type="text/css">
        .textAlignVer {
            font-size: 12px;
        }

        .textAlignVerRotate {
            display: block;
            -webkit-transform: rotate(-90deg);
            -moz-transform: rotate(-90deg);
            font-size: 12px;
        }

        a:hover {
            text-decoration: none;
        }

        input[type="text"] {
            font-size: 14px;
        }
    </style>
    <!-- _____________________________________________ Oat _______________________________________ -->

    <style>
        .highcharts-container {
            overflow: visible !important;
        }

        .MyChartTooltip {
            position: relative;
            z-index: 50;
            border-radius: 5px;
            background-color: #ffffff;
            padding: 5px;
            font-size: 9pt;
            overflow: auto;
            height: 250px;
        }

        .highcharts-tooltip {
            pointer-events: all !important;
        }
    </style>

    <script src="js/jquery-3.1.1.min.js"></script>
    <script src="code/highcharts.js"></script>
    <script src="code/highcharts-3d.js"></script>
    <script src="code/modules/exporting.js"></script>

    <script>
        function changePeriod() {
            var start = document.getElementById('startDate');
            var end = document.getElementById('endDate');
            var selectPeriod = document.getElementById('selectPeriod');
            if (selectPeriod.value == 'Today') {
                start.value = "<?php echo date("Y-m-d 00:00") ?>";
                end.value = "<?php echo date("Y-m-d H:00") ?>";
            } else if (selectPeriod.value == 'LastDay') {
                start.value = "<?php echo date("Y-m-d H:00", strtotime("-1 day")) ?>";
                end.value = "<?php echo date("Y-m-d H:00") ?>";
            } else if (selectPeriod.value == 'Last2Days') {
                start.value = "<?php echo date("Y-m-d H:00", strtotime("-2 day")) ?>";
                end.value = "<?php echo date("Y-m-d H:00") ?>";
            }
        }
    </script>
</head>






<body style="padding-top: 4.5rem">
    <?php include("menu_top.php"); ?>

    <!-- MENU DATE TIME -->
    <style type="text/css">
        @media (min-width: 768px) {
            .container {
                width: 500px;
            }
        }

        @media (min-width: 992px) {
            .container {
                width: 800px;
            }
        }

        @media (min-width: 1200px) {
            .container {
                width: 1300px;
            }
        }

        .form-inline {
            width: 1300px;
        }
    </style>
    <?php
   
//    echo date('Y-d-m H:i:s',strtotime('+1 hour'));

   $color_array=array(
    "3" => "#0000FF",
    "7" => "#FF4500",
    "13" => "#228B22",
    "14" => "#FF1493",
    "12" => "#9400D3",
    "6" => "#FF8C00",
    "X3" => "#cbcbb3",
    "11" => "#1E90FF",
    "5" => "#00FF00",
    "10" => "#DA70D6"
   );


    if (empty($_POST['selectPeriod'])) {
        $selectPeriod = "Last12Hour";
    } else {
        $selectPeriod = $_POST['selectPeriod'];
    }
    $check_date = 0;
    $str_query = "group by DATE_FORMAT(DATEOPER, '%Y/%m/%d %H') order by DATE_FORMAT(DATEOPER, '%Y/%m/%d %H')";



    if (empty($_POST['start']) || empty($_POST['end'])) {
        # code...
        // $date_from = date('Y-m-d H:i', strtotime('-1 day'));
        // $date_to = date('Y-m-d H:i');
        $date_from = date('Y-m-d H:00', strtotime('-12 Hour'));
        $date_to = date('Y-m-d H:00');
    } else {
        # code...
        $date_from  = $_POST['start'];
        $date_to = $_POST['end'];
    }

    $sql = mysqli_query($con_nat444,"select collector,dateoper,count(distinct cgn) cnt 
    from daily_check_cgn where cgn!=''
    AND type = 'all'
    and  dateoper BETWEEN '".$date_from."' and '".$date_to."'
    group by collector,dateoper 
    order by collector,dateoper");


    $date= array();
    while ($result = mysqli_fetch_array($sql)) {
        $date_db = date('Y-m-d H:i:s', strtotime($result['dateoper']));
        $date[] = $date_db;
        $data[$date_db][$result['collector']] =  $result['cnt'];

        if($result['collector'] == '93'){
            $data_line_93[] = $result['cnt'];
        }else if($result['collector'] == '94'){
            $data_line_94[] = $result['cnt'];
        }else if($result['collector'] == '95'){
            $data_line_95[] = $result['cnt'];
        }else if($result['collector'] == '72'){
            $data_line_72[] = $result['cnt'];
        }
    }

    $last_date = $date[count($date)-1];


    $sql_stack = mysqli_query($con_nat444,"select dateoper,collector,sum(cnt) sum from daily_check_cgn
    where  dateoper BETWEEN '".$date_from."' and '".$date_to."'
    and type = 'all'
    group by dateoper,collector order by dateoper,collector ;");

    while ($result = mysqli_fetch_array($sql_stack)) {
        $date_db = date('Y-m-d H:i:s', strtotime($result['dateoper']));
        $date[] = $date_db;
        $data_stack[$date_db][$result['collector']] =  $result['sum'];

        if($result['collector'] == '93'){
            $data_stack_93[] = $result['sum'];
        }else if($result['collector'] == '94'){
            $data_stack_94[] = $result['sum'];
        }else if($result['collector'] == '95'){
            $data_stack_95[] = $result['sum'];
        }else if($result['collector'] == '72'){
            $data_stack_72[] = $result['sum'];
        }
    }

    // print_r($data_stack_72);

        function DateTimeDiff($strDateTime1,$strDateTime2){
            return (strtotime($strDateTime2) - strtotime($strDateTime1))/  ( 60 * 60 ); 
       }
    
       $categorycount = DateTimeDiff($date_from , $date_to);

    //    for ($i=0; $i < $categorycount; $i++) { 
    //        echo date('Y-m-d H:00', strtotime('+' . $i . ' hour', strtotime($date_from))).'<br>';
    //    }


        
    $sql = mysqli_query($con_nat444,"select * from ( SELECT date_format(dateoper,'%Y-%m-%d %H:%i') as dateoper, collector, cgn, sum(cnt) as sum ,
    CASE 
        WHEN collector = '72' THEN '4'
        WHEN collector = '93' THEN '1'
        WHEN collector = '94' THEN '2'
        WHEN collector = '95' THEN '3'
    ELSE
        collector
    END sortcol
        from daily_check_cgn
        where  date_format(dateoper,'%Y-%m-%d %H:%i') BETWEEN '".$date_from."' and '".$date_to."'
        and type = 'all' 
        and cgn != ''
        group by dateoper, collector, cgn ) zz
        order by zz.dateoper, zz.sortcol*1, cgn*1");


    while ($result = mysqli_fetch_array($sql)) {
        $data_graph_stack[$result['dateoper']][$result['collector']][$result['cgn']] =  $result['sum'];

        $arr_collector[$result['collector']] = $result['collector'];
        $arr_cgn[$result['cgn']] = $result['cgn'];
    }

    for ($i = 0; $i < $categorycount; $i++) {
        $tmp_date = date('Y-m-d H:00', strtotime('+' . $i . ' hour', strtotime($date_from)));
        foreach ($arr_collector as $collector) {
            foreach ($arr_cgn as $cgn) {
                if( !empty($data_graph_stack[$tmp_date][$collector][$cgn]) ) {
                    if( empty($data_highchart_column[$collector][$cgn]) ) { 
                        $data_highchart_column[$collector][$cgn] = $data_graph_stack[$tmp_date][$collector][$cgn].", ";
                    }
                    else {
                        $data_highchart_column[$collector][$cgn] .= $data_graph_stack[$tmp_date][$collector][$cgn].", ";
                    }
                }
                else {
                    if( empty($data_highchart_column[$collector][$cgn]) ) { 
                        $data_highchart_column[$collector][$cgn] = "null, ";
                    }
                    else {
                        $data_highchart_column[$collector][$cgn] .= "null, ";
                    }
                }
            }
        }
    }

    $data_graph_column = "";
    foreach ($arr_collector as $collector) {
        foreach ($arr_cgn as $cgn) {
            $data_graph_column .= "
                {
                    name: '".$collector."-CGN".$cgn."',
                    color: '".$color_array[$cgn]."',
                    data: [".$data_highchart_column[$collector][$cgn]."],
                    stack: '".$collector."'
                },
            ";
        }
    }



    ?>

<div class="container">
    <div class="col-md-12">
      <div style="line-height: 10px;">NAT444 > <font color="blue">Log Collector by CGN</font></div>
    </div>
</div>
<br>

    <div class="container">
        <div class="row">
            <form action="check_cgn.php" method='post' class="form-inline" role="form">

                <div align="left" class="col-lg-1">
                <!-- <button type="button" class="btn btn-danger">MAX CONNECTION</button> -->
                </div>
                <div class="col-lg-1"></div>
                <div class="col-lg-1">Start Date</div>
                <div class="input-group date form_datetime col-md-2" data-date="" data-date-format="yyyy-mm-dd HH" data-link-field="dtp_input1">
                    <input name='start' id="startDate" class="form-control" size="7" type="text" value="<?php echo $date_from ?>" readonly>
                    <span class="input-group-addon"><span class="glyphicon glyphicon-calendar"><i class="fa fa-th" aria-hidden="true"></i></span></span></div>

                <div class="col-lg-1">End Date </div>
                <div class="input-group date form_datetime col-md-2" data-date="" data-date-format="yyyy-mm-dd HH" data-link-field="dtp_input1">
                    <input name='end' id="endDate" class="form-control" size="7" type="text" value="<?php echo $date_to ?>" readonly>
                    <span class="input-group-addon"><span class="glyphicon glyphicon-calendar"><i class="fa fa-th" aria-hidden="true"></i></span></span></div>


                <div class="col-lg-3">
                    <select class="form-control" onchange="changePeriod()" name="selectPeriod" id="selectPeriod">
                        <option <?php if ($selectPeriod == "Last12Hour") { ?> selected <?php } ?> value="Last12Hour">Last 12 Hour</option>
                        <option <?php if ($selectPeriod == "Today") { ?> selected <?php } ?> value="Today">Today</option>
                        <option <?php if ($selectPeriod == "LastDay") { ?> selected <?php } ?> value="LastDay">LastDay</option>
                        <option <?php if ($selectPeriod == "Last2Days") { ?> selected <?php } ?> value="Last2Days">Last 2 Days</option>
                        <option <?php if ($selectPeriod == "Custom") { ?> selected <?php } ?> value="Custom">Custom</option>
                    </select>
                    <button type="submit" class="btn btn-default col-lg-5">Submit</button>
                </div>

            </form>

        </div>
        <br>
        <div class="row">
            <div class="col-md-12">
                <div id="container"></div>
            </div>
        </div>
    </div>

<?php 
$m = 1000000;
?>

    <!-- END MENU DATE TIME -->
    <script type="text/javascript">
        function uncheckGraph(chart) {
            Highcharts.each(chart.series, function(p, i) {
                p.hide()
            });
        }

        function checkGraph(chart) {
            Highcharts.each(chart.series, function(p, i) {
                p.show()
            });
        }

        function chartLine(chart) {
            Highcharts.each(chart.series, function(p, i) {
                p.update({
                    type: "line"
                });
            });
        }

        function chartColumn(chart) {
            Highcharts.each(chart.series, function(p, i) {
                p.update({
                    type: "column"
                });
            });
        }
        $(function() {
            Highcharts.setOptions({
                lang: {
                    thousandsSep: ','
                }
            });

            var container = Highcharts.chart('container', {
                chart: {
                    zoomType: 'xy',
                    type: 'column',
                    borderColor: "#000000",
                    borderWidth: 1,
                    height: 600
                },

                title: {
                    text: 'Collector Count CGN: <?php echo date('d F Y H:i', strtotime($date_from)) ?> - <?php echo date('d F Y H:i', strtotime($date_to)) ?> ',
                },
                subtitle: {
                    text: '<table><tr><td><font style="color:#7cb5ec">Collector 93 </font> : <?php echo $data[date("Y-m-d H:00:00",strtotime($last_date))]['93']?> CGN.</td><td>, <font style="color:#FF0080">Collector 94</font> : <?php echo $data[date("Y-m-d H:00:00",strtotime($last_date))]['94']?> CGN.</td><td>, <font style="color:#ffc107">Collector 95</font> : <?php echo $data[date("Y-m-d H:00:00",strtotime($last_date))]['95']?> CGN.</td><td>, <font style="color:#0000CD">Collector 72</font> : <?php echo $data[date("Y-m-d H:00:00",strtotime($last_date))]['72'] ?> CGN.</td></tr></table>',
                    align: 'center',
                    useHTML: true,
                    style: {
                        "fontSize": "14px"
                    }
},

                xAxis: {
                    categories: [
                    <?php
                    for ($i = 0; $i < $categorycount; $i++) {
                        echo "'" . date('Y-m-d H:00', strtotime('+' . $i . ' hour', strtotime($date_from))) . "',";
                    }
                    ?>
                ],
                },

                yAxis: [
                    {
                    // max: <?php echo max(max($data_stack_72),max($data_stack_93),max($data_stack_94),max($data_stack_95))*5 ?>,
                    max: 30000000,
                    min: 0,
                    title: {
                        text: 'Log Collector (row).'
                    },
                    stackLabels: {
                        y:-17,
                        x:4,
                        rotation: -90,
                        enabled: true,
                        align: 'center',
                        style: {
                            fontWeight: 'normal',
                            color: 'black',
                            fontSize: '11px'
                        },
                        formatter: function() {
                            return Highcharts.numberFormat(this.total/1000000, 0)+' M.'
                        }
                    }
                },
                    {
                        max: <?php echo max(max($data_line_72),max($data_line_93),max($data_line_94),max($data_line_95))*1.2 ?>,
                    min: 0,
                    opposite: true,
                    title: {
                        text: 'Qty. sub.'
                    },
                    stackLabels: {
                        enabled: true,
                        align: 'center',
                        style: {
                            fontWeight: 'normal',
                            color: 'black',
                            fontSize: '11px'
                        },
                        formatter: function() {
                            return Highcharts.numberFormat(this.total, 0)
                        }
                    }
                }
                
                
                ],
                legend: {
                    // align: 'center',
                    // verticalAlign: 'bottom',
                    layout: 'horizontal', // default
                    // itemDistance: 1,
                    backgroundColor: '#ffffff',
                    borderColor: '#C98657',
                    borderWidth: 2,
                    // width: 800,
                    itemWidth: 260,
                    // margin: 1000,
                    // itemMarginLeft: 50,
                    // itemDistance: 300
                },


                plotOptions: {
                    series: {
                        dataLabels: {
                            enabled: false,
                            format: '{point.y:,.0f}'
                        }
                    },
                    column: {
                        stacking: 'normal'
                    }

                },
                series: [
                    {
                            name: 'Collector 93',
                            type: 'line',
                            data: [
                                <?php
                                    for ($i = 0; $i < $categorycount; $i++) {
                                        if(!empty($data[date('Y-m-d H:00:00', strtotime('+' . $i . ' hour', strtotime($date_from)))]['93'])){
                                            echo $data[date('Y-m-d H:00:00', strtotime('+' . $i . ' hour', strtotime($date_from)))]['93'] . ',';
                                        }else{
                                            echo "null,"; 
                                        }
                                    }
                                    ?>
                            ],
                            color: "#7cb5ec",
                            // legendIndex: <?php //echo $legendIndex_db1[$value_type] ?>,
                            dashStyle: 'Solid',
                            marker: {
                                symbol: 'circle',
                            },
                            yAxis: 1,
                        },
                        {
                            name: 'Collector 94',
                            yAxis: 1,
                            type: 'line',
                            data: [
                                <?php
                                    for ($i = 0; $i < $categorycount; $i++) {
                                        if(!empty($data[date('Y-m-d H:00:00', strtotime('+' . $i . ' hour', strtotime($date_from)))]['94'])){
                                            echo $data[date('Y-m-d H:00:00', strtotime('+' . $i . ' hour', strtotime($date_from)))]['94'] . ',';
                                        }else{
                                            echo "null,"; 
                                        }
                                    }
                                    ?>
                            ],
                            color: "#FF0080",
                            // legendIndex: <?php //echo $legendIndex_db1[$value_type] ?>,
                            dashStyle: 'LongDashDotDot',
                            marker: {
                                symbol: 'circle',
                            }
                        },
                        {
                            name: 'Collector 95',
                            type: 'line',
                            yAxis: 1,
                            data: [
                                <?php
                                    for ($i = 0; $i < $categorycount; $i++) {
                                        if(!empty($data[date('Y-m-d H:00:00', strtotime('+' . $i . ' hour', strtotime($date_from)))]['95'])){
                                            echo $data[date('Y-m-d H:00:00', strtotime('+' . $i . ' hour', strtotime($date_from)))]['95'] . ',';
                                        }else{
                                            echo "null,"; 
                                        }
                                    }
                                    ?>
                            ],
                            color: "#ffc107",
                            // legendIndex: <?php //echo $legendIndex_db1[$value_type] ?>,
                            dashStyle: 'Solid',
                            marker: {
                                symbol: 'circle',
                            }
                        },
                        {
                            name: 'Collector 72',
                            yAxis: 1,
                            type: 'line',
                            data: [
                                <?php
                                    for ($i = 0; $i < $categorycount; $i++) {
                                        if(!empty($data[date('Y-m-d H:00:00', strtotime('+' . $i . ' hour', strtotime($date_from)))]['72'])){
                                            echo $data[date('Y-m-d H:00:00', strtotime('+' . $i . ' hour', strtotime($date_from)))]['72'] . ',';
                                        }else{
                                            echo "null,"; 
                                        }
                                    }
                                    ?>
                            ],
                            color: "#0000CD",
                            // legendIndex: <?php //echo $legendIndex_db1[$value_type] ?>,
                            dashStyle: 'LongDashDotDot',
                            marker: {
                                symbol: 'circle',
                            }
                        },
                        <?php echo $data_graph_column; ?>
                ],
                tooltip: {
                    formatter: function() {
                        var s = [];
                        s.push('<span style="font-weight:bold;font-size:12px">' + this.x + '<span><br><span style="font-weight:bold;"><span><br><table>');
                        $.each(this.points, function(i, point) {
                            var str = point.series.name;
                            if(str.substring(0,3) == 'Log'){
                                s.push('<tr><td><span style="color:' + this.series.color + ';font-weight:bold;">' + point.series.name + ' :</td><td>' + Highcharts.numberFormat(point.y/1000000, 0, '.', ',') + ' M.<span></td></tr>');
                            }else{
                                s.push('<tr><td><span style="color:' + this.series.color + ';font-weight:bold;">' + point.series.name + ' :</td><td>' + Highcharts.numberFormat(point.y, 0, '.', ',') + ' CGN.<span></td></tr>');
                            }
                        });
                        s.push('</table>');
                        return s;
                    },
                    borderColor: '#000000',
                    useHTML: true,
                    shared: true
                },
                exporting: {
                    buttons: {
                        customButton: {
                            text: '<b>Uncheck</b>',
                            onclick: function() {
                                uncheckGraph(container);
                            }
                        },
                        anotherButton: {
                            text: "<b>Show all</b>",
                            onclick: function() {
                                checkGraph(container);
                            }
                        },
                        // lineButton: {
                        //     text: "<b>[Line]</b>",
                        //     onclick: function() {
                        //         chartLine(container);
                        //     }
                        // },
                        // columnButton: {
                        //     text: "<b>[Stacked column]</b>",
                        //     onclick: function() {
                        //         chartColumn(container);
                        //     }
                        // },
                    }
                }
            });
        });
    </script>

    <!-- jQuery first, then Tether, then Bootstrap JS. -->

    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0-alpha.6/js/bootstrap.min.js" integrity="sha384-vBWWzlZJ8ea9aCX4pEW3rVHjgjt7zpkNpZk+02D9phzyeVkE+jo0ieGizqPLForn" crossorigin="anonymous"></script>





    <script type="text/javascript" src="js/bootstrap-datetimepicker.js" charset="UTF-8"></script>
    <script type="text/javascript">
        $('.form_datetime').datetimepicker({
            format: 'yyyy-mm-dd hh:00',
            minView: 1,
            autoclose: 1,
        });

        $('.form_datetime').datetimepicker().on('changeDate', function(ev) {
            $('#selectPeriod').val('Custom').trigger('change');
        });
    </script>

</body>

</html>