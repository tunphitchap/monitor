<?php
include "connect210.php";
date_default_timezone_set("Asia/Bangkok");

header("Content-type: text/json");

$x = time() * 1000 - (900000);

$dada=date('H');
$dateda=date('Y-m-d '.$dada.':i:s');

$sqlcount=mysqli_query($con2,"
SELECT * FROM db1 
WHERE DATEOPER BETWEEN DATE_ADD(now(),INTERVAL -904 SECOND) AND DATE_ADD(now(),INTERVAL -15 MINUTE)
ORDER BY DATEOPER DESC LIMIT 1
");
$rows=mysqli_fetch_array($sqlcount);

$arr_data["time"] = $x;
$arr_data["WEBLOGIC_90"] = $rows["WEBLOGIC_90"];
$arr_data["WEBLOGIC_92"] = $rows["WEBLOGIC_92"];
$arr_data["RADIUS_86"] = $rows["RADIUS_86"];
$arr_data["RADIUS_88"] = $rows["RADIUS_88"];
$arr_data["TOTAL_4IP"] = $rows["TOTAL_4IP"];
$arr_data["TOTAL_1521"] = $rows["TOTAL_1521"];
$arr_data["DIFF"] = $rows["DIFF"];


echo json_encode($arr_data);
