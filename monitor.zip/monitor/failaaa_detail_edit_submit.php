<meta charset="UTF-8">
<?php
include "connect210.php";
 $hour=$_POST['hour'];
 $datechk=$_POST['datechk'];
 $txtremark=$_POST['txtremark'];

$query_chkre=mysqli_query($con2,"select count(*) cnt from FAILAAA_REMARK where date_remark='".$datechk."' 
	and time_hour='".$hour.":00-".$hour.":59';");
$rowchk=mysqli_fetch_array($query_chkre);
if($rowchk['cnt']==0)
{
$query_insert=mysqli_query($con2,"INSERT INTO FAILAAA_REMARK (date_remark,time_hour,data_remark) VALUES ('$datechk','".$hour.":00-".$hour.":59','$txtremark')");
}
else
{
$query_update=mysqli_query($con2,"UPDATE FAILAAA_REMARK SET data_remark='$txtremark' where date_remark='$datechk'  and time_hour='".$hour.":00-".$hour.":59'");
}
echo "<script>alert('บันทึกข้อมูลเรียบร้อย');window.close();window.opener.location.reload();</script>";
?>