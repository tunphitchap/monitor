<meta charset="UTF-8">
<?php

include "connect208.php";
 $hourchk=$_POST['hourchk'];
 $timechk=$_POST['timechk'];
 $datechk=$_POST['datechk'];
 $hosting=$_POST['hosting'];
 $txtremark=$_POST['txtremark'];

$query_chkre=mysqli_query($con,"select count(*) cnt f5_ltm_log_remark where date_remark='".$datechk."' and host='".$hosting."' and time_hour LIKE '".$hourchk.":%'");
$rowchk=mysql_fetch_array($query_chkre);
if($rowchk==0)
{
$query_insert=mysqli_query($con,"INSERT INTO f5_ltm_log_remark (date_remark,time_hour,data_remark,host) VALUES ('$datechk','$timechk','$txtremark','$hosting')");
}
else
{


$query_update=mysqli_query($con,"UPDATE f5_ltm_log_remark SET data_remark='$txtremark' where date_remark='$datechk' and host='$hosting' and time_hour LIKE '$timechk:%'");
}
echo "<script>alert('บันทึกข้อมูลเรียบร้อย');window.close();window.opener.location.reload();</script>";
?>