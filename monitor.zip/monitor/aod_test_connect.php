<?php
	$objConnect = mysql_connect("10.11.11.208","root","password");
	if($objConnect)
	{
		echo "Database Connected.";
	}
	else
	{
		echo "Database Connect Failed.";
	}

	mysql_close($objConnect);
?>
