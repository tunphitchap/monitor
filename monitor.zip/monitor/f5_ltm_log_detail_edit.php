
<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta name="viewport" content="initial-scale=1.0, maximum-scale=2.0">
    <meta name="description" content="">
    <meta name="author" content="">
  </head>
  <link rel="stylesheet" type="text/css" href="css/bootstrap.min.css">
    <!-- Custom styles for this template -->
  
  </head>
<?php
  date_default_timezone_set('Asia/Bangkok');
  include "connect208.php";


if(!empty($_GET['date']))
{
   $datestr=$_GET['date'];
}
else
{
   $datestr=date('Y-m-d');
}
 $timeing=$_GET['timehour'];
 $houring=$_GET['hour'];
 $hosti='10.11.11.'.$_GET['host'];
 $status=$_GET['status'];


$queryremark=mysqli_query($con,"select data_remark from f5_ltm_log_remark where date_remark='".$datestr."' and host='".$hosti."' and status='".$status."' and time_hour LIKE '".$houring.":%'");
$rowremark=mysqli_fetch_array($queryremark);

if($_GET['host']=="113")
{
     if($status=="down")
    {
    $querylogdetail=mysqli_query($con,"select trim(ltmlog) from f5_ltm_log where datetime LIKE '".$datestr." ".$houring.":%' and ltmlog LIKE '%down%' and host='".$hosti."'");
    }
}
elseif($_GET['host']=="114")
{

  if($status=="down")
    {
    $querylogdetail=mysqli_query($con,"select trim(ltmlog) from f5_ltm_log where datetime LIKE '".$datestr." ".$houring.":%' and ltmlog LIKE '%down%' and host='".$hosti."'");
    }
  elseif($status=="reject")
    {
    $querylogdetail=mysqli_query($con,"select trim(ltmlog) from f5_ltm_log where datetime LIKE '".$datestr." ".$houring.":%' and ltmlog LIKE '%Packet rejected%' and host='".$hosti."'");
    }

}
?>
<body>
<form action="edit_ltm_log_remark.php" method="post">
<div class="container" style="width: 96%;margin-top:2%;margin-left: 1%;">
    <input type="hidden" name="hourchk" value="<?php echo $houring;?>">
    <input type="hidden" name="timechk" value="<?php echo $timeing;?>">
    <input type="hidden" name="datechk" value="<?php echo $datestr;?>">
    <input type="hidden" name="statuschk" value="<?php echo $status;?>">
<div class="row">
  <div class="col-md-3 col-sm-3"> 
  <label for="">DATETIME</label>
    <input type="text" readonly class="form-control" value="<?php echo $datestr." ".$timeing?>" placeholder="DATETIME">
   </div>
  <div class="col-md-2 col-sm-2"> 
  <label for="">HOST</label>
   <input type="text" readonly class="form-control" name="hosting" value="<?php echo $hosti;?>" placeholder="Host">
   </div>
  <div class="col-md-4 col-sm-4"> 
  <label for="">Remark</label>
    <textarea class="form-control" required name="txtremark" cols="1" rows="1"><?php echo $rowremark[0];?></textarea>
  </div>
  <div class="col-md-1 col-sm-1" style="margin-top:0.5%;">
  <label for=""></label>
  <button type="submit" class="btn btn-primary btn-md">SUBMIT</button>
  </div>
  <div class="col-md-1 col-sm-1" style="margin-top:0.5%;">
  <label for=""></label>
  <input type="button" class="btn btn-warning btn-md" value="CANCLE" onclick="window_close();" title="close">
  </div>
  <div class="col-md-1 col-sm-1" style="margin-top:0.5%;">
  <label for=""></label>
  <?
if(!empty($rowremark))
{
?>
<a href="delete_ltm_log_remark.php?date=<?php echo $datestr;?>&hour=<?php echo $houring;?>&host=<?php echo $hosti; ?>&status=<?php echo $status;?>">
 <input type="button" class="btn btn-danger btn-md" value="CLEAR" title="Delete"> 

</a>
<?php  } ?>
  </div>
</div>
</form>

<div class="container" style="margin-top:2%;">
  <div class="row">
    <div class="col-md-12 col-sm-12">
      <font size="+0.5"><strong><p>LTM LOG DETAIl</p></strong></font>
    </div>
  </div>
  <!-- <div class="row"> -->
    <div class="col-md-12 col-sm-12" align="center">
      <textarea name="txtDescription" readonly class="form-control"  style="width:90%;" cols="20" rows="19"><?php
      while($rowlogdetail=mysqli_fetch_array($querylogdetail))
      {
        echo trim($rowlogdetail[0])."\n";
      }
      ?></textarea> 
    </div>
</div>
<script>
function window_close()
{
window.close()
}
</script>

  </body>
</html>
