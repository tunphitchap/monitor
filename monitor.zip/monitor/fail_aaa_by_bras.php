<?php
include "connect210.php";
date_default_timezone_set("Asia/Bangkok");
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Radius-Monitor</title>

    <?php include("import_lib.php"); ?>
    <link href="css/navbar-top-fixed.css" rel="stylesheet">

    <script src="js/jquery-3.1.1.min.js"></script>
    <script src="code/highcharts.js"></script>
    <script src="code/highcharts-3d.js"></script>
    <script src="code/modules/exporting.js"></script>

    <style type="text/css">
        .textAlignVer {
            font-size: 12px;
        }

        .textAlignVerRotate {
            display: block;
            -webkit-transform: rotate(-90deg);
            -moz-transform: rotate(-90deg);
            font-size: 12px;
        }

        a:hover {
            text-decoration: none;
        }
    </style>

    <style>
        .highcharts-container {
            overflow: visible !important;
        }

        .MyChartTooltip {
            position: relative;
            z-index: 50;
            border-radius: 5px;
            background-color: #ffffff;
            padding: 5px;
            font-size: 9pt;
            overflow: auto;
            height: 250px;
        }

        .highcharts-tooltip {
            pointer-events: all !important;
        }
    </style>

    <style type="text/css">
        @media (min-width: 768px) {
            .container {
                width: 500px;
            }
        }

        @media (min-width: 992px) {
            .container {
                width: 800px;
            }
        }

        @media (min-width: 1200px) {
            .container {
                width: 1300px;
            }
        }

        .form-inline {
            width: 1300px;
        }
    </style>
    <script>
        function changePeriod() {
            var data = document.getElementById('selectPeriod');
            var startDate = document.getElementById('startDate');
            var endDate = document.getElementById('endDate');
            if (data.value == 'Last_7_days') {
                startDate.value = "<?php echo date("Y-m-d", strtotime("-6 day")) ?>";
                endDate.value = "<?php echo date("Y-m-d") ?>";
            } else if (data.value == 'Last_Month') {
                startDate.value = "<?php echo date("Y-m-d", strtotime("-1 month")) ?>";
                endDate.value = "<?php echo date("Y-m-d") ?>";
            } else if (data.value == 'Previous_Month') {
                startDate.value = "<?php echo date("Y-m-d", strtotime("-1 month")); ?>";
                endDate.value = "<?php echo date("Y-m-t", strtotime("-1 month")); ?>";
            }
        }
    </script>
</head>

<body>
    <?php include "menu_top.php"; ?>
    <?php
    if (empty($_POST['selectPeriod'])) {
        $selectPeriod = "Custom";
    } else {
        $selectPeriod = $_POST['selectPeriod'];
    }

    if (!empty($_POST['start']) || !empty($_POST['end'])) {
        $start_date = $_POST['start'];
        $to_date =  $_POST['end'];
    } else {
        $start_date = date('Y-m-d', strtotime('-1 day'));
        $to_date = date('Y-m-d');
    }
    ?>
    <div class="container">
        <div class="row">
            <form action="fail_aaa_by_bras.php" method='post' class="form-inline" role="form">

                <div align="left" class="col-lg-3"><button type="button" class="btn btn-danger">FAIL Accounting By Bras</button></div>

                <div>Start Date </div>
                <div class="input-group date form_datetime col-lg-2" data-date="" data-date-format="yyyy-mm-dd" data-link-field="dtp_input1">
                    <input name='start' class="form-control" id="startDate" size="7" type="text" value="<?php echo $start_date; ?>" readonly>
                    <span class="input-group-addon"><span class="glyphicon glyphicon-calendar"><i class="fa fa-th" aria-hidden="true"></i></span></span></div>

                <div>End Date </div>
                <div class="input-group date form_datetime col-lg-2" data-date="" data-date-format="yyyy-mm-dd" data-link-field="dtp_input1">
                    <input name='end' class="form-control" id="endDate" size="7" type="text" value="<?php
                                                                                                    echo $to_date; ?>" readonly>
                    <span class="input-group-addon"><span class="glyphicon glyphicon-calendar"><i class="fa fa-th" aria-hidden="true"></i></span></span></div>
                <div class="col-lg-3">
                    <select class="form-control" onchange="changePeriod()" name="selectPeriod" id="selectPeriod">
                        <option <?php if ($selectPeriod == "Custom") { ?> selected <?php } ?> value="Custom">Custom</option>
                        <option <?php if ($selectPeriod == "Last_7_days") { ?> selected <?php } ?> value="Last_7_days">Last 7 days</option>
                        <option <?php if ($selectPeriod == "Last_Month") { ?> selected <?php } ?> value="Last_Month">Last Month</option>
                        <option <?php if ($selectPeriod == "Previous_Month") { ?> selected <?php } ?> value="Previous_Month">Previous Month</option>
                    </select>
                    <button type="submit" class="btn btn-default col-lg-5">Submit</button>
                </div>
            </form>

        </div>
    </div>
    <br>
    <div id="container" style="width: 1280px; height: 430px; margin: 0 auto">
        <?php
        $sql_sum = mysqli_query($con2, "select DATE_FORMAT(date,'%Y-%m-%d') as date,bras,sum(qty) as sum from FAILAAA where 1
                                and detail in ('ME60','ME5200')
                                and type <> ''
                                and date between '" . $start_date . " 00:00:00'  and '" . $to_date . " 23:59:59'
                                group by DATE_FORMAT(date,'%Y-%m-%d'),bras
                                order by DATE_FORMAT(date,'%Y-%m-%d'),bras");

        while ($result = mysqli_fetch_array($sql_sum)) {
            $data[$result['bras']][$result['date']] = $result['sum'];
            // $date[] = date('Y-m',strtotime($result['date']));
        }

        $sql_date = mysqli_query($con2, "select DISTINCT(aa.date) from (
            select DATE_FORMAT(date,'%Y-%m-%d') as date,bras,sum(qty) from FAILAAA where 1
            and detail in ('ME60','ME5200')
            and type <> ''
            and date between '" . $start_date . " 00:00:00'  and '" . $to_date . " 23:59:59'
            group by DATE_FORMAT(date,'%Y-%m-%d'),bras
            order by DATE_FORMAT(date,'%Y-%m-%d'),bras
        )aa ");

        while ($result = mysqli_fetch_array($sql_date)) {
            $date[] = date('d-F', strtotime($result['date']));
            $date_foreach[] = date('Y-m-d', strtotime($result['date']));
        }

        $sql_bras = mysqli_query($con2, "select DISTINCT(aa.bras) as bras ,bb.ro from (
            select DATE_FORMAT(date,'%Y-%m-%d') as date,bras,sum(qty) from FAILAAA where 1
            and detail in ('ME60','ME5200')
            and type <> ''
            and date between '" . $start_date . " 00:00:00'  and '" . $to_date . " 23:59:59'
            group by DATE_FORMAT(date,'%Y-%m-%d'),bras
            order by DATE_FORMAT(date,'%Y-%m-%d'),bras
        )aa LEFT JOIN map_ro bb ON SUBSTR(aa.bras,1,3) = bb.bras ");

        while ($result = mysqli_fetch_array($sql_bras)) {
            $bras[] = $result['bras'];
            $ro[$result['bras']] = $result['ro'];
        }

        // $sql_bras_categories = mysqli_query($con2, "select DISTINCT(CONCAT(aa.bras,'[RO',bb.ro,']')) as bras from (
        //     select DATE_FORMAT(date,'%Y-%m-%d') as date,bras,sum(qty) from FAILAAA where 1
        //     and detail in ('ME60','ME5200')
        //     and type <> ''
        //     and date between '" . $start_date . " 00:00:00'  and '" . $to_date . " 23:59:59'
        //     group by DATE_FORMAT(date,'%Y-%m-%d'),bras
        //     order by DATE_FORMAT(date,'%Y-%m-%d'),bras
        // )aa LEFT JOIN map_ro bb ON SUBSTR(aa.bras,1,3) = bb.bras ");

        // while ($result = mysqli_fetch_array($sql_bras_categories)) {
        //     $bras_categories[] = $result['bras'];
        // }

        foreach ($date_foreach as $key_date => $value_date) {
            foreach ($bras as $key_bras => $value_bras) {
                # code...
                // echo 'value_date = '.$value_date.'<br>';
                // echo 'value_bras = '.$value_bras.'<br>';
                if (empty($data[$value_bras][$value_date])) {
                    $data[$value_bras][$value_date] = 0;
                    // echo 'data = '.$data[$value_date][$value_bras].'------------------------------'.'<br>';
                } else {
                    // echo 'data = '.$data[$value_date][$value_bras].'------------------------------'.'<br>';
                }
            }
            # code...
        }
        // print_r($date_foreach);
        // echo '<br>';
        // print_r($data);


        ?>

        <script type="text/javascript">
            function uncheckGraph(chart) {
                Highcharts.each(chart.series, function(p, i) {
                    p.hide()
                });
            }

            function checkGraph(chart) {
                Highcharts.each(chart.series, function(p, i) {
                    p.show()
                });
            }

            function chartLine(chart) {
                Highcharts.each(chart.series, function(p, i) {
                    p.update({
                        type: "line"
                    });
                });
            }

            function chartColumn(chart) {
                Highcharts.each(chart.series, function(p, i) {
                    p.update({
                        type: "column"
                    });
                });
            }
            $(function() {
                Highcharts.setOptions({
                    lang: {
                        thousandsSep: ','
                    }
                });

                var container = Highcharts.chart('container', {
                    chart: {
                        zoomType: 'xy',
                        type: 'column',
                        borderColor: "#000000",
                        borderWidth: 1,
                        height: 450
                    },

                    title: {
                        text: 'FAIL Accounting by bras',
                    },
                    subtitle: {

                        text: 'Date : <?php echo date('d F Y', strtotime($start_date)) ?> - <?php echo date('d F Y', strtotime($to_date)) ?> ',
                        align: 'center',
                        useHTML: true,
                        style: {
                            "fontSize": "14px"
                        }
                    },

                    xAxis: {
                        categories: [
                            <?php
                            foreach ($date as $value) {
                                echo "'" . $value .
                                    "'" .
                                    ",";
                            }
                            ?>
                        ],
                    },

                    yAxis: [{
                        // max: 500000,
                        min: 0,
                        title: {
                            text: 'Total Size (TB)'
                        },
                        stackLabels: {
                            enabled: true,
                            align: 'center',
                            style: {
                                fontWeight: 'normal',
                                color: 'black',
                                fontSize: '11px'
                            },
                            formatter: function() {
                                return Highcharts.numberFormat(this.total, 0)
                            }
                        }
                    }],
                    legend: {
                        layout: 'horizontal', // default
                        itemDistance: 1,
                        backgroundColor: '#ffffff',
                        borderColor: '#C98657',
                        borderWidth: 2,
                        width: 800,
                        itemWidth: 200
                    },


                    plotOptions: {
                        series: {
                            dataLabels: {
                                enabled: false,
                                format: '{point.y:,.0f}'
                            }
                        },
                        column: {
                            stacking: 'normal'
                        }

                    },
                    series: [
                        <?php
                        foreach ($bras as $key_bras => $value_bras) {
                            # code...    
                            ?> {
                            name: '<?php echo $value_bras." [RO".$ro[$value_bras]."]"; ?>',
                            data: [
                                <?php
                                    foreach ($date_foreach as $key_date => $value_date) {
                                        # code...
                                        echo $data[$value_bras][$value_date] . ',';
                                    }
                                    ?>
                            ]
                        },
                        <?php
                        }
                        ?>
                    ],
                    exporting: {
                        buttons: {
                            customButton: {
                                text: '<b>Uncheck</b>',
                                onclick: function() {
                                    uncheckGraph(container);
                                }
                            },
                            anotherButton: {
                                text: "<b>Show all</b>",
                                onclick: function() {
                                    checkGraph(container);
                                }
                            },
                            lineButton: {
                                text: "<b>[Line]</b>",
                                onclick: function() {
                                    chartLine(container);
                                }
                            },
                            columnButton: {
                                text: "<b>[Stacked column]</b>",
                                onclick: function() {
                                    chartColumn(container);
                                }
                            }
                        }
                    }
                });
            });
        </script>


    <!-- jQuery first, then Tether, then Bootstrap JS. -->
	<script src="js/bootstrap.min2.js" integrity="sha384-vBWWzlZJ8ea9aCX4pEW3rVHjgjt7zpkNpZk+02D9phzyeVkE+jo0ieGizqPLForn" crossorigin="anonymous"></script>

        <script type="text/javascript" src="js/bootstrap-datetimepicker.js" charset="UTF-8"></script>
        <script type="text/javascript">
            $('.form_datetime').datetimepicker({
                // format: 'YYYY-MM-DD',
                weekStart: 1,
                todayBtn: 1,
                autoclose: 1,
                todayHighlight: 1,
                startView: 2,
                minView: 2,
                forceParse: 0,
                showMeridian: 1,
            });
        </script>
</body>

</html>