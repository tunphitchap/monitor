<?php
include "connect210.php";
date_default_timezone_set("Asia/Bangkok");
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Radius-Monitor</title>

    <?php include("import_lib.php"); ?>
    <link href="css/navbar-top-fixed.css" rel="stylesheet">

    <script src="js/jquery-3.1.1.min.js"></script>
    <script src="code/highcharts.js"></script>
    <script src="code/highcharts-3d.js"></script>
    <script src="code/modules/exporting.js"></script>

    <style type="text/css">
        .textAlignVer {
            font-size: 12px;
        }

        .textAlignVerRotate {
            display: block;
            -webkit-transform: rotate(-90deg);
            -moz-transform: rotate(-90deg);
            font-size: 12px;
        }

        a:hover {
            text-decoration: none;
        }
    </style>

    <style>
        .highcharts-container {
            overflow: visible !important;
        }

        .MyChartTooltip {
            position: relative;
            z-index: 50;
            border-radius: 5px;
            background-color: #ffffff;
            padding: 5px;
            font-size: 9pt;
            overflow: auto;
            height: 250px;
        }

        .highcharts-tooltip {
            pointer-events: all !important;
        }
    </style>

    <style type="text/css">
        @media (min-width: 768px) {
            .container {
                width: 500px;
            }
        }

        @media (min-width: 992px) {
            .container {
                width: 800px;
            }
        }

        @media (min-width: 1200px) {
            .container {
                width: 1300px;
            }
        }

        .form-inline {
            width: 1300px;
        }
    </style>
    <script>
        function changePeriod() {
            var data = document.getElementById('selectPeriod');
            var startDate = document.getElementById('startDate');
            var endDate = document.getElementById('endDate');
            if (data.value == 'Last_7_days') {
                startDate.value = "<?php echo date("Y-m-d", strtotime("-6 day")) ?>";
                endDate.value = "<?php echo date("Y-m-d") ?>";
            } else if (data.value == 'Last_Month') {
                startDate.value = "<?php echo date("Y-m-d", strtotime("-1 month")) ?>";
                endDate.value = "<?php echo date("Y-m-d") ?>";
            } else if (data.value == 'Previous_Month') {
                startDate.value = "<?php echo date("Y-m-t", strtotime("-2 month")); ?>";
                endDate.value = "<?php echo date("Y-m-t", strtotime("-1 month")); ?>";
            }
        }
    </script>
</head>

<body>
    <?php include "menu_top.php"; ?>
    <?php
    if (empty($_POST['selectPeriod'])) {
        $selectPeriod = "Custom";
    } else {
        $selectPeriod = $_POST['selectPeriod'];
    }

    if (!empty($_POST['start']) || !empty($_POST['end'])) {
        $start_date = $_POST['start'];
        $to_date =  $_POST['end'];
    } else {
        $start_date = date('Y-m-d', strtotime('-1 day'));
        $to_date = date('Y-m-d');
    }
    ?>

    
<div class="container">
<div class="col-md-12">
      <div style="line-height: 10px;">FAIL AAA > <font color="blue">FAIL AAA BY TYPE</font></div>
    </div></div><br>


    <div class="container">
        <div class="row">
            <form action="data_failaaa_type_day.php" method='post' class=" form-inline" role="form">

                <div align="left" class="col-lg-2">
                <!-- <button type="button" class="btn btn-danger">FAIL AAA</button> -->
                </div>

                <div>Start Date </div>
                <div class="input-group date form_datetime col-lg-2" data-date="" data-date-format="yyyy-mm-dd" data-link-field="dtp_input1">
                    <input name='start' class="form-control" id="startDate" size="7" type="text" value="<?php echo $start_date; ?>" readonly>
                    <span class="input-group-addon"><span class="glyphicon glyphicon-calendar"><i class="fa fa-th" aria-hidden="true"></i></span></span></div>

                <div>End Date </div>
                <div class="input-group date form_datetime col-lg-2" data-date="" data-date-format="yyyy-mm-dd" data-link-field="dtp_input1">
                    <input name='end' class="form-control" id="endDate" size="7" type="text" value="<?php
                                                                                                    echo $to_date; ?>" readonly>
                    <span class="input-group-addon"><span class="glyphicon glyphicon-calendar"><i class="fa fa-th" aria-hidden="true"></i></span></span></div>
                <div class="col-lg-3">
                    <select class="form-control" onchange="changePeriod()" name="selectPeriod" id="selectPeriod">
                        <option <?php if ($selectPeriod == "Custom") { ?> selected <?php } ?> value="Custom">Custom</option>
                        <option <?php if ($selectPeriod == "Last_7_days") { ?> selected <?php } ?> value="Last_7_days">Last 7 days</option>
                        <option <?php if ($selectPeriod == "Last_Month") { ?> selected <?php } ?> value="Last_Month">Last Month</option>
                        <option <?php if ($selectPeriod == "Previous_Month") { ?> selected <?php } ?> value="Previous_Month">Previous Month</option>
                    </select>
                    <button type="submit" class="btn btn-default col-lg-5">Submit</button>
                </div>
            </form>

        </div>
        <br>
        <div id="container" style="width: 1280px; height: 430px; margin: 0 auto">
        </div>
        <?php
        $sql_sum_data = mysqli_query($con2, "SELECT DATE_FORMAT(date,'%Y-%m-%d') as date, 
        CASE 
            WHEN type = 'start' THEN 'start' 
            WHEN type IN ('operate', 'process') THEN 'interim'
            WHEN type = 'stop' THEN 'stop' 
            ELSE 'Other' 
            END as new_type
        , sum(qty) as sum
        FROM FAILAAA 
        WHERE date between '" . $start_date . " 00:00:00'  and '" . $to_date . " 23:59:59'
        AND ( detail = 'ME60' OR detail = 'ME5200' ) 
        AND detail NOT LIKE '%COPY' AND detail not like 'ME60COPY'
        AND type <> '' 
        GROUP BY DATE_FORMAT(date,'%Y-%m-%d'), new_type");

        while ($result = mysqli_fetch_array($sql_sum_data)) {
            $data[$result['new_type']][$result['date']] = $result['sum'];
            // $date[] = date('Y-m',strtotime($result['date']));
        }

        $sql_date = mysqli_query($con2, "select DISTINCT(aa.date) from (
            SELECT DATE_FORMAT(date,'%Y-%m-%d') as date, 
        CASE 
            WHEN type = 'start' THEN 'start' 
            WHEN type IN ('operate', 'process') THEN 'interim'
            WHEN type = 'stop' THEN 'stop' 
            ELSE 'Other' 
            END as new_type
        , sum(qty) as sum
        FROM FAILAAA 
        WHERE date between '" . $start_date . " 00:00:00'  and '" . $to_date . " 23:59:59'
        AND ( detail = 'ME60' OR detail = 'ME5200' )
        AND detail NOT LIKE '%COPY' AND detail not like 'ME60COPY' 
        AND type <> '' 
        GROUP BY DATE_FORMAT(date,'%Y-%m-%d'), new_type
        )aa ");

        while ($result = mysqli_fetch_array($sql_date)) {
            $date[] = date('d-F', strtotime($result['date']));
            $date_foreach[] = date('Y-m-d', strtotime($result['date']));
        }

        $sql_new_type = mysqli_query($con2, "select DISTINCT(aa.new_type) as new_type from (
            SELECT DATE_FORMAT(date,'%Y-%m-%d') as date, 
        CASE 
            WHEN type = 'start' THEN 'start' 
            WHEN type IN ('operate', 'process') THEN 'interim'
            WHEN type = 'stop' THEN 'stop' 
            ELSE 'Other' 
            END as new_type
        , sum(qty) as sum
        FROM FAILAAA 
        WHERE date between '" . $start_date . " 00:00:00'  and '" . $to_date . " 23:59:59'
        AND ( detail = 'ME60' OR detail = 'ME5200' )
        AND detail NOT LIKE '%COPY' AND detail not like 'ME60COPY' 
        AND type <> '' 
        GROUP BY DATE_FORMAT(date,'%Y-%m-%d'), new_type
        )aa ");

        while ($result = mysqli_fetch_array($sql_new_type)) {
            $new_type[] = $result['new_type'];
            // $date_foreach[] = date('Y-m-d', strtotime($result['date']));
        }



        foreach ($new_type as $key_new_type => $value_new_type) {
            foreach ($date_foreach as $key_date_foreach => $value_date_foreach) {
                # code...
                // echo 'value_date = '.$value_date.'<br>';
                // echo 'value_bras = '.$value_bras.'<br>';
                if (empty($data[$value_new_type][$value_date_foreach])) {
                    $data[$value_new_type][$value_date_foreach] = 0;
                    // echo 'data = '.$data[$value_date][$value_bras].'------------------------------'.'<br>';
                } else {
                    // echo 'data = '.$data[$value_date][$value_bras].'------------------------------'.'<br>';
                }
            }
            # code...
        }

        // print_r($data);
        // print_r($date_foreach);
        // echo '<br>';
        // print_r($data);
        ?>
        <br>
        <br>
        <div class="table-responsive">
            <table class="table table-dark table-hover">
                <thead class="thead-dark">
                    <tr  class="table-active">
                        <th></td>
                        <?php foreach ($date as $key_date => $value_date) { ?>
                        <th><?php echo $value_date ?></th>
                        <?php
                        } ?>
                    </tr>
                </thead>
                <?php foreach ($new_type as $key_new_type => $value_new_type) { ?>
                <tr>
                    <th ><?php echo $value_new_type ?></th>
                    <?php foreach ($date_foreach as $key_date => $value_date) { ?>
                    <td><?php echo $data[$value_new_type][$value_date] ?></td>
                    <?php
                        } ?>
                </tr>
                <?php
                } ?>
            </table>
        </div>
    </div>
    <?php
    // print_r($new_type); 
    // print_r($data);
    // print_r($date_foreach); 
    ?>
    <script type="text/javascript">
        function uncheckGraph(chart) {
            Highcharts.each(chart.series, function(p, i) {
                p.hide()
            });
        }

        function checkGraph(chart) {
            Highcharts.each(chart.series, function(p, i) {
                p.show()
            });
        }

        function chartLine(chart) {
            Highcharts.each(chart.series, function(p, i) {
                p.update({
                    type: "line"
                });
            });
        }

        function chartColumn(chart) {
            Highcharts.each(chart.series, function(p, i) {
                p.update({
                    type: "column"
                });
            });
        }
        $(function() {
            Highcharts.setOptions({
                lang: {
                    thousandsSep: ','
                }
            });

            var container = Highcharts.chart('container', {
                chart: {
                    zoomType: 'xy',
                    type: 'column',
                    borderColor: "#000000",
                    borderWidth: 1,
                    height: 450
                },

                title: {
                    text: 'FAIL Accounting by Type',
                },
                subtitle: {

                    text: 'Date : <?php echo date('d F Y', strtotime($start_date)) ?> - <?php echo date('d F Y', strtotime($to_date)) ?> ',
                    align: 'center',
                    useHTML: true,
                    style: {
                        "fontSize": "14px"
                    }
                },

                xAxis: {
                    categories: [
                        <?php
                        foreach ($date as $value) {
                            echo "'" . $value .
                                "'" .
                                ",";
                        }
                        ?>
                    ],
                },

                yAxis: [{
                    // max: 500000,
                    min: 0,
                    title: {
                        text: 'Qty.'
                    },
                    stackLabels: {
                        enabled: true,
                        align: 'center',
                        style: {
                            fontWeight: 'normal',
                            color: 'black',
                            fontSize: '11px'
                        },
                        formatter: function() {
                            return Highcharts.numberFormat(this.total, 0)
                        }
                    }
                }],
                legend: {
                    // align: 'center',
                    // verticalAlign: 'bottom',
                    layout: 'horizontal', // default
                    // itemDistance: 1,
                    backgroundColor: '#ffffff',
                    borderColor: '#C98657',
                    borderWidth: 2,
                    // width: 800,
                    // itemWidth: 260,
                    // margin: 1000,
                    // itemMarginLeft: 50,
                    // itemDistance: 300
                },


                plotOptions: {
                    series: {
                        dataLabels: {
                            enabled: false,
                            format: '{point.y:,.0f}'
                        }
                    },
                    column: {
                        stacking: 'normal'
                    }

                },
                series: [
                    <?php
                    foreach ($new_type as $key_new_type => $value_new_type) {
                        # code...    
                        ?> {
                        name: '<?php echo $value_new_type ?>',
                        data: [
                            <?php
                                foreach ($date_foreach as $key_date => $value_date) {
                                    # code...
                                    echo $data[$value_new_type][$value_date] . ',';
                                }
                                ?>
                        ],
                        index: <?php
                                    if ($value_new_type == 'start') {
                                        echo '1';
                                    } else if ($value_new_type == 'interim') {
                                        echo '2';
                                    } else {
                                        echo '3';
                                    }
                                    ?>,
                        legendIndex: <?php
                                            if ($value_new_type == 'start') {
                                                echo '1';
                                            } else if ($value_new_type == 'interim') {
                                                echo '2';
                                            } else {
                                                echo '3';
                                            }
                                            ?>
                    },
                    <?php
                    }
                    ?>
                ],
                exporting: {
                    buttons: {
                        customButton: {
                            text: '<b>Uncheck</b>',
                            onclick: function() {
                                uncheckGraph(container);
                            }
                        },
                        anotherButton: {
                            text: "<b>Show all</b>",
                            onclick: function() {
                                checkGraph(container);
                            }
                        },
                        lineButton: {
                            text: "<b>[Line]</b>",
                            onclick: function() {
                                chartLine(container);
                            }
                        },
                        columnButton: {
                            text: "<b>[Stacked column]</b>",
                            onclick: function() {
                                chartColumn(container);
                            }
                        }
                    }
                }
            });
        });
    </script>


    <!-- jQuery first, then Tether, then Bootstrap JS. -->
	<script src="js/bootstrap.min2.js" integrity="sha384-vBWWzlZJ8ea9aCX4pEW3rVHjgjt7zpkNpZk+02D9phzyeVkE+jo0ieGizqPLForn" crossorigin="anonymous"></script>

    <script type="text/javascript" src="js/bootstrap-datetimepicker.js" charset="UTF-8"></script>
    <script type="text/javascript">
        $('.form_datetime').datetimepicker({
            // format: 'YYYY-MM-DD',
            weekStart: 1,
            todayBtn: 1,
            autoclose: 1,
            todayHighlight: 1,
            startView: 2,
            minView: 2,
            forceParse: 0,
            showMeridian: 1,
        });
    </script>
</body>

</html>