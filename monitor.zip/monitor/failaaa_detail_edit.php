<!DOCTYPE html>
<html lang="en">
<meta charset="UTF-8">
  <head>
    <meta charset="utf-8">
    <meta name="viewport" content="initial-scale=1.0, maximum-scale=2.0">
    <meta name="description" content="">
    <meta name="author" content="">
  </head>
  <link rel="stylesheet" type="text/css" href="css/bootstrap.min.css">

  <?php
    date_default_timezone_set('Asia/Bangkok');
    include "connect210.php";

    if(!empty($_GET['date']))
    {
       $datestr=$_GET['date'];
    }
    else
    {
       $datestr=date('Y-m-d');
    }
    $hour=$_GET['hour'];

    $queryremark=mysqli_query($con2,"select data_remark from FAILAAA_REMARK where date_remark='".$datestr."' and  time_hour='".$hour.":00-".$hour.":59';");
    $rowremark=mysqli_fetch_array($queryremark);
  ?>

  <body>
  <form action="failaaa_detail_edit_submit.php" method="post">
  <div class="container" style="width: 96%;margin-top:2%;margin-left: 1%;">
    <input type="hidden" name="hour" value="<?php echo $hour;?>">
    <input type="hidden" name="datechk" value="<?php echo $datestr;?>">
    <div class="row">
      <div class="col-md-4 col-sm-4"> 
        <label for="">DATETIME</label>
        <input type="text" readonly class="form-control" value="<?php echo $datestr." ".$hour.":00"?>" placeholder="DATETIME">
      </div>
      <div class="col-md-5 col-sm-5"> 
        <label for="">REMARK</label>
        <textarea class="form-control" required name="txtremark" cols="1" rows="3"><?php echo $rowremark[0];?></textarea>
      </div>
      <div class="col-md-1 col-sm-1" style="margin-top:0.5%;">
        <label for=""></label>
        <button type="submit" class="btn btn-primary btn-md">SUBMIT</button>
      </div>
      <div class="col-md-1 col-sm-1" style="margin-top:0.5%;">
        <label for=""></label>
        <input type="button" class="btn btn-warning btn-md" value="CANCLE" onclick="window_close();" title="close">
      </div>
      <div class="col-md-1 col-sm-1" style="margin-top:0.5%;">
        <label for=""></label>

        <a href="failaaa_detail_edit_delete.php?date=<?php echo $datestr;?>&hour=<?php echo $hour;?>">
          <input type="button" class="btn btn-danger btn-md" value="CLEAR" title="Delete"> 
        </a>
      </div>
    </div>
  </form>

<div class="container" style="margin-top:2%;">
  <div class="row">
    <div class="col-md-12 col-sm-12">
      <font size="+0.5"><strong><p>FAIL AAA DETAIL</p></strong></font>
    </div>
  </div>
  <div class="col-md-12 col-sm-12" align="center">
    <textarea name="txtDescription" readonly class="form-control"  style="width:90%;" cols="20" rows="10"><?php

      $sql=mysqli_query($con2, "SELECT date_format(date,'%Y-%m-%d') AS date, bras, sum(qty) AS qty 
        FROM FAILAAA WHERE date_format(date,'%Y-%m-%d %H:%i') 
        BETWEEN '".$datestr." ".$hour.":00' AND '".$datestr." ".$hour.":59' 
        GROUP BY date_format(date,'%Y-%m-%d'), bras ORDER BY date_format(date,'%Y-%m-%d %H:%i') DESC;");
      while ($result=mysqli_fetch_array($sql)){
        echo "BRAS= ".$result["bras"]."  COUNT= ".
        number_format($result["qty"], 0, '.', ',')."&#13;&#10;";}
    ?>
    </textarea> 
  </div>
</div>

<script>
function window_close()
{
  window.close()
}
</script>
</body>
</html>
