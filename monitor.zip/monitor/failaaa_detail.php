<!DOCTYPE html>
<?php
  error_reporting(E_ALL);
  ini_set('display_errors', 1);
?>



<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta name="viewport" content="initial-scale=1.0, maximum-scale=2.0">
    <meta name="description" content="">
    <meta name="author" content="">
    <link rel="icon" href="../../favicon.ico">
    <title>Radius-Monitor</title>

    <!-- Bootstrap core CSS -->
    <?php include("import_lib.php"); ?>
    <link href="css/navbar-top-fixed.css" rel="stylesheet">

    <script language="javascript">
      function js_popup(theURL,width,height) {
        leftpos = (screen.availWidth - width) / 2;
        toppos = (screen.availHeight - height) / 2;
        window.open(theURL, "viewdetails","width=" + width + ",height=" + height + ",left=" + leftpos + ",top=" + toppos);
      }
    </script>

      <style type="text/css">
        .textAlignVer{
          font-size:12px;
        }
        .textAlignVerRotate{
          display:block;
          -webkit-transform: rotate(-90deg);
          -moz-transform: rotate(-90deg);
          font-size:12px;
        }
        td { height: 27px }
        .fail_count_table_data a{
            color: blue;
            text-decoration: none;
        }
        a:hover{
          text-decoration: none;
        }
      </style>
  </head>



  <!-- [0] Initial -->
  <?php
    date_default_timezone_set('Asia/Bangkok');
    include "connect210.php";
  ?>



  <!-- [1] Assign Start & End Date -->
  <?php
    if(!empty($_GET['duration'])) //IF DROPDOWN SELECTED -*- CHECKPOINT
    {
      switch($_GET['duration']){
        case "lastmonth":
          // Last Month
          $dropdown_name="Last Month";
          $start_date=date('Y-m-d',strtotime(date("Y-m-d"). "-1 month"));
          $end_date=date("Y-m-d");
          break;
        case "prvmonth":
          // Previous Month
          $dropdown_name="Previous Month";
          $start_date=date('Y-m-d',strtotime(date("Y-m-d"). "first day of previous month"));
          $end_date=date('Y-m-d',strtotime(date("Y-m-d") . "last day of previous month"));  
          break;
        default: 
          // [Default] Last Week
          $dropdown_name="Last Week";
          $start_date=date('Y-m-d',strtotime(date("Y-m-d"). "-1 week"));
          $end_date=date("Y-m-d");
      }
    }
    elseif(!empty($_GET['date_form']))
    {
      // Custom Duration
      $dropdown_name="Custom";
      if($_GET['date_to'] > date('Y-m-d'))
      {
        $end_date=date('Y-m-d');
      }
      else
      {
        $end_date=$_GET['date_to'];
      }
      $start_date=$_GET['date_form'];   
    }
    elseif(empty($_GET['date_form']) and empty($_GET['type_dropdown']))
    {
      // [Default Page] Last Week
      $dropdown_name="Last Week";
      $start_date=date('Y-m-d',strtotime(date("Y-m-d"). "-1 week"));
      $end_date=date("Y-m-d");
    }

    // Assign lastday_counter
    $lastday=((strtotime($end_date) - strtotime($start_date))/(60*60*24)) + 1; 
  ?>



  <!-- BODY PART -->
  <body>
  <?php 
    include("menu_top.php");
  ?>


  <style type="text/css">
   @media (min-width: 768px) {
     .container {
     width: 500px;
     }
   }
   @media (min-width: 992px) {
     .container {
     width: 800px;
     }
   }
   @media (min-width: 1200px) {
     .container {
     width: 1300px;
     }
   }
   .form-inline {
      width: 1300px;
   }
  </style>



<!-- MENU DATE TIME -->


<div class="container">
<div class="col-md-12">
      <div style="line-height: 10px;">FAIL AAA > <font color="blue">FAIL AAA DETAIL</font></div>
    </div></div><br>


<div class="container">
  <div class="row">
  <form action="#" method='get' class="form-inline" role="form">

    <div align="left" class="col-lg-2">
    <!-- <button type="button" class="btn btn-danger">FAIL AAA</button> -->
    </div>

    <div>Start Date </div>
    <div class="input-group date form_datetime col-lg-2" data-date="" data-date-format="yyyy-mm-dd" data-link-field="dtp_input1">
    <input name='date_form' value="<?php echo $start_date;?>" class="form-control" size="7" type="text"  readonly>
        <span class="input-group-addon"><span class="glyphicon glyphicon-calendar"><i class="fa fa-th" aria-hidden="true"></i></span></span></div>

    <div>End Date </div>
    <div class="input-group date form_datetime col-lg-2" data-date="" data-date-format="yyyy-mm-dd" data-link-field="dtp_input1">
    <input name='date_to' value="<?php echo $end_date;?>" class="form-control" size="7" type="text"  readonly>
      <span class="input-group-addon"><span class="glyphicon glyphicon-calendar"><i class="fa fa-th" aria-hidden="true"></i></span></span></div>

    <div class="col-lg-1"></div>

    <div class="col-lg-3">
    <div class="btn-group">
    <button type="button" class="btn btn-secondary"><?php echo $dropdown_name; ?></button> 
    <button type="button" class="btn btn-danger dropdown-toggle dropdown-toggle-split" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
    <span class="sr-only">Toggle Dropdown</span></button>
    <div class="dropdown-menu">
        <a class="dropdown-item" href="failaaa_detail.php">Last Week</a>
        <a class="dropdown-item" href="failaaa_detail.php?duration=lastmonth">Last Month</a>
        <a class="dropdown-item" href="failaaa_detail.php?duration=prvmonth">Previous Month</a>
    </div><div class="col-lg-1"></div>
    <button type="submit" class="btn btn-default col-lg-5">Submit</button>
    </div>
    </form>
  </div>
</div>
<br>



<!-- [2] Check Input Date & Generate DateSeries - BY FIFAZ// -->
<?php
  $date_series='';
  if(strtotime($end_date) - strtotime($start_date) < 0){
    echo"<script language=\"JavaScript\">";
    echo"alert('เลือกช่วงเวลาไม่ถูกต้อง')";
    echo"</script>";    
  }
  else {
    $end_date_tmp=$end_date;
    while(date("Y-m-d",strtotime($end_date_tmp))!=date("Y-m-d",strtotime($start_date))){
      $date_series.="'".date("Y-m-d",strtotime($end_date_tmp))."',";
      $end_date_tmp=date("Y-m-d",strtotime( "-1 day", strtotime($end_date_tmp)));
    }
    $date_series.="'".date("Y-m-d",strtotime($end_date_tmp))."',";
  }
?>



<!-- Color Code & Time Hour -->
<?php
    $colorcode = array("Sun" => "#FF0000","Mon" => "#FFFF00","Tue" => "PINK","Wed" => "#00FF00","Thu" => "#FF8000","Fri" => "#00FFFF","Sat" => "#D358F7",);
    $timehour = array(
      "00" => "00:00-00:59",
      "01" => "01:00-01:59",
      "02" => "02:00-02:59",
      "03" => "03:00-03:59",
      "04" => "04:00-04:59",
      "05" => "05:00-05:59",
      "06" => "06:00-06:59",
      "07" => "07:00-07:59",
      "08" => "08:00-08:59",
      "09" => "09:00-09:59",
      "10" => "10:00-10:59",
      "11" => "11:00-11:59",
      "12" => "12:00-12:59",
      "13" => "13:00-13:59",
      "14" => "14:00-14:59",
      "15" => "15:00-15:59",
      "16" => "16:00-16:59",
      "17" => "17:00-17:59",
      "18" => "18:00-18:59",
      "19" => "19:00-19:59",
      "20" => "20:00-20:59",
      "21" => "21:00-21:59",
      "22" => "22:00-22:59",
      "23" => "23:00-23:59");
?>



<!-- HEADER -->
<div class="container">
<div class="row" align="center">
  <div class="col-md-12 col-sm-12">
    <h5>Fail AAA</h5>
    Date <?php echo ": ".$start_date." to ".$end_date;?>
  </div>
</div>



<!-- Fail AAA Detail Table -->
<table border="1" width="100%" style="margin-top: 1%;">
  
  <!-- Table Header -->
  <tr bgcolor="#eaeae1">
    <td height="90px;" width="100px;" align="center" colspan="2">
    <span class="textAlignVer"> 
    <strong>Date/Time</strong>
    </span></td> 
    <?php
      foreach($timehour as $value)
      {
    ?>
    <td height="90px;" width="30px;">
    <div style="width:30px;height:90px;">
      <svg>
          <text transform="rotate(270, 12, 0) translate(-75,5)"><?php echo $value?></text>
      </svg>
    </div>
    </td>
    <?php } ?>
    <td height="90px;" align="center"><span class="textAlignVer"><strong>Remark</strong></span></td> 
  </tr>
  <!-- End Table Header -->



  <!-- Query Table Data -->
  <?php
    $sql=mysqli_query($con2, "SELECT date_format(date,'%Y-%m-%d %H') AS date, sum(qty) AS qty FROM FAILAAA WHERE date_format(date,'%Y-%m-%d %H:%i:%s') BETWEEN '".$start_date." 00:00:00' AND '".$end_date." 23:59:59'AND detail NOT LIKE '%COPY' AND detail not like 'ME60COPY' GROUP BY date_format(date,'%Y-%m-%d %H');");
  ?>



  <!-- ***[Loop] Fail Count*** -->
  <?php
    $date_series_tmp= $date_series;
    while ($date_series_tmp!==''){
      $date_tmp=substr($date_series_tmp,1,strpos($date_series_tmp, "',")-1);  
      $dateview=$date_tmp;
      $day_abv=date("D", strtotime($dateview));
  ?>

            <!-- Each Day Row -->
            <tr>
              <!-- ***Date/Time Abv.*** -->
              <td width="50px;" rowspan="2" bgcolor="<?php echo $colorcode[$day_abv];?>" align="center"><span class="textAlignVer"><strong><?php echo $day_abv;?></strong></span></td>
              </td>
              <!-- ***Date/Time Label*** -->
              <td width="80px;" rowspan="2" align="center"><span class="textAlignVer"><?php echo $dateview;?></span></td>
              <?php 
               while ($result=mysqli_fetch_array($sql)) {
                  $time = $result["date"];
                  $result_set[$time] = $result["qty"];
                }
                foreach($timehour as $valuehour => $valuekey)
                {
                  if(isset($result_set[$date_tmp." ".$valuehour]))
                    $fail_count_table_data=number_format($result_set[$date_tmp." ".$valuehour], 0, '.', ',');
                  else
                    $fail_count_table_data='';
              ?>
              <td align="center">
              <span class="textAlignVer">
              <font class="fail_count_table_data a">
              <a href="#" onClick="js_popup('failaaa_detail_edit.php?date=<?php echo $date_tmp;?>&hour=<?php echo $valuehour;?>',1300,500); return false;" title="Code PHP Popup"><?php echo $fail_count_table_data;?></a>
              </font>
              </span>
              </td>
            <?php } ?> 

            <!-- Query Remark -->
            <?php
              $query_remark=mysqli_query($con2,"select time_hour as time_hour, data_remark as data_remark from FAILAAA_REMARK where date_remark='".$date_tmp."' order by time_hour");
            ?>
            <td><span class="textAlignVer">
            <?php
              $data_remark='';
                while($row_remark=mysqli_fetch_array($query_remark)){
                  echo " <font color=\"blue\">".$row_remark["time_hour"]." [".number_format($result_set[$date_tmp." ".substr($row_remark["time_hour"], 0, 2)], 0, '.', ',')."] => ".$row_remark["data_remark"]."</font><br/>";
                }   
            ?>

            </tr>
            <tr></tr>
            <?php $date_series_tmp=str_replace("'".(string)$date_tmp."',", "", $date_series_tmp);
      } 
    ?>
  <!--***End [Loop] Fail Count***-->
</table>



</div>
<br/><br/>

<!-- jQuery first, then Tether, then Bootstrap JS. -->
<script src="js/jquery-3.1.1.min.js"></script>
<script src="js/bootstrap.min2.js" integrity="sha384-vBWWzlZJ8ea9aCX4pEW3rVHjgjt7zpkNpZk+02D9phzyeVkE+jo0ieGizqPLForn" crossorigin="anonymous"></script>
<script type="text/javascript" src="js/bootstrap-datetimepicker.js" charset="UTF-8"></script>
<script type="text/javascript">
    $('.form_datetime').datetimepicker({
      weekStart: 1,
      todayBtn:  1,
      autoclose: 1,
      todayHighlight: 1,
      startView: 2,
      minView: 2,
      forceParse: 0,
      showMeridian: 1
    });
</script>
</body>
</html>
