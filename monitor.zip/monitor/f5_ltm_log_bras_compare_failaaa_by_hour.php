
<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta name="description" content="">
    <meta name="author" content="">
    <link rel="icon" href="../../favicon.ico">

    <title>Radius-Monitor</title>

    <?php include("import_lib.php"); ?>
    <link href="css/navbar-top-fixed.css" rel="stylesheet">

<!-- _____________________________________________ Oat _______________________________________ -->
 <script language="javascript">
 function js_popup(theURL,width,height) { //v2.0
 leftpos = (screen.availWidth - width) / 2;
     toppos = (screen.availHeight - height) / 2;
   window.open(theURL, "viewdetails","width=" + width + ",height=" + height + ",left=" + leftpos + ",top=" + toppos);
 }
 </script>

 <style type="text/css">
 .textAlignVer{
 font-size:12px;
 }
 .textAlignVerRotate{
 display:block;
 -webkit-transform: rotate(-90deg);
 -moz-transform: rotate(-90deg);
 font-size:12px;
 }
 a:hover{
 text-decoration: none;
 }
 </style>
<!-- _____________________________________________ Oat _______________________________________ -->

 <style>
 .highcharts-container {
     overflow: visible !important;
 }
 .MyChartTooltip {
     position: relative;
     z-index: 50;
     border-radius: 5px;
     background-color: #ffffff;
     padding: 5px;
     font-size: 9pt;
     overflow: auto;
     height: 250px;
 }
 .highcharts-tooltip {
   pointer-events: all !important;
 }
 </style>
  </head>

<!-- start chart ltm log -->
<?php
  date_default_timezone_set('Asia/Bangkok');
  include "connect208.php";
  include "connect210.php";
  $duration='';
  $name_dropdown = 'Last Week'; //DEFAULT

  if(isset($_GET['timeperiod'])){
    $timeperiod=$_GET['timeperiod'];
  }
  else{
    $timeperiod="22"; //DEFAULT 22:00
  }

if(isset($_GET['date'])){ //CUSTOM DURATION CHECK
  $date_from = $_GET['date'];
  $day = $_GET['date'];
  $today = date("Y-m-d");
  $time_from = $_GET['time'];
  $startdate_hour = date('Y-m-d',strtotime($date_from)).' '.date('H',strtotime($time_from)).':00';
  $name_dropdown = 'Custom';

} else {
if(isset($_GET['duration'])){ //NO CUSTOM => CHECK DROPDOWN ITEM
    switch($_GET['duration']){
      case "lastmonth": //DROPDOWN = LASTMONTH
        $name_dropdown = 'Last Month';
        $today = date("Y-m-d");
        $startdate_hour = date('Y-m-d',strtotime($today . "-1 month"));
        $startdate_hour = date('Y-m-d H:i',strtotime($startdate_hour . "+0 hour"));
        $show_time_from = date("Y-m-d",strtotime(date("Y-m-d"). "-1 month"));
        $show_time_from = date('Y-m-d H:i',strtotime($show_time_from . "+0 hour"));
        $today2 = date("Y-m-d H:i");
        $time_from = $timeperiod.':00';
        $date_from = date('Y-m-d',strtotime($today . "-1 month"));
        $day = date("Y-m-d");
        break;
      case "prvmonth": //DROPDOWN = PREVIOUSMOUTH
        $name_dropdown = 'Previous Month';
        $today = date("Y-m-d");
        $startdate_hour = date('Y-m-d',strtotime($today . "first day of previous month"));
        $startdate_hour = date('Y-m-d H:i',strtotime($startdate_hour . "+0 hour"));
        $show_time_from = date("Y-m-d",strtotime(date("Y-m-d"). "first day of previous month"));
        $show_time_from = date('Y-m-d H:i',strtotime($show_time_from . "+0 hour")); // เชื่อมข้อความให้เป็นเวลาที่กำหนด
        $today2 = date("Y-m-d H:i");
        $time_from = $timeperiod.':00';
        $date_from = date('Y-m-d',strtotime($today . "first day of previous month"));
        $day = date("Y-m-d");
        break;
      default: //DROPDOWN = LASTWEEK [DEFAULT]
        $today = date("Y-m-d");
        $startdate_hour = date('Y-m-d',strtotime($today . "-1 week"));
        $startdate_hour = date('Y-m-d H:i',strtotime($startdate_hour . "+0 hour"));
        $show_time_from = date("Y-m-d",strtotime(date("Y-m-d"). "-1 week"));
        $show_time_from = date('Y-m-d H:i',strtotime($show_time_from . "+0 hour"));
        $today2 = date("Y-m-d H:i");
        $time_from = $timeperiod.':00';
        $date_from = date('Y-m-d',strtotime($today . "-1 week"));
        $day = date("Y-m-d");
    }
  }
  else { //DROPDOWN = LASTWEEK [DEFAULT]
    $today = date("Y-m-d");
    $startdate_hour = date('Y-m-d',strtotime($today . "-1 week"));
    $startdate_hour = date('Y-m-d H:i',strtotime($startdate_hour . "+0 hour"));
    $show_time_from = date("Y-m-d",strtotime(date("Y-m-d"). "-1 week"));
    $show_time_from = date('Y-m-d H:i',strtotime($show_time_from . "+0 hour")); // เชื่อมข้อความให้เป็นเวลาที่กำหนด
    $today2 = date("Y-m-d H:i");
    $time_from = $timeperiod.':00';
    $date_from = date('Y-m-d',strtotime($today . "-1 week"));
    $day = date("Y-m-d");
  }
}

if(isset($_GET['date2'])){
  $date_to = $_GET['date2'];
  $day2 = $_GET['date2'];
  $time_to = $_GET['time'];
  $time_to = date('H:i',strtotime($time_to . "+59 min"));
  $enddate_hour = date('Y-m-d',strtotime($date_to)).' '.date('H',strtotime($time_to)).':00';
  $date_ptrfixdate_to = date('D',strtotime($date_to));
  $name_dropdown = 'Custom';

} else {
  if(isset($_GET['duration'])){ //NO CUSTOM => CHECK DROPDOWN ITEM
    switch($_GET['duration']){
      case "lastmonth": //DROPDOWN = LASTMONTH
        $name_dropdown = 'Last Month';
        $date_to = date("Y-m-d");
        $enddate_hour = date('Y-m-d',strtotime($date_to));
        $enddate_hour = $enddate_hour.' 23:00';
        $time_to= $timeperiod.':59';
        $date_ptrfixdate_to = date("D");
        $day2 = date("Y-m-d");
        break;
      case "prvmonth": //DROPDOWN = PREVIOUSMOUTH
        $name_dropdown = 'Previous Month';
        $date_to = date('Y-m-d',strtotime($today . "last day of previous month"));
        $enddate_hour = date('Y-m-d',strtotime($date_to));
        $enddate_hour = $enddate_hour.' 23:00';
        $time_to= $timeperiod.':59';
        $date_ptrfixdate_to = date("D");
        $day2 = date("Y-m-d");
        break;
      default: //DROPDOWN = LASTWEEK [DEFAULT]
        $date_to = date("Y-m-d");
        $enddate_hour = date('Y-m-d',strtotime($date_to));
        $enddate_hour = $enddate_hour.' 23:00';
        $show_time_to = date('Y-m-d',strtotime($date_to));
        $show_time_to = $show_time_to.' 23:00';
        $time_to= $timeperiod.':59';
        $date_ptrfixdate_to = date("D");
        $day2 = date("Y-m-d");
    }
  }
  else { //DROPDOWN = LASTWEEK [DEFAULT]
    $date_to = date("Y-m-d");
    $enddate_hour = date('Y-m-d',strtotime($date_to));
    $enddate_hour = $enddate_hour.' 23:00';
    $show_time_to = date('Y-m-d',strtotime($date_to));
    $show_time_to = $show_time_to.' 23:00';
    $time_to= $timeperiod.':59';
    $date_ptrfixdate_to = date("D");
    $day2 = date("Y-m-d");
  }
}

isset($time_series) ? : $time_series = ''; //Edit

$start = date('Y-m-d'); 
$from = date('Y-m-d',strtotime($today . "-1 days"));

     // การนับวันที่ และ เวลา
     function DateDiff($strDate1,$strDate2) // นับระยะห่างของวัน
     {
          return (strtotime($strDate2) - strtotime($strDate1))/  ( 60 * 60 * 24 );  // 1 day = 60*60*24
     }
     function TimeDiff($strTime1,$strTime2) // นับระยะห่างของเวลา
     {
          return (strtotime($strTime2) - strtotime($strTime1))/  ( 60 * 60 ); // 1 Hour =  60*60
     }
     function DateTimeDiff($strDateTime1,$strDateTime2) // นับระยะห่างของวันที่และเวลา
     {
          return (strtotime($strDateTime2) - strtotime($strDateTime1))/  ( 60 * 60 ); // 1 Hour =  60*60
     }

     $datecnt=DateDiff($date_from,$date_to)."<br>";
     $intcnt=intval($datecnt); // แปลงค่า String เป็น Int

     $datecnt_hour=DateTimeDiff($startdate_hour,$enddate_hour)."<br>";
     $intcnt_hour=intval($datecnt_hour); // แปลงค่า String เป็น Int

     $datecnt_time=TimeDiff($time_from,$time_to)."<br>";
     $intcnt_time=intval($datecnt_time); // แปลงค่า String เป็น Int

     // เช็คว่า วันห่างกันกี่วัน ถ้าน้อยกว่า 0 ให้แจ้งเตือนแล้วไม่ทำงานส่วนต่าง ๆ
     if ($intcnt < 0) {
       echo"<script language=\"JavaScript\">";
       echo"alert('กรอกข้อมูลไม่วันที่ไม่ถูกต้อง')";
       echo"</script>";
     }
     else {
        for($i=$intcnt_time; $i >= 0; $i--)
       {
           $time_hour_array[]= date('H',strtotime($time_to . "-".$i." hour")).':00';
       }

       for($i=$intcnt_hour; $i >= 0; $i--)
       {
         for ($j=0; $j < count($time_hour_array); $j++) {
           if ( date('H:i',strtotime($enddate_hour . "-".$i." hour"))  == $time_hour_array[$j] ) {
             $a_date_start_stop[]=date('Y-m-d H:i',strtotime($enddate_hour . "-".$i." hour"));
             $date_ptrfixdate[]=date("D",strtotime(date('Y-m-d H:i',strtotime($enddate_hour . "-".$i." hour"))));
           }
         }
       }

       isset($a_date_start_stop) ? : $a_date_start_stop[] = ''; //Edit // กัน $date ว่าง
       for ($d=0; $d < COUNT($a_date_start_stop); $d++) {
         $time_series .= "'".$date_ptrfixdate[$d]." ".$a_date_start_stop[$d]."',";
       }

    $time_from_query = date('H',strtotime($time_from));
    $time_to_query = date('H',strtotime($time_to));
      }
 ?>

<script src="js/jquery-3.1.1.min.js"></script>
<script src="code/highcharts.js"></script>
<script src="code/highcharts-3d.js"></script>
<script src="code/modules/exporting.js"></script>
<!-- end chart ltm log  -->

<body>
<?php include("menu_top.php");?>
<?php include("menu_date_time_f5_ltm_log_bras_compare_failaaa_by_hour.php");?>

<!-- jQuery first, then Tether, then Bootstrap JS. -->
<script src="js/bootstrap.min2.js" integrity="sha384-vBWWzlZJ8ea9aCX4pEW3rVHjgjt7zpkNpZk+02D9phzyeVkE+jo0ieGizqPLForn" crossorigin="anonymous"></script>


<?php
      //Start Query color
      $sql=mysqli_query($con,"select ro_bras_ip as ip_bras ,ro_color from f5_ro");

      while ($result=mysqli_fetch_array($sql)) {
        $a_ipbras = $result["ip_bras"];
        $a_bras_color[$a_ipbras] = $result["ro_color"];
      }
      //End Query color

    //Query หา nasip ของ 10.11.11.86
    $sql=mysqli_query($con,"SELECT f5_data.date , f5_data.bras_name , ro_bras_name , f5_data.nasipaddress , f5_data.ip_host , f5_data.cnt
      FROM (SELECT date_format(datetime,'%Y-%m-%d %H:00') as date, bras.bras_name as bras_name , bras.nasipaddress as nasipaddress ,bras.radius_host as ip_host, COUNT(bras.nasipaddress) as cnt
      from ( SELECT *
      , SUBSTRING(SUBSTRING_INDEX(ltmlog,':',4),-11,11) AS ltmlog_strIP
      , TRIM(REPLACE(SUBSTRING(SUBSTRING_INDEX(ltmlog,':',-1),1,5),':','')) as ltmlog_strPort
      FROM f5_ltm_log as f5_log
      WHERE ltmlog like '%down%'
        and (date_format(datetime,'%Y-%m-%d') between '$date_from' and '$date_to')
        and (date_format(datetime,'%H:%m') between '$time_from' and '$time_to')
      ) as f5_log JOIN f5_radius_port as bras
      on (f5_log.ltmlog_strPort = bras.radius_port and f5_log.ltmlog_strIP = bras.radius_host)
      where bras.radius_host = '10.11.11.86'
      GROUP BY date , bras.nasipaddress
      ) as f5_data join f5_ro
      on (f5_data.nasipaddress = f5_ro.ro_bras_ip)
      group by f5_ro.ro_bras_ip
      ORDER BY f5_ro.ro_id");

    while ($result=mysqli_fetch_array($sql)) {
      $a_nasip_array[] = $result["nasipaddress"];
    }

    // Query หา nasip ของ 10.11.11.88
    $sql=mysqli_query($con,"SELECT f5_data.date , f5_data.bras_name , ro_bras_name , f5_data.nasipaddress , f5_data.ip_host , f5_data.cnt
      FROM (SELECT date_format(datetime,'%Y-%m-%d %H:00') as date, bras.bras_name as bras_name , bras.nasipaddress as nasipaddress ,bras.radius_host as ip_host, COUNT(bras.nasipaddress) as cnt
      from ( SELECT *
      , SUBSTRING(SUBSTRING_INDEX(ltmlog,':',4),-11,11) AS ltmlog_strIP
      , TRIM(REPLACE(SUBSTRING(SUBSTRING_INDEX(ltmlog,':',-1),1,5),':','')) as ltmlog_strPort
      FROM f5_ltm_log as f5_log
      WHERE ltmlog like '%down%'
        and (date_format(datetime,'%Y-%m-%d') between '$date_from' and '$date_to')
        and (date_format(datetime,'%H:%m') between '$time_from' and '$time_to')
      ) as f5_log JOIN f5_radius_port as bras
      on (f5_log.ltmlog_strPort = bras.radius_port and f5_log.ltmlog_strIP = bras.radius_host)
      where bras.radius_host = '10.11.11.88'
      GROUP BY date , bras.nasipaddress
      ) as f5_data join f5_ro
      on (f5_data.nasipaddress = f5_ro.ro_bras_ip)
      group by f5_ro.ro_bras_ip
      ORDER BY f5_ro.ro_id");

    while ($result=mysqli_fetch_array($sql)) {
      $a_nasip_array_88[] = $result["nasipaddress"];
    }
    // จบคำสั่ง Query nasip ของ 10.11.11.88

      // start Query color
      $sql=mysqli_query($con,"select ro_bras_ip as ip_bras ,ro_color from f5_ro");

      while ($result=mysqli_fetch_array($sql)) {
        $a_ipbras = $result["ip_bras"];
        $a_bras_color[$a_ipbras] = $result["ro_color"]; // $data_final[$a_date] เก็บค่า cnt เป็นอ Array [ชี้ตำแหน่งด้วยวันที่]์
      }
      // End Query color

      // start query bras ข้อมูลหลัก

      // ------------------------------------ เริมการทำงานงาน Host 10.11.11.86 -----------------------------------------------------
      $sql=mysqli_query($con,"SELECT f5_data.date , f5_data.bras_name , ro_bras_name , f5_data.nasipaddress , f5_data.ip_host , f5_data.cnt
      FROM (SELECT date_format(datetime,'%Y-%m-%d %H:00') as date, bras.bras_name as bras_name , bras.nasipaddress as nasipaddress ,bras.radius_host as ip_host, COUNT(bras.nasipaddress) as cnt
      from ( SELECT *
      , SUBSTRING(SUBSTRING_INDEX(ltmlog,':',4),-11,11) AS ltmlog_strIP
      , TRIM(REPLACE(SUBSTRING(SUBSTRING_INDEX(ltmlog,':',-1),1,5),':','')) as ltmlog_strPort
      FROM f5_ltm_log as f5_log
      WHERE ltmlog like '%down%'
        and (date_format(datetime,'%Y-%m-%d') between '$date_from' and '$date_to')
        and (date_format(datetime,'%H:%m') between '$time_from' and '$time_to')
      ) as f5_log JOIN f5_radius_port as bras
      on (f5_log.ltmlog_strPort = bras.radius_port and f5_log.ltmlog_strIP = bras.radius_host)
      where bras.radius_host = '10.11.11.86'
      GROUP BY date , bras.nasipaddress
      ) as f5_data join f5_ro
      on (f5_data.nasipaddress = f5_ro.ro_bras_ip)
      #group by date_format(f5_data.date,'%Y-%m-%d %H:%m')
      ORDER BY f5_data.date,f5_ro.ro_id");

      while ($result=mysqli_fetch_array($sql)) {
        $a_date = $result["date"]; // $a_date เก็บวันที่
        $a_nasip = $result["nasipaddress"];
        $a_value[$a_date][$a_nasip] = $result["cnt"]; // $data_final[$a_date] เก็บค่า cnt เป็นอ Array [ชี้ตำแหน่งด้วยวันที่]์
        $a_bras_name[$a_nasip] = $result["ro_bras_name"]; // $data_final[$a_date] เก็บค่า cnt เป็นอ Array [ชี้ตำแหน่งด้วยวันที่]์
      }

      isset($a_nasip_array) ? : $a_nasip_array[] = ''; //Edit // กัน ipnas ว่าง
      for($d=0; $d<COUNT($a_date_start_stop); $d++) {
        //echo COUNT($a_date_start_stop);

        for($n=0; $n<COUNT($a_nasip_array); $n++) {
          //echo $a_nasip_array[$n].'<br>';
          isset($a_value[$a_date_start_stop[$d]][$a_nasip_array[$n]]) ? : $a_value[$a_date_start_stop[$d]][$a_nasip_array[$n]] = ''; //Edit
          if($a_value[$a_date_start_stop[$d]][$a_nasip_array[$n]] != '') {
            isset($data_value[$a_nasip_array[$n]]) ? : $data_value[$a_nasip_array[$n]] = ''; //Edit
            $data_value[$a_nasip_array[$n]] .= $a_value[$a_date_start_stop[$d]][$a_nasip_array[$n]].",";
          }
          else {
            isset($data_value[$a_nasip_array[$n]]) ? : $data_value[$a_nasip_array[$n]] = ''; //Edit
            $data_value[$a_nasip_array[$n]] .= "null,";
          }
        }
      }

      isset($show_data) ? : $show_data = ''; //Edit
      isset($show_color) ? : $show_color = ''; //Edit

      for ($i=0; $i < count($data_value); $i++) {
            isset($show_color) ? : $show_color = ''; //Edit
            if ($a_nasip_array[$i] != '') {
              $show_data .= " { id: '".TRIM($a_bras_name[$a_nasip_array[$i]])."', name: '".TRIM($a_bras_name[$a_nasip_array[$i]])."', data: [".$data_value[$a_nasip_array[$i]]."], stack: '10.11.11.86' },";
              $show_color .= "'".$a_bras_color[$a_nasip_array[$i]]."', ";
            }
            else { // กรณีไม่มีข้อมูลเลย
              //$show_data .= " { name: '', data: [".$data_value[$a_nasip_array[$i]]."] },";
              //$show_color .= "'red', ";
            }
      }
      // ------------------------------------ จบการทำงานงาน Host 10.11.11.86 -----------------------------------------------------

      // ------------------------------------ เริมการทำงานงาน Host 10.11.11.88 -----------------------------------------------------
      $sql=mysqli_query($con,"SELECT f5_data.date , f5_data.bras_name , ro_bras_name , f5_data.nasipaddress , f5_data.ip_host , f5_data.cnt
      FROM (SELECT date_format(datetime,'%Y-%m-%d %H:00') as date, bras.bras_name as bras_name , bras.nasipaddress as nasipaddress ,bras.radius_host as ip_host, COUNT(bras.nasipaddress) as cnt
      from ( SELECT *
      , SUBSTRING(SUBSTRING_INDEX(ltmlog,':',4),-11,11) AS ltmlog_strIP
      , TRIM(REPLACE(SUBSTRING(SUBSTRING_INDEX(ltmlog,':',-1),1,5),':','')) as ltmlog_strPort
      FROM f5_ltm_log as f5_log
      WHERE ltmlog like '%down%'
        and (date_format(datetime,'%Y-%m-%d') between '$date_from' and '$date_to')
        and (date_format(datetime,'%H:%m') between '$time_from' and '$time_to')
      ) as f5_log JOIN f5_radius_port as bras
      on (f5_log.ltmlog_strPort = bras.radius_port and f5_log.ltmlog_strIP = bras.radius_host)
      where bras.radius_host = '10.11.11.88'
      GROUP BY date , bras.nasipaddress
      ) as f5_data join f5_ro
      on (f5_data.nasipaddress = f5_ro.ro_bras_ip)
      #group by date_format(f5_data.date,'%Y-%m-%d %H:%m')
      ORDER BY f5_data.date,f5_ro.ro_id");

      while ($result=mysqli_fetch_array($sql)) {
        $a_date = $result["date"]; // $a_date เก็บวันที่
        $a_nasip = $result["nasipaddress"];
        $a_value_88[$a_date][$a_nasip] = $result["cnt"]; // $data_final[$a_date] เก็บค่า cnt เป็นอ Array [ชี้ตำแหน่งด้วยวันที่]์
        $a_bras_name[$a_nasip] = $result["ro_bras_name"]; // $data_final[$a_date] เก็บค่า cnt เป็นอ Array [ชี้ตำแหน่งด้วยวันที่]์
      }

      isset($a_nasip_array_88) ? : $a_nasip_array_88[] = ''; //Edit // กัน ipnas ว่าง
      for($d=0; $d<COUNT($a_date_start_stop); $d++) {
        //echo COUNT($a_date_start_stop);

        for($n=0; $n<COUNT($a_nasip_array_88); $n++) {
          isset($a_value_88[$a_date_start_stop[$d]][$a_nasip_array_88[$n]]) ? : $a_value_88[$a_date_start_stop[$d]][$a_nasip_array_88[$n]] = ''; //Edit
          if($a_value_88[$a_date_start_stop[$d]][$a_nasip_array_88[$n]] != '') {
            isset($data_value_88[$a_nasip_array_88[$n]]) ? : $data_value_88[$a_nasip_array_88[$n]] = ''; //Edit
            $data_value_88[$a_nasip_array_88[$n]] .= $a_value_88[$a_date_start_stop[$d]][$a_nasip_array_88[$n]].",";
          }
          else {
            isset($data_value_88[$a_nasip_array_88[$n]]) ? : $data_value_88[$a_nasip_array_88[$n]] = ''; //Edit
            $data_value_88[$a_nasip_array_88[$n]] .= "null,";
          }
        }
      }

      isset($show_data_88) ? : $show_data_88 = ''; //Edit
      isset($show_color_88) ? : $show_color_88 = ''; //Edit

      for ($i=0; $i < count($data_value_88); $i++) {
          if ($a_nasip_array_88[$i] != '') {

            $ck_name = 0;
            $msg_linkto = "";
            for ($j=0; $j < count($data_value); $j++) {
              isset($a_bras_name[$a_nasip_array[$j]]) ? : $a_bras_name[$a_nasip_array[$j]] = ''; //Edit // กัน $a_bras_name[$a_nasip_array[$j]] ว่าง
              if (TRIM($a_bras_name[$a_nasip_array_88[$i]]) == TRIM($a_bras_name[$a_nasip_array[$j]])) {
                $msg_linkto = "linkedTo: '".TRIM($a_bras_name[$a_nasip_array_88[$i]])."',  ";
              }
            }

            $show_data_88 .= " { ".$msg_linkto."name: '".TRIM($a_bras_name[$a_nasip_array_88[$i]])."', data: [".$data_value_88[$a_nasip_array_88[$i]]."], stack: '10.11.11.88' },";
            $show_color_88 .= "'".$a_bras_color[$a_nasip_array_88[$i]]."', ";
          }
          else { // กรณีไม่มีข้อมูลเลย
            //$show_data_88 .= " { name: '', data: [".$data_value_88[$a_nasip_array_88[$i]]."] },";
            //$show_color_88 .= "'red', ";
          }
      }
      // ------------------------------------ จบการทำงานงาน Host 10.11.11.88 -----------------------------------------------------

      //echo strlen($show_data_88); // strlen(ตัวแปรสตริง) เช็คว่า String นี้มีข้อความกี่ตัวอักษร
      // หากไม่มีข้อมูลทั้ง 2 เครื่อง ให้แสดงค่าว่าง
      if ( (strlen($show_data) == 0) and (strlen($show_data_88) == 0) ) {
        for ($i=0; $i < count($data_value); $i++) {
          $show_data .= " { name: '', data: [".$data_value[$a_nasip_array[$i]]."] },";
          $show_color .= "'red', ";
          $show_data_88 .= " { name: '', data: [".$data_value_88[$a_nasip_array_88[$i]]."] },";
          $show_color_88 .= "'red', ";
        }
      }

  // End query bras
  
 ?>

<!-- QUERY DATA FROM SERVER [FROM SELECTED DURATION] -->
<?php
  $all_bras_name="#";
  //QUERY RESULT = [TIME=>Fri 2017-09-08 10:00][BRAS][QTY]
  $sql2=mysqli_query($con2, "SELECT date_format(date,'%a %Y-%m-%d %H') AS date, bras, sum(qty) AS qty 
    FROM FAILAAA WHERE date_format(date,'%Y-%m-%d %H') BETWEEN '".$date_from." ".substr($time_from,0,2)."' AND '".$date_to." ".substr($time_from,0,2)."' AND date_format(date,'%H')='".substr($time_from,0,2)."' GROUP BY date_format(date,'%a %Y-%m-%d %H'), bras ORDER BY date_format(date,'%a %Y-%m-%d %H') DESC;");
  $sum=0;
  while ($result=mysqli_fetch_array($sql2)) { //LOOP UNTIL NO RESULT
    $bras = $result["bras"];
    $date = $result["date"].":00";
    $qty = $result["qty"];
    $sum+=$qty;
    $result_set[$bras][$date] = $qty; //CREATE RESULT SET FOR HIGHCHART
    if (stripos($all_bras_name,"#".$bras."#")==false) //IF FOUND NEW BRAS NAME. ADD IT!
      $all_bras_name.="#".$bras."#";
  }

?>

<!-- QUERY BRAS COLOR FROM SERVER -->
<?php
  $sql=mysqli_query($con,"SELECT ro_bras_name AS bras_name, ro_color AS bras_color FROM f5_ro");
  while ($result=mysqli_fetch_array($sql)) {
    $bras_name = $result["bras_name"];
    $bras_color[$bras_name] = $result["bras_color"];
  }
?>

<!-- CONVERT RESULT_SET TO HIGHCHARTS_SERIES [WITH NULL PARAMETER] 
TIME SERIES EXAMPLE = 'Wed 2017-09-06 11:00','Wed 2017-09-06 12:00','Wed 2017-09-06 13:00',
-->
<?php
  $highcharts_series ='';
  $highcharts_color ='';

  $all_bras_name=str_replace("##","#",$all_bras_name);

  //LOOP EVERY UNIQUE BRAS NAME
  while($all_bras_name!=='#'){
    $bras_name_tmp=substr($all_bras_name,1,(int)strpos($all_bras_name, "#", strpos($all_bras_name, "#") + strlen("#"))-1);
    $highcharts_series.="{id: '".$bras_name_tmp."', name: '".$bras_name_tmp."', data: [";
    $highcharts_color.="'".$bras_color[$bras_name_tmp]."',";

    //LOOP EVERY UNIQUE TIME
    $time_series_tmp= $time_series;
    while ($time_series_tmp!==''){
      $date_tmp=substr($time_series_tmp,1,strpos($time_series_tmp, "',")-1);
      
      //CHECK IS [DATE][BRAS] AVALABLE?
      if(isset($result_set[$bras_name_tmp][$date_tmp])) //VALUE AVALABLE
        $highcharts_series.=$result_set[$bras_name_tmp][$date_tmp].",";

      else //VALUE UNAVALABLE
        $highcharts_series.="null,";

      //REMOVE FROM ALL_TIME [GO TO NEXT TIME]
      $time_series_tmp=str_replace("'".(string)$date_tmp."',", "", $time_series_tmp);
    }

    //REMOVE FROM ALL_BRAS_NAME [GO TO NEXT BRAS NAME]
    $all_bras_name=preg_replace('/#'.(string)$bras_name_tmp.'/', '', $all_bras_name, 1);
    $highcharts_series.="]},";
  }
?>

<!-- start chart ltm log -->
<!-- <div id="container" style="width:1280px; height:430px;margin: 0 auto"></div> -->

<div id="container2" style="width:1280px; height:430px;margin: 0 auto"></div>

<script type="text/javascript">
Highcharts.setOptions({
    lang: {
        thousandsSep: ','
    }
});
Highcharts.chart('container', {
    chart: {
        type: 'column',
        borderColor: "#000000",
        borderWidth: 1
    },
    colors: [<?php echo $show_color ?> <?php echo $show_color_88 ?>], // เปลี่ยนแท่งกราฟ
    title: {
        text: 'F5 - 113 LTM LOG (BY HOUR) : Status Down , Host : 10.11.11.86 , 10.11.11.88'
    },
    subtitle: {
            text: '<?php echo 'Date: '.$date_from.' to '.$date_to.' Time: '.$time_from.' - '.$time_to; ?>',
        align: 'center',
        x: -20
    },
    xAxis: {
        categories: [<?php echo $time_series; ?>],
    },
    yAxis: {
        min: 0,
        max: 80,
        title: {
            text: 'Total Status Down'
        },
        stackLabels: {
            enabled: true,
            rotation: -50,
            x: 0,
            y: -10,
            style: {
                fontWeight: 'bold',
                color: (Highcharts.theme && Highcharts.theme.textColor) || 'gray',
            },

        }
    },
    legend: {
        enabled : true, //เปิดให้แถบแต่ล่ะ Bras มาอยู่ข้างล่าง
        itemWidth: 140 // กำหนดระยะห่างการแสดงข้อความ (จัดเรียงให้ตรงกัน)


    },
    tooltip: {
      useHTML: true,
      formatter: function () {
        var s = '<b><u>' + this.x + '</u></b></br> <table>';
        var total_1 = 0 , total_2 = 0 , total = 0;
        var text_1 = [] , text_2 = [];
        var i_1 = 0 , i_2 = 0;
        var sum_text = '<div class="MyChartTooltip">';

         $.each(this.points, function () {
             if(this.series.options.stack == '10.11.11.86') {
               text_1[i_1] = '<td><b><font color="'+this.series.color+'">' + this.series.name + ': </font>' + this.y + '</td>';
               i_1++;
               total_1 += this.y;
             }
             else if(this.series.options.stack == '10.11.11.88') {
               text_2[i_2] = '<td><b><font color="'+this.series.color+'">' + this.series.name + ': </font>' + this.y + '</td>';
               i_2++;
               total_2 += this.y;
             }

             total += this.y;
         });

         sum_text += s; // ใส่หัว Title
         var cnt_loop

         if (text_1.length >= text_2.length) {
           var cnt_loop = text_1.length;
         }
         else {
           var cnt_loop = text_2.length;
         }

         for (var j = 0; j < cnt_loop; j++) {
           sum_text += '<tr>';

           if ( text_1[j] != null) {
             sum_text += text_1[j];
           }
           else {
             sum_text += '<td></td>';
           }
           if ( text_2[j] != null) {
             sum_text += text_2[j];
           }
           else {
             sum_text += '<td></td>';
           }
           //sum_text += '</br>';
           sum_text += '</tr>';
         }

         if( total_1 != 0 ) {
           total_1 = '<td> <b><u>Total 86 : ' + total_1 + '<u></b> </td>';
         }
         else {
             total_1 = '<td></td>';
         }
         if( total_2 != 0 ) {
           total_2 = '<td> <b><u>Total 88 : ' + total_2 + '<u></b> </td>';
         }
         else {
             total_2 = '<td></td>';
         }
         sum_text += '<tr>' + total_1 + total_2 + '</tr>';
         sum_text += '</table>';
         sum_text += '<b><u>Total All: ' + total + '<u></b>';

         sum_text += '<div>';
         return sum_text;
      },
      shared: true,
      crosshairs: true
    },
    plotOptions: {
        column: {
            stacking: 'normal'
        }
    },
    series: [ <?php echo $show_data; ?> <?php echo $show_data_88; ?> ]
});



Highcharts.chart('container2', {
      chart: {
        type: 'column',
        borderColor: "#000000",
        borderWidth: 1
    },

    title: {
        text: 'Fail AAA (BY HOUR)'
    },

    subtitle: {
     text: '<?php echo 'Date: '.$date_from.' to '.$date_to.' Time: '.$time_from.' - '.$time_to; ?>',
        align: 'center',
        x: -20
    },
    xAxis: {
        categories: [<?php echo $time_series; ?>],
    },

    yAxis: {
        title: {
            text: 'Total Fail AAA'
        },
        stackLabels: {
            enabled: true,
            rotation: -50,
            x: 0,
            y: -10,
            style: {
                fontWeight: 'bold',
                color: (Highcharts.theme && Highcharts.theme.textColor) || 'gray',
            },
        }
    },
    legend: {
        enabled : true,
        itemWidth: 140
    },
tooltip: {

      useHTML: true,
      formatter: function () {
        var s = '<b><u>' + this.x + '</u></b></br> <table>';
        var total = 0;
        var bras_text = [];
        var i = 0;
        var sum_text = '<div class="MyChartTooltip">';

         $.each(this.points, function () {
               bras_text[i] = '<td><b><font color="'+this.series.color+'">' + this.series.name + ': </font>' + addCommas(this.y) + '</td>';
               i++;
               total += this.y;
         });

         sum_text += s;
         var cnt_loop=bras_text.length;

         for (var j = 0; j < cnt_loop; j++) {
           sum_text += '<tr>';

           if ( bras_text[j] != null) {
             sum_text += bras_text[j];
           }
           else {
             sum_text += '<td></td>';
           }
           sum_text += '</tr>';
         }

         sum_text += '</table>';
         sum_text += '<b><u>Total: ' + addCommas(total) + '<u></b>';
         sum_text += '<div>';
         return sum_text;
      },

      shared: true,
      crosshairs: true
    },

    plotOptions: {
        column: {
            stacking: 'normal'
        }
    },

    series: [<?php echo $highcharts_series; ?>]

});

function addCommas(nStr)
{
    nStr += '';
    x = nStr.split('.');
    x1 = x[0];
    x2 = x.length > 1 ? '.' + x[1] : '';
    var rgx = /(\d+)(\d{3})/;
    while (rgx.test(x1)) {
        x1 = x1.replace(rgx, '$1' + ',' + '$2');
    }
    return x1 + x2;
}


</script>
<!-- end chart ltm log -->

<script type="text/javascript" src="js/bootstrap-datetimepicker.js" charset="UTF-8"></script>
<script type="text/javascript">
    $('.form_datetime').datetimepicker({
        //language:  'fr',
      weekStart: 1,
      todayBtn:  1,
      autoclose: 1,
      todayHighlight: 1,
      startView: 2,
      minView: 2,
      forceParse: 0,
      showMeridian: 1, // ตัวแบ่ง AM และ PM
    });

    $(function () {

      $('#lastweek-dropdown-item').on('click', function(event) {
          window.location.href = "f5_ltm_log_bras_compare_failaaa_by_hour.php?duration=lastweek&timeperiod="
          +($('#datetimepicker1').datetimepicker('getDate').getHours()<10?'0':'')+$('#datetimepicker1').datetimepicker('getDate').getHours();
      });
      $('#lastmonth-dropdown-item').on('click', function(event) {
          window.location.href = "f5_ltm_log_bras_compare_failaaa_by_hour.php?duration=lastmonth&timeperiod="
          +($('#datetimepicker1').datetimepicker('getDate').getHours()<10?'0':'')+$('#datetimepicker1').datetimepicker('getDate').getHours();
      });
      $('#prvmonth-dropdown-item').on('click', function(event) {
          window.location.href = "f5_ltm_log_bras_compare_failaaa_by_hour.php?duration=prvmonth&timeperiod="
          +($('#datetimepicker1').datetimepicker('getDate').getHours()<10?'0':'')+$('#datetimepicker1').datetimepicker('getDate').getHours();
      });


      $('#datetimepicker1').datetimepicker({
        startDate: '<?php echo $date_to.' 00:00'; ?>',
        minuteStep: 5, // ช่วงนาทีที่จะแสดง
        format: 'hh:ii',
        language:  'fr',
        weekStart: 1,
        todayBtn:  1,
        autoclose: 1,
        todayHighlight: 1,
        startView: 1, // แก้ส่วนรับค่า startView: number เช่น ใส่ 0 รับค่าเวลา ณ ชั่วโมงปัจจุบัน หรือ ใส่ 1 รับค่าเวลา หรือ ใส่ 2 รับค่าวันที่และเวลา หรือ ใส่ 3 รับค่าเดือน หรือ ใส่ 4 รับค่าปี
        minView: 1,
        maxView: 1,
        forceParse: 0,
      });
      $('#datetimepicker2').datetimepicker({
        startDate: '<?php echo $date_to.' 00:00'; ?>',
        minuteStep: 5, // ช่วงนาทีที่จะแสดง
        format: 'hh:ii',
        language:  'fr',
        weekStart: 1,
        todayBtn:  1,
        autoclose: 1,
        todayHighlight: 1,
        startView: 1, // แก้ส่วนรับค่า startView: number เช่น ใส่ 0 รับค่าเวลา ณ ชั่วโมงปัจจุบัน หรือ ใส่ 1 รับค่าเวลา หรือ ใส่ 2 รับค่าวันที่และเวลา หรือ ใส่ 3 รับค่าเดือน หรือ ใส่ 4 รับค่าปี
        minView: 0,
        maxView: 1,
        forceParse: 0
      });
    });

</script>

<!-- _____________________________________ Code Oat __________________________________________________ -->
<br>
<?php
$colorcode = array("Sun" => "#FF0000","Mon" => "#FFFF00","Tue" => "PINK","Wed" => "#00FF00","Thu" => "#FF8000","Fri" => "#00FFFF","Sat" => "#D358F7",);

$timehour = array(
  "00" => "00:00-00:59",
  "01" => "01:00-01:59",
  "02" => "02:00-02:59",
  "03" => "03:00-03:59",
  "04" => "04:00-04:59",
  "05" => "05:00-05:59",
  "06" => "06:00-06:59",
  "07" => "07:00-07:59",
  "08" => "08:00-08:59",
  "09" => "09:00-09:59",
  "10" => "10:00-10:59",
  "11" => "11:00-11:59",
  "12" => "12:00-12:59",
  "13" => "13:00-13:59",
  "14" => "14:00-14:59",
  "15" => "15:00-15:59",
  "16" => "16:00-16:59",
  "17" => "17:00-17:59",
  "18" => "18:00-18:59",
  "19" => "19:00-19:59",
  "20" => "20:00-20:59",
  "21" => "21:00-21:59",
  "22" => "22:00-22:59",
  "23" => "23:00-23:59"
  );
?>

<?php
$name_dropdown="Last Week";
 $dstart=$date_from;
 $dendd=$date_to;
 $lastday=DateDiff("".$dstart."","".$dendd."")+1;
 $j=0;
?>

  </body>
</html>
