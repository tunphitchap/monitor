<?php  
	$con = mysqli_connect("10.11.11.208","monitordb","z53XegdSYxtNbcZY");

	if (!$con) {
    die("Database connection monitor failed : " . mysqli_error());
	}

	$db_select = mysqli_select_db($con, "monitor");
	if (!$db_select) {
    	die("Database selection monitor failed: " . mysqli_error());
	}
	mysqli_set_charset( $con, 'utf8');


	$con_nat444 = mysqli_connect("10.11.11.208","nat","N6XZZ6FSv4gCKK9M");

	if (!$con_nat444) {
    die("Database connection nat444 failed: " . mysqli_error());
	}

	$db_select = mysqli_select_db($con_nat444, "nat444");
	if (!$db_select) {
    	die("Database selection nat444 failed: " . mysqli_error());
	}
	mysqli_set_charset( $con_nat444, 'utf8');
?>
