<?php
date_default_timezone_set('Asia/Bangkok');
include "connect210.php";

?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta name="description" content="">
    <meta name="author" content="">
    <link rel="icon" href="../../favicon.ico">

    <title>Radius-Monitor</title>

    <?php include("import_lib.php"); ?>

    <!-- _____________________________________________ Oat _______________________________________ -->

    <style type="text/css">
        .textAlignVer {
            font-size: 12px;
        }

        .textAlignVerRotate {
            display: block;
            -webkit-transform: rotate(-90deg);
            -moz-transform: rotate(-90deg);
            font-size: 12px;
        }

        a:hover {
            text-decoration: none;
        }

        input[type="text"] {
            font-size: 14px;
        }
    </style>
    <!-- _____________________________________________ Oat _______________________________________ -->

    <style>
        .highcharts-container {
            overflow: visible !important;
        }

        .MyChartTooltip {
            position: relative;
            z-index: 50;
            border-radius: 5px;
            background-color: #ffffff;
            padding: 5px;
            font-size: 9pt;
            overflow: auto;
            height: 250px;
        }

        .highcharts-tooltip {
            pointer-events: all !important;
        }
    </style>

    <script src="js/jquery-3.1.1.min.js"></script>
    <script src="code/highcharts.js"></script>
    <script src="code/highcharts-3d.js"></script>
    <script src="code/modules/exporting.js"></script>

    <script>
        function changePeriod() {
            var start = document.getElementById('startDate');
            var end = document.getElementById('endDate');
            var selectPeriod = document.getElementById('selectPeriod');
            if (selectPeriod.value == 'LastWeek') {
                start.value = "<?php echo date("Y-m-d", strtotime('-1 week')) ?>";
                end.value = "<?php echo date("Y-m-d") ?>";
            } else if (selectPeriod.value == 'LastMonth') {
                start.value = "<?php echo date("Y-m-d", strtotime("-1 month")) ?>";
                end.value = "<?php echo date("Y-m-d") ?>";
            } else if (selectPeriod.value == 'PreviousMonth') {
                start.value = "<?php echo date("Y-m-01", strtotime("-1 month")) ?>";
                end.value = "<?php echo date("Y-m-t", strtotime("-1 month")) ?>";
            }
        }
    </script>
</head>






<body style="padding-top: 4.5rem">
    <?php include("menu_top.php"); ?>

    <!-- MENU DATE TIME -->
    <style type="text/css">
        @media (min-width: 768px) {
            .container {
                width: 500px;
            }
        }

        @media (min-width: 992px) {
            .container {
                width: 800px;
            }
        }

        @media (min-width: 1200px) {
            .container {
                width: 1300px;
            }
        }

        .form-inline {
            width: 1300px;
        }
    </style>
    <?php
    if (empty($_POST['selectPeriod'])) {
        $selectPeriod = "LastWeek";
    } else {
        $selectPeriod = $_POST['selectPeriod'];
    }
    $check_date = 0;
    $str_query = "group by DATE_FORMAT(DATEOPER, '%Y/%m/%d') order by DATE_FORMAT(DATEOPER, '%Y/%m/%d')";

    if (empty($_POST['start']) || empty($_POST['end'])) {
        # code...
        $date_from = date('Y-m-d', strtotime('-1 week'));
        $date_to = date('Y-m-d');
    } else {
        # code...
        $date_from  = $_POST['start'];
        $date_to = $_POST['end'];
    }

    if ($selectPeriod == "LastWeek") {  
        $sql_data_before  = mysqli_query($con2, "SELECT DATE_FORMAT( min(DATEOPER), '%Y/%m/%d' ) AS date, 
        max(WEBLOGIC_90) AS WEBLOGIC_90, 
        max(WEBLOGIC_92) AS WEBLOGIC_92, 
        max(RADIUS_86) AS RADIUS_86, 
        max(RADIUS_88) AS RADIUS_88, 
        TOTAL_4IP, 
        TOTAL_1521, 
        max(DIFF) AS OTHER, 
        ( max(WEBLOGIC_90) + max(WEBLOGIC_92) + max(RADIUS_86) + max(RADIUS_88) + max(DIFF)) AS Total_Max_Conn 
       FROM db1_daily where DATE_FORMAT(DATEOPER,'%Y-%m-%d') between '" . date('Y-m-d', strtotime('-1 week' . $date_from)) . "' and '" . date('Y-m-d', strtotime('-1 week' . $date_to)) . "'" . $str_query);

// echo "<pre>";
// print_r("SELECT DATE_FORMAT( min(DATEOPER), '%Y/%m/%d' ) AS date, 
// max(WEBLOGIC_90) AS WEBLOGIC_90, 
// max(WEBLOGIC_92) AS WEBLOGIC_92, 
// max(RADIUS_86) AS RADIUS_86, 
// max(RADIUS_88) AS RADIUS_88, 
// TOTAL_4IP, 
// TOTAL_1521, 
// max(DIFF) AS OTHER, 
// ( max(WEBLOGIC_90) + max(WEBLOGIC_92) + max(RADIUS_86) + max(RADIUS_88) + max(DIFF)) AS Total_Max_Conn 
// FROM db1_daily where DATEOPER between '" . date('Y-m-d', strtotime('-1 month' . $date_from)) . "' and '" . date('Y-m-t', strtotime('-1 month' . $date_from)) . "'" . $str_quer);
// echo "</pre>";
// exit();

        $sql_data_db2_daily_before  = mysqli_query($con2, "SELECT DATE_FORMAT( min(DATEOPER), '%Y/%m/%d' ) AS date,
        max(WEBLOGIC_90) AS WEBLOGIC_90, 
        max(WEBLOGIC_92) AS WEBLOGIC_92, 
        max(RADIUS_86) AS RADIUS_86, 
        max(RADIUS_88) AS RADIUS_88, 
        TOTAL_4IP, 
        TOTAL_1521, 
        max(DIFF) AS OTHER, 
        ( max(WEBLOGIC_90) + max(WEBLOGIC_92) + max(RADIUS_86) + max(RADIUS_88) + max(DIFF)) AS Total_Max_Conn 
        FROM db2_daily  where DATEOPER between '" . date('Y-m-d', strtotime('-1 week' . $date_from)) . "' and '" . date('Y-m-d', strtotime('-1 week' . $date_to)) . "'" . $str_query);

    } else {
        $sql_data_before  = mysqli_query($con2, "SELECT DATE_FORMAT( min(DATEOPER), '%Y/%m/%d' ) AS date, 
        max(WEBLOGIC_90) AS WEBLOGIC_90, 
        max(WEBLOGIC_92) AS WEBLOGIC_92, 
        max(RADIUS_86) AS RADIUS_86, 
        max(RADIUS_88) AS RADIUS_88, 
        TOTAL_4IP, 
        TOTAL_1521, 
        max(DIFF) AS OTHER, 
        ( max(WEBLOGIC_90) + max(WEBLOGIC_92) + max(RADIUS_86) + max(RADIUS_88) + max(DIFF)) AS Total_Max_Conn 
       FROM db1_daily where DATEOPER between '" . date('Y-m-d', strtotime('-1 month' . $date_from)) . "' and '" . date('Y-m-t', strtotime('-1 month' . $date_from)) . "'" . $str_query);
       
    //    echo "sql_data_before"."<br>";
    //    echo "SELECT DATE_FORMAT( min(DATEOPER), '%Y/%m/%d' ) AS date, 
    //    max(WEBLOGIC_90) AS WEBLOGIC_90, 
    //    max(WEBLOGIC_92) AS WEBLOGIC_92, 
    //    max(RADIUS_86) AS RADIUS_86, 
    //    max(RADIUS_88) AS RADIUS_88, 
    //    TOTAL_4IP, 
    //    TOTAL_1521, 
    //    max(DIFF) AS OTHER, 
    //    ( max(WEBLOGIC_90) + max(WEBLOGIC_92) + max(RADIUS_86) + max(RADIUS_88) + max(DIFF)) AS Total_Max_Conn 
    //   FROM db1_daily where DATEOPER between '" . date('Y-m-d', strtotime('-1 month' . $date_from)) . "' and '" . date('Y-m-t', strtotime('-1 month' . $date_from)) . "'" . $str_query;

        $sql_data_db2_daily_before  = mysqli_query($con2, "SELECT DATE_FORMAT( min(DATEOPER), '%Y/%m/%d' ) AS date,
        max(WEBLOGIC_90) AS WEBLOGIC_90, 
        max(WEBLOGIC_92) AS WEBLOGIC_92, 
        max(RADIUS_86) AS RADIUS_86, 
        max(RADIUS_88) AS RADIUS_88, 
        TOTAL_4IP, 
        TOTAL_1521, 
        max(DIFF) AS OTHER, 
        ( max(WEBLOGIC_90) + max(WEBLOGIC_92) + max(RADIUS_86) + max(RADIUS_88) + max(DIFF)) AS Total_Max_Conn 
        FROM db2_daily  where DATEOPER between '" . date('Y-m-d', strtotime('-1 month' . $date_from)) . "' and '" . date('Y-m-t', strtotime('-1 month' . $date_from)) . "'" . $str_query);
    }



    $type_before = ['WEBLOGIC_90', 'WEBLOGIC_92', 'RADIUS_86', 'RADIUS_88', 'OTHER', 'Total_Max_Conn'];
    $type_Pm_before = ['8011', '8012', '8013', '8014', '8015', 'IP_BCS', 'OTHER'];
    while ($result = mysqli_fetch_array($sql_data_before)) {
        $date_before[] = date('Y-m-d', strtotime($result['date']));
        $data_before['WEBLOGIC_90'][date('Y-m-d', strtotime($result['date']))] = $result['WEBLOGIC_90'];
        $data_before['WEBLOGIC_92'][date('Y-m-d', strtotime($result['date']))] = $result['WEBLOGIC_92'];
        $data_before['RADIUS_86'][date('Y-m-d', strtotime($result['date']))] = $result['RADIUS_86'];
        $data_before['RADIUS_88'][date('Y-m-d', strtotime($result['date']))] = $result['RADIUS_88'];
        $data_before['OTHER'][date('Y-m-d', strtotime($result['date']))] = $result['OTHER'];
        $data_before['Total_Max_Conn'][date('Y-m-d', strtotime($result['date']))] = $result['Total_Max_Conn'];
    }

    $type_db2_daily_before = ['WEBLOGIC_90', 'WEBLOGIC_92', 'RADIUS_86', 'RADIUS_88', 'OTHER', 'Total_Max_Conn'];
    $type_db2_daily_Pm_before = ['8011', '8012', '8013', '8014', '8015', 'IP_BCS', 'OTHER'];
    while ($result = mysqli_fetch_array($sql_data_db2_daily_before)) {
        $date_db2_daily_before[] = date('Y-m-d', strtotime($result['date']));
        $data_db2_daily_before['WEBLOGIC_90'][date('Y-m-d', strtotime($result['date']))] = $result['WEBLOGIC_90'];
        $data_db2_daily_before['WEBLOGIC_92'][date('Y-m-d', strtotime($result['date']))] = $result['WEBLOGIC_92'];
        $data_db2_daily_before['RADIUS_86'][date('Y-m-d', strtotime($result['date']))] = $result['RADIUS_86'];
        $data_db2_daily_before['RADIUS_88'][date('Y-m-d', strtotime($result['date']))] = $result['RADIUS_88'];
        $data_db2_daily_before['OTHER'][date('Y-m-d', strtotime($result['date']))] = $result['OTHER'];
        $data_db2_daily_before['Total_Max_Conn'][date('Y-m-d', strtotime($result['date']))] = $result['Total_Max_Conn'];
    }

    //now
    //now
    //now
    $sql_data  = mysqli_query($con2, "SELECT DATE_FORMAT( min(DATEOPER), '%Y/%m/%d' ) AS date, 
    max(WEBLOGIC_90) AS WEBLOGIC_90, 
    max(WEBLOGIC_92) AS WEBLOGIC_92, 
    max(RADIUS_86) AS RADIUS_86, 
    max(RADIUS_88) AS RADIUS_88, 
    TOTAL_4IP, 
    TOTAL_1521, 
    max(DIFF) AS OTHER, 
    ( max(WEBLOGIC_90) + max(WEBLOGIC_92) + max(RADIUS_86) + max(RADIUS_88) + max(DIFF)) AS Total_Max_Conn 
   FROM db1_daily where DATEOPER between '" . $date_from . "' and '" . $date_to . "'" . $str_query);

//    echo  "SELECT DATE_FORMAT( min(DATEOPER), '%Y/%m/%d' ) AS date, 
//    max(WEBLOGIC_90) AS WEBLOGIC_90, 
//    max(WEBLOGIC_92) AS WEBLOGIC_92, 
//    max(RADIUS_86) AS RADIUS_86, 
//    max(RADIUS_88) AS RADIUS_88, 
//    TOTAL_4IP, 
//    TOTAL_1521, 
//    max(DIFF) AS OTHER, 
//    ( max(WEBLOGIC_90) + max(WEBLOGIC_92) + max(RADIUS_86) + max(RADIUS_88) + max(DIFF)) AS Total_Max_Conn 
//   FROM db1_daily where DATEOPER between '" . $date_from . "' and '" . $date_to . "'" . $str_query;
   
//    echo "<br>"."sql_data"."<br>";
//    echo  "SELECT DATE_FORMAT( min(DATEOPER), '%Y/%m/%d' ) AS date, 
//    max(WEBLOGIC_90) AS WEBLOGIC_90, 
//    max(WEBLOGIC_92) AS WEBLOGIC_92, 
//    max(RADIUS_86) AS RADIUS_86, 
//    max(RADIUS_88) AS RADIUS_88, 
//    TOTAL_4IP, 
//    TOTAL_1521, 
//    max(DIFF) AS OTHER, 
//    ( max(WEBLOGIC_90) + max(WEBLOGIC_92) + max(RADIUS_86) + max(RADIUS_88) + max(DIFF)) AS Total_Max_Conn 
//   FROM db1_daily where DATEOPER between '" . $date_from . "' and '" . $date_to . "'" . $str_query;

    $sql_data_db2_daily  = mysqli_query($con2, "SELECT DATE_FORMAT( min(DATEOPER), '%Y/%m/%d' ) AS date,
    max(WEBLOGIC_90) AS WEBLOGIC_90, 
    max(WEBLOGIC_92) AS WEBLOGIC_92, 
    max(RADIUS_86) AS RADIUS_86, 
    max(RADIUS_88) AS RADIUS_88, 
    TOTAL_4IP, 
    TOTAL_1521, 
    max(DIFF) AS OTHER, 
    ( max(WEBLOGIC_90) + max(WEBLOGIC_92) + max(RADIUS_86) + max(RADIUS_88) + max(DIFF)) AS Total_Max_Conn 
    FROM db2_daily  where DATEOPER between '" . $date_from . "' and '" . $date_to . "'" . $str_query);

    //now
    //now
    //now
    $type_text1 = ['WEBLOGIC_26', 'WEBLOGIC_27', 'RADIUS_45', 'RADIUS_46', 'OTHER', 'Total_Max_Conn'];
    $type = ['WEBLOGIC_90', 'WEBLOGIC_92', 'RADIUS_86', 'RADIUS_88', 'OTHER', 'Total_Max_Conn'];
    $type_Pm = ['8011', '8012', '8013', '8014', '8015', 'IP_BCS', 'OTHER'];
    while ($result = mysqli_fetch_array($sql_data)) {
        $date[] = date('Y-m-d', strtotime($result['date']));
        $data['WEBLOGIC_90'][date('Y-m-d', strtotime($result['date']))] = $result['WEBLOGIC_90'];
        $data['WEBLOGIC_92'][date('Y-m-d', strtotime($result['date']))] = $result['WEBLOGIC_92'];
        $data['RADIUS_86'][date('Y-m-d', strtotime($result['date']))] = $result['RADIUS_86'];
        $data['RADIUS_88'][date('Y-m-d', strtotime($result['date']))] = $result['RADIUS_88'];
        $data['OTHER'][date('Y-m-d', strtotime($result['date']))] = $result['OTHER'];
        $data['Total_Max_Conn'][date('Y-m-d', strtotime($result['date']))] = $result['Total_Max_Conn'];
    }
    $type_text2 = ['WEBLOGIC_26', 'WEBLOGIC_27', 'RADIUS_45', 'RADIUS_46', 'OTHER', 'Total_Max_Conn'];
    $type_db2_daily = ['WEBLOGIC_90', 'WEBLOGIC_92', 'RADIUS_86', 'RADIUS_88', 'OTHER', 'Total_Max_Conn'];
    $type_db2_daily_Pm = ['8011', '8012', '8013', '8014', '8015', 'IP_BCS', 'OTHER'];
    while ($result = mysqli_fetch_array($sql_data_db2_daily)) {
        $date_db2_daily[] = date('Y-m-d', strtotime($result['date']));
        $data_db2_daily['WEBLOGIC_90'][date('Y-m-d', strtotime($result['date']))] = $result['WEBLOGIC_90'];
        $data_db2_daily['WEBLOGIC_92'][date('Y-m-d', strtotime($result['date']))] = $result['WEBLOGIC_92'];
        $data_db2_daily['RADIUS_86'][date('Y-m-d', strtotime($result['date']))] = $result['RADIUS_86'];
        $data_db2_daily['RADIUS_88'][date('Y-m-d', strtotime($result['date']))] = $result['RADIUS_88'];
        $data_db2_daily['OTHER'][date('Y-m-d', strtotime($result['date']))] = $result['OTHER'];
        $data_db2_daily['Total_Max_Conn'][date('Y-m-d', strtotime($result['date']))] = $result['Total_Max_Conn'];
    }
    // print_r($data);
    $sql_color = mysqli_query($con2, "select * from db_color");
    while ($result = mysqli_fetch_array($sql_color)) {
        # code...
        $color[$result['type']] = $result['color'];
        $color2[$result['type']] = $result['color2'];
        $legendIndex_db1_daily[$result['type']] = $result['legendIndex_db1'];
        $legendIndex_db2_daily[$result['type']] = $result['legendIndex_db2'];
        $dashStyles1[$result['type']] = $result['dashStyle1'];
        $dashStyles2[$result['type']] = $result['dashStyle2'];
    }
    //now before
    $top_max_DB1_daily_WL_before = max(max($data_before['WEBLOGIC_90']), max($data_before['WEBLOGIC_92']));
    $top_max_DB2_daily_WL_before = max(max($data_db2_daily_before['WEBLOGIC_90']), max($data_db2_daily_before['WEBLOGIC_92']));

    $top_max_RA1_before = max(max($data_before['RADIUS_86']), max($data_before['RADIUS_88']));
    $top_max_RA2_before = max(max($data_db2_daily_before['RADIUS_86']), max($data_db2_daily_before['RADIUS_88']));

    $top_max_Other1_before = max($data_before['OTHER']);
    $top_max_Other2_before = max($data_db2_daily_before['OTHER']);

    $top_max_Total_Max_Conn_before = max($data_before['Total_Max_Conn']);
    $top_max_Total2_Max_Conn_before = max($data_db2_daily_before['Total_Max_Conn']);
    
        //now before

    //now value
    $top_max_DB1_daily_WL = max(max($data['WEBLOGIC_90']), max($data['WEBLOGIC_92']));
    $top_max_DB2_daily_WL = max(max($data_db2_daily['WEBLOGIC_90']), max($data_db2_daily['WEBLOGIC_92']));

    $top_max_RA1 = max(max($data['RADIUS_86']), max($data['RADIUS_88']));
    $top_max_RA2 = max(max($data_db2_daily['RADIUS_86']), max($data_db2_daily['RADIUS_88']));

    $top_max_Other1 = max($data['OTHER']);
    $top_max_Other2 = max($data_db2_daily['OTHER']);

    $top_max_Total_Max_Conn = max($data['Total_Max_Conn']);
    $top_max_Total2_Max_Conn = max($data_db2_daily['Total_Max_Conn']);

    $top_max_DB1_daily_WL_dif = $top_max_DB1_daily_WL - $top_max_DB1_daily_WL_before;
    $top_max_DB2_daily_WL_dif = $top_max_DB2_daily_WL - $top_max_DB2_daily_WL_before;

    $top_max_RA1_dif = $top_max_RA1 - $top_max_RA1_before;
    $top_max_RA2_dif = $top_max_RA2 - $top_max_RA2_before;

    $top_max_Other1_dif = $top_max_Other1 - $top_max_Other1_before;
    $top_max_Other2_dif = $top_max_Other2 - $top_max_Other2_before;

    $top_max_Total_Max_Conn_dif = $top_max_Total_Max_Conn - $top_max_Total_Max_Conn_before;
    $top_max_Total2_Max_Conn_dif = $top_max_Total2_Max_Conn - $top_max_Total2_Max_Conn_before;

    if ($top_max_DB1_daily_WL_dif >= 0) {
        $color_top_max_DB1_daily_WL_dif = 'green';
        $is_top_max_DB1_daily_WL_dif = '+';
    } else {
        $color_top_max_DB1_daily_WL_dif = 'red';
        $is_top_max_DB1_daily_WL_dif = '';
    }

    if ($top_max_DB2_daily_WL_dif >= 0) {
        $color_top_max_DB2_daily_WL_dif = 'green';
        $is_top_max_DB2_daily_WL_dif = '+';
    } else {
        $color_top_max_DB2_daily_WL_dif = 'red';
        $is_top_max_DB2_daily_WL_dif = '';
    }

    if ($top_max_RA1_dif >= 0) {
        $color_top_max_RA1_dif = 'green';
        $is_top_max_RA1_dif = '+';
    } else {
        $color_top_max_RA1_dif = 'red';
        $is_top_max_RA1_dif = '';
    }

    if ($top_max_RA2_dif >= 0) {
        $color_top_max_RA2_dif = 'green';
        $is_top_max_RA2_dif = '+';
    } else {
        $color_top_max_RA2_dif = 'red';
        $is_top_max_RA2_dif = '';
    }

    if ($top_max_Other1_dif >= 0) {
        $color_top_max_Other1_dif = 'green';
        $is_top_max_Other1_dif = '+';
    } else {
        $color_top_max_Other1_dif = 'red';
        $is_top_max_Other1_dif = '';
    }

    if ($top_max_Other2_dif >= 0) {
        $color_top_max_Other2_dif = 'green';
        $is_top_max_Other2_dif = '+';
    } else {
        $color_top_max_Other2_dif = 'red';
        $is_top_max_Other2_dif = '';
    }

    if ($top_max_Total_Max_Conn_dif >= 0) {
        $color_top_max_Total_Max_Conn_dif = 'green';
        $is_top_max_Total_Max_Conn_dif = '+';
    } else {
        $color_top_max_Total_Max_Conn_dif = 'red';
        $is_top_max_Total_Max_Conn_dif = '';
    }

    if ($top_max_Total2_Max_Conn_dif >= 0) {
        $color_top_max_Total2_Max_Conn_dif = 'green';
        $is_top_max_Total2_Max_Conn_dif = '+';
    } else {
        $color_top_max_Total2_Max_Conn_dif = 'red';
        $is_top_max_Total2_Max_Conn_dif = '';
    }

    ?>

<div class="container">
    <div class="col-md-12">
      <div style="line-height: 10px;">MAX CONNECTION > <font color="blue">DATABASE RAC DAILY</font></div>
    </div>
</div>
<br>

    <div class="container">
        <div class="row">
            <form action="data_con2_daily.php" method='post' class="form-inline" role="form">

                <div align="left" class="col-lg-1">
                <!-- <button type="button" class="btn btn-danger">MAX CONNECTION</button> -->
                </div>
                <div class="col-lg-1"></div>
                <div class="col-lg-1">Start Date</div>
                <div class="input-group date form_datetime col-md-2" data-date="" data-date-format="yyyy-mm-dd" data-link-field="dtp_input1">
                    <input name='start' id="startDate" class="form-control" size="7" type="text" value="<?php echo $date_from ?>" readonly>
                    <span class="input-group-addon"><span class="glyphicon glyphicon-calendar"><i class="fa fa-th" aria-hidden="true"></i></span></span></div>

                <div class="col-lg-1">End Date </div>
                <div class="input-group date form_datetime col-md-2" data-date="" data-date-format="yyyy-mm-dd" data-link-field="dtp_input1">
                    <input name='end' id="endDate" class="form-control" size="7" type="text" value="<?php echo $date_to ?>" readonly>
                    <span class="input-group-addon"><span class="glyphicon glyphicon-calendar"><i class="fa fa-th" aria-hidden="true"></i></span></span></div>


                <div class="col-lg-3">
                    <select class="form-control" onchange="changePeriod()" name="selectPeriod" id="selectPeriod">
                        <option <?php if ($selectPeriod == "LastWeek") { ?> selected <?php } ?> value="LastWeek">LastWeek</option>
                        <option <?php if ($selectPeriod == "LastMonth") { ?> selected <?php } ?> value="LastMonth">LastMonth</option>
                        <option <?php if ($selectPeriod == "PreviousMonth") { ?> selected <?php } ?> value="PreviousMonth">PreviousMonth</option>
                        <option <?php if ($selectPeriod == "Custom") { ?> selected <?php } ?> value="Custom">Custom</option>
                    </select>
                    <button type="submit" class="btn btn-default col-lg-5">Submit</button>
                </div>

            </form>

        </div>
        <br>
        <!-- <div class="row">
            <div class="col-md-6">
                <div id="container"></div>
            </div>
            <div class="col-md-6">
                <div id="container_db2_daily"></div>
            </div>
        </div> -->
        <div class="row">
            <div class="col-md-12">
                <div id="container"></div>
            </div>
        </div>

    </div>

    <!-- <br>
    <div id="container" style="width: 1280px; height: 430px; margin: 0 auto"></div>
    <br>
    <div id="container_db2_daily" style="width: 1280px; height: 430px; margin: 0 auto"></div> -->




    <!-- END MENU DATE TIME -->
    <script type="text/javascript">
        function uncheckGraph(chart) {
            Highcharts.each(chart.series, function(p, i) {
                p.hide()
            });
        }

        function checkGraph(chart) {
            Highcharts.each(chart.series, function(p, i) {
                p.show()
            });
        }

        function chartLine(chart) {
            Highcharts.each(chart.series, function(p, i) {
                p.update({
                    type: "line"
                });
            });
        }

        function chartColumn(chart) {
            Highcharts.each(chart.series, function(p, i) {
                p.update({
                    type: "column"
                });
            });
        }
        $(function() {
            Highcharts.setOptions({
                lang: {
                    thousandsSep: ','
                }
            });

            var container = Highcharts.chart('container', {
                chart: {
                    zoomType: 'xy',
                    type: 'spline',
                    borderColor: "#000000",
                    borderWidth: 1,
                    height: 450
                },

                title: {
                    text: 'Max Connection DB1_daily,DB2_daily : <?php echo date('d F Y', strtotime($date_from)) ?> - <?php echo date('d F Y', strtotime($date_to)) ?>',
                },
                subtitle: {
                    text: '<table>' +
                        '<tr><td>DB1_daily-Total Max Conn. : <?php echo number_format(max($data['Total_Max_Conn'])); ?> <span style="color:<?php echo $color_top_max_Total_Max_Conn_dif ?>"> (<?php echo $is_top_max_Total_Max_Conn_dif . number_format($top_max_Total_Max_Conn_dif) ?>)</span> ,DB1_daily-Weblogic : <?php echo number_format($top_max_DB1_daily_WL) ?><span style="color:<?php echo $color_top_max_DB1_daily_WL_dif ?>"> (<?php echo $is_top_max_DB1_daily_WL_dif . number_format($top_max_DB1_daily_WL_dif) ?>)</span>, DB1_daily-Radius-Acct : <?php echo number_format($top_max_RA1) ?> <span style="color:<?php echo $color_top_max_RA1_dif ?>"> (<?php echo $is_top_max_RA1_dif . number_format($top_max_RA1_dif) ?>)</span>, DB1_daily-Other/Sql : <?php echo number_format($top_max_Other1) ?><span style="color:<?php echo $color_top_max_Other1_dif ?>"> (<?php echo $is_top_max_Other1_dif . number_format($top_max_Other1_dif) ?>)</span></td></tr>' +
                        '<tr><td>DB2_daily-Total Max Conn. : <?php echo number_format(max($data_db2_daily['Total_Max_Conn'])); ?><span style="color:<?php echo $color_top_max_Total2_Max_Conn_dif ?>"> (<?php echo $is_top_max_Total2_Max_Conn_dif . number_format($top_max_Total2_Max_Conn_dif) ?>)</span> ,DB2_daily-Weblogic : <?php echo number_format($top_max_DB2_daily_WL) ?><span style="color:<?php echo $color_top_max_DB2_daily_WL_dif ?>"> (<?php echo $is_top_max_DB2_daily_WL_dif . number_format($top_max_DB2_daily_WL_dif) ?>)</span>, DB2_daily-Radius-Acct : <?php echo number_format($top_max_RA2) ?> <span style="color:<?php echo $color_top_max_RA2_dif ?>"> (<?php echo $is_top_max_RA2_dif . number_format($top_max_RA2_dif) ?>)</span>, DB1_daily-Other/Sql : <?php echo number_format($top_max_Other2) ?><span style="color:<?php echo $color_top_max_Other2_dif ?>"> (<?php echo $is_top_max_Other2_dif . number_format($top_max_Other2_dif) ?>)</span></td></tr>' +
                        '</table>',
                    align: 'center',
                    useHTML: true,
                    style: {
                        "fontSize": "14px"
                    }
                },

                xAxis: {
                    categories: [
                        <?php
                        foreach ($date as $value) {
                            echo "'" . (($check_date == 1) ? date('Y-m-d', strtotime($value)) : $value) .
                                "'" .
                                ",";
                        }
                        ?>
                    ],
                },

                yAxis: [{
                    // max: 500000,
                    min: 0,
                    title: {
                        text: 'Max Connection.'
                    },
                    stackLabels: {
                        enabled: true,
                        align: 'center',
                        style: {
                            fontWeight: 'normal',
                            color: 'black',
                            fontSize: '11px'
                        },
                        formatter: function() {
                            return Highcharts.numberFormat(this.total, 0)
                        }
                    }
                }],
                legend: {
                    // align: 'center',
                    // verticalAlign: 'bottom',
                    layout: 'horizontal', // default
                    // itemDistance: 1,
                    backgroundColor: '#ffffff',
                    borderColor: '#C98657',
                    borderWidth: 2,
                    // width: 800,
                    itemWidth: 260,
                    // margin: 1000,
                    // itemMarginLeft: 50,
                    // itemDistance: 300
                },


                plotOptions: {
                    series: {
                        dataLabels: {
                            enabled: false,
                            format: '{point.y:,.0f}'
                        }
                    },
                    column: {
                        stacking: 'normal'
                    }

                },
                series: [
                    <?php
                    foreach ($type as $key_type => $value_type) {
                        ?> {
                            name: '<?php echo '<span>DB1_daily-</span>' .  $type_text1[$key_type] ?>',
                            data: [
                                <?php
                                    foreach ($date as $key_date => $value_date) {
                                        echo $data[$value_type][$value_date] . ',';
                                    }
                                    ?>
                            ],
                            color: "<?php echo $color[$value_type] ?>",
                            dashStyle: '<?php echo $dashStyles2[$value_type] ?>',
                            legendIndex: <?php echo $legendIndex_db1_daily[$value_type] ?>,
                            marker: {
                                symbol: 'circle',
                            }
                        },
                    <?php
                    }
                    ?>

                    <?php
                    foreach ($type_db2_daily as $key_type => $value_type) {
                        ?> {
                            name: '<?php echo '<span>DB2_daily-</span>' . $type_text1[$key_type] ?>',
                            data: [
                                <?php
                                    foreach ($date_db2_daily as $key_date => $value_date) {
                                        echo $data_db2_daily[$value_type][$value_date] . ',';
                                    }
                                    ?>
                            ],
                            dashStyle: '<?php echo $dashStyles1[$value_type] ?>',
                            color: "<?php echo $color2[$value_type] ?>",
                            legendIndex: <?php echo $legendIndex_db1_daily[$value_type] ?>,
                            marker: {
                                symbol: 'square',
                            }
                        },
                    <?php
                    }
                    ?>
                ],
                tooltip: {
                    formatter: function() {
                        var s = [];
                        s.push('<span style="font-weight:bold;font-size:12px">' + this.x + '<span><br><span style="font-weight:bold;"><span><br><table>');
                        $.each(this.points, function(i, point) {
                            s.push('<tr><td><span style="color:' + this.series.color + ';font-weight:bold;">' + point.series.name + ' :</td><td>' + Highcharts.numberFormat(point.y, 0, '.', ',') + '<span></td></tr>');
                        });
                        s.push('</table>');
                        return s;
                    },
                    borderColor: '#000000',
                    useHTML: true,
                    shared: true
                },
                exporting: {
                    buttons: {
                        customButton: {
                            text: '<b>Uncheck</b>',
                            onclick: function() {
                                uncheckGraph(container);
                            }
                        },
                        anotherButton: {
                            text: "<b>Show all</b>",
                            onclick: function() {
                                checkGraph(container);
                            }
                        },
                        // lineButton: {
                        //     text: "<b>[Line]</b>",
                        //     onclick: function() {
                        //         chartLine(container);
                        //     }
                        // },
                        // columnButton: {
                        //     text: "<b>[Stacked column]</b>",
                        //     onclick: function() {
                        //         chartColumn(container);
                        //     }
                        // },
                    }
                }
            });

            var container_db2_daily = Highcharts.chart('container_db2_daily', {
                chart: {
                    zoomType: 'xy',
                    type: 'line',
                    borderColor: "#000000",
                    borderWidth: 1,
                    height: 450
                },

                title: {
                    text: 'Max Connection DB2_daily',
                },
                subtitle: {

                    text: 'Date : <?php echo date('d F Y H:i', strtotime($date_from)) ?> - <?php echo date('d F Y H:i', strtotime($date_to)) ?> ',
                    align: 'center',
                    useHTML: true,
                    style: {
                        "fontSize": "14px"
                    }
                },

                xAxis: {
                    categories: [
                        <?php
                        foreach ($date_db2_daily as $value) {
                            echo "'" . (($check_date == 1) ? date('Y-m-d', strtotime($value)) : $value) .
                                "'" .
                                ",";
                        }
                        ?>
                    ],
                },

                yAxis: [{
                    // max: 500000,
                    min: 0,
                    title: {
                        text: 'Qty.'
                    },
                    stackLabels: {
                        enabled: true,
                        align: 'center',
                        style: {
                            fontWeight: 'normal',
                            color: 'black',
                            fontSize: '11px'
                        },
                        formatter: function() {
                            return Highcharts.numberFormat(this.total, 0)
                        }
                    }
                }],
                legend: {
                    // align: 'center',
                    // verticalAlign: 'bottom',
                    layout: 'horizontal', // default
                    // itemDistance: 1,
                    backgroundColor: '#ffffff',
                    borderColor: '#C98657',
                    borderWidth: 2,
                    // width: 800,
                    // itemWidth: 260,
                    // margin: 1000,
                    // itemMarginLeft: 50,
                    // itemDistance: 300
                },


                plotOptions: {
                    series: {
                        dataLabels: {
                            enabled: false,
                            format: '{point.y:,.0f}'
                        }
                    },
                    column: {
                        stacking: 'normal'
                    }

                },
                series: [
                    <?php
                    foreach ($type_db2_daily as $key_type => $value_type) {
                        ?> {
                            name: '<?php echo $value_type ?>',
                            data: [
                                <?php
                                    foreach ($date_db2_daily as $key_date => $value_date) {
                                        echo $data_db2_daily[$value_type][$value_date] . ',';
                                    }
                                    ?>
                            ],
                        },
                    <?php
                    }
                    ?>
                ],
                tooltip: {
                    formatter: function() {
                        var s = [];
                        s.push('<span style="font-weight:bold;font-size:12px">' + this.x + '<span><br><span style="font-weight:bold;"><span><br><table>');
                        $.each(this.points, function(i, point) {
                            s.push('<tr><td><span style="color:' + this.series.color + ';font-weight:bold;">' + point.series.name + ' :</td><td>' + Highcharts.numberFormat(point.y, 0, '.', ',') + '<span></td></tr>');
                        });
                        s.push('</table>');
                        return s;
                    },
                    borderColor: '#000000',
                    useHTML: true,
                    shared: true
                },
                exporting: {
                    buttons: {
                        customButton: {
                            text: '<b>Uncheck</b>',
                            onclick: function() {
                                uncheckGraph(container_db2_daily);
                            }
                        },
                        anotherButton: {
                            text: "<b>Show all</b>",
                            onclick: function() {
                                checkGraph(contcontainer_db2_dailyainer);
                            }
                        },
                        // lineButton: {
                        //     text: "<b>[Line]</b>",
                        //     onclick: function() {
                        //         chartLine(container_db2_daily);
                        //     }
                        // },
                        // columnButton: {
                        //     text: "<b>[Stacked column]</b>",
                        //     onclick: function() {
                        //         chartColumn(container_db2_daily);
                        //     }
                        // }
                    }
                },
                // navigation: {
                //     buttonOptions: {
                //         align: 'right',
                //         y:10
                //     }
                // }
            });
        });
    </script>

    <!-- jQuery first, then Tether, then Bootstrap JS. -->
	<script src="js/bootstrap.min2.js" integrity="sha384-vBWWzlZJ8ea9aCX4pEW3rVHjgjt7zpkNpZk+02D9phzyeVkE+jo0ieGizqPLForn" crossorigin="anonymous"></script>

    <script type="text/javascript" src="js/bootstrap-datetimepicker.js" charset="UTF-8"></script>
    <script type="text/javascript">
        $('.form_datetime').datetimepicker({
            format: 'yyyy-mm-dd',
            minView: 2
        });
        $('.form_datetime').datetimepicker().on('changeDate', function(ev) {
            $('#selectPeriod').val('Custom').trigger('change');
        });
    </script>

</body>
</html>