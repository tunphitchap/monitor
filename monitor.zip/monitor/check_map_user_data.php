<?php  
	$con = mysqli_connect("10.11.11.208","root","password");

	if (!$con) {
    die("Database connection failed: " . mysqli_error());
	}

	$db_select = mysqli_select_db($con, "nat444");
	if (!$db_select) {
    	die("Database selection failed: " . mysqli_error());
	}
	mysqli_set_charset( $con, 'utf8');

	////////////////////////////////
$data=array();
  $sql=mysqli_query($con, "select date_oper from daily_mapuser_cgn group by date_oper order by date_oper desc;");
  while ($result=mysqli_fetch_array($sql)) {
  	$data[$result['date_oper']]=1;
  }


	////////////////////////////////

	$start=date('Y-m-d 00:00:00',strtotime($_GET['start']));
	$end=date('Y-m-d 23:30:00',strtotime($_GET['end']));

	echo "<b>***CHECK MAP USER DATA***</b><br><br>";
	echo 'START='.$start.'<br>END='.$end.'<br><br>';

	$end_tmp=$end;
	while($start!=$end_tmp){
		if(isset($data[$end_tmp])){
			//echo '<b>'.$end_tmp.'</b><br>';
		}
		else{
			if($end_tmp<date('Y-m-d H:i:s',strtotime( strtotime($end_tmp)))){
				echo '<b><font color="green">'.$end_tmp.'</font></b><br>';
			}
			else{
				echo '<b><font color="red">'.$end_tmp.'</font></b><br>';
			}
			
		}
		
		$end_tmp=date('Y-m-d H:i:s',strtotime("-30 minute", strtotime($end_tmp)));
	}


?>