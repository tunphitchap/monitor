<meta charset="UTF-8">
<?php
include "connect208.php";

 $hourchk=$_GET['hour'];
 $hosting=$_GET['host'];
 $datechk=$_GET['date'];
 $status=$_GET['status'];


$query_chkre=mysqli_query($con,"select count(*) cnt from f5_ltm_log_remark where date_remark='".$datechk."' and host='".$hosting."' and status='".$status."' and time_hour LIKE '".$hourchk.":%'");
$rowchk=mysqli_fetch_array($query_chkre);
if($rowchk['cnt']>0)
{
	$delete_remark=mysqli_query($con,"delete from f5_ltm_log_remark where  date_remark='".$datechk."' and host='".$hosting."' and status='".$status."' and time_hour LIKE '".$hourchk.":%'");
}
echo "<script>alert('ลบข้อมูลเรียบร้อย');window.close();window.opener.location.reload();</script>";
?>