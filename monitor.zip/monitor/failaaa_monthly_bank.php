
<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta name="description" content="">
    <meta name="author" content="">
    <link rel="icon" href="../../favicon.ico">

    <title>Radius-Monitor</title>

    <?php include("import_lib.php"); ?>
    <link href="css/navbar-top-fixed.css" rel="stylesheet">

    <style type="text/css">
       .textAlignVer{
       font-size:12px;
       }
       .textAlignVerRotate{
       display:block;
       -webkit-transform: rotate(-90deg);
       -moz-transform: rotate(-90deg);
       font-size:12px;
       }
       a:hover{
       text-decoration: none;
       }
    </style>
    <!-- _____________________________________________ Oat _______________________________________ -->

    <style>
     .highcharts-container {
         overflow: visible !important;
     }
     .MyChartTooltip {
         position: relative;
         z-index: 50;
         border-radius: 5px;
         background-color: #ffffff;
         padding: 5px;
         font-size: 9pt;
         overflow: auto;
         height: 250px;
     }
     .highcharts-tooltip {
       pointer-events: all !important;
     }
     </style>
  </head>

<!-- [0] Initialize - BY FIFAZ// -->
<?php
  date_default_timezone_set('Asia/Bangkok');
  include "connect210.php";


// CONNECT 208 //
  $con = mysqli_connect("10.11.11.208","nat","N6XZZ6FSv4gCKK9M");
  if (!$con) {
    die("Database connection failed: " . mysqli_error());
  }

  $db_select = mysqli_select_db($con, "nat444");
  if (!$db_select) {
      die("Database selection failed: " . mysqli_error());
  }
  mysqli_set_charset( $con, 'utf8');
  // END CONNECT 208 //




?>



<!-- [1] Assign $monthly_start And $monthly_end For [2] - BY FIFAZ// -->
<?php
  $duration='';
  $dropdown_name = 'This Year'; // --> Default

  // Set $monthly_start [Start Date]
  if(isset($_GET['start'])){ // --> Custom = Found 'date' From GET Method
    $dropdown_name = 'Custom';
    $monthly_start = $_GET['start'];
  }
  else {
    if(isset($_GET['duration'])){ // --> No Custom = Check Drop Down Item
      switch($_GET['duration']){
        case "lastyear":
          //Last Year
          $dropdown_name = 'Last Year';
          $monthly_start = date('Y-m',strtotime(date("Y-m-d")."-1 year"));
          break;
        case "prvyear":
          //Previous Year
          $dropdown_name = 'Previous Year';
          $monthly_start = date('Y-m',strtotime(date('Y',strtotime(date("Y-m-d") . "first day of previous year")).'-01'));
          break;
        default: 
          //[Default] This Year
          $monthly_start = date('Y-01');
      }
    }
    else {
      //[Default] This Year
      $monthly_start = date('Y-01');
    }
  }

  // Set $monthly_end [End Date]
  if(isset($_GET['end'])){
    $dropdown_name = 'Custom';
    $monthly_end = $_GET['end'];
  } 
  else {
    if(isset($_GET['duration'])){ // --> No Custom = Check Drop Down Item
      switch($_GET['duration']){
        case "lastyear":
          //Last Year
          $dropdown_name = 'Last Year';
          $monthly_end = date('Y-m');
          break;
        case "prvyear":
          //Previous Year
          $dropdown_name = 'Previous Year';
          $monthly_end = date('Y',strtotime(date("Y-m-d") . "first day of previous year")).'-12';
          break;
        default:
          //[Default] This Year
          $monthly_end = date('Y-m');
      }
    }
    else {
      //[Default] This Year
      $monthly_end = date('Y-m');
    }
  }
?>



<!-- [2] Check Input Date & Generate TimeSeries [Categories For Highchart] - BY FIFAZ// -->
<?php
  $time_series='';
  if(strtotime($monthly_end) - strtotime($monthly_start) < 0){
    echo"<script language=\"JavaScript\">";
    echo"alert('เลือกช่วงเวลาไม่ถูกต้อง')";
    echo"</script>";    
  }
  else {
    $monthly_start_tmp=$monthly_start;
    while(date("Y-F",strtotime($monthly_start_tmp))!=date("Y-F",strtotime($monthly_end))){
      $time_series.="'".date("Y-F",strtotime($monthly_start_tmp))."',";
      $monthly_start_tmp=date("Y-F",strtotime( "+1 month", strtotime($monthly_start_tmp)));
    }
    $time_series.="'".date("Y-F",strtotime($monthly_start_tmp))."',";
  }    
?>



<!-- [3.1] Query Data From Server [By BRAS] -->
<?php
  $all_bras_name="#";
  $sql=mysqli_query($con2, "SELECT date_format(date,'%Y-%M') AS date , bras,(SELECT m.ro FROM map_bras_ro m WHERE m.bras=f.bras) AS ro, sum(qty) AS qty 
    FROM FAILAAA f WHERE date_format(date,'%Y-%m') BETWEEN '".$monthly_start."' AND '".$monthly_end."' GROUP BY date_format(date,'%Y-%m'), bras ORDER BY ro ASC;");
  $sum_qty=0;
  while ($result=mysqli_fetch_array($sql)) {
    $bras = $result["bras"];
    $date = $result["date"];
    $qty = $result["qty"];
    $result_set_by_bras[$bras][$date] = $qty;
    if (stripos($all_bras_name,"#".$bras."#")==false) // --> Collect All BRAS Name
      $all_bras_name.="#".$bras."#";
    $sum_qty+=$qty;
  }
?>



<!-- [3.2] Query Data From Server [By Type] -->
<?php
  $sql=mysqli_query($con2, "SELECT date_format(date,'%Y-%M') AS date , type, sum(qty) AS qty 
    FROM FAILAAA WHERE date_format(date,'%Y-%m') BETWEEN '".$monthly_start."' AND '".$monthly_end."' GROUP BY date_format(date,'%Y-%m'), type ORDER BY date_format(date,'%Y-%m') DESC;");
  while ($result=mysqli_fetch_array($sql)) {
    if ($result["type"]=="start"||$result["type"]=="process"||$result["type"]=="stop"){
      $type = $result["type"];
      $date = $result["date"];
      $qty = $result["qty"];
      $result_set_by_type[$type][$date] = $qty;
    }
    else {
      $type="other";
      $date = $result["date"];
      $qty = $result["qty"];
      $result_set_by_type[$type][$date] = $qty;
    }
}
?>



<!-- [4.1] Convert RESULT_SET_BY_BRAS To Highchart Series [Only 1st Graph] -->
<?php
$bras_ro_array=[];

  // Query RO Number for BRAS Name
$sql=mysqli_query($con2, "SELECT bras, ro FROM map_bras_ro;");
 while ($result=mysqli_fetch_array($sql)) {
    $bras_ro_array[$result['bras']]=$result['ro'];
  }

  
 // Query RO Number for BRAS Name
  $sql=mysqli_query($con, "SELECT bras_name as bras, ro FROM summary_user_ip_bras;");
 while ($result=mysqli_fetch_array($sql)) {
    $bras_ro_array[str_replace("-","",$result['bras'])]=$result['ro'];
  }





 function get_bras_color($bras_name,$color_array){
    switch ($color_array[$bras_name]) {
    case 1:
        return '#0a0ad6';
        break;
    case 2:
        return '#cc3801';
        break;
    case 3:
        return '#3bd63b';
        break;
    case 4:
        return '#ce1a7b';
        break;
    case 5:
        return '#8b0d8b';
        break;
    case 6:
        return '#ce6743';
        break;
    case 7:
        return '#cd9b9b';
        break;
    case 8:
        return '#16ccff';
        break;
    case 9:
        return '#98ff23';
        break;
    case 10:
        return '#e57ce1';
        break;
    default:
        return '#ff0000';
  }
  }

  $all_bras_name=str_replace("##","#",$all_bras_name);

  $highcharts_series_1st='';
  // Loop Every Unique BRAS Name
  while($all_bras_name!=='#'){
    $bras_name_tmp=substr($all_bras_name,1,(int)strpos($all_bras_name, "#", strpos($all_bras_name, "#") + strlen("#"))-1);
    $highcharts_series_1st.="{id: '".$bras_name_tmp."', name: '".$bras_name_tmp." [RO".$bras_ro_array[$bras_name_tmp]."]', color: '".get_bras_color($bras_name_tmp,$bras_ro_array)."' ,data: ["; 
    // Loop Every Unique Time
    $time_series_tmp= $time_series;
    while ($time_series_tmp!==''){
      $date_tmp=substr($time_series_tmp,1,strpos($time_series_tmp, "',")-1);
            // Check Is [DATE][BRAS] Available?
      if(isset($result_set_by_bras[$bras_name_tmp][$date_tmp])) // --> Value Available
        $highcharts_series_1st.=$result_set_by_bras[$bras_name_tmp][$date_tmp].",";
      else // --> Value Unavailable
        $highcharts_series_1st.="null,";
      // Remove From time_series_tmp [Go To Next Time]
      $time_series_tmp=str_replace("'".(string)$date_tmp."',", "", $time_series_tmp);
    }
    // Remove From all_bras_name [Go To Next BRAS Name]
    $all_bras_name=preg_replace('/#'.(string)$bras_name_tmp.'/', '', $all_bras_name, 1);
    $highcharts_series_1st.="], stack: 'bras'},";
  }
?>



<!-- [4.2] Convert RESULT_SET_BY_TYPE To Highchart Series [For 1st & 2nd Graph] -->
 <?php
  $highcharts_series_2nd='';

    // [4.2.1] Type = 'START'
    $highcharts_series_1st.="{id: 'START', name: 'START',color: '#82FA58', data: [";
    $highcharts_series_2nd.="{id: 'START', name: 'START',color: '#82FA58', data: [";
    $time_series_tmp=$time_series;
    while ($time_series_tmp!==''){
      $date_tmp=substr($time_series_tmp,1,strpos($time_series_tmp, "',")-1); 
      // Check Is [TYPE][BRAS] Available?
      if(isset($result_set_by_type["start"][$date_tmp])){ // --> Value Available
        $highcharts_series_1st.=$result_set_by_type["start"][$date_tmp].",";
        $highcharts_series_2nd.=$result_set_by_type["start"][$date_tmp].",";
      } 
      else // --> Value Unavailable
      {
        $highcharts_series_1st.="null,";
        $highcharts_series_2nd.="null,";
      }
      // Remove From time_series_tmp [Go To Next Time]
      $time_series_tmp=str_replace("'".(string)$date_tmp."',", "", $time_series_tmp);
    }
    $highcharts_series_1st.="], stack: 'type'},";
    $highcharts_series_2nd.="], stack: 'type'},";

    // [4.2.2] Type = 'INTERIM'
    $highcharts_series_1st.="{id: 'INTERIM', name: 'INTERIM',color: '#F7D358', data: [";
    $highcharts_series_2nd.="{id: 'INTERIM', name: 'INTERIM',color: '#F7D358', data: [";
    $time_series_tmp= $time_series;
    while ($time_series_tmp!==''){
      $date_tmp=substr($time_series_tmp,1,strpos($time_series_tmp, "',")-1);
      // Check Is [TYPE][BRAS] Available?
      if(isset($result_set_by_type["process"][$date_tmp])){ // --> Value Available
        $highcharts_series_1st.=$result_set_by_type["process"][$date_tmp].",";
        $highcharts_series_2nd.=$result_set_by_type["process"][$date_tmp].",";
      }
      else // --> Value Unavailable
      {
        $highcharts_series_1st.="null,";
        $highcharts_series_2nd.="null,";
      }
      // Remove From time_series_tmp [Go To Next Time]
      $time_series_tmp=str_replace("'".(string)$date_tmp."',", "", $time_series_tmp);
    }
    $highcharts_series_1st.="], stack: 'type'},";
    $highcharts_series_2nd.="], stack: 'type'},";

    // [4.2.3] Type = 'STOP'
    $highcharts_series_1st.="{id: 'STOP', name: 'STOP',color: '#FA5858', data: [";
    $highcharts_series_2nd.="{id: 'STOP', name: 'STOP',color: '#FA5858', data: [";
    $time_series_tmp= $time_series;
    while ($time_series_tmp!==''){
      $date_tmp=substr($time_series_tmp,1,strpos($time_series_tmp, "',")-1);
      // Check Is [TYPE][BRAS] Available?
      if(isset($result_set_by_type["stop"][$date_tmp])){ // --> Value Available
        $highcharts_series_1st.=$result_set_by_type["stop"][$date_tmp].",";
        $highcharts_series_2nd.=$result_set_by_type["stop"][$date_tmp].",";
      }
      else // --> Value Unavailable
      {
        $highcharts_series_1st.="null,";
        $highcharts_series_2nd.="null,";
      }
      // Remove From time_series_tmp [Go To Next Time]
      $time_series_tmp=str_replace("'".(string)$date_tmp."',", "", $time_series_tmp);
    }
    $highcharts_series_1st.="], stack: 'type'},";
    $highcharts_series_2nd.="], stack: 'type'},";

    // [4.2.4] Type = 'OTHER'
    $highcharts_series_1st.="{id: 'OTHER', name: 'OTHER',color: '#58FAF4', data: [";
    $highcharts_series_2nd.="{id: 'OTHER', name: 'OTHER',color: '#58FAF4', data: [";
    $time_series_tmp= $time_series;
    while ($time_series_tmp!==''){
      $date_tmp=substr($time_series_tmp,1,strpos($time_series_tmp, "',")-1);  
      // Check Is [TYPE][BRAS] Available?
      if(isset($result_set_by_type["other"][$date_tmp])) // --> Value Available
      {
        $highcharts_series_1st.=$result_set_by_type["other"][$date_tmp].",";
        $highcharts_series_2nd.=$result_set_by_type["other"][$date_tmp].",";
      }
      else // --> Value Unavailable
      {
        $highcharts_series_1st.="null,";
        $highcharts_series_2nd.="null,";
      }
      // Remove From time_series_tmp [Go To Next Time]
      $time_series_tmp=str_replace("'".(string)$date_tmp."',", "", $time_series_tmp);
    }
    $highcharts_series_1st.="], stack: 'type'},";
    $highcharts_series_2nd.="], stack: 'type'},";
?>

<script src="js/jquery-3.1.1.min.js"></script>
<script src="code/highcharts.js"></script>
<script src="code/highcharts-3d.js"></script>
<script src="code/modules/exporting.js"></script>

<body>
<?php include("menu_top.php");?>


<!-- MENU DATE TIME -->
<style type="text/css">
 @media (min-width: 768px) {
   .container {
   width: 500px;
   }
 }
 @media (min-width: 992px) {
   .container {
   width: 800px;
   }
 }
 @media (min-width: 1200px) {
   .container {
   width: 1300px;
   }
 }
 .form-inline {
    width: 1300px;
 }
 </style>

<!-- MENU DATE TIME -->


<div class="container">
<div class="col-md-12">
      <div style="line-height: 10px;">FAIL AAA > <font color="blue">FAIL AAA MONTHLY</font></div>
    </div></div><br>


<div class="container">
  <div class="row">
  <form action="#" method='get' class="form-inline" role="form">
  
    <div align="left" class="col-lg-2">
    <!-- <button type="button" class="btn btn-danger">FAIL AAA</button> -->
    </div>

    <div>Start Date </div>
    <div class="input-group date form_datetime col-lg-2" data-date="" data-date-format="yyyy-mm" data-link-field="dtp_input1">
    <input name='start' class="form-control" size="7" type="text" value="<?php if(isset($_GET['start'])){echo $_GET['start'];}else{echo $monthly_start;}?>" readonly>
    <span class="input-group-addon"><span class="glyphicon glyphicon-calendar"><i class="fa fa-th" aria-hidden="true"></i></span></span></div>

    <div>End Date </div>
    <div class="input-group date form_datetime col-lg-2" data-date="" data-date-format="yyyy-mm" data-link-field="dtp_input1">
    <input name='end' class="form-control" size="7" type="text" value="<?php if(isset($_GET['end'])){echo $_GET['end'];}else{echo $monthly_end;}?>" readonly>
    <span class="input-group-addon"><span class="glyphicon glyphicon-calendar"><i class="fa fa-th" aria-hidden="true"></i></span></span></div>

    <div class="col-lg-1"></div>

    <div class="col-lg-3">
    <div class="btn-group">
    <button type="button" class="btn btn-secondary"><?php echo $dropdown_name; ?></button> 
    <button type="button" class="btn btn-danger dropdown-toggle dropdown-toggle-split" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
    <span class="sr-only">Toggle Dropdown</span></button>
    <div class="dropdown-menu">
    <a class="dropdown-item" href="failaaa_monthly.php">This Year</a>
    <a class="dropdown-item" href="failaaa_monthly.php?duration=lastyear">Last Year</a>
    <a class="dropdown-item" href="failaaa_monthly.php?duration=prvyear">Previous Year</a>
    </div><div class="col-lg-1"></div>
    <button type="submit" class="btn btn-default col-lg-5">Submit</button>
    </div>
    </form>
  </div>
</div>
<br>




<!-- END MENU DATE TIME -->

<!-- jQuery first, then Tether, then Bootstrap JS. -->
<script src="js/bootstrap.min2.js" integrity="sha384-vBWWzlZJ8ea9aCX4pEW3rVHjgjt7zpkNpZk+02D9phzyeVkE+jo0ieGizqPLForn" crossorigin="anonymous"></script>

<!-- Highchart Area -->
<div id="first_container" style="width: 1280px; height: 430px; margin: 0 auto"></div>
<!-- <div id="second_container" style="width:1280px; height:430px;margin: 0 auto"></div> -->

<!-- 1st Graph : By BRAS & By Type -->
<script type="text/javascript">
Highcharts.setOptions({
    lang: {
        thousandsSep: ','
    }
});
Highcharts.chart('first_container', {
    chart: {
        zoomType: 'xy',
        type: 'column',
        borderColor: "#000000",
        borderWidth: 1
    },
    title: {
        text: 'Fail AAA (MONTHLY)'
    },
    subtitle: {
        text: '<?php echo 'Month: '.date("Y-F",strtotime($monthly_start)).' to '.date("Y-F",strtotime($monthly_end)); ?>',
        align: 'center',
        x: -20
    },
    xAxis: {
        categories: [<?php echo $time_series; ?>],
    },
    yAxis: {
        title: {
            text: 'Total Fail AAA'
        },
        stackLabels: {
            enabled: true,
            formatter: function () {
              if (this.stack=='bras')
                  return addCommas(this.total);
              else
                  return "";
            },
            rotation: -90,
            x: 0,
            y: -25,
            style: {
                fontWeight: 'bold',
                color: (Highcharts.theme && Highcharts.theme.textColor) || 'gray',
            },
        }
    },
    legend: {
        enabled : true,
        itemWidth: 140
    },
    tooltip: {
        useHTML: true,
        formatter: function () {
          var s = '<b><u>' + this.x + '</u></b></br> <table>';
          var total = 0;
          var text_1 = [] , text_2 = [];
          var i_1 = 0 , i_2 = 0;
          var sum_text = '<div class="MyChartTooltip">';

          $.each(this.points, function () {
             if(this.series.options.stack == 'bras') {
               text_1[i_1] = '<td><b><font color="'+this.series.color+'">' + this.series.name + ': </font>' + addCommas(this.y) + '&nbsp;&nbsp;&nbsp;</td>';
               i_1++;
               total += this.y;
             }
             else if(this.series.options.stack == 'type') {
               text_2[i_2] = '<td><b><font color="'+this.series.color+'">' + this.series.name + ': </font>' + addCommas(this.y) + '</td>';
               i_2++;
             }
             
          });

          sum_text += s;
          var cnt_loop

          if (text_1.length >= text_2.length)
            var cnt_loop = text_1.length;
          else
            var cnt_loop = text_2.length;

          sum_text +='<td><b><u>BRAS<u></b></td>';
          sum_text +='<td><b><u>TYPE<u></b></td>';

          for (var j = 0; j < cnt_loop; j++) {
            sum_text += '<tr>';           

            if (text_1[j] != null)
              sum_text += text_1[j];
            else
              sum_text += '<td></td>';
            
            if (text_2[j] != null)
              sum_text += text_2[j];
            else
              sum_text += '<td></td>';

            sum_text += '</tr>';
          }
          
          sum_text += '</table>';
          sum_text += '<b><u>Total: ' + addCommas(total) + '<u></b>';
          sum_text += '<div>';
          return sum_text;
      },
      shared: true,
      crosshairs: true
    },
    plotOptions: {
        column: {
            stacking: 'normal'
        }
    },
    series: [<?php echo $highcharts_series_1st; ?>]
});
function addCommas(nStr)
{
    nStr += '';
    x = nStr.split('.');
    x1 = x[0];
    x2 = x.length > 1 ? '.' + x[1] : '';
    var rgx = /(\d+)(\d{3})/;
    while (rgx.test(x1)) {
        x1 = x1.replace(rgx, '$1' + ',' + '$2');
    }
    return x1 + x2;
}
</script>



<!-- 2nd Graph : By Type -->
<script type="text/javascript">
Highcharts.setOptions({
    lang: {
        thousandsSep: ','
    }
});
Highcharts.chart('second_container', {
    chart: {
        zoomType: 'xy',
        type: 'column',
        borderColor: "#000000",
        borderWidth: 1
    },
    title: {
        text: 'Fail AAA (MONTHLY)'
    },
    subtitle: {
        text: '<?php echo 'Month: '.date("Y-F",strtotime($monthly_start)).' to '.date("Y-F",strtotime($monthly_end)); ?>',
        align: 'center',
        x: -20
    },
    xAxis: {
        categories: [<?php echo $time_series; ?>],
    },
    yAxis: {
        title: {
            text: 'Total Fail AAA'
        },
        stackLabels: {
            enabled: true,
            rotation: -50,
            x: 0,
            y: -25,
            style: {
                fontWeight: 'bold',
                color: (Highcharts.theme && Highcharts.theme.textColor) || 'gray',
            },
        }
    },
    legend: {
        enabled : true,
        itemWidth: 140
    },
    tooltip: {
      useHTML: true,
      formatter: function () {
        var s = '<b><u>' + this.x + '</u></b></br> <table>';
        var total = 0;
        var bras_text = [];
        var i = 0;
        var sum_text = '<div class="MyChartTooltip">';

         $.each(this.points, function () {
               bras_text[i] = '<td><b><font color="'+this.series.color+'">' + this.series.name + ': </font>' + addCommas(this.y) + '</td>';
               i++;
               total += this.y;
         });

         sum_text += s;
         var cnt_loop=bras_text.length;

         for (var j = 0; j < cnt_loop; j++) {
           sum_text += '<tr>';

           if (bras_text[j] != null) {
             sum_text += bras_text[j];
           }
           else {
             sum_text += '<td></td>';
           }
           sum_text += '</tr>';
         }

         sum_text += '</table>';
         sum_text += '<b><u>Total: ' + addCommas(total) + '<u></b>';
         sum_text += '<div>';
         return sum_text;
      },
      shared: true,
      crosshairs: true
    },

    plotOptions: {
        column: {
            stacking: 'normal'
        }
    },
    series: [<?php echo $highcharts_series_2nd; ?>]
});
function addCommas(nStr)
{
    nStr += '';
    x = nStr.split('.');
    x1 = x[0];
    x2 = x.length > 1 ? '.' + x[1] : '';
    var rgx = /(\d+)(\d{3})/;
    while (rgx.test(x1)) {
        x1 = x1.replace(rgx, '$1' + ',' + '$2');
    }
    return x1 + x2;
}
</script>



<script type="text/javascript" src="js/bootstrap-datetimepicker.js" charset="UTF-8"></script>
<script type="text/javascript">
  $('.form_datetime').datetimepicker({
    weekStart: 1,
    todayBtn:  1,
    autoclose: 1,
    todayHighlight: 1,
    startView: 3,
    minView: 3,
    forceParse: 0,
    showMeridian: 0
  });

  $(function () {
    $('#datetimepicker1').datetimepicker({
      startDate: '<?php echo $monthly_end.' 00:00'; ?>',
      minuteStep: 5,
      format: 'hh:ii',
      language:  'fr',
      weekStart: 1,
      todayBtn:  1,
    	autoclose: 1,
    	todayHighlight: 1,
    	startView: 1,
    	minView: 1,
    	maxView: 1,
    	forceParse: 0,
    });
    $('#datetimepicker2').datetimepicker({
      startDate: '<?php echo $monthly_end.' 00:00'; ?>',
      minuteStep: 5,
      format: 'hh:ii',
      language:  'fr',
      weekStart: 1,
      todayBtn:  1,
    	autoclose: 1,
    	todayHighlight: 1,
    	startView: 1,
    	minView: 0,
    	maxView: 1,
    	forceParse: 0
    });
  });
</script>

</body>
</html>
