<?php 

  /// Default Parameter ///
  $top_no=0;
  $sendmail_status=FALSE;
  $date=date('Y-m-d',strtotime('-1 day'));
  $date_yesterday=date('Y-m-d',strtotime('-1 day'));
  $data_tcp=array();    $cnt_tcp=0;
  $data_udp=array();    $cnt_udp=0;
  $max_row=0;

  if($_GET['sendmail']==1){
    $sendmail_status=TRUE;
  }

  if(isset($_GET['top'])){
    $top_no=$_GET['top'];
  }
  else{
    $top_no=100;
  }

  /// Connect To DB ///
  $user = "root";
  $pass = "1qazxsw2@3BB";
  $db_name = "exceed_quota";
  $hostname = "10.11.30.59";
  $db_type = "mysql";
  $conn=mysql_connect($hostname,$user,$pass);
  mysql_query("USE $db_name");
  mysql_query("SET NAMES UTF8");
  /// End Connect To DB ///


  // Query Data From Server //
  // 1. TCP //
  $sql_tcp = "SELECT username, protocal, sum(qty) AS qty_ex_port, sum(sum_count) AS counter FROM tbl_exceed_data WHERE protocal != '' AND protocal='TCP' AND DATE_FORMAT(fdate,'%Y-%m-%d')='".$date_yesterday."' GROUP BY username ORDER BY sum(qty) DESC LIMIT ".$top_no;
  $result_tcp = mysql_query($sql_tcp);
  while($result=mysql_fetch_array($result_tcp)){
    $data_tcp[$cnt_tcp]['USERNAME']=$result['username'];
    $data_tcp[$cnt_tcp]['QTY']=$result['qty_ex_port'];
    $data_tcp[$cnt_tcp]['COUNTER']=$result['counter'];
    $cnt_tcp++;
  }
  // 2. UDP //
  $sql_udp = "SELECT username, protocal, sum(qty) AS qty_ex_port, sum(sum_count) AS counter FROM tbl_exceed_data WHERE protocal != '' AND protocal='UDP' AND DATE_FORMAT(fdate,'%Y-%m-%d')='".$date_yesterday."' GROUP BY username ORDER BY sum(qty) DESC LIMIT ".$top_no;
  $result_udp = mysql_query($sql_udp);
  while($result=mysql_fetch_array($result_udp)){
    $data_udp[$cnt_udp]['USERNAME']=$result['username'];
    $data_udp[$cnt_udp]['QTY']=$result['qty_ex_port'];
    $data_udp[$cnt_udp]['COUNTER']=$result['counter'];
    $cnt_udp++;
  }

  if($cnt_tcp>$cnt_udp){
    $max_row=$cnt_tcp;
  }
  else{
    $max_row=$cnt_udp;   
  }

  $avg_tcp=number_format(8888888,2);
  $avg_udp=number_format(777777,2);
  // End Query Data From Server //



      // STEP 1 : WRITE HEADER MAIL //
      $email_body.=write_header_mail($top_no,$date);

      // STEP 2 : WRITE TABLE MAIL //
      $email_body.=write_table_mail($top_no,$max_row,$data_tcp,$data_udp,$avg_tcp,$avg_udp);

      // STEP 3 : WRITE TAIL MAIL //
      $email_body.=write_tail_mail();



echo "<b>Daily Report Exceed NAT Port Quota : Top ".$top_no." [Date: ".$date."]</b><br>";
echo "<b>CNT_TCP=".$cnt_tcp.", CNT_UDP=".$cnt_udp.", MAX_ROW=".$max_row."</b><br>";
echo "<b>**********[START EMAIL PART]**********</b><br>";
echo $email_body; 
echo "<b>**********[END EMAIL PART]**********</b><br>"; 



// Send Mail Part //
  if($sendmail_status==TRUE){
    echo "<b>**********[SENDING EMAIL SUCCESSFULLY]**********</b><br>";

    $mailto = 'matis.a@jasmine.com,manaschai.j@jasmine.com,pathumthip.p@jasmine.com,sahapab.p@jasmine.com';
    //$mailto='sahapab.p@jasmine.com';
    $header = "From: Sahapab Photikum <sahapab.p@jasmine.com>\r\n";
    $header .= "Cc: radmin@3bbmail.com,isnetwork@3bbmail.com\n";
    $subject = "=?UTF-8?B?".base64_encode("Daily Report Exceed NAT Port Quota : Top ".$top_no." ประจำวันที่ ".$date)."?=";
    $header .= "MIME-Version: 1.0\r\n";
    $header .= "Content-Type: text/html; charset=UTF-8\r\n";
    $header .= "Content-Transfer-Encoding: base64\r\n\r\n";

    $main_message .= chunk_split(base64_encode($email_body))."\r\n";
    mail($mailto, $subject, $main_message, $header);
   }
// End Send Mail Part //
?>



<?php

// BELOW IS TON OF XML CODE : DON'T READ IT >_< //

function write_table_mail($top_no,$max_row,$data_tcp,$data_udp,$avg_tcp,$avg_udp){
  $string.="<table class=MsoNormalTable border=0 cellspacing=0 cellpadding=0 width=786 style='width:589.3pt;margin-left:-1.15pt;border-collapse:collapse'>

                                <!-- HEADER -->
                                <tr style='height:12.75pt'>
                                    <td width=380 nowrap colspan=4 valign=bottom style='width:285.3pt;border:solid windowtext 1.0pt;background:#92CDDC;padding:0cm 5.4pt 0cm 5.4pt;height:12.75pt'>
                                        <p class=MsoNormal align=center style='text-align:center'>
                                            <span style='font-size:10.0pt;font-family:\"Tahoma\",\"sans-serif\";color:black'>Top ".$top_no." (TCP), Avg./Day ".$avg_tcp." 
                                                <o:p></o:p>
                                            </span>
                                        </p>
                                    </td>
                                    <td width=20 nowrap valign=bottom style='width:15.0pt;padding:0cm 5.4pt 0cm 5.4pt;height:12.75pt'></td>
                                    <td width=385 nowrap colspan=4 valign=bottom style='width:289.0pt;border:solid windowtext 1.0pt;background:#B1A0C7;padding:0cm 5.4pt 0cm 5.4pt;height:12.75pt'>
                                        <p class=MsoNormal align=center style='text-align:center'>
                                            <span style='font-size:10.0pt;font-family:\"Tahoma\",\"sans-serif\";color:black'>Top ".$top_no." (UDP), Avg./Day ".$avg_udp." 
                                                <o:p></o:p>
                                            </span>
                                        </p>
                                    </td>
                                </tr>

                                <!-- SUB HEADER [YELLOW LINE] -->
                                <tr style='height:12.75pt'>
                                    <td width=35 nowrap valign=bottom style='width:26.55pt;border:solid windowtext 1.0pt;border-top:none;background:yellow;padding:0cm 5.4pt 0cm 5.4pt;height:12.75pt'>
                                        <p class=MsoNormal align=center style='text-align:center'>
                                            <span style='font-size:10.0pt;font-family:\"Tahoma\",\"sans-serif\";color:black'>No.
                                                <o:p></o:p>
                                            </span>
                                        </p>
                                    </td>
                                    <td width=133 nowrap valign=bottom style='width:100.0pt;border-top:none;border-left:none;border-bottom:solid windowtext 1.0pt;border-right:solid windowtext 1.0pt;background:yellow;padding:0cm 5.4pt 0cm 5.4pt;height:12.75pt'>
                                        <p class=MsoNormal align=center style='text-align:center'>
                                            <span style='font-size:10.0pt;font-family:\"Tahoma\",\"sans-serif\";color:black'>Username
                                                <o:p></o:p>
                                            </span>
                                        </p>
                                    </td>
                                    <td width=152 nowrap valign=bottom style='width:114.2pt;border-top:none;border-left:none;border-bottom:solid windowtext 1.0pt;border-right:solid windowtext 1.0pt;background:yellow;padding:0cm 5.4pt 0cm 5.4pt;height:12.75pt'>
                                        <p class=MsoNormal align=center style='text-align:center'>
                                            <span style='font-size:10.0pt;font-family:\"Tahoma\",\"sans-serif\";color:black'>Qty. Exceed NAT Port
                                                <o:p></o:p>
                                            </span>
                                        </p>
                                    </td>
                                    <td width=59 nowrap valign=bottom style='width:44.55pt;border-top:none;border-left:none;border-bottom:solid windowtext 1.0pt;border-right:solid windowtext 1.0pt;background:yellow;padding:0cm 5.4pt 0cm 5.4pt;height:12.75pt'>
                                        <p class=MsoNormal align=center style='text-align:center'>
                                            <span style='font-size:10.0pt;font-family:\"Tahoma\",\"sans-serif\";color:black'>Counter
                                                <o:p></o:p>
                                            </span>
                                        </p>
                                    </td>
                                    <td width=20 nowrap valign=bottom style='width:15.0pt;padding:0cm 5.4pt 0cm 5.4pt;height:12.75pt'></td>
                                    <td width=34 nowrap valign=bottom style='width:25.8pt;border:solid windowtext 1.0pt;border-top:none;background:yellow;padding:0cm 5.4pt 0cm 5.4pt;height:12.75pt'>
                                        <p class=MsoNormal align=center style='text-align:center'>
                                            <span style='font-size:10.0pt;font-family:\"Tahoma\",\"sans-serif\";color:black'>No.
                                                <o:p></o:p>
                                            </span>
                                        </p>
                                    </td>
                                    <td width=147 nowrap valign=bottom style='width:110.0pt;border-top:none;border-left:none;border-bottom:solid windowtext 1.0pt;border-right:solid windowtext 1.0pt;background:yellow;padding:0cm 5.4pt 0cm 5.4pt;height:12.75pt'>
                                        <p class=MsoNormal align=center style='text-align:center'>
                                            <span style='font-size:10.0pt;font-family:\"Tahoma\",\"sans-serif\";color:black'>Username
                                                <o:p></o:p>
                                            </span>
                                        </p>
                                    </td>
                                    <td width=145 nowrap valign=bottom style='width:108.65pt;border-top:none;border-left:none;border-bottom:solid windowtext 1.0pt;border-right:solid windowtext 1.0pt;background:yellow;padding:0cm 5.4pt 0cm 5.4pt;height:12.75pt'>
                                        <p class=MsoNormal align=center style='text-align:center'>
                                            <span style='font-size:10.0pt;font-family:\"Tahoma\",\"sans-serif\";color:black'>Qty. Exceed NAT Port
                                                <o:p></o:p>
                                            </span>
                                        </p>
                                    </td>
                                    <td width=59 nowrap valign=bottom style='width:44.55pt;border-top:none;border-left:none;border-bottom:solid windowtext 1.0pt;border-right:solid windowtext 1.0pt;background:yellow;padding:0cm 5.4pt 0cm 5.4pt;height:12.75pt'>
                                        <p class=MsoNormal align=center style='text-align:center'>
                                            <span style='font-size:10.0pt;font-family:\"Tahoma\",\"sans-serif\";color:black'>Counter
                                                <o:p></o:p>
                                            </span>
                                        </p>
                                    </td>
                                </tr>";

  for($i=0;$i<=$max_row-1;$i++){
                  if(isset($data_tcp[$i]['USERNAME'])){
                        $string.="<!-- TCP TABLE -->
                                  <tr style='height:12.75pt'>
                                    <td width=35 nowrap valign=bottom style='width:26.55pt;border:solid windowtext 1.0pt;border-top:none;padding:0cm 5.4pt 0cm 5.4pt;height:12.75pt'>
                                        <p class=MsoNormal align=center style='text-align:center'>
                                            <span style='font-size:10.0pt;font-family:\"Tahoma\",\"sans-serif\";color:black'>".($i+1)."
                                                <o:p></o:p>
                                            </span>
                                        </p>
                                    </td>
                                    <td width=133 nowrap valign=bottom style='width:100.0pt;border-top:none;border-left:none;border-bottom:solid windowtext 1.0pt;border-right:solid windowtext 1.0pt;padding:0cm 5.4pt 0cm 5.4pt;height:12.75pt'>
                                        <p class=MsoNormal align=center style='text-align:center'>
                                            <span style='font-size:10.0pt;font-family:\"Tahoma\",\"sans-serif\";color:black'>".$data_tcp[$i]['USERNAME']."
                                                <o:p></o:p>
                                            </span>
                                        </p>
                                    </td>
                                    <td width=152 nowrap valign=bottom style='width:114.2pt;border-top:none;border-left:none;border-bottom:solid windowtext 1.0pt;border-right:solid windowtext 1.0pt;padding:0cm 5.4pt 0cm 5.4pt;height:12.75pt'>
                                        <p class=MsoNormal align=right style='text-align:right'>
                                            <span style='font-size:10.0pt;font-family:\"Tahoma\",\"sans-serif\";color:black'>".number_format($data_tcp[$i]['QTY'])."
                                                <o:p></o:p>
                                            </span>
                                        </p>
                                    </td>
                                    <td width=59 nowrap valign=bottom style='width:44.55pt;border-top:none;border-left:none;border-bottom:solid windowtext 1.0pt;border-right:solid windowtext 1.0pt;padding:0cm 5.4pt 0cm 5.4pt;height:12.75pt'>
                                        <p class=MsoNormal align=right style='text-align:right'>
                                            <span style='font-size:10.0pt;font-family:\"Tahoma\",\"sans-serif\";color:black'>".number_format($data_tcp[$i]['COUNTER'])."
                                                <o:p></o:p>
                                            </span>
                                        </p>
                                    </td>";
                      }
                      else{
                        $string.="<!-- TCP TABLE -->
                                  <tr style='height:12.75pt'>
                                    <td width=35 nowrap valign=bottom style='width:26.55pt;border-top:none;padding:0cm 5.4pt 0cm 5.4pt;height:12.75pt'>
                                        <p class=MsoNormal align=center style='text-align:center'>
                                            <span style='font-size:10.0pt;font-family:\"Tahoma\",\"sans-serif\";color:black'>
                                                <o:p></o:p>
                                            </span>
                                        </p>
                                    </td>
                                    <td width=133 nowrap valign=bottom style='width:100.0pt;border-top:none;border-left:none;padding:0cm 5.4pt 0cm 5.4pt;height:12.75pt'>
                                        <p class=MsoNormal align=center style='text-align:center'>
                                            <span style='font-size:10.0pt;font-family:\"Tahoma\",\"sans-serif\";color:black'>
                                                <o:p></o:p>
                                            </span>
                                        </p>
                                    </td>
                                    <td width=152 nowrap valign=bottom style='width:114.2pt;border-top:none;border-left:none;padding:0cm 5.4pt 0cm 5.4pt;height:12.75pt'>
                                        <p class=MsoNormal align=right style='text-align:right'>
                                            <span style='font-size:10.0pt;font-family:\"Tahoma\",\"sans-serif\";color:black'>
                                                <o:p></o:p>
                                            </span>
                                        </p>
                                    </td>
                                    <td width=59 nowrap valign=bottom style='width:44.55pt;border-top:none;border-left:none;padding:0cm 5.4pt 0cm 5.4pt;height:12.75pt'>
                                        <p class=MsoNormal align=right style='text-align:right'>
                                            <span style='font-size:10.0pt;font-family:\"Tahoma\",\"sans-serif\";color:black'>
                                                <o:p></o:p>
                                            </span>
                                        </p>
                                    </td>";
                      }



                            $string.="<!-- SPACE BETWEEN TCP AND UDP -->
                                    <td width=20 nowrap valign=bottom style='width:15.0pt;padding:0cm 5.4pt 0cm 5.4pt;height:12.75pt'></td>";

                  if(isset($data_udp[$i]['USERNAME'])){
                            $string.="<!-- UDP TABLE -->
                                    <td width=34 nowrap valign=bottom style='width:25.8pt;border:solid windowtext 1.0pt;border-top:none;padding:0cm 5.4pt 0cm 5.4pt;height:12.75pt'>
                                        <p class=MsoNormal align=center style='text-align:center'>
                                            <span style='font-size:10.0pt;font-family:\"Tahoma\",\"sans-serif\";color:black'>".($i+1)."
                                                <o:p></o:p>
                                            </span>
                                        </p>
                                    </td>
                                    <td width=147 nowrap valign=bottom style='width:110.0pt;border-top:none;border-left:none;border-bottom:solid windowtext 1.0pt;border-right:solid windowtext 1.0pt;padding:0cm 5.4pt 0cm 5.4pt;height:12.75pt'>
                                        <p class=MsoNormal align=center style='text-align:center'>
                                            <span style='font-size:10.0pt;font-family:\"Tahoma\",\"sans-serif\";color:black'>".$data_udp[$i]['USERNAME']."
                                                <o:p></o:p>
                                            </span>
                                        </p>
                                    </td>
                                    <td width=145 nowrap valign=bottom style='width:108.65pt;border-top:none;border-left:none;border-bottom:solid windowtext 1.0pt;border-right:solid windowtext 1.0pt;padding:0cm 5.4pt 0cm 5.4pt;height:12.75pt'>
                                        <p class=MsoNormal align=right style='text-align:right'>
                                            <span style='font-size:10.0pt;font-family:\"Tahoma\",\"sans-serif\";color:black'>".number_format($data_udp[$i]['QTY'])."
                                                <o:p></o:p>
                                            </span>
                                        </p>
                                    </td>
                                    <td width=59 nowrap valign=bottom style='width:44.55pt;border-top:none;border-left:none;border-bottom:solid windowtext 1.0pt;border-right:solid windowtext 1.0pt;padding:0cm 5.4pt 0cm 5.4pt;height:12.75pt'>
                                        <p class=MsoNormal align=right style='text-align:right'>
                                            <span style='font-size:10.0pt;font-family:\"Tahoma\",\"sans-serif\";color:black'>".number_format($data_udp[$i]['QTY'])."
                                                <o:p></o:p>
                                            </span>
                                        </p>
                                    </td>
                                </tr>";
                  }
                  else{
                            $string.="<!-- UDP TABLE -->
                                    <td width=34 nowrap valign=bottom style='width:25.8pt;border-top:none;padding:0cm 5.4pt 0cm 5.4pt;height:12.75pt'>
                                        <p class=MsoNormal align=center style='text-align:center'>
                                            <span style='font-size:10.0pt;font-family:\"Tahoma\",\"sans-serif\";color:black'>
                                                <o:p></o:p>
                                            </span>
                                        </p>
                                    </td>
                                    <td width=147 nowrap valign=bottom style='width:110.0pt;border-top:none;border-left:none;padding:0cm 5.4pt 0cm 5.4pt;height:12.75pt'>
                                        <p class=MsoNormal align=center style='text-align:center'>
                                            <span style='font-size:10.0pt;font-family:\"Tahoma\",\"sans-serif\";color:black'>
                                                <o:p></o:p>
                                            </span>
                                        </p>
                                    </td>
                                    <td width=145 nowrap valign=bottom style='width:108.65pt;border-top:none;border-left:none;padding:0cm 5.4pt 0cm 5.4pt;height:12.75pt'>
                                        <p class=MsoNormal align=right style='text-align:right'>
                                            <span style='font-size:10.0pt;font-family:\"Tahoma\",\"sans-serif\";color:black'>
                                                <o:p></o:p>
                                            </span>
                                        </p>
                                    </td>
                                    <td width=59 nowrap valign=bottom style='width:44.55pt;border-top:none;border-left:none;padding:0cm 5.4pt 0cm 5.4pt;height:12.75pt'>
                                        <p class=MsoNormal align=right style='text-align:right'>
                                            <span style='font-size:10.0pt;font-family:\"Tahoma\",\"sans-serif\";color:black'>
                                                <o:p></o:p>
                                            </span>
                                        </p>
                                    </td>
                                </tr>";
                  }
  } // END FOR
                                
  $string.="</table>";
  return $string;
}

function write_header_mail($top_no,$date){
  $string="<html
    xmlns:v=\"urn:schemas-microsoft-com:vml\"
    xmlns:o=\"urn:schemas-microsoft-com:office:office\"
    xmlns:w=\"urn:schemas-microsoft-com:office:word\"
    xmlns:x=\"urn:schemas-microsoft-com:office:excel\"
    xmlns:m=\"http://schemas.microsoft.com/office/2004/12/omml\"
    xmlns=\"http://www.w3.org/TR/REC-html40\">
    <head>
        <meta http-equiv=Content-Type content=\"text/html; charset=windows-874\">
            <meta name=Generator content=\"Microsoft Word 14 (filtered medium)\">
                <style>
                    <!--
  /* Font Definitions */
  @font-face
      {font-family:\"Angsana New\";
      panose-1:2 2 6 3 5 4 5 2 3 4;}
  @font-face
      {font-family:\"Cordia New\";
      panose-1:2 11 3 4 2 2 2 2 2 4;}
  @font-face
      {font-family:\"Cordia New\";
      panose-1:2 11 3 4 2 2 2 2 2 4;}
  @font-face
      {font-family:Calibri;
      panose-1:2 15 5 2 2 2 4 3 2 4;}
  @font-face
      {font-family:Tahoma;
      panose-1:2 11 6 4 3 5 4 4 2 4;}
  @font-face
      {font-family:\"Leelawadee UI\";
      panose-1:2 11 5 2 4 2 4 2 2 3;}
  @font-face
      {font-family:Leelawadee;
      panose-1:2 11 5 2 4 2 4 2 2 3;}
  /* Style Definitions */
  p.MsoNormal, li.MsoNormal, div.MsoNormal
      {margin:0cm;
      margin-bottom:.0001pt;
      font-size:11.0pt;
      font-family:\"Calibri\",\"sans-serif\";}
  a:link, span.MsoHyperlink
      {mso-style-priority:99;
      color:blue;
      text-decoration:underline;}
  a:visited, span.MsoHyperlinkFollowed
      {mso-style-priority:99;
      color:purple;
      text-decoration:underline;}
  p
      {mso-style-priority:99;
      mso-margin-top-alt:auto;
      margin-right:0cm;
      mso-margin-bottom-alt:auto;
      margin-left:0cm;
      font-size:14.0pt;
      font-family:\"Angsana New\",\"serif\";}
  span.17
      {mso-style-type:personal-compose;
      font-family:\"Calibri\",\"sans-serif\";
      color:windowtext;}
  .MsoChpDefault
      {mso-style-type:export-only;
      font-family:\"Calibri\",\"sans-serif\";}
  @page WordSection1
      {size:612.0pt 792.0pt;
      margin:72.0pt 72.0pt 72.0pt 72.0pt;}
  div.WordSection1
      {page:WordSection1;}
  -->
                </style>
            </head>
            <body lang=EN-US link=blue vlink=purple>
                <div class=WordSection1>
                    <p>
                        <b>
                            <span lang=TH style='font-size:12.0pt;font-family:\"Tahoma\",\"sans-serif\";color:#1F497D'>เรียน</span>
                        </b>
                        <b>
                            <span style='font-size:12.0pt;font-family:\"Tahoma\",\"sans-serif\";color:#1F497D'>&nbsp;
                                <span lang=TH>ทุกท่าน</span>
                            </span>
                        </b>
                        <span lang=TH></span>
                        <span style='font-size:12.0pt;font-family:\"Tahoma\",\"sans-serif\";color:#1F497D'>
                            <o:p></o:p>
                        </span>
                    </p>
                    <p class=MsoNormal>
                        <span style='font-size:12.0pt;font-family:\"Tahoma\",\"sans-serif\";color:#1F497D'>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; Daily Report Exceed NAT Port Quota : Top ".$top_no." 
                            <span lang=TH>ประจำวันที่ ".$date."&nbsp;รายละเอียดดังตารางครับ<br><span style='mso-tab-count:1'>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </span>สามารถดูรายละเอียดเพิ่มเติมได้ที่ <br><span style='mso-spacerun:yes'>&nbsp;</span><span style='mso-tab-count:1'>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </span></span></span><u><span style='font-size:12.0pt;font-family:\"Tahoma\",\"sans-serif\";color:black;mso-themecolor:text1'>http://radiusinfo.isr.<span lang=TH>3</span>bb.in.th/<span class=SpellE>exceed_quota</span>/<span class=SpellE>exceed_quota_detail_hourly_byuser.php</span></span></u><span style='font-size:12.0pt;font-family:\"Tahoma\",\"sans-serif\";color:#1F497D'><o:p></o:p></span></p><br>";
  return $string;
}

function write_tail_mail(){
  $string="<p class=MsoNormal>
                                <span lang=TH style='font-size:12.0pt;font-family:\"Tahoma\",\"sans-serif\";color:#1F497D'>
                                    <br>
                                        <br>
                                        </span>
                                        <span style='font-size:12.0pt;font-family:\"Tahoma\",\"sans-serif\";color:#1F497D'>
                                            <o:p></o:p>
                                        </span>
                                    </p>
                                    <p class=MsoNormal>
                                        <span lang=TH style='font-size:12.0pt;font-family:\"Tahoma\",\"sans-serif\";color:#1F497D'>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; *หมายเหตุ : </span>
                                        <span lang=TH style='font-size:12.0pt;font-family:\"Tahoma\",\"sans-serif\";color:red'>เป็นระบบส่งอีเมลอัตโนมัติ
                                            <br>
                                                <br>
                                                </span>
                                                <span style='font-size:12.0pt;font-family:\"Tahoma\",\"sans-serif\";color:red'>
                                                    <o:p></o:p>
                                                </span>
                                            </p>
                                            <p class=MsoNormal>
                                                <span style='color:#1F497D'>
                                                    <o:p>&nbsp;</o:p>
                                                </span>
                                            </p>
                                            <p class=MsoNormal>
                                                <b>
                                                    <span lang=TH style='font-size:14.0pt;font-family:\"Leelawadee\",\"sans-serif\";color:#002060'>ขอแสดงความนับถือ</span>
                                                </b>
                                                <span lang=TH></span>
                                                <b>
                                                    <span style='font-size:14.0pt;font-family:\"Leelawadee\",\"sans-serif\";color:#002060'>
                                                        <o:p></o:p>
                                                    </span>
                                                </b>
                                            </p>
                                            <p class=MsoNormal>
                                                <b>
                                                    <span style='font-size:8.0pt;font-family:\"Leelawadee\",\"sans-serif\";color:gray'>o</span>
                                                </b>
                                                <b>
                                                    <span style='font-size:8.0pt;font-family:\"Leelawadee\",\"sans-serif\";color:gray'>-o-o-o-o-o-o-o-o-o-o-o-o-o-o-o-o-o-o-o-o-o-o-o-o-o-o-o-o</span>
                                                </b>
                                                <span style='font-size:8.0pt;font-family:\"Leelawadee\",\"sans-serif\"'>
                                                    <o:p></o:p>
                                                </span>
                                            </p>
                                            <p class=MsoNormal>
                                                <b>
                                                    <span lang=TH style='font-size:14.0pt;font-family:\"Leelawadee UI\",\"sans-serif\";color:#31849B'>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</span>
                                                </b>
                                                <b>
                                                    <span lang=TH style='font-size:12.0pt;font-family:\"Leelawadee UI\",\"sans-serif\";color:#E36C0A'>สหภาพ โพธิคำ (ฟีฟ่า)</span>
                                                </b>
                                                <span lang=TH></span>
                                                <b>
                                                    <span style='font-size:12.0pt;font-family:\"Leelawadee UI\",\"sans-serif\";color:#E36C0A'>
                                                        <o:p></o:p>
                                                    </span>
                                                </b>
                                            </p>
                                            <p class=MsoNormal>
                                                <b>
                                                    <span style='font-family:\"Leelawadee UI\",\"sans-serif\";color:#31849B'>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;E-Mail&nbsp;&nbsp; :&nbsp;&nbsp; 
                                                        <a href=\"mailto:sahapab.p@jasmine.com\">sahapab.p@jasmine.com</a>
                                                        <o:p></o:p>
                                                    </span>
                                                </b>
                                            </p>
                                            <p class=MsoNormal>
                                                <b>
                                                    <span style='font-family:\"Leelawadee UI\",\"sans-serif\";color:#31849B'>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</span>
                                                </b>
                                                <b>
                                                    <span style='font-family:\"Leelawadee UI\",\"sans-serif\";color:#E36C0A'>&nbsp;Tel.&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; :&nbsp;&nbsp; 02-100-8965 
                                                        <o:p></o:p>
                                                    </span>
                                                </b>
                                            </p>
                                            <p class=MsoNormal>
                                                <b>
                                                    <span style='font-family:\"Leelawadee UI\",\"sans-serif\";color:#31849B'>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Triple T Broadband PCL. [9th Floor] 
                                                        <o:p></o:p>
                                                    </span>
                                                </b>
                                            </p>
                                            <p class=MsoNormal>
                                                <b>
                                                    <span style='font-size:8.0pt;font-family:\"Leelawadee\",\"sans-serif\";color:gray'>o-o-o-o-o-o-o-o-o-o-o-o-o-o-o-o-o-o-o-o-o-o-o-o-o-o-o-o-o</span>
                                                </b>
                                                <b>
                                                    <span style='color:gray'>
                                                        <o:p></o:p>
                                                    </span>
                                                </b>
                                            </p>
                                            <p class=MsoNormal>
                                                <o:p>&nbsp;</o:p>
                                            </p>
                                        </div>
                                    </body>
                                </html>";
  return $string;
}

?>