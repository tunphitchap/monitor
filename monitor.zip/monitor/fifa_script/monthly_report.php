<?php
	echo "MONTHLY REPORT FOR EZ COPY PASTE EIEI!!<br>";
	$month='2018-04';
?>

<?php
	echo "<b><font face='Century Gothic'>NAT444: Subscriber Byte Usage (Download) : ".date("M",strtotime($month))."' ".date("y",strtotime($month))."</font></b><br><br>";
	echo "จำนวนลูกค้า 3BB-NAT ที่มีการ Online ทั้งหมด 	  1,306,021 ราย  (-11,134)<br>";
  	echo "รวมการใช้งานทั้งหมด 		 	  198,789  TB. (-3,126)<br>";
  	echo "เฉลี่ยการใช้งาน 			  	  152.21 GB. ต่อราย  (-1.09)<br>";
?>

<?
define( '_VALID_ACCESS', 1 );
session_start();

//	if( $_SESSION['ses_status'] != 3 ){
//		header("Location:_execlogout.php");
//		exit;
//	}
include("../library/lib_t_view.php");
$dtime = new DT();
#Create Obj
$dbObj = new DBConn;
$msObj = new MS( $dbObj );

#Table Name
//	$_CONFIG[ONLINEAPPLY] = "customer_ratio";
//	$_CONFIG[INSTALLADDR] = "installation_address ";

//Get Parameter.
$status_id = trim( mosGetParam( $_FORM, 'status_id', ''  ));
$status_id = (!empty($status_id))? $status_id : "99";
$sdate = trim( mosGetParam( $_FORM, 'sdate', ''  ));
$class_attribute = trim( mosGetParam( $_FORM, 'class_attribute', ''  ));
$percent = trim( mosGetParam( $_FORM, 'percent', ''  ));
$approved = trim( mosGetParam( $_FORM, 'approved', ''  ));
$action2	= trim( mosGetParam( $_FORM, 'action2', '' ));
//if ($sdate !='') {
   //$d_datime = $dtime->GetDateComp($sdate." ".$stime,$time=1);

//}
// $cb1 = "unchecked";
if(isset($_POST['approved'])) { $cb1 = "checked"; }
//echo "pppppppppppp".isset($_POST['approved'])."oooooo".$cb1;
//	$approved = (!empty($approved))? $approved : "N";

$keyword = trim( mosGetParam( $_FORM, 'keyword', ''  ));
$action	= trim( mosGetParam( $_FORM, 'action', '' ));
$id = $_FORM['id'];
$mode ='';
if(!isset($_POST['mode'])){
	$mode = 1;
}else {
	$mode = $_POST['mode'];
}


#####//Set Show Page ////////////////////////////////////////////////////////
$limit = '40';		// How many results should be shown at a time
$scroll = '30'; 	// How many elements to the record bar are shown at a time

$display = (!isset ($_GET['show']) || $_GET['show']==0)? 1 : $_GET['show'];
if( !empty( $userkey ) )
$display = 1;
$start = (($display * $limit) - $limit);
#####/////////////////////////////////////////////////////////////////////////




 if($_POST['day4']==!""){
 $day2=$_POST["day4"];"</br>";
 $mode=substr("$day2", 10);
 $d_datime =substr("$day2",0,10);
  $sdate =substr("$day2",0,10);
 $dayy = date('d F Y',strtotime($day3));
 $table = $_POST['mode'];
}

// $dayy = date('d F Y',strtotime($day2));

//if  ($sdate == ""){
//   $sdate = date("j/m/Y");
//}
//Take Action


//	if(isset($_POST['approved']) &&
//	$_POST['approved'] == 'Yes')
//	{
//	    echo "Need wheelchair access.";
//	}
///	else
//	{
//	    echo "Do not Need wheelchair access.";
//	}
//=======================================================
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">
<html>
   <head>
      <title>Allot Application</title>
      <link rel="stylesheet" type="text/css" href="../includes/style_menu.css"/>
         <link rel="stylesheet" type="text/css" href="../icons/iconpacks/icons.css"/>
            <script type="text/javascript" src="../includes/BlockToggle.js"></script>
            <meta http-equiv="Content-Type" content="text/html; charset=utf-8"/>
               <link rel="stylesheet" type="text/css" href="../themes/classic/theme.css"/>
                  <script language="javaScript" type="text/javascript" src="../includes/calendar.js"></script>
                  <script language="javaScript" type="text/javascript" src="../includes/checkdate.js"></script>
                  <link href="../includes/calendar.css" rel="stylesheet" type="text/css">
                     <link rel="stylesheet" type="text/css" href="../grid/gt_grid.css" />
                        <link rel="stylesheet" type="text/css" href="../grid/skin/vista/skinstyle.css" />
                           <script type="text/javascript" src="../grid/gt_msg_en.js"></script>
                           <script type="text/javascript" src="../grid/gt_grid_all.js"></script>

                           <script type="text/javascript" src="../grid/calendar/calendar.js"></script>
                           <script type="text/javascript" src="../grid/calendar/calendar-setup.js"></script>
                           <script type="text/javascript" src="../grid/xml2json.js"></script>
                           <script type="text/javascript" src="../grid/gt_const.js"></script>
                           <!--<style type="text/css">

                           .style1 {color: #999900}
                           .style2 {color: #CC9900}

                           </style>-->
                           <!--<style type="text/css">
                           <!--
                           .panelContent {
                           background: #f8f8f8;
                           overflow: hidden;
                           position: relative;
                           }
                           .panelContentContainer {
                           border : 1px solid #4f4f4f;
                           clear:both;
                           }
                           .panelheader {
                           height: 2em;
                           color : black;
                           font-weight : normal;
                           background: #E0E8FA;
                           float: left;
                           margin-left: 1px;
                           margin-right: 1px;
                           margin-bottom: 0px;
                           margin-top: 0.3em;
                           text-align: center;
                           white-space:nowrap;
                           overflow:hidden;
                           width: 20%;
                           }
                           #tabsExample {
                           width: 900px;
                           }
                           body,td,th {
                           font-family: Tahoma;
                           font-size: 10px;
                           }
                           -->

                           <!---------------------------------------------------------------------->
                           <script type="text/javascript" >

                              var grid_demo_id = "myGrid1" ;
                              var grid_details_id = "myGrid2";

                              var dsConfig = {

                                 fields :[
                                 {name : 'sum_mbps' },
                                 {name : 'fdate' },
                                 {name : 'end_numcount'},
                                 //{name : 'percentage' },
                                 {name : 'sum_bandwidth' },
                                 // initValue : function(record){
                                 //				//return (((record['sum_bandwidth'] *300)/8)/1000000).toFixed(2);
                                 //				return ((record['sum_bandwidth'] )/1000000).toFixed(2);
                                 //			}
                                 //			},
                                 {name : 'percentage_DL'  },
                                 //{name : 'numcount_bt'  },
                                 {name : 'numcount_bt' ,
                                    initValue : function(record){
                                       return (record['start_numcount'])+' - '+(record['end_numcount']);
                                    }
                                 },
                                 {name : 'sum_bandwidth_bt'} ,
                                 //###################################
                                 {name : 'min_bandwidth'} ,
                                 //###################################

                                 //initValue : function(record){
                                 //				//return (((record['sum_bandwidth_bt'] *300)/8)/1000000).toFixed(2);
                                 //				return ((record['sum_bandwidth_bt'] )/1000000).toFixed(2);
                                 //			}
                                 //			},
                                 {name : 'bandwidth_per_cs'} ,
                                 {name : 'sum_bandwidth_g'} ,
                                 {name : 'percentage_g'} ,
                                 //initValue : function(record){
                                 //				//return (((record['bandwidth_per_cs'] *300)/8)/1000).toFixed(2);
                                 //				return ((record['bandwidth_per_cs'] )/1000).toFixed(2);
                                 //			}
                                 //			},
                                 //{name : 'Mbps' },
                                 //initValue : function(record){
                                 //				//return (((record['bandwidth_per_cs'] *300)/8)/1000).toFixed(2);
                                 //				return ((record['bandwidth_per_cs'] )*8/3/60/60).toFixed(2);
                                 //			}
                                 //			}
                                 //		{name : 'customer'  },
                                 //		{name : 'order2005' ,type: 'float' },
                                 //		{name : 'order2006' ,type: 'float' },
                                 //		{name : 'order2007' ,type: 'float' },
                                 //		{name : 'order2008' ,type: 'float' },
                                 //				{name : 'aaaa' ,type: 'float' },
                                 //						{name : 'cccc' ,type: 'float' },
                                 //		{name : 'delivery_date' ,type:'date'  }

                                 ],
                                 recordType : 'object'
                              }

                              var dsConfigDetails = {
                                 uniqueField : 'no' ,
                                 fields :[
                                 {name : 'from_date' },
                                 {name : 'subscriber' },
                                 {name : 'Mbps' },


                                 {name : 'Mbytes' }	,
                                 {name : 'ibyt' }
                                 //{name : 'Kbps' ,
                                 //	     initValue : function(record){
                                 //				//return (record['in_bandwidth']*300/24/60/60).toFixed(2);
                                 //				return (record['in_bandwidth']*8/3/60/60).toFixed(2);
                                 //			}
                                 //			},
                                 //		{name : 'Mbytes' ,
                                 //	     initValue : function(record){
                                 //				//return (((record['in_bandwidth'] *300)/8)/1000).toFixed(2);
                                 //				return ((record['in_bandwidth'] )/1000).toFixed(2);
                                 //			}
                                 //			},
                                 //		{name : 'Gbytes' ,
                                 //	     initValue : function(record){
                                 //				//return (((record['in_bandwidth'] *300)/8)/1000000).toFixed(2);
                                 //				return ((record['in_bandwidth'] )/1000000).toFixed(2);
                                 //			}
                                 //			}

                                 //		{name : 'customer'  },
                                 //		{name : 'order2005' ,type: 'float' },
                                 //		{name : 'order2006' ,type: 'float' },
                                 //		{name : 'order2007' ,type: 'float' },
                                 //		{name : 'order2008' ,type: 'float' },
                                 //				{name : 'aaaa' ,type: 'float' },
                                 //						{name : 'cccc' ,type: 'float' },
                                 //		{name : 'delivery_date' ,type:'date'  }

                                 ]
                                 //	recordType : 'array'
                              }

                              var colsConfig = [
                              {id: 'fdate' , header: "fdate" , width :80 ,headAlign: "center" ,align: "center"},
                              {id: 'end_numcount' , header: "end_numcount" , width :85 ,headAlign: "center",align: "right"},
                              {id: 'percentage' , header: "percentage" , width :65 ,headAlign: "center" ,align: "right"},
                              {id: 'sum_bandwidth' , header: "sum_bandwidth" , width :67  ,headAlign: "center",align: "right"},
                              <!--	 			renderer : function(value ,record,columnObj,grid,colNo,rowNo){ -->
                              <!--				   return   record['sum_bandwidth'];  ->
                              <!--				   }  -->
                              <!--{id: 'sum_mbps' , header: "Mbps" , width :80 ,inChart :true, chartColor : '99bb88',headAlign: "center" ,align: "right"} ,-->

                              {id: 'percentage_DL' , header: "percentage_dl" , width :55 ,inChart :true, chartColor : 'eecc99',headAlign: "center" ,align: "right"},
                              {id: 'numcount_bt' , header: "numcount_bt" , width :120 ,inChart :true, chartColor : '99bb88',headAlign: "center" ,align: "right"},
                              {id: 'sum_bandwidth_bt' , header: "sum_bandwidth_bt" , width :65 ,inChart :true, chartColor : '77aa33' ,headAlign: "center",align: "right"},
                              {id: 'min_bandwidth' , header: "min_bandwidth" , width :65 ,inChart :true, chartColor : '77aa33' ,headAlign: "center",align: "right"},

                              <!--  	 			renderer : function(value ,record,columnObj,grid,colNo,rowNo){  -->
                                 <!--				   return   record['sum_bandwidth_bt'];   -->
                              <!--				   } -->

                              {id: 'bandwidth_per_cs' , header: "bandwidth_per_cs (bandwidth)" , width :65 ,inChart :true, chartColor : '99bb88',headAlign: "center",align: "right" }   ,

                              <!--ping-->
                              {id: 'sum_bandwidth_g' , header: "bandwidth_per_cs (bandwidth)" , width :60 ,inChart :true, chartColor : '99bb88',headAlign: "center",align: "right" }   ,
                              {id: 'percentage_g' , header: "bandwidth_per_cs (bandwidth)" , width :60 ,inChart :true, chartColor : '99bb88',headAlign: "center",align: "right" }   ,

                              <!--{id: 'Mbps' , header: "Mbps" , width :80 ,inChart :true, chartColor : '99bb88',headAlign: "center" ,align: "right"}-->


                              ];




                              var colsConfigDetails = [
                              {id: 'from_date' , header: "Date" , width :250,align:'center',headAlign: "center" },
                              {id: 'subscriber', header: "Subscriber" , width :200,align:'left',headAlign: "center" ,renderer : function(value ,record,columnObj,grid,colNo,rowNo){
                                 return '<a target=blank href="../views/t_netflow_search_sub.php?subscriber2=' + value + '&edate2=<?=$sdate?>&tt=1">' + value + ' </a>';
                              }
                           },

                           {id: 'ibyt2' , header: "MB" , width :100,headAlign: "center",align: "right"},
                           {id: 'ibyt3' , header: "Byte" , width :120,headAlign: "center",align: "right"},
                           {id: 'Mbps' , header: "Mbps" , width :95,headAlign: "center",align: "right"}
                           ];

                           function masterCompleted(grid){
                              var colObj=grid.columnMap['country'];
                              colObj.group();

                           }




                           var gridConfig={
                              id : grid_demo_id,
                              loadURL : "../controller/Controller_nat444_ratio_view.php?sdate='<?=$d_datime ?>'&class_attribute=<?=$class_attribute?>&mode=<?=$mode?>&table=<?=$table?>",
                              exportURL : "../export_php/rep_ratio_nex.php?export=true&sdate='<?=$d_datime ?>'",
                              exportFileName : 'test_export_doc',
                              width: "800",  //"100%", // 700,
                              height: "320",  //"100%", // 330,
                              container : 'gridbox',
                              replaceContainer : true,
                              SigmaGridPath : '../../grid/',
                              encoding : 'UTF-8', // Sigma.$encoding(),
                              customHead : 'myHead',
                              dataset : dsConfig ,
                              columns : colsConfig ,
                              onCellClick  : function(value, record , cell, row,  colNO, rowNO,columnObj,grid){
                              var no = record["numcount_bt"];
                              var end_numcount = record["end_numcount"];
                              var start_numcount = record["start_numcount"];
                              mygridDetails.loadURL = "../controller/Controller_nat444_ratio_view_detail.php?sdate='<?=$d_datime?>'&pageNo=<?=$display?>&class_attribute=<?=$class_attribute?>&end_numcount="+ end_numcount+"&start_numcount="+ start_numcount;
                              mygridDetails.exportURL = "../export_php/rep_ratio_nex_detail.php?export=true&sdate='<?=$d_datime?>'&pageNo=<?=$display?>&end_numcount="+ end_numcount;

                              mygridDetails.render();
                              mygridDetails.reload();
                              },
                              pageSize:20,
                              pageSizeList : [5,10,15,20],
                              toolbarContent : 'nav | goto | pagesize |reload state'

                              };


                              var gridConfigDetails={
                              id : "grid_details_id",

                              exportURL : "./export_php/report_excel_sum_details.php?export=true&sdate='<?=$d_datime?>'&subscriber=<?=$subscriber?>&pageNo=<?=$display?>&numcount=",
                              exportFileName : 'test_export_doc',
                              dataset : dsConfigDetails ,
                              columns : colsConfigDetails ,
                              width: "800",  //"100%", // 700,
                              height: "300",  //"100%", // 330,
                              container : 'gridboxDetails',
                              replaceContainer : true,
                              toolbarPosition : 'bottom',

                              pageSize:20,
                              pageSizeList : [5,10,15,20],
                              toolbarContent : 'nav | goto | pagesize | xls |reload state',
                              beforeSave : function(reqParam){

                              },
                              showGridMenu : true,
                              allowCustomSkin : true,
                              allowFreeze : true,
                              allowGroup : true,
                              allowHide : true,
                              remotePaging : true,
                              autoLoad : false

                              };


                              var mygrid=new Sigma.Grid( gridConfig );
                              var mygridDetails = new Sigma.Grid(gridConfigDetails);

                              /*Sigma.Utils.onLoad( function(){
                              mygrid.render();
                              mygrid.reload();
                              } );
                              Sigma.Utils.onLoad( function(){
                              mygridDetails.render();
                              mygridDetails.reload();
                              } ); */
                              Sigma.Util.onLoad( Sigma.Grid.render(mygrid) );
                              Sigma.Util.onLoad( Sigma.Grid.render(mygridDetails) );
                              //////////////////////////////////////////////////////////

                           </script>
                           <style type="text/css">
                              <!--
                              body {
                                 background-color: #ffffff;
                              }
                              -->
                           </style></head>
                           <script language="JavaScript">
                              <!--

                              function MM_goToURL() { //v3.0
                                 var i, args=MM_goToURL.arguments; document.MM_returnValue = false;
                                 for (i=0; i<(args.length-1); i+=2) eval(args[i]+".location='"+args[i+1]+"'");
                              }

                              function MM_openBrWindow(theURL,winName,features) { //v2.0
                                 window.open(theURL,winName,features);
                              }


                              function setValue() {
                                 if(document.forms[0].approved.checked) document.forms[0].approved.value = "Yes"
                                 else document.forms[0].approved.value = "No"


                                 }

                                 function doFilter() {

                                    var filterInfo=[
                                    {
                                       fieldName : "percentage",
                                       logic : "startWith",
                                       value : Sigma.Util.getValue("f_value1")
                                    }
                                    ]
                                    //	alert(filterInfo);
                                    var grid=Sigma.$grid("myGrid1");
                                    var rowNOs=grid.applyFilter(filterInfo);

                                 }

                                 //-->
                              </script>

                              <!-- Logo & Bar  -->



                              <? include "../includes/calender.html" ?>



                              <div id="gsNavBar" class="gcBorder1">
                                 <div class="gbBreadCrumb">
                                    <div class="block-core-BreadCrumb">Bandwidth Ratio NAT444 >> Bandwidth Ratio NAT444 Download

                                    </div>
                                 </div>
                              </div>
                              <br>
                              <? $sql = "select fdate,remark  from customer_ratio_radius_nat444   group by remark,fdate order by fdate desc ";
                               $result = mysql_query($sql);  ?>
                                 <form action="nat444_radius_ratio_view.php" name = allot method="post" id="siteAdminForm" enctype="application/x-www-form-urlencoded">
                                    <fieldset><legend>Bandwidth Ratio NAT444 Download: online ต่อเนื่องในแต่ละวัน </legend>
                                       <table >
                                          <tr>
                                             <br /><td ><strong> From Date :</strong></td>
                                                <td  ><!-- <input type="text" name="sdate" id="sdate"   value="<?=$sdate ?>" onkeyup="beginchk(this,event)" />
                                                   <a href="#" onclick="setYears(1947, <?php echo date("Y")+1; ?>);
                                                      showCalender(this, 'sdate');"> <img src="../images/iconCalendar.gif" alt="" align="bottom" /></a> -->
                                           <select name="day4">
<?while($row = mysql_fetch_array($result))
  {
$day = $row[0];
$remark = $row[1];
$remarkk = $row[0]."".$row[1];

 ?>

          <option value="<?php echo $day;echo $remark;?>"<?php if($day2 == $remarkk){ echo "selected='selected'";}?>><?php echo $day; ?>--><?php echo $remark; ?></option>

<? }?>
 </select><input type="hidden" name="remarkk" value='<?=$remark; ?>'><td >
                                            </td>

                                                      <td ><strong> Select Mode :</strong></td>
                                                      <td>
                                                      	<select id="mode" name="mode">
										<option value="1"<?php if($table == 1){ echo "selected='selected'";}?>>5 -> 100 %</option>
										<option value="2"<?php if($table == 2){ echo "selected='selected'";}?>>10 -> 100 %</option>
														</select>
                                                      </td>
                                                      <td>
                                                         <input type="submit" name="action2" id="action2" value="OK" />
                                                      </td>
                                                      </p>
                                                   </div><td><?php

if($mode=="day")
{		echo $ramak2="ข้อมูลรายวัน";
}else if($mode=="week")
{		echo $ramak2="ข้อมูลรายสัปดาห์";
}else if($mode=="month")
{		echo $ramak2="ข้อมูลรายเดือน";
}
/////////////////////////////////////////////////////////////////////////////////////
													  ?></td>
                                         </tr>
                                             </table>
                                          </fieldset>
                                          <table width="100%" border="0" >
                                             <tr>
                                                <td width="800" bgcolor="<?php echo $bgcolor ; ?>"><p>
                                                   <label> </label>
                                                </p>
                                                <table id="myHead" >
                                                   <tr>
                                                      <td rowspan="2" columnId='fdate' ALIGN="center" resizable='false'>วันที่</td>
                                                      <td colspan="2" ALIGN="center">ลูกค้า</td>
                                                      <td colspan="2" ALIGN="center">จำนวน Bytes สะสม</td>
                                                      <td colspan="4" ALIGN="center">เรียงลำดับลูกค้าตามข้อมูล Download (Byte Count)</td>
                                                      <td colspan="2" ALIGN="center">Bytes per Group</td>

          </tr>
                                                   <tr>
                                                      <td columnId='end_numcount'ALIGN="center">จำนวนลูกค้า</td>
                                                      <td columnId='percentage'ALIGN="center">สัดส่วน(%)</td>

                                                      <td columnId='sum_bandwidth'ALIGN="center">TB</td>
                                                      <!--<td columnId='sum_mbps'ALIGN="center">Mbps</td>-->
                                                      <td columnId='percentage_DL'ALIGN="center">%สะสม</td>

                                                      <td columnId='numcount_bt'ALIGN="center">รายที่</td>
                                                      <td columnId='sum_bandwidth_bt'ALIGN="center">Max (GB)</td>
                                                      <td columnId='min_bandwidth'ALIGN="center">Min (GB)</td>

                                                      <td columnId='bandwidth_per_cs'ALIGN="center">Avg. (GB)</td>

                                                      <!--ping-->
                                                      <td columnId='sum_bandwidth_g'ALIGN="center">TB</td>
                                                      <td columnId='percentage_g'ALIGN="center">%/Group</td>

                                                      <!--<td columnId='bandwidth_per_cs'ALIGN="center">Mbps</td>-->
												</tr>

                                                </table>


                                                <div id="bigbox" style="margin:1px;display:!none;">
                                                   <div id="gridbox" style="border:0px solid #cccccc;background-color:#f3f3f3;padding:5px;height:400px;width:800px;" ></div>
                                                </div>
																	    <script type="text/javascript" src="../chart/FusionCharts.js"></script>

<!-- ------------------------------------------------- Code BOSS ------------------------------------------------- -->
<?php
	if ($sdate != '') {
		$month_select = date('Y-m',strtotime($sdate));
		$month_before = date('Y-m',strtotime($sdate . "-1 month"));

		$sql=mysql_query(" SELECT fdate, start_numcount
			, FORMAT(end_numcount,0) end_numcount
			, percentage
			, FORMAT((sum_bandwidth/1000000000000),0) sum_bandwidth
			, '-' as sum_mbps
			, percentage_DL percentage_DL
			, FORMAT((sum_bandwidth_bt/1000000000),2) sum_bandwidth_bt
			, FORMAT(min_bandwidth/1000000000,2) min_bandwidth
			, FORMAT(bandwidth_per_cs/1000000000,2) bandwidth_per_cs
			, '-' as Mbps
			, FORMAT(sum_bandwidth_g/1000000000000,0) sum_bandwidth_g
			, percentage_g
			From customer_ratio_radius_nat444
			Where date_format(fdate,'%Y-%m') in ('$month_select','$month_before')
				And remark = '$mode'
				And percentage = 100
			order by fdate
			limit 2");

		$num_rows = mysql_num_rows($sql);
		$cnt_loop = 0;

		if ($num_rows == 2) {
			while ($result=mysql_fetch_array($sql)) {
				$num_end_numcount[$cnt_loop] = $result["end_numcount"];
				$num_end_numcount[$cnt_loop] = intval(str_replace(",","",$num_end_numcount[$cnt_loop]));
				$num_sum_bandwidth[$cnt_loop] = $result["sum_bandwidth"];
				$num_sum_bandwidth[$cnt_loop] = intval(str_replace(",","",$num_sum_bandwidth[$cnt_loop]));
			  $text_fdate = $result["fdate"];
				$cnt_loop++;
			}
		}
		else if ($num_rows == 1) {
			while ($result=mysql_fetch_array($sql)) {
				$num_end_numcount[1] = $result["end_numcount"];
				$num_end_numcount[1] = intval(str_replace(",","",$num_end_numcount[1]));
				$num_sum_bandwidth[1] = $result["sum_bandwidth"];
				$num_sum_bandwidth[1] = intval(str_replace(",","",$num_sum_bandwidth[1]));
			  $text_fdate = $result["fdate"];
			}
		}

		for ($i=0; $i < 2; $i++) {
			$num_end_numcount[$i] = isset($num_end_numcount[$i]) ? $num_end_numcount[$i] : 0;
		}

			$result_end_numcount = $num_end_numcount[1] - $num_end_numcount[0];
			$result_sum_bandwidth = $num_sum_bandwidth[1] - $num_sum_bandwidth[0];

			$result_avg_bandwidth[0] = ((($num_sum_bandwidth[0] / $num_end_numcount[0]) *100) *10);
			$result_avg_bandwidth[1] = ((($num_sum_bandwidth[1] / $num_end_numcount[1]) *100) *10);

			$all_result_avg_bandwidth = $result_avg_bandwidth[1] - $result_avg_bandwidth[0];

			if ($result_end_numcount >= 0) {
				$color_end_numcount = "#009900";
				$add_text_end_numcount = "เพิ่มขึ้น";
			}
			else {
				$color_end_numcount = "#ff0000";
				$add_text_end_numcount = "ลดลง";
			}

			if ($result_sum_bandwidth >= 0) {
				$color_sum_bandwidth = "#009900";
				$add_text_sum_bandwidth = "เพิ่มขึ้น";
			}
			else {
				$color_sum_bandwidth = "#ff0000";
				$add_text_sum_bandwidth = "ลดลง";
			}

			if ($all_result_avg_bandwidth >= 0) {
				$color_avg_bandwidth = "#009900";
				$add_text_avg_bandwidth = "เพิ่มขึ้น";
			}
			else {
				$color_avg_bandwidth = "#ff0000";
				$add_text_avg_bandwidth = "ลดลง";
			}

			?>
			<fieldset>
				<!-- <legend></legend> -->
				<label> - จำนวนลูกค้า 3BB-NAT ที่มีการ Online ทั้งหมด <?php echo number_format($num_end_numcount[1]); ?> ราย <font color="<?php echo $color_end_numcount; ?>">(โดย<?php echo $add_text_end_numcount; ?> <?php echo number_format(ABS($result_end_numcount)); ?> ราย)</font></label><br>
				<label> - รวมปริมาณการใช้งานทั้งหมด <?php echo number_format($num_sum_bandwidth[1]); ?> TB. <font color="<?php echo $color_sum_bandwidth; ?>">(โดย<?php echo $add_text_sum_bandwidth; ?> <?php echo number_format(ABS($result_sum_bandwidth)); ?> TB.)</font></label><br>
				<label> - เฉลี่ยการใช้งานคิดเป็น <?php echo number_format($result_avg_bandwidth[1],2); ?> GB. ต่อราย <font color="<?php echo $color_avg_bandwidth; ?>">(โดย<?php echo $add_text_avg_bandwidth; ?> <?php echo number_format(ABS($all_result_avg_bandwidth),2); ?> GB.)</font></label><br>
			</fieldset>
			<?php
	}
	else {
		$month_select = '';
		$month_before = '';
	}



?>

<!-- ------------------------------------------------- Code BOSS ------------------------------------------------- -->

              <table width="100%" height="100%"><tr width="100%" height="100%"><td width="100%" height="100%">
							<div align="center" id="chartContainer1" width="80%">FusionCharts will load here!</div></td></tr>
							</table>



<script>
	  var myChart1 = new FusionCharts( "../chart/MSCombiDY2D.swf",
      "myChartId", "100%", "400", "0", "1" );
      myChart1.setXMLUrl("../controller/Controller_nat444_ratio_table.php?day=<?echo $d_datime;?>&mode=<?echo $mode;?>&table=<? echo $table; ?>");
	  myChart1.setTransparent(true);
      myChart1.render("chartContainer1");
</script>
                                                <p>&nbsp;</p>
                                                <div id="bigboxDetails" style="margin:1px;display:!none;">
                                                   <div id="gridboxDetails" style="border:0px solid #cccccc;background-color:#f3f3f3;padding:5px;height:250px;width:700px;" ></div>
                                                </div>
                                             </td>
                                          </tr>
                                       </table>

                                    </div>
                                    <div id="gsContent" class="gbBlock giWarning">
                                       <h3><font size="2" face="Tahoma">
                                          <!-- Page : start -->
                                          <?
                                          if(!empty($sdate)){
                                             $qrySel1 = "select count(*) as cnt from customer_ratio_nex where fdate ='$d_datime' ";
                                          }
                                          $handle = mysql_query($qrySel1);
                                          $_numrows = mysql_fetch_object($handle);
                                          $numrows = $_numrows->cnt;

                                          $display = (!isset ($_GET['show']))? 1 : $_GET['show'];
                                          $_self = $_SERVER['PHP_SELF'];

                                          if(empty($action2)) {
                                             $numrows =0;
                                          }
                                          $paging = ceil ($numrows / $limit);
                                          if ($display > 1) {
                                             $previous = $display - 1;
                                             printf("<a href=\"%s?show=1&status_id=%s&keyword=%s&sdate=%s\"><img src=\"icons/images/i.p.firstpg.gif\" border=0></a> ", $_self, $status_id, $keyword,$sdate);
                                             printf("<a href=\"%s?show=%s&status_id=%s&keyword=%s&sdate=%s\"><img src=\"icons/images/i.p.prevpg.gif\" border=0></a> ", $_self, $previous, $status_id, $keyword,$sdate);
                                          }

                                          if ($numrows != $limit) {
                                             if ($paging > $scroll) {											// remove this to get rid of the scroll feature
                                                $first = $_GET['show'];
                                                $last = ($scroll - 1) + $_GET['show'];
                                             } else {
                                                $first = 1;
                                                $last = $paging;
                                             }// REMOVE THIS TO GET RID OF THE SCROLL FEATURE
                                             if ($last > $paging ) {
                                                $first = $paging - ($scroll - 1);
                                                $last = $paging;
                                             }

                                             for ($i = $first;$i <= $last;$i++){
                                                if ($display == $i)
                                                echo "[<b><font color=#000000>$i</font></b>]";
                                                else
                                                printf("[<a href=\"%s?show=%s&status_id=%s&keyword=%s&sdate=%s\">%s</a>]", $_self, $i, $status_id, $keyword, $sdate,$i);
                                             }
                                          }

                                          if ($display < $paging) {
                                             $next = $display + 1;
                                             printf(" <a href=\"%s?show=%s&status_id=%s&keyword=%s&sdate=%s\"><img src=\"icons/images/i.p.nextpg.gif\" border=0></a>", $_self, $next, $status_id, $keyword,$sdate);
                                             printf(" <a href=\"%s?show=%s&status_id=%s&keyword=%s&sdate=%s\"><img src=\"icons/images/i.p.lastpg.gif\" border=0></a>", $_self, $paging, $status_id, $keyword,$sdate);
                                          }
                                          ?>
                                          <!-- Page : end  -->
                                       </font></h3>
                                    </div>

                                 </div></td>
                              </tr>
                           </table>
                           <!-- /Main Table -->

                        </form>
                     </div>

                  </body>
               </html>
               <?
               $dbObj->disconn();
               unset( $msObj );
               unset( $dbObj );

               ?>
