<html>
<?php
    // Connect To DB.208
    $con = mysqli_connect("10.11.11.208","root","password");
    if (!$con) {
    die("Database connection failed: " . mysqli_error());
    }

    $db_select = mysqli_select_db($con, "hw_interface");
    if (!$db_select) {
        die("Database selection failed: " . mysqli_error());
    }
    mysqli_set_charset( $con, 'utf8');
?>

    <head>
    <style>
        table, th, td {
        border: 1px solid black;
        border-collapse: collapse;
    }
    th {
        width: 25%;  /* only for demo, not really required */
        background-image: linear-gradient(to right, rgba(0, 150, 0, 1) 0%, rgba(0, 175, 0, 1) 17%, rgba(0, 190, 0, 1) 33%, rgba(82, 210, 82, 1) 67%, rgba(131, 230, 131, 1) 83%, rgba(180, 221, 180, 1) 100%);  /* your gradient */
        background-repeat: no-repeat;  /* don't remove */
    }
th.negative {
  background-image: linear-gradient(to left, rgba(0, 150, 0, 1) 0%, rgba(0, 175, 0, 1) 17%, rgba(0, 190, 0, 1) 33%, rgba(82, 210, 82, 1) 67%, rgba(131, 230, 131, 1) 83%, rgba(180, 221, 180, 1) 100%);  /* your gradient */
  background-position: 100% 100%;
}  

    </style>
</head>
<body>

<?php echo "<b>*****Link Config Not Map Contract (Compare with ".$_REQUEST['percentage']." % of similar.)*****</b><br><br>";?>

<?php 
	if(isset($_REQUEST['percentage']))
		$input_percent=$_REQUEST['percentage'];
	else
		$input_percent=85;
?>

<form action="" method="get">
    <b>Compare Percentage:</b> <input type="text" value="<?php echo $input_percent;?>" name="percentage" />&nbsp;<input type="submit" value="Submit" />
</form>


<?php 
    if(isset($_REQUEST['percentage'])){

    $percent=$_REQUEST['percentage'];
    $count=0;

    $not_map_counter=0;
    $sql_not_map_contract=mysqli_query($con,"SELECT DISTINCT c.id,c.hw_type,c.cid, c.node, c.capacity, c.ifHighSpeed, c.fullport, c.destination, c.dest_node, c.provider, c.dest_sub_group, c.port_status, c.protocal 
        FROM tbl_hw_config c 
        WHERE 1 AND c.walk='Y' AND c.cid!='' AND c.port_status = 'up' and c.dest_group='1' 
        AND c.cid NOT IN (select circuit_no from tbl_contract_circuit) 
        ORDER BY c.dest_sub_group DESC, c.node,cast(c.slot AS unsigned),cast(c.port AS unsigned);");

    //echo "<b>CID Not Map Contract:</b><br><br>"; // Create Table

    echo "<table><tr><td align='center' bgcolor='yellow'><b>No.</b></td><td align='center' bgcolor='#2EFEF7'><b>CID Not Map Contract</b></td><td align='center' bgcolor='#F781F3'><b>Compare With</b></td><td align='center' bgcolor='lime'><b>Contract ID</b></td><td align='center' bgcolor='red'><b>Contract No.</b></td><td align='center' bgcolor='#FE9A2E'><b>Percent of Similar</b></td></tr>";

    while($result_not_map_contract=mysqli_fetch_array($sql_not_map_contract)){
        $not_map_counter++;
        //echo "[".$not_map_counter."] ".$result_not_map_contract['cid']."<br>";
        compare_not_map_cid($result_not_map_contract['cid']);
    }

    }   // END IF 

    echo "</table>";

?>

<?php 
    function compare_not_map_cid($cid_not_map) {
        $sql_all_contract=mysqli_query($GLOBALS['con'],"SELECT circuit_no, cont_id FROM tbl_contract_circuit;");
        while($result_all_contract=mysqli_fetch_array($sql_all_contract)){
            $conpare_percent=compare($cid_not_map,$result_all_contract['circuit_no']);
            if($conpare_percent>=$GLOBALS['percent']){
                $GLOBALS['count']++;

                
                ////////// GET CONT_NO //////////
                $sql_cont_no=mysqli_query($GLOBALS['con'],"SELECT cont_no FROM tbl_contract WHERE cont_id='".$result_all_contract['cont_id']."' LIMIT 1;");
                $result_cont_no=mysqli_fetch_array($sql_cont_no);
                $contract_no=$result_cont_no['cont_no'];
                ////////// END GET CONT_NO //////////

                echo "<tr><td align='center'>".$GLOBALS['count']."</td><td>&nbsp;&nbsp;&nbsp;".$cid_not_map."&nbsp;&nbsp;&nbsp;</td><td>&nbsp;&nbsp;&nbsp;"
                .$result_all_contract['circuit_no']."&nbsp;&nbsp;&nbsp;</td><td align='center'>".$result_all_contract['cont_id']."</td><td align='center'>".$contract_no."</td><th style='background-size: ".$conpare_percent."% 100%'>".$conpare_percent." %</th></tr>";
            }
        }
    }

    function compare($cid1, $cid2) {
        $cid1 = trim(strtolower($cid1));
        $cid2 = trim(strtolower($cid2));
        similar_text($cid1, $cid2, $percentage);
        $formated_percents = number_format($percentage);
    return $formated_percents; 
    }
?>

</body>
</html>