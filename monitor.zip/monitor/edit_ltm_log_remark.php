<meta charset="UTF-8">
<?php
include "connect208.php";
 $hourchk=$_POST['hourchk'];
 $timechk=$_POST['timechk'];
 $datechk=$_POST['datechk'];
 $hosting=$_POST['hosting'];
 $txtremark=$_POST['txtremark'];
 $status=$_POST['statuschk'];

$query_chkre=mysqli_query($con,"select count(*) cnt from f5_ltm_log_remark where date_remark='".$datechk."' and host='".$hosting."' and status='".$status."' and time_hour LIKE '".$hourchk.":%'");
$rowchk=mysqli_fetch_array($query_chkre);
if($rowchk['cnt']==0)
{
$query_insert=mysqli_query($con,"INSERT INTO f5_ltm_log_remark (date_remark,time_hour,data_remark,host,status) VALUES ('$datechk','$timechk','$txtremark','$hosting','$status')");
}
else
{
$query_update=mysqli_query($con,"UPDATE f5_ltm_log_remark SET data_remark='$txtremark' where date_remark='$datechk' and host='$hosting' and status='$status' and time_hour LIKE '$hourchk:%'");
}
echo "<script>alert('บันทึกข้อมูลเรียบร้อย');window.close();window.opener.location.reload();</script>";
?>