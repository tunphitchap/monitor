
<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta name="description" content="">
    <meta name="author" content="">
    <link rel="icon" href="../../favicon.ico">

    <title>Log Monitor</title>

    <?php include("import_lib.php"); ?>
    <link href="css/navbar-top-fixed.css" rel="stylesheet">
  </head>

    <!-- Custom styles for this template -->
  
  </head>
<!-- start chart ltm log -->
<?php
  date_default_timezone_set('Asia/Bangkok');
  include "connect208.php";

if($_GET['date'] != ""){
	$date_from = $_GET['date'];
	$day = $_GET['date']; 
}else{
	$date_from = date("Y-m-d"); 
	$day = date("Y-m-d"); 
}



$start = date("Y-m-d"); ;
$from = date('m-d-Y',strtotime($today . "-1 days"));



for($h=0;$h<24;$h++){
if ($h < 10){
   $time .=  "'".$day." 0".$h."',";
}else {
   $time .=  "'".$day." ".$h."',";
}


}


// start f5 113 


$sql=mysql_query("select date_format(datetime,'%Y-%m-%d %H') as date,COUNT(*) as cnt from f5_ltm_log where host ='10.11.11.113' and date_format(datetime,'%Y-%m-%d')  = '$date_from' and ltmlog like '%down%' GROUP BY date_format(datetime,'%Y-%m-%d %H')");
while ($rsyear=mysql_fetch_array($sql)) {
    $a_date = $rsyear["date"];
	$data_final[$a_date] = $rsyear["cnt"];

}


for($h=0;$h<24;$h++){
if ($h < 10){
   
    $chk = $day." 0".$h;
    $data_chk = $data_final[$chk];
   if($data_chk != 0)
	{
     //echo $data_chk;
	 $data_end .=  "$data_chk,";
	}else
	{
	$data_end .=  "null,";
	}
}else {
      $chk = $day." ".$h;
    $data_chk = $data_final[$chk];
   if($data_chk != 0)
	{
     //echo $data_chk;
	 $data_end .=  "$data_chk,";
	}else
	{
	$data_end .=  "null,";
	}
}
}

//end f5 113

//start f5 114
$sql_114=mysql_query("select date_format(datetime,'%Y-%m-%d %H') as date,COUNT(*) as cnt from f5_ltm_log where host ='10.11.11.114' and date_format(datetime,'%Y-%m-%d') = '$date_from' and ltmlog like '%down%' GROUP BY date_format(datetime,'%Y-%m-%d %H')");
while ($rsyear_114=mysql_fetch_array($sql_114)) {
    $a_date_114 = $rsyear_114["date"];
	$data_final_114[$a_date_114] = $rsyear_114["cnt"];

}


for($j=0;$j<24;$j++){

if ($j < 10){
   
    $chk_114 = $day." 0".$h;
    $data_chk_114 = $data_final_114[$chk_114];
   if($data_chk_114 != 0)
	{
     //echo $data_chk_114;
	 $data_end_114 .=  "$data_chk_114,";
	}else
	{
	$data_end_114 .=  "null,";
	}
}else {
      $chk_114 = $day." ".$j;
    $data_chk_114 = $data_final_114[$chk_114];
   if($data_chk_114 != 0)
	{
     //echo $data_chk_114;
	 $data_end_114 .=  "$data_chk_114,";
	}else
	{
	$data_end_114 .=  "null,";
	}
}
}
//end f5 114




////QUERY SHOW REAMRK/////

$query_remark=mysql_query("SELECT data_remark_113,data_remark_114 FROM f5_ltm_log_remark where date_remark='".$date_from."'");
$row_remark=mysql_fetch_array($query_remark);
////QUERY SHOW REAMRK/////

 ?>

    <script src="js/jquery-3.1.1.min.js"></script>
<script src="code/highcharts.js"></script>
<script src="code/modules/exporting.js"></script>
<!-- end chart ltm log  -->
  <body>

<?php include("menu_top.php");?>


 <div class="container">
<!-- start from -->

	<div class="col-lg-12 col-sm-offset-3">
		<h3><button type="button" class="btn btn-danger">F5</button><button type="button" class="btn btn-primary">LTM LOG</button>
		</h3>
	</div>
    <form action="f5_ltm_log_hour.php" method='get' class="form-inline"  role="form">   
     
				<div class="col-md-7 col-sm-offset-1">
				<div class="form-group">
					<label for="dtp_input1" class="col-md-/ control-label">วันที่</label>
					<div class="input-group date form_datetime col-md-4" data-date="" data-date-format="yyyy-mm-dd" data-link-field="dtp_input1">
						<input name='date' class="form-control" size="7" type="text" value="<?php if($_GET['date']!=""){echo $_GET['date'];}else {echo $day;}?>" readonly>
						<span class="input-group-addon"><span class="glyphicon glyphicon-calendar"><i class="fa fa-th" aria-hidden="true"></i></span></span>
					</div>	 
					<button type="submit" class="btn btn-default">SEARCH</button>
            </div>
			</div>
    </form>

<!-- end from -->
 
<div id="container" style="min-width: auto; height: 380px; margin: 0 auto"></div>
<div class="clearfix">
<h4>Remark</h4>
</div>
<form action="f5_ltm_log_hour.php" method='post'>
<input type="hidden" value="<?php echo $date_from;?>" name="date_remark"> 
<div class="col-md-12 col-sm-12">
  <div class="row">
      <div class="col-md-6 col-sm-6">
      <label>LTM LOG 113</label>
        <div class="clearfix" style="width:100%">
           <!--  <textarea class="form-control" cols="30" rows="5" name="txtremark_113">
              <?php if(!empty($row_remark[0])){ echo $row_remark[0];}?>
            </textarea> -->
            <textarea class="form-control" rows="7" name="txtremark_113"><?php echo $row_remark[0];?></textarea>
        </div>
      </div>
       <div class="col-md-6 col-sm-6">
       <label>LTM LOG 114</label>
        <div class="clearfix" style="width:100%">
        <textarea class="form-control" rows="7" name="txtremark_114"><?php echo $row_remark[1];?></textarea>
          <!--   <textarea class="form-control" cols="30" rows="5" name="txtremark_114">
              <?php if(!empty($row_remark[1])){ echo $row_remark[1];}?>
            </textarea> -->
        </div>
      </div>
    </div>
  </div>
<div class="clearfix" align="center">
<input type="submit" value="SUBMIT" name="remark" class="form-control btn btn-primary" style="margin-top: 1%;width: 10%">

</div>
</form>
</br>
</br>
<div class="clearfix"></div>
<!--start table ltm log -->


<?php
$perpage = 20;
 if (isset($_GET['page'])) {
 $page = $_GET['page'];
 } else {
 $page = 1;
 }
 $start = ($page - 1) * $perpage;

$sql=mysql_query("select * from f5_ltm_log where host ='10.11.11.113' and date_format(datetime,'%Y-%m-%d')  = '$date_from' order by datetime desc limit {$start} , {$perpage}");
while ($rsyear=mysql_fetch_array($sql)) {
    $datetime[] = $rsyear["datetime"];
	$ltmlog[] = $rsyear["ltmlog"];
	$ltmhost[] = $rsyear["host"];

}
echo "<table class='table'>
  <thead>
    <tr>
      <th>#</th>
      <th>Datetime</th>
      <th>LTM Log</th>
      <th>Host</th>
    </tr>
  </thead>
  <tbody>";
for($i=0;$i<count($ltmlog);$i++){
echo"
    <tr>
      <th scope='row'>".($i+1)."</th>
      <td>".$datetime[$i]."</td>
      <td>".$ltmlog[$i]."</td>
      <td>".$ltmhost[$i]."</td>
    </tr>


";
}
echo "  </tbody></table>";


$query2=mysql_query("select * from f5_ltm_log where host ='10.11.11.113' and date_format(datetime,'%Y-%m-%d')  = '$date_from' ");
 $total_record = mysql_num_rows($query2);
 $total_page = ceil($total_record / $perpage);

?>

<nav aria-label="Page navigation example">
  <ul class="pagination">
 <li class="page-item">
 <a class="page-link" href="f5_ltm_log_hour.php?date=<?php echo $date_from;?>&&page=1" aria-label="Previous">
 <span aria-hidden="true">&laquo;</span>
 </a>
 </li>
 <?php for($i=1;$i<=$total_page;$i++){ ?>
 <li class="page-item"><a class="page-link" href="f5_ltm_log_hour.php?date=<?php echo $date_from;?>&&page=<?php echo $i; ?>"><?php echo $i; ?></a></li>
 <?php } ?>
<li class="page-item">
 <a class="page-link" href="f5_ltm_log_hour.php?date=<?php echo $date_from;?>&&page=<?php echo $total_page;?>" aria-label="Next">
 <span aria-hidden="true">&raquo;</span>
 </a>
 </li>
 </ul>
 </nav>
<!--end table ltm log -->

</div>

<!-- jQuery first, then Tether, then Bootstrap JS. -->
<script src="js/bootstrap.min2.js" integrity="sha384-vBWWzlZJ8ea9aCX4pEW3rVHjgjt7zpkNpZk+02D9phzyeVkE+jo0ieGizqPLForn" crossorigin="anonymous"></script>


<!-- start chart ltm log -->
<script type="text/javascript">

Highcharts.chart('container', {
    chart: {
        type: 'column'
    },
    title: {
        text: 'F5  LTM LOG'
    },
    subtitle: {
        text: 'F5 LTM LOG (DOWN) วันที่  <?=$date_from;?> ของแต่ละชั่วโมง'
    },
    xAxis: {
        categories: [<?php echo $time; ?>
        ],
        crosshair: true
    },
    yAxis: {
        min: 0,
        title: {
            text: 'counter'
        }
    },
    tooltip: {
        headerFormat: '<span style="font-size:10px">{point.key}</span><table>',
        pointFormat: '<tr><td style="color:{series.color};padding:0">{series.name}: </td>' +
            '<td style="padding:0"><b>{point.y:.0f}</b></td></tr>',
        footerFormat: '</table>',
        shared: true,
        useHTML: true
    },
    plotOptions: {
        column: {
            pointPadding: 0.2,
            borderWidth: 0
        }
    },
    series: [{
        name: 'F5-113 (LTM)',
        data: [<?php echo $data_end;?>]

    },{
        name: 'F5-114(LTM)',
        data: [<?php echo $data_end_114;?>]

    }]
});
		</script>
		<!-- end chart ltm log -->


		<script type="text/javascript" src="js/bootstrap-datetimepicker.js" charset="UTF-8"></script>

<script type="text/javascript">
    $('.form_datetime').datetimepicker({
        //language:  'fr',
      weekStart: 1,
        todayBtn:  1,
		autoclose: 1,
		todayHighlight: 1,
		startView: 2,
		minView: 2,
		forceParse: 0,
        showMeridian: 1
    });

</script>
  </body>


<?php
if(!empty($_POST['remark']))
{
 
  $datere=$_POST['date_remark'];
  $dataremark_113=$_POST['txtremark_113']; 
  $dataremark_114=$_POST['txtremark_114']; 
 // $datare=str_replace("\n", "<br>\n", $_POST['txtremark']);

$query_chk=mysql_query("select count(*) as cnt_chk from f5_ltm_log_remark where date_remark='".$datere."'");
$row_chk=mysql_fetch_array($query_chk);

if(($row_chk[0])>0)
{
  $query_update=mysql_query("UPDATE f5_ltm_log_remark SET data_remark_113='".$dataremark_113."',data_remark_114='".$dataremark_114."' where date_remark='".$_POST['date_remark']."'");
}
else
{
  $query_insert=mysql_query("INSERT INTO f5_ltm_log_remark (date_remark,data_remark_113,data_remark_114) VALUES ('$datere','$dataremark_113','$dataremark_114')");
}
    echo "<script>alert('บันทึกข้อมูลเรียบร้อย');window.location='f5_ltm_log_hour.php?date=".$_POST['date_remark']."'</script>";

}


?>
</html>
