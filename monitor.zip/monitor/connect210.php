<?php  
	$con2 = mysqli_connect("10.11.11.210","conrag","pbwC8gQmCy28RBRU");

	if (!$con2) {
    die("Database connection failed: " . mysqli_error());
	}

	$db_select = mysqli_select_db($con2, "con_rag");
	if (!$db_select) {
    	die("Database selection failed: " . mysqli_error());
	}
	mysqli_set_charset( $con2, 'utf8');
?>
