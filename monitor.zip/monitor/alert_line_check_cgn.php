<?php
date_default_timezone_set('Asia/Bangkok');
include "connect210.php";
include "connect208.php";


$con_nat444 = mysqli_connect($servername, $username, $password, $dbname);

?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta name="description" content="">
    <meta name="author" content="">
    <link rel="icon" href="../../favicon.ico">

    <title>Radius-Monitor</title>

</head>


<body>

 <?php
 $content='Log%20Collector%20by%20CGNaod';
 $check=0;
 			$date_from_onday=date('Y-m-d',strtotime('-1 day'));

 			$date_from=date('Y-m-d');
 		    $query_cgn = mysqli_query($con_nat444,"select cgn from daily_check_cgn 
			where date_format(dateoper,'%Y-%m-%d %H:%i')='".$date_from_onday." 06:00' 
			and type = 'all' and cgn != ''
			group by cgn 
			order by cgn*1");
			while($result_cgn=mysqli_fetch_array($query_cgn))
			{
				$v_cgn[]=$result_cgn['cgn'];
			}

			$query_data_collector = mysqli_query($con_nat444,"select collector,cgn from daily_check_cgn 
			where date_format(dateoper,'%Y-%m-%d %H:%i')='".$date_from." 06:00' 
			and type = 'all' and cgn != ''
			group by collector,cgn 
			order by collector,cgn*1;
			");
			while($result_data_collector=mysqli_fetch_array($query_data_collector))
			{
				$v_data_collector[$result_data_collector['collector']][$result_data_collector['cgn']]=$result_data_collector['cgn'];
			}

			$query_collector=mysqli_query($con_nat444,"select collector,
			case 
				when collector='72' then '4'
				when collector='93' then '1'
				when collector='94' then '2' 
				when collector='95' then '3' 
			else collector 
			end sortcol 
			from daily_check_cgn 
			where date_format(dateoper,'%Y-%m-%d %H:%i')='".$date_from." 06:00' 
			and type = 'all' and cgn != ''
			group by collector 
			order by sortcol");
			while($result_collector=mysqli_fetch_array($query_collector))
			{
				$v_collector[]=$result_collector['collector'];
			}

			for($i=0;$i<count($v_collector);$i++)
			{
				// echo "Collector => ".$v_collector[$i]."<br>";

					for($j=0;$j<count($v_cgn);$j++)
					{
						if(!empty($v_data_collector[$v_collector[$i]][$v_cgn[$j]]))
						{
							// echo "CGN => ".$v_data_collector[$v_collector[$i]][$v_cgn[$j]]."<br>";
						}
						else
						{
							if($v_collector[$i]!= '72' && $v_data_collector[$v_collector[$i]][$v_cgn[$j]] = 'devname="A'){
								// echo $v_collector[$i].'|'.$v_data_collector[$v_collector[$i]][$v_cgn[$j]].'<br>';
							}
							else{
							$check++;
							// echo "CGN ".$v_cgn[$j]."=> no Data <br>";
							$content.="ไม่มีข้อมูลของ Collector%20:%20".$v_collector[$i]."%20(%20CGN-".$v_cgn[$j]."%20)aod";
							}
							
						}
						
					}
			}

// echo $content;
if($check)
{
// exec("curl http://10.11.11.180/aodalert/AlertRadius.php?content=".$content."");
file_get_contents("http://10.11.30.157/alert_radius/AlertRadius.php?content=".$content."");
// file_get_contents("http://10.11.30.157/alert_radius/AlertDeveloper.php?content=".$content."");
}

 ?>
</body>

</html>