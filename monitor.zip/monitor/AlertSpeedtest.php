<?php
date_default_timezone_set('Asia/Bangkok');
$connect1=mysql_connect("10.11.13.202","speedtest","3bbSpeedTest");
mysql_select_db("speedtest",$connect1);
mysql_query("SET CHARACTER SET utf8",$connect1);

?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta name="description" content="">
    <meta name="author" content="">
    <link rel="icon" href="../../favicon.ico">

    <title>Radius-Monitor</title>

</head>


<body>

 <?php
 $content="ตรวจสอบข้อมูล%20Speedtest%20(Ookla,nPerf)%20ย้อนหลัง%201%20วันaod";
 $check=0;
 // $content='Chec%20Collector%20by%20CGNaod';
 	$date_from_onday=date('Y-m-d',strtotime('-1 day'));

 	$query_nperf=mysql_query("select count(*) cnt from logs_nperf 
	where date_format(timestamps,'%Y-%m-%d')='".$date_from_onday."'",$connect1);
	$result_nperf=mysql_fetch_array($query_nperf);


	$query_ookla=mysql_query("select count(*) cnt from logs_net 
	where date_format(timestamps,'%Y-%m-%d')='".$date_from_onday."'",$connect1);
	$result_ookla=mysql_fetch_array($query_ookla);

	if($result_ookla['cnt']>0)
	{
		
	}
	else
	{
		$check++;
		$content.="Ookla%20:%20ไม่มีข้อมูลaod";
	}

	if($result_nperf['cnt']>0)
	{
		
	}
	else
	{
		$check++;
		$content.="nPerf%20:%20ไม่มีข้อมูลaod";
	}

if($check>0)
{
	// echo "true";
	file_get_contents("http://10.11.11.180/aodalert/AlertRadius.php?content=".$content."");
}

 ?>
</body>

</html>