<?php 
	include('navbar.php');
	include('db_connect.php');

	$db_select = mysqli_select_db($con_nat, "nat444");
	if (!$db_select) {
    	die("Database selection failed: " . mysqli_error());
	}
	mysqli_set_charset( $con_nat, 'utf8');

	// Get CGN-NO from summary_user_ip_bras //
	$cgn_no=array();
	$query=mysqli_query($con_nat,"select bras_ip,cgn from summary_user_ip_bras");
	while($result=mysqli_fetch_array($query)){
		$cgn_no[$result['bras_ip']]=$result['cgn'];
	}


	$db_select = mysqli_select_db($con_radiusinfo, "radiusinfo");
	if (!$db_select) {
    	die("Database selection failed: " . mysqli_error());
	}
	mysqli_set_charset( $con_radiusinfo, 'utf8');

	$bras_list=array();


	// CHANGE QOS LIST HERE!!!!! //
	//$qos_profile_list=array('100_100','200_200','300_300','500_500');

	$qos_profile_list=array();
	$q_list="100_100,200_200";
	if(isset($_POST['qos_list'])){
		$qos_profile_list=explode(',', $_POST['qos_list']);
		$q_list=$_POST['qos_list'];
	}

	$qos_list_str='';
	foreach ($qos_profile_list as $qos_profile){
		$qos_list_str.=$qos_profile.',';
	}
	$qos_list_str=substr(trim($qos_list_str), 0, -1);



	$bras_ip=array();
	$bras_ro=array();
	$query=mysqli_query($con_radiusinfo,"select ro,name_ro,IP from tb_bras where status='on' order by ro,name_ro");
	while($result=mysqli_fetch_array($query)){
		array_push($bras_list,$result['name_ro']);
		$bras_ip[$result['name_ro']]=$result['IP'];
		$bras_ro[$result['name_ro']]=$result['ro'];
    }

?>
<style type="text/css">
	textarea{
	    height: 100%;
	    width: 100%;
	   -webkit-box-sizing: border-box; /* Safari/Chrome, other WebKit */
	    -moz-box-sizing: border-box;    /* Firefox, other Gecko */
	    box-sizing: border-box;         /* Opera/IE 8+ */
	    background: url(http://i.imgur.com/2cOaJ.png);
		background-attachment: local;
		background-repeat: no-repeat;
		padding-left: 35px;
		padding-top: 10px;
		    border-color:#ccc;
	}
		.tableFixHead          { overflow-y: auto; height: 100px; }
.tableFixHead thead th { position: sticky; top: 0; }

	#table-wrapper {
  position:relative;
}
#table-scroll {
  height:415px;
  overflow:auto;  
  margin-top:0px;
}
#table-wrapper table {
  width:100%;
    
}
/* Just common table stuff. Really. */
th, td { padding: 1px 1px; }
th     { background:#eee; }
.table-condensed{
  font-size: 11px;
  font-family: Tahoma;
}
</style>

<script type="text/javascript">
	function substring_word(result,word){
		var start = "["+word+"]";
		var end = "[/"+word+"]";
		return result.substring(result.indexOf(start)+start.length, result.indexOf(end))
	}
	function get_qos(qos_profile,bras_name,ip_bras){
		document.getElementById('td_'+bras_name+'_'+qos_profile).innerText = "Wait...";
		$.ajax({url: "read_bras.php?fn=disp_qos_profile&ip_bras="+ip_bras+"&qos_profile="+qos_profile, success: 
	    	function(result){
	      		document.getElementById('td_'+bras_name+'_'+qos_profile).innerText = substring_word(result,"Total users");
	    	},
			complete:function(){
		    	//get_qos("300_300",bras_name,ip_bras);
		   	}
   	 	});
	}
</script>

<div class="container-fluid">
	<div class="row">
		<form action="#" method="post">
			<div class="col-md-1"></div>
		    <div class="col-md-2 text-left"><button type="button" class="btn btn-success">QoS Profile Sum</button></div>
		    <div class="col-md-4 text-center">ใส่รายชื่อ QoS Profile ที่ต้องการแสดง โดยใช้ Comma คั่น เช่น "100_100,200_200" แล้วกด Submit <b>แล้วคลิ๊กที่ตารางเพื่อแสดงค่า</b></div>
		    <div class="col-md-3"><input type="text" class="form-control" id="qos_list" name="qos_list" value="<?=$q_list?>"></div>
		    <div class="col-md-1"><button type="submit" class="btn btn-primary">Submit</button></div>
		    <div class="col-md-1"></div>
		</form>
	</div>
	<br>
	<div class="row">
		<div class="col-md-1"></div>
		<div class="col-md-10">

			<?php if(isset($_POST['qos_list'])){ ?>
	<div id="table-wrapper">
  <div id="table-scroll">
    <table border=1 class="tableFixHead">
        <thead>
            <tr>
                <th class="text-center">RO</th>
		        <th class="text-center">BRAS Name</th>
		        <th class="text-center">BRAS IP</th>
		        <th class="text-center">CGN</th>
		        <?php foreach ($qos_profile_list as $qos_profile){ ?>
		        <th class="text-center"><?=$qos_profile?></th>
		        <?php } ?>
            </tr>
        </thead>
        <tbody>
        		<?php 
				foreach($bras_list as $bras){ ?>
					<tr>
						<td class="text-center"><?=$bras_ro[$bras]?></td>
						<td class="text-center"><?=$bras?></td>
						<td class="text-center"><?=$bras_ip[$bras]?></td>
						<?php if(isset($cgn_no[$bras_ip[$bras]]))
		      			echo "<td class='text-center'>".$cgn_no[$bras_ip[$bras]]."</td>";
		      		else
		      			echo "<td class='text-center'>-</td>"; 
		      		?>

		      		<?php foreach ($qos_profile_list as $qos_profile){ ?>
		      		<td class='text-center' onclick="get_qos('<?=$qos_profile?>','<?=$bras?>','<?=$bras_ip[$bras]?>');" id="td_<?=$bras?>_<?=$qos_profile?>"><span role="button">-</span></td>
					<?php } ?>

					</tr>
				<?php } ?> 	
        </tbody>
    </table>
  </div>
</div> <?php } 
			// END IF ISSET QOS_LIST
		?>
		</div>
		<!-- <div class="col-md-4 text-center">
	    	<textarea id="txt_area" name="txt_area" rows="20">
			</textarea>
	    </div> -->
	    <div class="col-md-1"></div>
	</div>
</div>

