<?php  
	// Connect To DB //
	$con_nat = mysqli_connect("10.11.11.208","nat","N6XZZ6FSv4gCKK9M");
	if (!$con_nat) {
    die("Database connection failed nat : " . mysqli_error());
	}

	$con_radiusinfo = mysqli_connect("10.11.11.208","radiusinfo","xm4nJLAgq8MvgaT2");
	if (!$con_radiusinfo) {
    die("Database connection failed radiusinfo : " . mysqli_error());
	}
?>

