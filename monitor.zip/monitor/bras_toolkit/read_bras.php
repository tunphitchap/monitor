<?php
 include('Net/SSH2.php');
 set_include_path(getcwd());
	$user_bras='nuttapto';
	$pass_bras='widy1al';
	$user_noa='nuttapto';
	$pass_noa='widy1al';

 $ssh = new Net_SSH2('10.10.19.30');
 if (!$ssh->login($user_noa, $pass_noa)) {
     exit('Login Failed');
 }

 $ip_bras=$_GET['ip_bras'];




function get_value($raw_output,$word,$next_word){
	$value_pos=strrpos($raw_output,$word,0)+strlen($word);
	$next_value_pos=strrpos($raw_output,$next_word,$value_pos);
	return (int) filter_var(substr($raw_output,$value_pos,$next_value_pos-$value_pos), FILTER_SANITIZE_NUMBER_INT);
}

// DISPLAY ACCESS-USER
if($_GET['fn']=='disp_access_user'){
	 // LOGIN TO BRAS //
	 $ssh->write("telnet ".$ip_bras."\n");
	 $ssh->write($user_bras."\n");
	 $ssh->read('Password:');
	 $ssh->write($pass_bras."\n");
	 $ssh->setTimeout(2);

	 $ssh->write("disp access-user\n");
	 $ssh->write(" ");
	 $ssh->write(" ");
	 $ssh->write(" ");
	 $ssh->write(" ");
	 $raw_output=strval($ssh->read());
	 $ssh->write("quit");
	 $ssh->write("exit");

	$word_sequence=array('Total users','IPv4 users','IPv6 users','Dual-Stack users','Lac users','RUI local users','RUI remote users','Wait authen-ack','Authentication success','Accounting ready','Accounting state','Wait leaving-flow-query','Wait accounting-start','Wait accounting-stop','Wait authorization-client','Wait authorization-server','Domain-name');
	for($i=0;$i<count($word_sequence)-1;$i++){
		echo "[".$word_sequence[$i]."]".get_value($raw_output,$word_sequence[$i],$word_sequence[$i+1])."[/".$word_sequence[$i]."]<br>";
	}
}
// DISPLAY ACCESS-USER    

if($_GET['fn']=='disp_qos_profile'){
			$ssh->write("telnet ".$ip_bras."\n");
			 $ssh->write($user_bras."\n");
			 $ssh->read('Password:');
			 $ssh->write($pass_bras."\n");
			 $ssh->setTimeout(2);

	//$qos_list=explode(",", $_GET['qos_profile']);

	//foreach($qos_list as $qos){
		$ssh->write("disp access-user qos-profile ".$_GET['qos_profile']." sum\n");
	//}

	$raw_output=strval($ssh->read());
	//$raw_output_arr=explode("qos-profile", $raw_output);
	$ssh->write("quit");
	$ssh->write("exit");

	//echo $raw_output;

	$word_sequence=array('Total users','<');
		for($i=0;$i<count($word_sequence)-1;$i++){
			if (strpos($raw_output, 'Total users') != true) {
			    echo "[".$word_sequence[$i]."]0[/".$word_sequence[$i]."]<br>";
			}
			else{
				echo "[".$word_sequence[$i]."]".get_value($raw_output,$word_sequence[$i],$word_sequence[$i+1])."[/".$word_sequence[$i]."]<br>";
			}
	}
}

if($_GET['fn']=='authen_none'){
			 $ssh->write("telnet ".$ip_bras."\n");
			 $ssh->write($user_bras."\n");
			 $ssh->read('Password:');
			 $ssh->write($pass_bras."\n");
			 $ssh->setTimeout(1);

		$ssh->write("disp access-user authen-method none | Exclude @ji\n");
		$raw_output=strval($ssh->read());
		$total_string="";
		if(strpos($raw_output, 'No online user') == false){
					while(strpos($raw_output, 'RUI Local users') == false) {
					    $ssh->write(" ");
					    $raw_output.=strval($ssh->read());
					}
					$raw_output=substr($raw_output, strpos($raw_output,"Access type"));
					$data_arr=explode(" ", $raw_output);
					foreach($data_arr as $user_detail){
						if(strpos($user_detail, '@') == true){
							$total_string.=$user_detail."<br>";	
							//print_r(explode(" ", $user_detail))	;
						}
					}
		}

	
	
	
	
	if($total_string=="")
		echo "No User.";
	else
		echo $total_string;

	$ssh->write("quit");
	$ssh->write("exit");

}



?>
