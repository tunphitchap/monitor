<?php 
	include('navbar.php');
	include('db_connect.php');

	$db_select = mysqli_select_db($con_nat, "nat444");
	if (!$db_select) {
    	die("Database selection failed: " . mysqli_error());
	}
	mysqli_set_charset( $con_nat, 'utf8');

	// Get CGN-NO from summary_user_ip_bras //
	$cgn_no=array();
	$query=mysqli_query($con_nat,"select bras_ip,cgn from summary_user_ip_bras");
	while($result=mysqli_fetch_array($query)){
		$cgn_no[$result['bras_ip']]=$result['cgn'];
	}


	$db_select = mysqli_select_db($con_radiusinfo, "radiusinfo");
	if (!$db_select) {
    	die("Database selection failed: " . mysqli_error());
	}
	mysqli_set_charset( $con_radiusinfo, 'utf8');

	$bras_list=array();
	$bras_ip=array();
	$bras_ro=array();
	$word_sequence=array('Total users','IPv4 users','IPv6 users','Dual-Stack users','Lac users','RUI local users','RUI remote users','Wait authen-ack','Authentication success','Accounting ready','Accounting state','Wait leaving-flow-query','Wait accounting-start','Wait accounting-stop','Wait authorization-client','Wait authorization-server','Domain-name');

	$query=mysqli_query($con_radiusinfo,"select ro,name_ro,IP,model from tb_bras where status='on' order by ro,name_ro");
	while($result=mysqli_fetch_array($query)){
		array_push($bras_list,$result['name_ro']);
		$bras_ip[$result['name_ro']]=$result['IP'];
		$bras_ro[$result['name_ro']]=$result['ro'];
		$bras_model[$result['name_ro']]=$result['model'];
    }

?>	

<style type="text/css">
	.tableFixHead          { overflow-y: auto; height: 100px; }
.tableFixHead thead th { position: sticky; top: 0; }

/* Just common table stuff. Really. */
table  { border-collapse: collapse; width: 100%; }
th, td { padding: 1px 1px; }
th     { background:#eee; }
.table-condensed{
  font-size: 11px;
  font-family: Tahoma;
}

</style>

<script>
	function substring_word(result,word){
		var start = "["+word+"]";
		var end = "[/"+word+"]";
		return result.substring(result.indexOf(start)+start.length, result.indexOf(end))
	}
	function get_bras_result(bras_name,ip_bras){
	    $.ajax({url: "read_bras.php?fn=disp_access_user&ip_bras="+ip_bras, success: 
	    	function(result){
	      		$("#"+bras_name+"_Total_users").html(substring_word(result,"Total users"));
	      		$("#"+bras_name+"_IPv4_users").html(substring_word(result,"IPv4 users"));
	      		$("#"+bras_name+"_IPv6_users").html(substring_word(result,"IPv6 users"));
	      		$("#"+bras_name+"_Dual-Stack_users").html(substring_word(result,"Dual-Stack users"));
	      		$("#"+bras_name+"_Lac_users").html(substring_word(result,"Lac users"));
	      		$("#"+bras_name+"_RUI_local_users").html(substring_word(result,"RUI local users"));
	      		$("#"+bras_name+"_RUI_remote_users").html(substring_word(result,"RUI remote users"));
	      		$("#"+bras_name+"_Wait_authen-ack").html(substring_word(result,"Wait authen-ack"));
	      		$("#"+bras_name+"_Authentication_success").html(substring_word(result,"Authentication success"));
	      		$("#"+bras_name+"_Accounting_ready").html(substring_word(result,"Accounting ready"));
	      		$("#"+bras_name+"_Accounting_state").html(substring_word(result,"Accounting state"));
	      		$("#"+bras_name+"_Wait_leaving-flow-query").html(substring_word(result,"Wait leaving-flow-query"));
	      		$("#"+bras_name+"_Wait_accounting-start").html(substring_word(result,"Wait accounting-start"));
	      		$("#"+bras_name+"_Wait_accounting-stop").html(substring_word(result,"Wait accounting-stop"));
	      		$("#"+bras_name+"_Wait_authorization-client").html(substring_word(result,"Wait authorization-client"));
	      		$("#"+bras_name+"_Wait_authorization-server").html(substring_word(result,"Wait authorization-server"));
	    	}
		});
	}
</script>

<div class="container-fluid">
	<div class="row">
		<div class="col-md-1"></div>
	    <div class="col-md-10 text-center"><button type="button" class="btn btn-primary">Display Access-User</button></div>
	    <div class="col-md-1"></div>
	</div>
	<br>
	<div class="row">
		<div class="col-md-12">
			<table class="table table-striped table-bordered tableFixHead table-condensed text-center">
		    <thead>
		      <tr>
		        <th class="text-center">RO</th>
		        <th class="text-center">BRAS Name</th>
		        <th class="text-center">BRAS IP</th>
			<th class="text-center">MODEL</th>
		        <th class="text-center">CGN</th>
		        <th class="text-center">^_^</th>
		        <?php 
		        	foreach($word_sequence as $word){
		        		if($word!=$word_sequence[count($word_sequence)-1])
		        			echo "<th class='text-center'>".$word."</th>";
		        	}
		        ?>
		      </tr>
		    </thead>
		    <tbody>
		      <?php
		      	foreach ($bras_list as $bras) {
		      		echo "<tr>";
		      		echo "<td>".$bras_ro[$bras]."</td>";
		      		echo "<td>".$bras."</td>";
		      		echo "<td>".$bras_ip[$bras]."</td>";
				echo "<td>".$bras_model[$bras]."</td>";
		      		if(isset($cgn_no[$bras_ip[$bras]]))
		      			echo "<td>".$cgn_no[$bras_ip[$bras]]."</td>";
		      		else
		      			echo "<td>-</td>";
		      		echo "<td><button onclick=\"get_bras_result('".$bras."','".$bras_ip[$bras]."');\">GET!</button></td>";
		      		//echo "<td id='".$bras."_totalusers' name='".$bras."_totalusers'>N/A</td>";

		        	foreach($word_sequence as $word){
		        		if($word!=$word_sequence[count($word_sequence)-1])
		        			echo "<td id='".$bras."_".str_replace(' ', '_', $word)."'>-</td>";
		        	}
		
		      		echo "</tr>";
		      		//echo "<script>get_bras_result('".$bras."','".$bras_ip[$bras]."');</script>";
		      		//echo "<script>get_bras_result('".$bras."');</script>"; // Call AJAX Function
		      	}
		      ?>    
		     </tbody>
		     </table>
		 </div>
	</div> 

</div>



</body>
</html>
