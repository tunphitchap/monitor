<?php 
	include('navbar.php');
	include('db_connect.php');

	$db_select = mysqli_select_db($con_nat, "nat444");
	if (!$db_select) {
    	die("Database selection failed: " . mysqli_error());
	}
	mysqli_set_charset( $con_nat, 'utf8');

	// Get CGN-NO from summary_user_ip_bras //
	$cgn_no=array();
	$query=mysqli_query($con_nat,"select bras_ip,cgn from summary_user_ip_bras");
	while($result=mysqli_fetch_array($query)){
		$cgn_no[$result['bras_ip']]=$result['cgn'];
	}


	$db_select = mysqli_select_db($con_radiusinfo, "radiusinfo");
	if (!$db_select) {
    	die("Database selection failed: " . mysqli_error());
	}
	mysqli_set_charset( $con_radiusinfo, 'utf8');

	$bras_list=array();
	$bras_ip=array();
	$bras_ro=array();
	$query=mysqli_query($con_radiusinfo,"select ro,name_ro,IP from tb_bras where status='on' order by ro,name_ro");
	while($result=mysqli_fetch_array($query)){
		array_push($bras_list,$result['name_ro']);
		$bras_ip[$result['name_ro']]=$result['IP'];
		$bras_ro[$result['name_ro']]=$result['ro'];
    }

?>
<style type="text/css">
	textarea{
	    height: 100%;
	    width: 100%;
	   -webkit-box-sizing: border-box; /* Safari/Chrome, other WebKit */
	    -moz-box-sizing: border-box;    /* Firefox, other Gecko */
	    box-sizing: border-box;         /* Opera/IE 8+ */
	    background: url(http://i.imgur.com/2cOaJ.png);
		background-attachment: local;
		background-repeat: no-repeat;
		padding-left: 35px;
		padding-top: 10px;
		    border-color:#ccc;
	}
		.tableFixHead          { overflow-y: auto; height: 100px; }
.tableFixHead thead th { position: sticky; top: 0; }

	#table-wrapper {
  position:relative;
}
#table-scroll {
  height:445px;
  overflow:auto;  
  margin-top:0px;
}
#table-wrapper table {
  width:100%;
    
}
/* Just common table stuff. Really. */
th, td { padding: 1px 1px; }
th     { background:#eee; }
.table-condensed{
  font-size: 11px;
  font-family: Tahoma;
}

</style>

<script type="text/javascript">
	function get_userlist(ip_bras,bras_name){
		document.getElementById('txt_area').value = "Wait...";
		document.getElementById('cnt_label').innerText = "[ BRAS: "+bras_name+" ("+ip_bras+") ]";
		$.ajax({url: "read_bras.php?fn=authen_none&ip_bras="+ip_bras, success: 
	    	function(result){
	    		var newline = String.fromCharCode(13, 10);
	      		document.getElementById('txt_area').value = result.replace(/<br>/g, "\n");
	    	},
			complete:function(){
		    	//get_qos("300_300",bras_name,ip_bras);
		   	}
   	 	});
	}
</script>

<div class="container-fluid">
	<div class="row">
		<div class="col-md-1"></div>
	    <div class="col-md-10 text-center"><button type="button" class="btn btn-danger">Authentication Method : NONE</button></div>
	    <div class="col-md-1"></div>
	</div>
	<br>
	<div class="row">
		<div class="col-md-1"></div>
		<div class="col-md-5">
			<div id="table-wrapper">
  <div id="table-scroll">
    <table border=1 class="tableFixHead">
        <thead>
            <tr>
                <th class="text-center">RO</th>
		        <th class="text-center">BRAS Name</th>
		        <th class="text-center">BRAS IP</th>
		        <th class="text-center">CGN</th>
		        <th class="text-center">^_^</th>
            </tr>
        </thead>
        <tbody>
        		<?php 
				foreach($bras_list as $bras){ ?>
					<tr>
						<td class="text-center"><?=$bras_ro[$bras]?></td>
						<td class="text-center"><?=$bras?></td>
						<td class="text-center"><?=$bras_ip[$bras]?></td>
						<?php if(isset($cgn_no[$bras_ip[$bras]]))
		      			echo "<td class='text-center'>".$cgn_no[$bras_ip[$bras]]."</td>";
		      		else
		      			echo "<td class='text-center'>-</td>"; ?>
		      		<td class='text-center'><button onclick="get_userlist('<?=$bras_ip[$bras]?>','<?=$bras?>');">GET!</button></td>
					</tr>
				<?php } ?> 	
        </tbody>
    </table>
  </div>
</div>
		</div>
	    <div class="col-md-5 text-center">
	    	<p id="cnt_label" name="cnt_label">[ BRAS: - ]</p>
	    	<textarea rows="20" id="txt_area" name="txt_area">
			</textarea>
	    </div>
	    <div class="col-md-1"></div>
	</div>
</div>

