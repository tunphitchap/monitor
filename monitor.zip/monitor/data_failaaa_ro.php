<?php
include "connect210.php";
date_default_timezone_set("Asia/Bangkok");
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Radius-Monitor</title>

    <?php include("import_lib.php"); ?>
    <link href="css/navbar-top-fixed.css" rel="stylesheet">

    <script src="js/jquery-3.1.1.min.js"></script>
    <script src="code/highcharts.js"></script>
    <script src="code/highcharts-3d.js"></script>
    <script src="code/modules/exporting.js"></script>

    <style type="text/css">
        .textAlignVer {
            font-size: 12px;
        }

        .textAlignVerRotate {
            display: block;
            -webkit-transform: rotate(-90deg);
            -moz-transform: rotate(-90deg);
            font-size: 12px;
        }

        a:hover {
            text-decoration: none;
        }
    </style>

    <style>
        .highcharts-container {
            overflow: visible !important;
        }

        .MyChartTooltip {
            position: relative;
            z-index: 50;
            border-radius: 5px;
            background-color: #ffffff;
            padding: 5px;
            font-size: 9pt;
            overflow: auto;
            height: 250px;
        }

        .highcharts-tooltip {
            pointer-events: all !important;
        }
    </style>

    <style type="text/css">
        @media (min-width: 768px) {
            .container {
                width: 500px;
            }
        }

        @media (min-width: 992px) {
            .container {
                width: 800px;
            }
        }

        @media (min-width: 1200px) {
            .container {
                width: 1300px;
            }
        }

        .form-inline {
            width: 1300px;
        }
    </style>
    <script>
        function changePeriod() {
            var data = document.getElementById('selectPeriod');
            var startDate = document.getElementById('startDate');
            var endDate = document.getElementById('endDate');
            if (data.value == 'Last_7_days') {
                startDate.value = "<?php echo date("Y-m-d", strtotime("-6 day")) ?>";
                endDate.value = "<?php echo date("Y-m-d") ?>";
            } else if (data.value == 'Last_Month') {
                startDate.value = "<?php echo date("Y-m-d", strtotime("-1 month")) ?>";
                endDate.value = "<?php echo date("Y-m-d") ?>";
            } else if (data.value == 'Previous_Month') {
                startDate.value = "<?php echo date("Y-m-t", strtotime("-2 month")); ?>";
                endDate.value = "<?php echo date("Y-m-t", strtotime("-1 month")); ?>";
            }
        }
    </script>
</head>

<body>
    <?php include "menu_top.php"; ?>
    <?php
    if (empty($_POST['selectPeriod'])) {
        $selectPeriod = "Custom";
    } else {
        $selectPeriod = $_POST['selectPeriod'];
    }

    if (!empty($_POST['start']) || !empty($_POST['end'])) {
        $start_date = $_POST['start'];
        $to_date =  $_POST['end'];
    } else {
        $start_date = date('Y-m-d', strtotime('-1 day'));
        $to_date = date('Y-m-d');
    }
    ?>

<div class="container">
<div class="col-md-12">
      <div style="line-height: 10px;">FAIL AAA > <font color="blue">FAIL AAA ACTIVE SUB</font></div>
    </div></div><br>

    <div class="container">
        <div class="row">
            <form action="data_failaaa_ro.php" method='post' class=" form-inline" role="form">

                <div align="left" class="col-lg-2">
                <!-- <button type="button" class="btn btn-danger">FAIL AAA</button> -->
                </div>

                <div>Start Date </div>
                <div class="input-group date form_datetime col-lg-2" data-date="" data-date-format="yyyy-mm-dd" data-link-field="dtp_input1">
                    <input name='start' class="form-control" id="startDate" size="7" type="text" value="<?php echo $start_date; ?>" readonly>
                    <span class="input-group-addon"><span class="glyphicon glyphicon-calendar"><i class="fa fa-th" aria-hidden="true"></i></span></span></div>

                <div>End Date </div>
                <div class="input-group date form_datetime col-lg-2" data-date="" data-date-format="yyyy-mm-dd" data-link-field="dtp_input1">
                    <input name='end' class="form-control" id="endDate" size="7" type="text" value="<?php
                                                                                                    echo $to_date; ?>" readonly>
                    <span class="input-group-addon"><span class="glyphicon glyphicon-calendar"><i class="fa fa-th" aria-hidden="true"></i></span></span></div>
                <div class="col-lg-3">
                    <select class="form-control" onchange="changePeriod()" name="selectPeriod" id="selectPeriod">
                        <option <?php if ($selectPeriod == "Custom") { ?> selected <?php } ?> value="Custom">Custom</option>
                        <option <?php if ($selectPeriod == "Last_7_days") { ?> selected <?php } ?> value="Last_7_days">Last 7 days</option>
                        <option <?php if ($selectPeriod == "Last_Month") { ?> selected <?php } ?> value="Last_Month">Last Month</option>
                        <option <?php if ($selectPeriod == "Previous_Month") { ?> selected <?php } ?> value="Previous_Month">Previous Month</option>
                    </select>
                    <button type="submit" class="btn btn-default col-lg-5">Submit</button>
                </div>
            </form>

        </div>
    </div>
    <br>

    <?php
    $sql_sum_data = mysqli_query($con2, "SELECT b.ro, sum(a.qty) as qty
        FROM FAILAAA a , map_ro b
        where SUBSTR(a.bras,1,3) = b.bras	
        and a.date between '" . $start_date . " 00:00:00'  and '" . $to_date . " 23:59:59'
        and (a.detail='ME60' or a.detail='ME5200')
        AND detail NOT LIKE '%COPY' AND detail not like 'ME60COPY'
        and a.type <> ''
        GROUP BY b.ro
        ORDER BY b.ro");

    $sum_qty = 0;
    $count_ro = 0;
    $max_qty = 0;
    while ($result = mysqli_fetch_array($sql_sum_data)) {
        $data[$result['ro']] = $result['qty'];
        $sum_qty += $result['qty'];
        $count_ro++;
        $ro[] = ro($result['ro']);
        // $date[] = date('Y-m',strtotime($result['date']));
        if($result['qty'] > $max_qty) { $max_qty = $result['qty']; }
    }
    // print_r($ro);
    // echo '<hr>';



    function ro($ro)
    {
        switch ($ro) {
            case '1':
                $name = 'RO1-CBI';
                break;
            case '2':
                $name = 'RO2-NMA';
                break;
            case '3':
                $name = 'RO3-KKN';
                break;
            case '4':
                $name = 'RO4-PLK';
                break;
            case '5':
                $name = 'RO5-CMI';
                break;
            case '6':
                $name = 'RO6-NPT';
                break;
            case '7':
                $name = 'RO7-SNI-PKT';
                break;
            case '8':
                $name = 'RO8-HYI';
                break;
            case '9':
                $name = 'RO9-AYA';
                break;
            case '10':
                $name = 'RO10-JAS';
                break;
            default;
                $name = 'Debug';
                break;
        }
        return $name;
    }

    // print_r($ro);
    $to_date_for_sql = date('Y-m-d', strtotime('-1 day' . $to_date));
    $sql_active_sub = mysqli_query($con2, "SELECT * FROM active_sub_by_ro
    WHERE DATE_FORMAT(FDATE,'%Y-%m-%d') = DATE_FORMAT('" . $to_date_for_sql . "' ,'%Y-%m-%d')
    ORDER BY RO ");

    $sum_data_active_sub = 0;
    while ($result = mysqli_fetch_array($sql_active_sub)) {
        $data_active_sub[$result['RO']] = $result['ACTIVE_SUB'];
        $sum_data_active_sub += $result['ACTIVE_SUB'];
        // $date[] = date('Y-m',strtotime($result['date']));
    }




    // foreach ($ro as $key_ro => $value_ro) {
    //     if (empty($data[$key_ro + 1])) {
    //         $data[$key_ro + 1] = 0;
    //     }
    // }

    $avg_fail = $sum_qty / $count_ro;
    $avg_per_last =  round(($sum_qty / $sum_data_active_sub) * 100, 2);
    // echo 'avg_per_last = ' . $avg_per_last;
    // print_r($data_active_sub);
    // print_r($data);

    $max_per = 0;
    foreach ($data as $key => $value) {
        # code...
        $avg_per[] =  round(($data[$key] / $data_active_sub[$key]) * 100, 2);
        $tmp_per = round(($data[$key] / $data_active_sub[$key]) * 100, 2);
        if($tmp_per > $max_per) { $max_per = $tmp_per; }
    }
    // echo $avg_fail;

    // print_r($data);
    // print_r($date_foreach);
    // echo '<br>';
    // print_r($avg_per);
    // print_r($data);

    ?>
        <div id="container" style="width: 1280px; height: 430px; margin: 0 auto">
            <script type="text/javascript">
                function uncheckGraph(chart) {
                    Highcharts.each(chart.series, function(p, i) {
                        p.hide()
                    });
                }

                function checkGraph(chart) {
                    Highcharts.each(chart.series, function(p, i) {
                        p.show()
                    });
                }

                function chartLine(chart) {
                    Highcharts.each(chart.series, function(p, i) {
                        p.update({
                            type: "line"
                        });
                    });
                }

                function chartColumn(chart) {
                    Highcharts.each(chart.series, function(p, i) {
                        p.update({
                            type: "column"
                        });
                    });
                }
                $(function() {
                    Highcharts.setOptions({
                        lang: {
                            thousandsSep: ','
                        },
                    });

                    var container = Highcharts.chart('container', {
                        chart: {
                            zoomType: 'xy',
                            type: 'column',
                            borderColor: "#000000",
                            borderWidth: 1,
                            height: 450,
                        },

                        title: {
                            text: 'FAIL Accounting by RO and % Fail AAA by active Subs.',
                        },
                        subtitle: {

                            text: 'Date : <?php echo date('d F Y', strtotime($start_date)) ?> - <?php echo date('d F Y', strtotime($to_date)) ?> ',
                            align: 'center',
                            useHTML: true,
                            style: {
                                "fontSize": "14px"
                            }
                        },

                        xAxis: {
                            categories: [
                                <?php
                                $str_cat = '';
                                foreach ($ro as $value) {
                                    $str_cat .= "'" . $value .
                                        "'" .
                                        ",";
                                }
                                $str_cat .= "'Average'";
                                echo $str_cat;
                                ?>
                            ],
                        },

                        yAxis: [{
                            // max: 500000,
                            max: <?php echo $max_qty*1.5; ?>,
                            min: 0,
                            title: {
                                text: 'Qty.'
                            },
                            stackLabels: {
                                enabled: true,
                                align: 'center',
                                style: {
                                    fontWeight: 'normal',
                                    color: 'black',
                                    fontSize: '11px'
                                },
                                formatter: function() {
                                    return Highcharts.numberFormat(this.total, 0)
                                }
                            }
                        }, {
                            min: -80,
                            // max: 50,
                            max: <?php echo $max_per*1.85;?>,

                            title: {
                                text: '% Fail'
                            },
                            opposite: true
                        }, ],
                        legend: {
                            // align: 'center',
                            // verticalAlign: 'bottom',
                            layout: 'horizontal', // default
                            // itemDistance: 1,
                            backgroundColor: '#ffffff',
                            borderColor: '#C98657',
                            borderWidth: 2,
                            // width: 800,
                            // itemWidth: 260,
                            // margin: 1000,
                            // itemMarginLeft: 50,
                            // itemDistance: 300
                        },


                        plotOptions: {
                            series: {
                                dataLabels: {
                                    enabled: false,
                                    format: '{point.y:,.0f}'
                                }
                            },
                            column: {
                                colorByPoint: true
                            }
                            // column: {
                            //     stacking: 'normal'
                            // }

                        },
                        colors: [
                            '#0a0ad6',
                            '#cc3801',
                            '#3bd63b',
                            '#ce1a7b',
                            '#8b0d8b',
                            '#ce6743',
                            '#cd9b9b',
                            '#16ccff',
                            '#98ff23',
                            '#e57ce1',
                        ],
                        series: [{
                                name: 'fail Accounting By RO',
                                data: [
                                    <?php

                                    $str_data = "";
                                    foreach ($data as $key => $value) {
                                        # code...
                                        $str_data .= $value . ',';
                                    }
                                    $str_data .= $avg_fail;
                                    echo $str_data;
                                    ?>
                                ],
                                dataLabels: {
                                    color: 'black',
                                    x: -3,
                                    y: -5,
                                    enabled: true,
                                    // rotation: -45,
                                    format: '{point.y:,.0f}',
                                    style: {
                                        fontSize: '12px',
                                        fontFamily: 'Helvetica',

                                    },
                                },
                            },
                            {
                                name: '% Fail AAA by Active Sub.',
                                type: 'line',
                                visible: false,
                                color: '#00FF00',
                                yAxis: 1,
                                data: [
                                    <?php
                                    $str_avg_per = "";
                                    foreach ($avg_per as $key => $value) {
                                        # code...
                                        $str_avg_per .= $value . ',';
                                    }
                                    $str_avg_per .= $avg_per_last;
                                    echo $str_avg_per;
                                    ?>
                                ],
                                dataLabels: {
                                    x: -3,
                                    y: -5,
                                    format: '{point.y:,.2f}' + '%',
                                    enabled: true,
                                    rotation: -45,
                                    style: {
                                        fontSize: '12px',
                                        fontFamily: 'Helvetica'
                                    }
                                },
                                tooltip: {
                                    headerFormat: '<b>{point.key}</b><br>',
                                    pointFormat: '<span style="font-weight:bold;">\u25CF {series.name}</span> : <b>{point.y} %</b><br/>',
                                    useHTML: true,
                                }
                            },

                        ],
                        exporting: {
                            buttons: {
                                customButton: {
                                    text: '<b>Uncheck</b>',
                                    onclick: function() {
                                        uncheckGraph(container);
                                    }
                                },
                                anotherButton: {
                                    text: "<b>Show all</b>",
                                    onclick: function() {
                                        checkGraph(container);
                                    }
                                },
                                lineButton: {
                                    text: "<b>[Line]</b>",
                                    onclick: function() {
                                        chartLine(container);
                                    }
                                },
                                columnButton: {
                                    text: "<b>[Stacked column]</b>",
                                    onclick: function() {
                                        chartColumn(container);
                                    }
                                }
                            }
                        }
                    });
                });
            </script>


            <!-- jQuery first, then Tether, then Bootstrap JS. -->
	        <script src="js/bootstrap.min2.js" integrity="sha384-vBWWzlZJ8ea9aCX4pEW3rVHjgjt7zpkNpZk+02D9phzyeVkE+jo0ieGizqPLForn" crossorigin="anonymous"></script>

            <script type="text/javascript" src="js/bootstrap-datetimepicker.js" charset="UTF-8"></script>
            <script type="text/javascript">
                $('.form_datetime').datetimepicker({
                    // format: 'YYYY-MM-DD',
                    weekStart: 1,
                    todayBtn: 1,
                    autoclose: 1,
                    todayHighlight: 1,
                    startView: 2,
                    minView: 2,
                    forceParse: 0,
                    showMeridian: 1,
                });
            </script>
</body>

</html>