<?php
include "connect210.php";
date_default_timezone_set("Asia/Bangkok");

header("Content-type: text/json");

$x = time() * 1000 - 900000;


$sqlcount=mysqli_query($con2,"SELECT * FROM wl2
WHERE DATEOPER BETWEEN DATE_ADD(now(),INTERVAL -904 SECOND) AND DATE_ADD(now(),INTERVAL -15 MINUTE) ORDER BY DATEOPER DESC LIMIT 1");
$rows=mysqli_fetch_array($sqlcount);

$arr_data["time"] = $x;
$arr_data["A"] = $rows["VIP168"];
$arr_data["B"] = $rows["VIP169"];
$arr_data["C"] = $rows["VIP170"];
$arr_data["D"] = $rows["VIP118"];
$arr_data["E"] = $rows["SUM_4VIP"];
$arr_data["F"] = $rows["P8011"];
$arr_data["G"] = $rows["P8012"];
$arr_data["H"] = $rows["P8013"];
$arr_data["I"] = $rows["P8014"];
$arr_data["J"] = $rows["P8015"];
$arr_data["K"] = $rows["SUM_5PORT"];
$arr_data["L"] = $rows["IP_BCS"];
$arr_data["M"] = $rows["DIFF"];

echo json_encode($arr_data);



?>