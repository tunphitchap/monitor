<?php
date_default_timezone_set('Asia/Bangkok');
include "connect210.php";

?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta name="description" content="">
    <meta name="author" content="">
    <link rel="icon" href="../../favicon.ico">

    <title>Radius-Monitor</title>

    <?php include("import_lib.php"); ?>

    <!-- _____________________________________________ Oat _______________________________________ -->

    <style type="text/css">
        .textAlignVer {
            font-size: 12px;
        }

        .textAlignVerRotate {
            display: block;
            -webkit-transform: rotate(-90deg);
            -moz-transform: rotate(-90deg);
            font-size: 12px;
        }

        a:hover {
            text-decoration: none;
        }

        input[type="text"] {
            font-size: 14px;
        }
    </style>
    <!-- _____________________________________________ Oat _______________________________________ -->

    <style>
        .highcharts-container {
            overflow: visible !important;
        }

        .MyChartTooltip {
            position: relative;
            z-index: 50;
            border-radius: 5px;
            background-color: #ffffff;
            padding: 5px;
            font-size: 9pt;
            overflow: auto;
            height: 250px;
        }

        .highcharts-tooltip {
            pointer-events: all !important;
        }
    </style>

    <script src="js/jquery-3.1.1.min.js"></script>
    <script src="code/highcharts.js"></script>
    <script src="code/highcharts-3d.js"></script>
    <script src="code/modules/exporting.js"></script>

    <script>
        function changePeriod() {
            var start = document.getElementById('startDate');
            var end = document.getElementById('endDate');
            var selectPeriod = document.getElementById('selectPeriod');
            if (selectPeriod.value == 'Today') {
                start.value = "<?php echo date("Y-m-d 00:00") ?>";
                end.value = "<?php echo date("Y-m-d H:i") ?>";
            } else if (selectPeriod.value == 'LastDay') {
                start.value = "<?php echo date("Y-m-d H:i", strtotime("-1 day")) ?>";
                end.value = "<?php echo date("Y-m-d H:i") ?>";
            } else if (selectPeriod.value == 'Last2Days') {
                start.value = "<?php echo date("Y-m-d H:i", strtotime("-2 day")) ?>";
                end.value = "<?php echo date("Y-m-d H:i") ?>";
            }
        }
    </script>
</head>






<body style="padding-top: 4.5rem">
    <?php include("menu_top.php"); ?>

    <!-- MENU DATE TIME -->
    <style type="text/css">
        @media (min-width: 768px) {
            .container {
                width: 500px;
            }
        }

        @media (min-width: 992px) {
            .container {
                width: 800px;
            }
        }

        @media (min-width: 1200px) {
            .container {
                width: 1300px;
            }
        }

        .form-inline {
            width: 1300px;
        }
    </style>
    <?php
   
//    echo date('Y-d-m H:i:s',strtotime('+1 hour'));




    if (empty($_POST['selectPeriod'])) {
        $selectPeriod = "LastDay";
    } else {
        $selectPeriod = $_POST['selectPeriod'];
    }
    $check_date = 0;
    $str_query = "group by DATE_FORMAT(DATEOPER, '%Y/%m/%d %H') order by DATE_FORMAT(DATEOPER, '%Y/%m/%d %H')";



    if (empty($_POST['start']) || empty($_POST['end'])) {
        # code...
        $date_from = date('Y-m-d H:i', strtotime('-1 day'));
        $date_to = date('Y-m-d H:i');
    } else {
        # code...
        $date_from  = $_POST['start'];
        $date_to = $_POST['end'];
    }

    $sql_data  = mysqli_query($con2, "SELECT DATE_FORMAT( min(DATEOPER), '%Y/%m/%d %H:%i:%S' ) AS date, max(WEBLOGIC_90) AS WEBLOGIC_90, max(WEBLOGIC_92) AS WEBLOGIC_92, max(RADIUS_86) AS RADIUS_86, max(RADIUS_88) AS RADIUS_88, TOTAL_4IP, TOTAL_1521, max(DIFF) AS OTHER, ( max(WEBLOGIC_90) + max(WEBLOGIC_92) + max(RADIUS_86) + max(RADIUS_88) + max(DIFF)) AS Total_Max_Conn 
    FROM db1 where DATEOPER between '" . $date_from . "' and '" . $date_to . "'" . $str_query);
    // $text_head_show = ['WEBLOGIC_26', 'WEBLOGIC_27', 'RADIUS_ODA2_45', 'RADIUS_ODA1_46', 'OTHER', 'Total_Max_Conn'];
    $text_head_show = ['WEBLOGIC_26', 'WEBLOGIC_27', 'RADIUS_45', 'RADIUS_46', 'OTHER', 'Total_Max_Conn'];
    $type = ['WEBLOGIC_90', 'WEBLOGIC_92', 'RADIUS_86', 'RADIUS_88','OTHER', 'Total_Max_Conn'];
    while ($result = mysqli_fetch_array($sql_data)) {
        $date[] = date('Y-m-d H:00', strtotime($result['date']));
        $data['WEBLOGIC_90'][date('Y-m-d H:00', strtotime($result['date']))] = $result['WEBLOGIC_90'];
        $data['WEBLOGIC_92'][date('Y-m-d H:00', strtotime($result['date']))] = $result['WEBLOGIC_92'];
        $data['RADIUS_86'][date('Y-m-d H:00', strtotime($result['date']))] = $result['RADIUS_86'];
        $data['RADIUS_88'][date('Y-m-d H:00', strtotime($result['date']))] = $result['RADIUS_88'];
        // $data['TOTAL_4IP'][date('Y-m-d H:i', strtotime($result['date']))] = $result['TOTAL_4IP'];
        // $data['TOTAL_1521'][date('Y-m-d H:i', strtotime($result['date']))] = $result['TOTAL_1521'];
        $data['OTHER'][date('Y-m-d H:00', strtotime($result['date']))] = $result['OTHER'];
        $data['Total_Max_Conn'][date('Y-m-d H:00', strtotime($result['date']))] = $result['Total_Max_Conn'];
    }


    $sql_data_db2  = mysqli_query($con2, "SELECT DATE_FORMAT( min(DATEOPER), '%Y/%m/%d %H:%i:%S' ) AS date, max(WEBLOGIC_90) AS WEBLOGIC_90, max(WEBLOGIC_92) AS WEBLOGIC_92, max(RADIUS_86) AS RADIUS_86, max(RADIUS_88) AS RADIUS_88, TOTAL_4IP, TOTAL_1521, max(DIFF) AS OTHER, ( max(WEBLOGIC_90) + max(WEBLOGIC_92) + max(RADIUS_86) + max(RADIUS_88) + max(DIFF)) AS Total_Max_Conn 
    FROM db2 where DATEOPER between '" . $date_from . "' and '" . $date_to . "'" . $str_query);


    $type_db2 = ['WEBLOGIC_90', 'WEBLOGIC_92', 'RADIUS_86', 'RADIUS_88', 'OTHER', 'Total_Max_Conn'];
    while ($result = mysqli_fetch_array($sql_data_db2)) {
        $date_db2[] = date('Y-m-d H:00', strtotime($result['date']));
        $data_db2['WEBLOGIC_90'][date('Y-m-d H:00', strtotime($result['date']))] = $result['WEBLOGIC_90'];
        $data_db2['WEBLOGIC_92'][date('Y-m-d H:00', strtotime($result['date']))] = $result['WEBLOGIC_92'];
        $data_db2['RADIUS_86'][date('Y-m-d H:00', strtotime($result['date']))] = $result['RADIUS_86'];
        $data_db2['RADIUS_88'][date('Y-m-d H:00', strtotime($result['date']))] = $result['RADIUS_88'];
        // $data_db2['TOTAL_4IP'][date('Y-m-d H:i', strtotime($result['date']))] = $result['TOTAL_4IP'];
        // $data_db2['TOTAL_1521'][date('Y-m-d H:i', strtotime($result['date']))] = $result['TOTAL_1521'];
        $data_db2['OTHER'][date('Y-m-d H:00', strtotime($result['date']))] = $result['OTHER'];
        $data_db2['Total_Max_Conn'][date('Y-m-d H:00', strtotime($result['date']))] = $result['Total_Max_Conn'];
    }
    // print_r($data);
    $sql_color = mysqli_query($con2,"select * from db_color");
    while ($result = mysqli_fetch_array($sql_color)) {
        # code...
        $color[$result['type']] = $result['color'];
        $color2[$result['type']] = $result['color2'];
        $legendIndex_db1[$result['type']] = $result['legendIndex_db1'];
        $legendIndex_db2[$result['type']] = $result['legendIndex_db2'];
        $dashStyles1[$result['type']] = $result['dashStyle1'];
        $dashStyles2[$result['type']] = $result['dashStyle2'];
    }


        //now value
        $top_max_DB1_WL = max(max($data['WEBLOGIC_90']), max($data['WEBLOGIC_92']));
        $top_max_DB2_WL = max(max($data_db2['WEBLOGIC_90']), max($data_db2['WEBLOGIC_92']));
    
        $top_max_RA1 = max(max($data['RADIUS_86']), max($data['RADIUS_88']));
        $top_max_RA2 = max(max($data_db2['RADIUS_86']), max($data_db2['RADIUS_88']));
    
        $top_max_Other1 = max($data['OTHER']);
        $top_max_Other2 = max($data_db2['OTHER']);
    
        $top_max_Total_Max_Conn = max($data['Total_Max_Conn']);
        $top_max_Total2_Max_Conn = max($data_db2['Total_Max_Conn']);
        //now value


        function DateTimeDiff($strDateTime1,$strDateTime2){
            return (strtotime($strDateTime2) - strtotime($strDateTime1))/  ( 60 * 60 ); 
       }
    
       $categorycount = DateTimeDiff($date_from , $date_to);

    //    for ($i=0; $i < $categorycount; $i++) { 
    //        echo date('Y-m-d H:00', strtotime('+' . $i . ' hour', strtotime($date_from))).'<br>';
    //    }
    ?>

<div class="container">
    <div class="col-md-12">
      <div style="line-height: 10px;">MAX CONNECTION > <font color="blue">DATABASE RAC HOURLY</font></div>
    </div>
</div>
<br>

    <div class="container">
        <div class="row">
            <form action="data_con2_hour.php" method='post' class="form-inline" role="form">

                <div align="left" class="col-lg-1">
                <!-- <button type="button" class="btn btn-danger">MAX CONNECTION</button> -->
                </div>
                <div class="col-lg-1"></div>
                <div class="col-lg-1">Start Date</div>
                <div class="input-group date form_datetime col-md-2" data-date="" data-date-format="yyyy-mm-dd HH" data-link-field="dtp_input1">
                    <input name='start' id="startDate" class="form-control" size="7" type="text" value="<?php echo $date_from ?>" readonly>
                    <span class="input-group-addon"><span class="glyphicon glyphicon-calendar"><i class="fa fa-th" aria-hidden="true"></i></span></span></div>

                <div class="col-lg-1">End Date </div>
                <div class="input-group date form_datetime col-md-2" data-date="" data-date-format="yyyy-mm-dd HH" data-link-field="dtp_input1">
                    <input name='end' id="endDate" class="form-control" size="7" type="text" value="<?php echo $date_to ?>" readonly>
                    <span class="input-group-addon"><span class="glyphicon glyphicon-calendar"><i class="fa fa-th" aria-hidden="true"></i></span></span></div>


                <div class="col-lg-3">
                    <select class="form-control" onchange="changePeriod()" name="selectPeriod" id="selectPeriod">
                        <option <?php if ($selectPeriod == "Today") { ?> selected <?php } ?> value="Today">Today</option>
                        <option <?php if ($selectPeriod == "LastDay") { ?> selected <?php } ?> value="LastDay">LastDay</option>
                        <option <?php if ($selectPeriod == "Last2Days") { ?> selected <?php } ?> value="Last2Days">Last 2 Days</option>
                        <option <?php if ($selectPeriod == "Custom") { ?> selected <?php } ?> value="Custom">Custom</option>
                    </select>
                    <button type="submit" class="btn btn-default col-lg-5">Submit</button>
                </div>

            </form>

        </div>
        <br>
        <div class="row">
            <div class="col-md-12">
                <div id="container"></div>
            </div>
        </div>
    </div>

    <!-- END MENU DATE TIME -->
    <script type="text/javascript">
        function uncheckGraph(chart) {
            Highcharts.each(chart.series, function(p, i) {
                p.hide()
            });
        }

        function checkGraph(chart) {
            Highcharts.each(chart.series, function(p, i) {
                p.show()
            });
        }

        function chartLine(chart) {
            Highcharts.each(chart.series, function(p, i) {
                p.update({
                    type: "line"
                });
            });
        }

        function chartColumn(chart) {
            Highcharts.each(chart.series, function(p, i) {
                p.update({
                    type: "column"
                });
            });
        }
        $(function() {
            Highcharts.setOptions({
                lang: {
                    thousandsSep: ','
                }
            });

            var container = Highcharts.chart('container', {
                chart: {
                    zoomType: 'xy',
                    type: 'line',
                    borderColor: "#000000",
                    borderWidth: 1,
                    height: 450
                },

                title: {
                    text: 'Max Connection DB1,DB2 <?php echo date('d F Y H:i', strtotime($date_from)) ?> - <?php echo date('d F Y H:i', strtotime($date_to)) ?> ',
                },
                subtitle: {

                    text: '<table>'
                            +'<tr><td>DB1-Total Max Conn. : <?php echo number_format($top_max_Total_Max_Conn) ?></td><td>, DB1-Weblogic : <?php echo number_format($top_max_DB1_WL)?></td><td>, DB1-Radius-Acct : <?php echo number_format($top_max_RA1) ?></td><td>, DB1-Other/Sql : <?php echo number_format($top_max_Other1) ?></td></tr>'
                            +'<tr><td>DB2-Total Max Conn. : <?php echo number_format($top_max_Total2_Max_Conn) ?></td><td>, DB2-Weblogic : <?php echo number_format($top_max_DB2_WL)?></td><td>, DB2-Radius-Acct : <?php echo number_format($top_max_RA1) ?></td><td>, DB2-Other/Sql : <?php echo number_format($top_max_Other2) ?></td></tr>'
                            +'</table>',
                    align: 'center',
                    useHTML: true,
                    style: {
                        "fontSize": "14px"
                    }
                },

                xAxis: {
                    categories: [
                    <?php
                    for ($i = 0; $i < $categorycount; $i++) {
                        echo "'" . date('Y-m-d H:00', strtotime('+' . $i . ' hour', strtotime($date_from))) . "',";
                    }
                    ?>
                ],
                },

                yAxis: [{
                    // max: 500000,
                    min: 0,
                    title: {
                        text: 'Max Connection.'
                    },
                    stackLabels: {
                        enabled: true,
                        align: 'center',
                        style: {
                            fontWeight: 'normal',
                            color: 'black',
                            fontSize: '11px'
                        },
                        formatter: function() {
                            return Highcharts.numberFormat(this.total, 0)
                        }
                    }
                }],
                legend: {
                    // align: 'center',
                    // verticalAlign: 'bottom',
                    layout: 'horizontal', // default
                    // itemDistance: 1,
                    backgroundColor: '#ffffff',
                    borderColor: '#C98657',
                    borderWidth: 2,
                    // width: 800,
                    itemWidth: 260,
                    // margin: 1000,
                    // itemMarginLeft: 50,
                    // itemDistance: 300
                },


                plotOptions: {
                    series: {
                        dataLabels: {
                            enabled: false,
                            format: '{point.y:,.0f}'
                        }
                    },
                    column: {
                        stacking: 'normal'
                    }

                },
                series: [
                    <?php
                    foreach ($type as $key_type => $value_type) {
                        ?> {
                            name: '<?php echo'<span>DB1-</span>' .  $text_head_show[$key_type] ?>',
                            data: [
                                <?php
                                    for ($i = 0; $i < $categorycount; $i++) {
                                        if(!empty($data[$value_type][date('Y-m-d H:00', strtotime('+' . $i . ' hour', strtotime($date_from)))])){
                                            echo $data[$value_type][date('Y-m-d H:00', strtotime('+' . $i . ' hour', strtotime($date_from)))] . ',';
                                        }else{
                                            echo "null,"; 
                                        }
                                    }
                                    ?>
                            ],
                            color: "<?php echo $color[$value_type] ?>",
                            legendIndex: <?php echo $legendIndex_db1[$value_type] ?>,
                            dashStyle: '<?php echo $dashStyles2[$value_type] ?>',
                            marker: {
                                symbol: 'circle',
                            }
                        },
                    <?php
                    }
                    ?>

                    <?php
                    foreach ($type_db2 as $key_type => $value_type) {
                        ?> {
                            name: '<?php echo '<span>DB2-</span>' . $text_head_show[$key_type] ?>',
                            data: [
                                <?php
                                    for ($i = 0; $i < $categorycount; $i++) {
                                        if(!empty($data_db2[$value_type][date('Y-m-d H:00', strtotime('+' . $i . ' hour', strtotime($date_from)))])){
                                            echo $data_db2[$value_type][date('Y-m-d H:00', strtotime('+' . $i . ' hour', strtotime($date_from)))] . ',';
                                        }else{
                                            echo "null,"; 
                                        }
                                    }
                                    ?>
                            ],
                            color: "<?php echo $color2[$value_type] ?>",
                            legendIndex: <?php echo $legendIndex_db1[$value_type] ?>,
                            dashStyle: '<?php echo $dashStyles1[$value_type] ?>',
                            marker: {
                                symbol: 'square',
                            }
                        },
                    <?php
                    }
                    ?>
                ],
                tooltip: {
                    formatter: function() {
                        var s = [];
                        s.push('<span style="font-weight:bold;font-size:12px">' + this.x + '<span><br><span style="font-weight:bold;"><span><br><table>');
                        $.each(this.points, function(i, point) {
                            s.push('<tr><td><span style="color:' + this.series.color + ';font-weight:bold;">' + point.series.name + ' :</td><td>' + Highcharts.numberFormat(point.y, 0, '.', ',') + '<span></td></tr>');
                        });
                        s.push('</table>');
                        return s;
                    },
                    borderColor: '#000000',
                    useHTML: true,
                    shared: true
                },
                exporting: {
                    buttons: {
                        customButton: {
                            text: '<b>Uncheck</b>',
                            onclick: function() {
                                uncheckGraph(container);
                            }
                        },
                        anotherButton: {
                            text: "<b>Show all</b>",
                            onclick: function() {
                                checkGraph(container);
                            }
                        },
                        // lineButton: {
                        //     text: "<b>[Line]</b>",
                        //     onclick: function() {
                        //         chartLine(container);
                        //     }
                        // },
                        // columnButton: {
                        //     text: "<b>[Stacked column]</b>",
                        //     onclick: function() {
                        //         chartColumn(container);
                        //     }
                        // },
                    }
                }
            });

            var container_db2 = Highcharts.chart('container_db2', {
                chart: {
                    zoomType: 'xy',
                    type: 'spline',
                    borderColor: "#000000",
                    borderWidth: 1,
                    height: 450
                },

                title: {
                    text: 'Max Connection DB2',
                },
                subtitle: {

                    text: 'Date : <?php echo date('d F Y H:i', strtotime($date_from)) ?> - <?php echo date('d F Y H:i', strtotime($date_to)) ?> ',
                    align: 'center',
                    useHTML: true,
                    style: {
                        "fontSize": "14px"
                    }
                },

                xAxis: {
                    categories: [
                        <?php
                        foreach ($date_db2 as $value) {
                            echo "'" . (($check_date == 1) ? date('Y-m-d', strtotime($value)) : $value) .
                                "'" .
                                ",";
                        }
                        ?>
                    ],
                },

                yAxis: [{
                    // max: 500000,
                    min: 0,
                    title: {
                        text: 'Qty.'
                    },
                    stackLabels: {
                        enabled: true,
                        align: 'center',
                        style: {
                            fontWeight: 'normal',
                            color: 'black',
                            fontSize: '11px'
                        },
                        formatter: function() {
                            return Highcharts.numberFormat(this.total, 0)
                        }
                    }
                }],
                legend: {
                    // align: 'center',
                    // verticalAlign: 'bottom',
                    layout: 'horizontal', // default
                    // itemDistance: 1,
                    backgroundColor: '#ffffff',
                    borderColor: '#C98657',
                    borderWidth: 2,
                    // width: 800,
                    // itemWidth: 260,
                    // margin: 1000,
                    // itemMarginLeft: 50,
                    // itemDistance: 300
                },


                plotOptions: {
                    series: {
                        dataLabels: {
                            enabled: false,
                            format: '{point.y:,.0f}'
                        }
                    },
                    column: {
                        stacking: 'normal'
                    }

                },
                series: [
                    <?php
                    foreach ($type_db2 as $key_type => $value_type) {
                        ?> {
                            name: '<?php echo $value_type ?>',
                            data: [
                                <?php
                                    foreach ($date_db2 as $key_date => $value_date) {
                                        echo $data_db2[$value_type][$value_date] . ',';
                                    }
                                    ?>
                            ],
                        },
                    <?php
                    }
                    ?>
                ],
                tooltip: {
                    formatter: function() {
                        var s = [];
                        s.push('<span style="font-weight:bold;font-size:12px">' + this.x + '<span><br><span style="font-weight:bold;"><span><br><table>');
                        $.each(this.points, function(i, point) {
                            s.push('<tr><td><span style="color:' + this.series.color + ';font-weight:bold;">' + point.series.name + ' :</td><td>' + Highcharts.numberFormat(point.y, 0, '.', ',') + '<span></td></tr>');
                        });
                        s.push('</table>');
                        return s;
                    },
                    borderColor: '#000000',
                    useHTML: true,
                    shared: true
                },
                exporting: {
                    buttons: {
                        customButton: {
                            text: '<b>Uncheck</b>',
                            onclick: function() {
                                uncheckGraph(container_db2);
                            }
                        },
                        anotherButton: {
                            text: "<b>Show all</b>",
                            onclick: function() {
                                checkGraph(contcontainer_db2ainer);
                            }
                        },
                        // lineButton: {
                        //     text: "<b>[Line]</b>",
                        //     onclick: function() {
                        //         chartLine(container_db2);
                        //     }
                        // },
                        // columnButton: {
                        //     text: "<b>[Stacked column]</b>",
                        //     onclick: function() {
                        //         chartColumn(container_db2);
                        //     }
                        // }
                    }
                },
                // navigation: {
                //     buttonOptions: {
                //         align: 'right',
                //         y:10
                //     }
                // }
            });
        });
    </script>

    <!-- jQuery first, then Tether, then Bootstrap JS. -->
	<script src="js/bootstrap.min2.js" integrity="sha384-vBWWzlZJ8ea9aCX4pEW3rVHjgjt7zpkNpZk+02D9phzyeVkE+jo0ieGizqPLForn" crossorigin="anonymous"></script>

    <script type="text/javascript" src="js/bootstrap-datetimepicker.js" charset="UTF-8"></script>
    <script type="text/javascript">
        $('.form_datetime').datetimepicker({
            format: 'yyyy-mm-dd hh:00',
            minView: 1
        });

        $('.form_datetime').datetimepicker().on('changeDate', function(ev) {
            $('#selectPeriod').val('Custom').trigger('change');
        });
    </script>

</body>

</html>