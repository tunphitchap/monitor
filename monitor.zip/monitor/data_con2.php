<?php
date_default_timezone_set("Asia/Bangkok");
?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta name="description" content="">
    <meta name="author" content="">
    <link rel="icon" href="../../favicon.ico">

    <title>Radius-Monitor</title>

    <?php include("import_lib.php"); ?>

    <!-- _____________________________________________ Oat _______________________________________ -->

    <style type="text/css">
        .textAlignVer {
            font-size: 12px;
        }

        .textAlignVerRotate {
            display: block;
            -webkit-transform: rotate(-90deg);
            -moz-transform: rotate(-90deg);
            font-size: 12px;
        }

        a:hover {
            text-decoration: none;
        }

        input[type="text"] {
            font-size: 14px;
        }
    </style>
    <!-- _____________________________________________ Oat _______________________________________ -->

    <style>
        .highcharts-container {
            overflow: visible !important;
        }

        .MyChartTooltip {
            position: relative;
            z-index: 50;
            border-radius: 5px;
            background-color: #ffffff;
            padding: 5px;
            font-size: 9pt;
            overflow: auto;
            height: 250px;
        }

        .highcharts-tooltip {
            pointer-events: all !important;
        }
    </style>

    <script src="js/jquery-3.1.1.min.js"></script>
    <script src="code/highcharts.js"></script>
    <script src="code/highcharts-3d.js"></script>
    <script src="code/modules/exporting.js"></script>

    <script>
        function changePeriod() {
            var start = document.getElementById('startDate');
            var end = document.getElementById('endDate');
            var selectPeriod = document.getElementById('selectPeriod');
            if (selectPeriod.value == 'Today') {
                start.value = "<?php echo date("Y-m-d 00:00") ?>";
                end.value = "<?php echo date("Y-m-d H:i") ?>";
            } else if (selectPeriod.value == 'LastDay') {
                start.value = "<?php echo date("Y-m-d H:i", strtotime("-1 day")) ?>";
                end.value = "<?php echo date("Y-m-d H:i") ?>";
            } else if (selectPeriod.value == 'Last2Days') {
                start.value = "<?php echo date("Y-m-d H:i", strtotime("-2 day")) ?>";
                end.value = "<?php echo date("Y-m-d H:i") ?>";
            }
        }
    </script>
</head>



<!-- [0] Initialize - BY FIFAZ// -->
<?php
date_default_timezone_set('Asia/Bangkok');
include "connect210.php";

?>


<body style="padding-top: 4.5rem">
    <?php include("menu_top.php"); ?>

    <!-- MENU DATE TIME -->
    <style type="text/css">
        @media (min-width: 768px) {
            .container {
                width: 500px;
            }
        }

        @media (min-width: 992px) {
            .container {
                width: 800px;
            }
        }

        @media (min-width: 1200px) {
            .container {
                width: 1300px;
            }
        }

        .form-inline {
            width: 1300px;
        }
    </style>
    <?php
    if (empty($_POST['selectPeriod'])) {
        $selectPeriod = "LastDay";
    } else {
        $selectPeriod = $_POST['selectPeriod'];
    }
    $check_date = 0;
    $str_query = "group by DATE_FORMAT(DATEOPER, '%Y/%m/%d %H') order by DATE_FORMAT(DATEOPER, '%Y/%m/%d %H')";
 

    if (empty($_POST['start']) || empty($_POST['end'])) {
        # code...
        $date_from = date('Y-m-d H:i', strtotime('-1 day'));
        $date_to = date('Y-m-d H:i');
    } else {
        # code...
        $date_from  = $_POST['start'];
        $date_to = $_POST['end'];
    }

    
   

    $sql_data  = mysqli_query($con2, "SELECT DATE_FORMAT(min(DATEOPER),'%Y/%m/%d %H:%i:%S') as date,max(VIP168) as VIP168,max(VIP169) as VIP169,max(VIP170) as VIP170,max(VIP118) as VIP118,max(SUM_4VIP) as SUM_4VIP,max(P8011) as P8011,max(P8012) as P8012,max(P8013) as P8013,
    max(P8014) as P8014,max(P8015) as P8015,max(SUM_5PORT) as SUM_5PORT,max(IP_BCS) as IP_BCS,max(DIFF) as DIFF
    FROM wl1_hourly where DATEOPER between '" . $date_from . "' and '" . $date_to . "'" . $str_query);

    $type = ['VIP168', 'VIP169', 'VIP170', 'VIP118', 'SUM_4VIP', 'P8011', 'P8012', 'P8013', 'P8014', 'P8015', 'SUM_5PORT', 'IP_BCS', 'DIFF'];
    $type_Pm = ['8011', '8012', '8013', '8014', '8015', 'IP_BCS', 'DIFF'];
    while ($result = mysqli_fetch_array($sql_data)) {
        $date[] = date('Y-m-d H:i', strtotime($result['date']));
        $data['VIP168'][date('Y-m-d H:i', strtotime($result['date']))] = $result['VIP168'];
        $data['VIP169'][date('Y-m-d H:i', strtotime($result['date']))] = $result['VIP169'];
        $data['VIP170'][date('Y-m-d H:i', strtotime($result['date']))] = $result['VIP170'];
        $data['VIP118'][date('Y-m-d H:i', strtotime($result['date']))] = $result['VIP118'];
        $data['SUM_4VIP'][date('Y-m-d H:i', strtotime($result['date']))] = $result['SUM_4VIP'];
        $data['8011'][date('Y-m-d H:i', strtotime($result['date']))] = $result['P8011'];
        $data['8012'][date('Y-m-d H:i', strtotime($result['date']))] = $result['P8012'];
        $data['8013'][date('Y-m-d H:i', strtotime($result['date']))] = $result['P8013'];
        $data['8014'][date('Y-m-d H:i', strtotime($result['date']))] = $result['P8014'];
        $data['8015'][date('Y-m-d H:i', strtotime($result['date']))] = $result['P8015'];
        $data['SUM_5PORT'][date('Y-m-d H:i', strtotime($result['date']))] = $result['SUM_5PORT'];
        $data['IP_BCS'][date('Y-m-d H:i', strtotime($result['date']))] = $result['IP_BCS'];
        $data['DIFF'][date('Y-m-d H:i', strtotime($result['date']))] = $result['DIFF'];
    }


    $sql_data_db2  = mysqli_query($con2, "SELECT DATE_FORMAT(min(DATEOPER),'%Y/%m/%d %H:%i:%S') as date,max(VIP168) as VIP168,max(VIP169) as VIP169,max(VIP170) as VIP170,max(VIP118) as VIP118,max(SUM_4VIP) as SUM_4VIP,max(P8011) as P8011,max(P8012) as P8012,max(P8013) as P8013,
    max(P8014) as P8014,max(P8015) as P8015,max(SUM_5PORT) as SUM_5PORT,max(IP_BCS) as IP_BCS,max(DIFF) as DIFF
    FROM wl2_hourly where DATEOPER between '" . $date_from . "' and '" . $date_to . "'" . $str_query);

    $type_db2 = ['VIP168', 'VIP169', 'VIP170', 'VIP118', 'SUM_4VIP', 'P8011', 'P8012', 'P8013', 'P8014', 'P8015', 'SUM_5PORT', 'IP_BCS', 'DIFF'];
    $type_db2_Pm = ['8011', '8012', '8013', '8014', '8015', 'IP_BCS', 'DIFF'];
    while ($result = mysqli_fetch_array($sql_data_db2)) {
        $date_db2[] = date('Y-m-d H:i', strtotime($result['date']));
        $data_db2['VIP168'][date('Y-m-d H:i', strtotime($result['date']))] = $result['VIP168'];
        $data_db2['VIP169'][date('Y-m-d H:i', strtotime($result['date']))] = $result['VIP169'];
        $data_db2['VIP170'][date('Y-m-d H:i', strtotime($result['date']))] = $result['VIP170'];
        $data_db2['VIP118'][date('Y-m-d H:i', strtotime($result['date']))] = $result['VIP118'];
        $data_db2['SUM_4VIP'][date('Y-m-d H:i', strtotime($result['date']))] = $result['SUM_4VIP'];
        $data_db2['8011'][date('Y-m-d H:i', strtotime($result['date']))] = $result['P8011'];
        $data_db2['8012'][date('Y-m-d H:i', strtotime($result['date']))] = $result['P8012'];
        $data_db2['8013'][date('Y-m-d H:i', strtotime($result['date']))] = $result['P8013'];
        $data_db2['8014'][date('Y-m-d H:i', strtotime($result['date']))] = $result['P8014'];
        $data_db2['8015'][date('Y-m-d H:i', strtotime($result['date']))] = $result['P8015'];
        $data_db2['SUM_5PORT'][date('Y-m-d H:i', strtotime($result['date']))] = $result['SUM_5PORT'];
        $data_db2['IP_BCS'][date('Y-m-d H:i', strtotime($result['date']))] = $result['IP_BCS'];
        $data_db2['DIFF'][date('Y-m-d H:i', strtotime($result['date']))] = $result['DIFF'];
    }
    // print_r($data);
    $type_max = ['VIP-118', 'VIP-168', 'VIP-169', 'VIP-170'];
    foreach ($date as $key_date => $value_date) {
        $data_max['VIP-118'][$value_date] = max($data['8011'][$value_date], $data['8012'][$value_date], $data_db2['8011'][$value_date], $data_db2['8012'][$value_date]);
        $data_max['VIP-168'][$value_date] = max($data['8013'][$value_date], $data_db2['8013'][$value_date]);
        $data_max['VIP-169'][$value_date] = max($data['8014'][$value_date], $data_db2['8014'][$value_date]);
        $data_max['VIP-170'][$value_date] = max($data['8015'][$value_date], $data_db2['8015'][$value_date]);
    }
    $data_max_max['VIP-118'] = max($data_max['VIP-118']);
    $data_max_max['VIP-168'] = max($data_max['VIP-168']);
    $data_max_max['VIP-169'] = max($data_max['VIP-169']);
    $data_max_max['VIP-170'] = max($data_max['VIP-170']);


    $sql_color = mysqli_query($con2, "select * from wl_color");
    while ($result = mysqli_fetch_array($sql_color)) {
        $color1[$result['type']] = $result['color1'];
        $color2[$result['type']] = $result['color2'];
        $legendIndex_wl1[$result['type']] = $result['legendIndex_wl1'];
        $legendIndex_wl2[$result['type']] = $result['legendIndex_wl2'];
        $marker1[$result['type']] = $result['marker1'];
        $marker2[$result['type']] = $result['marker2'];
    }

    // print_r($legendIndex_wl2);
    ?>

    <div class="container">
        <div class="row">
            <form action="data_con.php" method='post' class="form-inline" role="form">

                <div align="left" class="col-lg-1"><button type="button" class="btn btn-danger">MAX CONNECTION</button></div>
                <div class="col-lg-1"></div>
                <div class="col-lg-1">Start Date</div>
                <div class="input-group date form_datetime col-md-2" data-date="" data-date-format="yyyy-mm-dd hh:ii" data-link-field="dtp_input1">
                    <input name='start' id="startDate" class="form-control" size="7" type="text" value="<?php echo $date_from ?>" readonly>
                    <span class="input-group-addon"><span class="glyphicon glyphicon-calendar"><i class="fa fa-th" aria-hidden="true"></i></span></span></div>

                <div class="col-lg-1">End Date </div>
                <div class="input-group date form_datetime col-md-2" data-date="" data-date-format="yyyy-mm-dd hh:ii" data-link-field="dtp_input1">
                    <input name='end' id="endDate" class="form-control" size="7" type="text" value="<?php echo $date_to ?>" readonly>
                    <span class="input-group-addon"><span class="glyphicon glyphicon-calendar"><i class="fa fa-th" aria-hidden="true"></i></span></span></div>


                <div class="col-lg-3">
                    <select class="form-control" onchange="changePeriod()" name="selectPeriod" id="selectPeriod">
                        <option <?php if ($selectPeriod == "Today") { ?> selected <?php } ?> value="Today">Today</option>
                        <option <?php if ($selectPeriod == "LastDay") { ?> selected <?php } ?> value="LastDay">LastDay</option>
                        <option <?php if ($selectPeriod == "Last2Days") { ?> selected <?php } ?> value="Last2Days">Last2Days</option>
                        <!-- <option <?php if ($selectPeriod == "threeSecond") { ?> selected <?php } ?> value="threeSecond">3 Second</option>  -->
                    </select>
                    <button type="submit" class="btn btn-default col-lg-5">Submit</button>
                </div>

            </form>

        </div>
        <br>
        <div class="row">

            <div class="col-md-12 col-sm-12" id="container"></div>

            <!-- <div class="col-md-6">
                <div id="container_db2"></div>
            </div> -->
        </div>
        <div class="row">
            <div style="margin: 0 auto;">
                10.11.11.118 : 8011,8012 Radius<br>
                10.11.11.168 : 8013 MRTG,HelpDesk<br>
                10.11.11.169 : 8014 WA,DDB,Promotion<br>
                10.11.11.170 : 8015 BCS,NetOSS,TTTBB
            </div>
        </div>
 



    <!-- END MENU DATE TIME -->
    <script type="text/javascript">
        function uncheckGraph(chart) {
            Highcharts.each(chart.series, function(p, i) {
                p.hide()
            });
        }

        function checkGraph(chart) {
            Highcharts.each(chart.series, function(p, i) {
                p.show()
            });
        }

        function chartLine(chart) {
            Highcharts.each(chart.series, function(p, i) {
                p.update({
                    type: "line"
                });
            });
        }

        function chartColumn(chart) {
            Highcharts.each(chart.series, function(p, i) {
                p.update({
                    type: "column"
                });
            });
        }
        $(function() {
            Highcharts.setOptions({
                lang: {
                    thousandsSep: ','
                }
            });

            var container = Highcharts.chart('container', {
                chart: {
                    zoomType: 'xy',
                    type: 'spline',
                    borderColor: "#000000",
                    borderWidth: 1,
                    height: 450
                },

                title: {
                    text: 'Max Connection WL1,WL2 : <?php echo date('d F Y H:i', strtotime($date_from)) ?> - <?php echo date('d F Y H:i', strtotime($date_to)) ?>',
                },
                subtitle: {
                    text: '<span style="color:#FF0080;font-weight: bold;">VIP-118</span> : <?php echo number_format($data_max_max['VIP-118']) ?> , <span style="color:#FF8C0A;font-weight: bold;">VIP-168</span> : <?php echo number_format($data_max_max['VIP-168']) ?> , <span style="color:#0000CD;font-weight: bold;">VIP-169</span> : <?php echo number_format($data_max_max['VIP-169']);?> , <span style="color:#006400;font-weight: bold;">VIP-170</span> : <?php echo number_format($data_max_max['VIP-170']) ?>',
                    align: 'center',
                    useHTML: true,
                    style: {
                        "fontSize": "14px"
                    }
                },

                xAxis: {
                    categories: [
                        <?php
                        foreach ($date as $value) {
                            echo "'" . (($check_date == 1) ? date('Y-m-d', strtotime($value)) : $value) .
                                "'" .
                                ",";
                        }
                        ?>
                    ],
                },

                yAxis: [{
                    // max: 500000,
                    min: 0,
                    title: {
                        text: 'Max Connection.'
                    },
                    stackLabels: {
                        enabled: true,
                        align: 'center',
                        style: {
                            fontWeight: 'normal',
                            color: 'black',
                            fontSize: '11px'
                        },
                        formatter: function() {
                            return Highcharts.numberFormat(this.total, 0)
                        }
                    }
                }],
                legend: {
                    // align: 'center',
                    // verticalAlign: 'bottom',
                    layout: 'horizontal', // default
                    // itemDistance: 1,
                    backgroundColor: '#ffffff',
                    borderColor: '#C98657',
                    borderWidth: 2,
                    // width: 800,
                    // itemWidth: 260,
                    // margin: 1000,
                    // itemMarginLeft: 50,
                    // itemDistance: 300
                },


                plotOptions: {
                    series: {
                        dataLabels: {
                            enabled: false,
                            format: '{point.y:,.0f}'
                        }
                    },
                    column: {
                        stacking: 'normal'
                    }

                },
                series: [
                    <?php
                    foreach ($type_Pm as $key_type => $value_type) {
                        ?> {
                            name: '<?php echo '<span style="color: green;">WL1-</span>' . $value_type  ?>',
                            data: [
                                <?php
                                    foreach ($date as $key_date => $value_date) {
                                        echo $data[$value_type][$value_date] . ',';
                                    }
                                    ?>
                            ],
                            color: "<?php echo $color1[$value_type] ?>",
                            legendIndex: <?php echo $legendIndex_wl1[$value_type] ?>,
                            marker: {
                                symbol: '<?php echo $marker1[$value_type] ?>',
                            }
                        },
                    <?php
                    }
                    ?>
                    <?php
                    foreach ($type_db2_Pm as $key_type => $value_type) {
                        ?> {
                            name: '<?php echo '<span style="color: red;">WL2-</span>' . $value_type ?>',
                            data: [
                                <?php
                                    foreach ($date_db2 as $key_date => $value_date) {
                                        echo $data_db2[$value_type][$value_date] . ',';
                                    }
                                    ?>
                            ],
                            dashStyle: 'shortdot',
                            color: "<?php echo $color2[$value_type] ?>",
                            legendIndex: <?php echo $legendIndex_wl2[$value_type] ?>,
                            marker: {
                                symbol: '<?php echo $marker2[$value_type] ?>',
                            }
                        },
                    <?php
                    }
                    ?>
                    <?php
                    foreach ($type_max as $key_max => $value_max) {
                        ?> {
                            name: '<?php echo $value_max; ?>',
                            data: [
                                <?php
                                    foreach ($date as $key_date => $value_date) {
                                        echo $data_max[$value_max][$value_date] . ',';
                                    }
                                    ?>
                            ],
                            color: "<?php echo $color1[$value_max] ?>",
                            legendIndex: <?php echo $legendIndex_wl1[$value_max] ?>,
                            marker: {
                                symbol: 'circle',
                                fillColor: '#FFFFFF',
                                lineWidth: 2,
                                lineColor: null // inherit from series
                            }
                            // dashStyle: 'LongDash'
                        },
                    <?php
                    }
                    ?>
                ],
                legend: {
                    layout: 'horizontal', // default
                    itemDistance: 1,
                    backgroundColor: '#ffffff',
                    borderColor: '#C98657',
                    borderWidth: 2,
                    // width: 800,
                    itemWidth: 150
                },
                tooltip: {
                    formatter: function() {
                        var s = [];
                        s.push('<span style="font-weight:bold;font-size:12px">' + this.x + '<span><br><span style="font-weight:bold;"><span><br><table>');
                        $.each(this.points, function(i, point) {
                            s.push('<tr><td><span style="color:' + this.series.color + ';font-weight:bold;">' + point.series.name + ' :</td><td>' + Highcharts.numberFormat(point.y, 0, '.', ',') + '<span></td></tr>');
                        });
                        s.push('</table>');
                        return s;
                    },
                    borderColor: '#000000',
                    useHTML: true,
                    shared: true
                },
                exporting: {
                    buttons: {
                        customButton: {
                            text: '<b>Uncheck</b>',
                            onclick: function() {
                                uncheckGraph(container);
                            }
                        },
                        anotherButton: {
                            text: "<b>Show all</b>",
                            onclick: function() {
                                checkGraph(container);
                            }
                        },
                        // lineButton: {
                        //     text: "<b>[Line]</b>",
                        //     onclick: function() {
                        //         chartLine(container);
                        //     }
                        // },
                        // columnButton: {
                        //     text: "<b>[Stacked column]</b>",
                        //     onclick: function() {
                        //         chartColumn(container);
                        //     }
                        // },
                    }
                }
            });
        });
    </script>

    <!-- jQuery first, then Tether, then Bootstrap JS. -->
	<script src="js/bootstrap.min2.js" integrity="sha384-vBWWzlZJ8ea9aCX4pEW3rVHjgjt7zpkNpZk+02D9phzyeVkE+jo0ieGizqPLForn" crossorigin="anonymous"></script>

    <script type="text/javascript" src="js/bootstrap-datetimepicker.js" charset="UTF-8"></script>
    <script type="text/javascript">
        $('.form_datetime').datetimepicker({
            format: 'yyyy-mm-dd hh:00',
            minView: 1
        });
    </script>

</body>

</html>