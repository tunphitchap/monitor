<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta name="viewport" content="initial-scale=1.0, maximum-scale=2.0">
    <meta name="description" content="">
    <meta name="author" content="">
    <link rel="icon" href="../../favicon.ico">

    <title>Log Monitor</title>

    <?php include("import_lib.php"); ?>
    <script src="js/jquery-3.1.1.min.js"></script>
    <link href="css/navbar-top-fixed.css" rel="stylesheet">

  <script language="javascript">
function js_popup(theURL,width,height) { //v2.0
  leftpos = (screen.availWidth - width) / 2;
      toppos = (screen.availHeight - height) / 2;
    window.open(theURL, "viewdetails","width=" + width + ",height=" + height + ",left=" + leftpos + ",top=" + toppos);
}
</script>

<style type="text/css">
.textAlignVer{
  font-size:12px;
}
.textAlignVerRotate{
  display:block;
  -webkit-transform: rotate(-90deg);
  -moz-transform: rotate(-90deg);
  font-size:12px;
}
.data113 a{
    color: red;
    text-decoration: none;
}
.data114 a{
    color: blue;
    text-decoration: none;
}
a:hover{
  text-decoration: none;
}
</style>


    <!-- Custom styles for this template -->
  </head>
<?php
  date_default_timezone_set('Asia/Bangkok');
  include "connect208.php";

?>
  <body>

<?php 
include("menu_top.php");

if(!empty($_GET['type_dropdown']))
{
  if($_GET['type_dropdown']=="lastweek")
  {
     $name_dropdown="Last Week";
      $dstart=date('Y-m-d');
      $dendd=date("Y-m-d", strtotime('-7 days'));
      $dend=date("Y-m-d", strtotime('-6 days'));
      $lastday=DateDiff("".$dendd."","".$dstart."");
      $j=0;
  }
  elseif($_GET['type_dropdown']=="lastmonth")
  {
     $name_dropdown="Last Month";
      $dstart=date('Y-m-d');
      $dend=date("Y-m-d", strtotime('-1 month'));
      $lastday=DateDiff("".$dend."","".$dstart."")+1;
      $j=0;
  }
  elseif($_GET['type_dropdown']=="previousmonth")
  {
     $dstart=date('Y-m-t', strtotime('-1 month'));
     $dend=date("Y-m-01", strtotime('-1 month'));
     $name_dropdown="Previous Month";
     $lastday=date("t", strtotime('-1 month'));
  }
}
elseif(!empty($_GET['date_form']))
{

    if($_GET['date_to']>date('Y-m-d'))
      {
        $dstart=date('Y-m-d');
      }
      else
      {
        $dstart=$_GET['date_to'];
      }

  $dend=$_GET['date_form'];
  $name_dropdown="Custom";
  $lastday=DateDiff("".$_GET['date_form']."","".$dstart."")+1;
  $j=0;
}
elseif(empty($_GET['date_form']) and empty($_GET['type_dropdown']))
{
  $name_dropdown="Last Week";
  $dstart=date('Y-m-d');
  $dendd=date("Y-m-d", strtotime('-7 days'));
  $dend=date("Y-m-d", strtotime('-6 days'));
  $lastday=DateDiff("".$dendd."","".$dstart."");
  $j=0;
}


include("menu_date_detail.php");

 function DateDiff($strDate1,$strDate2)
   {
        return (strtotime($strDate2) - strtotime($strDate1))/  ( 60 * 60 * 24 );  // 1 day = 60*60*24
   }
   function TimeDiff($strTime1,$strTime2)
   {
        return (strtotime($strTime2) - strtotime($strTime1))/  ( 60 * 60 ); // 1 Hour =  60*60
   }
   function DateTimeDiff($strDateTime1,$strDateTime2)
   {
        return (strtotime($strDateTime2) - strtotime($strDateTime1))/  ( 60 * 60 ); // 1 Hour =  60*60
   }

$colorcode = array("Sun" => "#FF0000","Mon" => "#FFFF00","Tue" => "PINK","Wed" => "#00FF00","Thu" => "#FF8000","Fri" => "#00FFFF","Sat" => "#D358F7",);

$timehour = array(
  "00" => "00:00-00:59",
  "01" => "01:00-01:59",
  "02" => "02:00-02:59",
  "03" => "03:00-03:59",
  "04" => "04:00-04:59",
  "05" => "05:00-05:59",
  "06" => "06:00-06:59",
  "07" => "07:00-07:59",
  "08" => "08:00-08:59",
  "09" => "09:00-09:59",
  "10" => "10:00-10:59",
  "11" => "11:00-11:59",
  "12" => "12:00-12:59",
  "13" => "13:00-13:59",
  "14" => "14:00-14:59",
  "15" => "15:00-15:59",
  "16" => "16:00-16:59",
  "17" => "17:00-17:59",
  "18" => "18:00-18:59",
  "19" => "19:00-19:59",
  "20" => "20:00-20:59",
  "21" => "21:00-21:59",
  "22" => "22:00-22:59",
  "23" => "23:00-23:59"
  );




?>
<div class="container">
<div class="row" align="center">
  <div class="col-md-12 col-sm-12">
    <h5>F5 LTM LOG 113 - 114</h5>
    Date <?php echo ": ".$dend." to ".$dstart;?>
  </div>
  <div class="col-md-12 col-sm-12" align="right">
    <table border="0" style="width: 15%">
    <tr>
      <td width="5%">
        <button style="background-color: blue;" type="button" class="btn"></button>
      </td>
      <td>
        <font size="-1"> Status : Packet rejected</font>
      </td>
    </tr>
    </table>
    
  </div>
   <div class="col-md-12 col-sm-12" align="right">
    <table border="0" style="width: 15%">
    <tr>
      <td width="5%">
        <button style="background-color: red;" type="button" class="btn"></button>
      </td>
      <td>
        <font size="-1"> Status : Down</font>
      </td>
    </tr>
    </table>
  </div>
</div>
<table border="1" width="100%" style="margin-top: 1%;">
  <tr bgcolor="#eaeae1">
    <td height="90px;" width="100px;" align="center" colspan="2">
    <span class="textAlignVer">
    <strong>Date/Time</strong>
    </span></td>
    <td height="90px;" width="40px;" align="center"></td>
<?php
foreach($timehour as $value)
{
  ?>
<td height="90px;" width="30px;">
    <div style="width:30px;height:90px;">
       <svg>
          <text transform="rotate(270, 12, 0) translate(-75,5)"><?php echo $value?></text>
      </svg>
    </div>
</td>
  <?
}
   ?>
    <td height="90px;" align="center"><span class="textAlignVer"><strong>Remark</strong></span></td>
  </tr>

  <?php

for($i=$lastday;$i>=1;$i--)
{
    if(!empty($_GET['date_form']))
    {
      if($_GET['date_to']>date('Y-m-d'))
      {
        $dato=date('Y-m-d');
      }
      else
      {
        $dato=$_GET['date_to'];
      }
          $DAYENG=date("D", strtotime('-'.$j.' days',strtotime($dato)));
          $datestart=date("Y-m-d", strtotime('-'.$j.' days',strtotime($dato)));
          $dateview=date("d-m-Y", strtotime('-'.$j.' days',strtotime($dato)));
          $j++;
    }
    elseif(!empty($_GET['type_dropdown']))
    {
      if($_GET['type_dropdown']=="previousmonth")
      {
          $premonth=date("Y-m", strtotime('-1 month'));
          // date("Y-m-d", strtotime($premonth.'-'.$i));
          $DAYENG=date("D", strtotime($premonth.'-'.$i));
          $datestart=date("Y-m-d", strtotime($premonth.'-'.$i)); 
          $dateview=date("d-m-Y", strtotime($premonth.'-'.$i));
      }
      else
      {
          $DAYENG=date("D", strtotime('-'.$j.' days'));
          $datestart=date("Y-m-d", strtotime('-'.$j.' days'));
          $dateview=date("d-m-Y", strtotime('-'.$j.' days'));
          $j++;
      }
    }
    elseif(empty($_GET['date_form']) and empty($_GET['type_dropdown']))
    {
          $DAYENG=date("D", strtotime('-'.$j.' days'));
          $datestart=date("Y-m-d", strtotime('-'.$j.' days'));
          $dateview=date("d-m-Y", strtotime('-'.$j.' days'));
         $j++;
    }


?>
<tr>
<td width="50px;" rowspan="2" bgcolor="<?php echo $colorcode[$DAYENG];?>" align="center"><span class="textAlignVer"><strong>
    <?php echo $DAYENG;?></strong></span></td>
</td>
<td width="80px;" rowspan="2" align="center"><span class="textAlignVer"><?php echo $dateview;?></span></td>
<td align="center"><span class="textAlignVer">113</span></td>
 <?php 
    // for($j=0;$j<count($timehour);$j++)
    foreach($timehour as $valuehour => $valuekey)
    {
$countchk=mysqli_query($con,"select count(*) as cntlog from (SELECT TIME_FORMAT(datetime, '%H:%i') AS time_str
  FROM f5_ltm_log
 WHERE     date_format(datetime, '%Y-%m-%d') = '".$datestart."'
       AND ltmlog LIKE '%down%'
       AND TIME_FORMAT(datetime, '%H')='".$valuehour."'
       AND host='10.11.11.113'
GROUP BY TIME_FORMAT(datetime, '%H:%i')) aa");
$rowcountchk=mysqli_fetch_array($countchk);
if($rowcountchk[0]==0)
{
$data113="";
$data113_show="";
}
elseif($rowcountchk[0]>1)
{
$query_time_str_113=mysqli_query($con,"SELECT TIME_FORMAT(datetime, '%H:%i') AS time_str
                      FROM f5_ltm_log
                     WHERE     date_format(datetime, '%Y-%m-%d') = '".$datestart."'
                           AND ltmlog LIKE '%down%'
                           AND TIME_FORMAT(datetime, '%H')='".$valuehour."'
                           AND host='10.11.11.113'
                    GROUP BY TIME_FORMAT(datetime, '%H:%i')
                     LIMIT 1");
$row_time_str_113=mysqli_fetch_array($query_time_str_113);
$query_time_end_113=mysqli_query($con,"SELECT TIME_FORMAT(datetime, '%H:%i') AS time_end
                        FROM f5_ltm_log
                       WHERE     date_format(datetime, '%Y-%m-%d') = '".$datestart."'
                             AND ltmlog LIKE '%down%'
                             AND TIME_FORMAT(datetime, '%H')='".$valuehour."'
                             AND host='10.11.11.113'
                      GROUP BY TIME_FORMAT(datetime, '%H:%i')
                      ORDER BY TIME_FORMAT(datetime, '%H:%i') DESC
                       LIMIT 1");
$row_time_end_113=mysqli_fetch_array($query_time_end_113);

$data113=$row_time_str_113[0]."-<br/>".$row_time_end_113[0];
$data113_show=$row_time_str_113[0]."-".$row_time_end_113[0];
}
else
{

  $query_time_str_113=mysqli_query($con,"SELECT TIME_FORMAT(datetime, '%H:%i') AS time_str
                      FROM f5_ltm_log
                     WHERE     date_format(datetime, '%Y-%m-%d') = '".$datestart."'
                           AND ltmlog LIKE '%down%'
                           AND TIME_FORMAT(datetime, '%H')='".$valuehour."'
                           AND host='10.11.11.113'
                    GROUP BY TIME_FORMAT(datetime, '%H:%i')
                     LIMIT 1");
$row_time_str_113=mysqli_fetch_array($query_time_str_113);
$data113=$row_time_str_113[0];
$data113_show=$row_time_str_113[0];
}

      ?>
        <td>
          <span class="textAlignVer">
            <font class="data113 a">
              <a href="#" onClick="js_popup('f5_ltm_log_detail_edit.php?date=<?php echo $datestart;?>&timehour=<?php echo $data113_show;?>&hour=<?php echo $valuehour;?>&host=113&status=down',1300,600); return false;" title="Code PHP Popup"><?php echo $data113;?></a>
            </font>
          </span>
        </td>
      <?
    }

$query_re_113=mysqli_query($con,"select concat(time_hour,'_',data_remark) as detailremark,status from f5_ltm_log_remark where date_remark='".$datestart."' and host='10.11.11.113' order by time_hour");
    ?>
    <td><span class="textAlignVer">
    <?php
    $data_re_113='';
    while($row_re_113=mysqli_fetch_array($query_re_113))
    {
        if($row_re_113[1]=="down")
       {
        echo " <font color=\"red\">".$row_re_113[0]."</font><br/>";
       }
       elseif($row_re_113[1]=="reject")
       {
        echo " <font color=\"blue\">".$row_re_113[0]."</font><br/>";
       }
    } 

    ?>
    </span></td>
  </tr>
<tr>
  <td align="center"><span class="textAlignVer">114</span></td>
<?php 
    // for($j=0;$j<count($timehour);$j++)
    foreach($timehour as $valuehour => $valuekey)
    {

// LOG DOWN
$countchkdown=mysqli_query($con,"select count(*) as cntlog from (SELECT TIME_FORMAT(datetime, '%H:%i') AS time_str
  FROM f5_ltm_log
 WHERE     date_format(datetime, '%Y-%m-%d') = '".$datestart."'
       AND ltmlog LIKE '%down%'
       AND TIME_FORMAT(datetime, '%H')='".$valuehour."'
       AND host='10.11.11.114'
GROUP BY TIME_FORMAT(datetime, '%H:%i')) aa");
$rowcountchkdown=mysqli_fetch_array($countchkdown);
if($rowcountchkdown[0]==0)
{
$data114_down="";
}
elseif($rowcountchkdown[0]>1)
{
$query_timedown_str_114=mysqli_query($con,"SELECT TIME_FORMAT(datetime, '%H:%i') AS time_str
                      FROM f5_ltm_log
                     WHERE     date_format(datetime, '%Y-%m-%d') = '".$datestart."'
                           AND ltmlog LIKE '%down%'
                           AND TIME_FORMAT(datetime, '%H')='".$valuehour."'
                           AND host='10.11.11.114'
                    GROUP BY TIME_FORMAT(datetime, '%H:%i')
                     LIMIT 1");
$row_timedown_str_114=mysqli_fetch_array($query_timedown_str_114);
$query_timedown_end_114=mysqli_query($con,"SELECT TIME_FORMAT(datetime, '%H:%i') AS time_end
                        FROM f5_ltm_log
                       WHERE     date_format(datetime, '%Y-%m-%d') = '".$datestart."'
                             AND ltmlog LIKE '%down%'
                             AND TIME_FORMAT(datetime, '%H')='".$valuehour."'
                             AND host='10.11.11.114'
                      GROUP BY TIME_FORMAT(datetime, '%H:%i')
                      ORDER BY TIME_FORMAT(datetime, '%H:%i') DESC
                       LIMIT 1");
$row_timedown_end_114=mysqli_fetch_array($query_timedown_end_114);

$data114_down=$row_timedown_str_114[0]."-<br/>".$row_timedown_end_114[0];
$data114down_show=$row_timedown_str_114[0]."-".$row_timedown_end_114[0];
}
else
{

  $query_timedown_str_114=mysqli_query($con,"SELECT TIME_FORMAT(datetime, '%H:%i') AS time_str
                      FROM f5_ltm_log
                     WHERE     date_format(datetime, '%Y-%m-%d') = '".$datestart."'
                           AND ltmlog LIKE '%down%'
                           AND TIME_FORMAT(datetime, '%H')='".$valuehour."'
                           AND host='10.11.11.114'
                    GROUP BY TIME_FORMAT(datetime, '%H:%i')
                     LIMIT 1");
$row_timedown_str_114=mysqli_fetch_array($query_timedown_str_114);
$data114_down=$row_timedown_str_114[0];
$data114down_show=$row_timedown_str_114[0];
}
// LOG DOWN    


$countchk=mysqli_query($con,"select count(*) as cntlog from (SELECT TIME_FORMAT(datetime, '%H:%i') AS time_str
  FROM f5_ltm_log
 WHERE     date_format(datetime, '%Y-%m-%d') = '".$datestart."'
       AND ltmlog LIKE '%Packet rejected%'
       AND TIME_FORMAT(datetime, '%H')='".$valuehour."'
       AND host='10.11.11.114'
GROUP BY TIME_FORMAT(datetime, '%H:%i')) aa");
$rowcountchk=mysqli_fetch_array($countchk);
if($rowcountchk[0]==0)
{
$data114="";
$data114_show="";
}
elseif($rowcountchk[0]>1)
{
$query_time_str_114=mysqli_query($con,"SELECT TIME_FORMAT(datetime, '%H:%i') AS time_str
                      FROM f5_ltm_log
                     WHERE     date_format(datetime, '%Y-%m-%d') = '".$datestart."'
                           AND ltmlog LIKE '%Packet rejected%'
                           AND TIME_FORMAT(datetime, '%H')='".$valuehour."'
                           AND host='10.11.11.114'
                    GROUP BY TIME_FORMAT(datetime, '%H:%i')
                     LIMIT 1");
$row_time_str_114=mysqli_fetch_array($query_time_str_114);
$query_time_end_114=mysqli_query($con,"SELECT TIME_FORMAT(datetime, '%H:%i') AS time_end
                        FROM f5_ltm_log
                       WHERE     date_format(datetime, '%Y-%m-%d') = '".$datestart."'
                             AND ltmlog LIKE '%Packet rejected%'
                             AND TIME_FORMAT(datetime, '%H')='".$valuehour."'
                             AND host='10.11.11.114'
                      GROUP BY TIME_FORMAT(datetime, '%H:%i')
                      ORDER BY TIME_FORMAT(datetime, '%H:%i') DESC
                       LIMIT 1");
$row_time_end_114=mysqli_fetch_array($query_time_end_114);

$data114=$row_time_str_114[0]."-<br/>".$row_time_end_114[0];
$data114_show=$row_time_str_114[0]."-".$row_time_end_114[0];
}
else
{

  $query_time_str_114=mysqli_query($con,"SELECT TIME_FORMAT(datetime, '%H:%i') AS time_str
                      FROM f5_ltm_log
                     WHERE     date_format(datetime, '%Y-%m-%d') = '".$datestart."'
                           AND ltmlog LIKE '%Packet rejected%'
                           AND TIME_FORMAT(datetime, '%H')='".$valuehour."'
                           AND host='10.11.11.114'
                    GROUP BY TIME_FORMAT(datetime, '%H:%i')
                     LIMIT 1");
$row_time_str_114=mysqli_fetch_array($query_time_str_114);
$data114=$row_time_str_114[0];
$data114_show=$row_time_str_114[0];

}
      ?>
        <td>
         <span class="textAlignVer">
          <?php if(!empty($data114_down)){?>
             <font class="data113 a">
              <a href="#" onClick="js_popup('f5_ltm_log_detail_edit.php?date=<?php echo $datestart;?>&timehour=<?php echo $data114down_show;?>&hour=<?php echo $valuehour;?>&host=114&status=down',1300,580); return false;" title="Code PHP Popup"><?php echo $data114_down;?></a>
            </font>
            <br/>
          <?php } ?>
            <font class="data114 a">
              <a href="#" onClick="js_popup('f5_ltm_log_detail_edit.php?date=<?php echo $datestart;?>&timehour=<?php echo $data114_show;?>&hour=<?php echo $valuehour;?>&host=114&status=reject',1300,580); return false;" title="Code PHP Popup"><?php echo $data114;?></a>
            </font>
          </span>
        </td>
      <?
    }
$query_re_114=mysqli_query($con,"select concat(time_hour,'_',data_remark) as detailremark,status  from f5_ltm_log_remark where date_remark='".$datestart."' and host='10.11.11.114' order by time_hour");
    ?>
     <td>
     <span class="textAlignVer">
        <?php
    $data_re_114='';
    while($row_re_114=mysqli_fetch_array($query_re_114))
    {
     
       if($row_re_114[1]=="down")
       {
         echo " <font color=\"red\">".$row_re_114[0]."</font><br/>";
       }
       elseif($row_re_114[1]=="reject")
       {
         echo " <font color=\"blue\">".$row_re_114[0]."</font><br/>";
       }
    } 
     // echo substr($data_re_114,0,-2);
    ?>
     </span>
     </td>
  </tr>
<?php
}
  ?>
  </table>
</div>
<br/><br/>


<!-- jQuery first, then Tether, then Bootstrap JS. -->
<script src="js/bootstrap.min2.js" integrity="sha384-vBWWzlZJ8ea9aCX4pEW3rVHjgjt7zpkNpZk+02D9phzyeVkE+jo0ieGizqPLForn" crossorigin="anonymous"></script>

<script type="text/javascript" src="js/bootstrap-datetimepicker.js" charset="UTF-8"></script>

<script type="text/javascript">
    $('.form_datetime').datetimepicker({
        //language:  'fr',
      
      weekStart: 1,
        todayBtn:  1,
    autoclose: 1,
    todayHighlight: 1,
     startView: 2,
    minView: 2,
    forceParse: 0,
        showMeridian: 1
    });

</script>
  </body>
</html>
