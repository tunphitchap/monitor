<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta name="description" content="">
    <meta name="author" content="">
    <link rel="icon" href="../../favicon.ico">

    <title>Radius-Monitor</title>

    <?php include("import_lib.php"); ?>
    <link href="css/navbar-top-fixed.css" rel="stylesheet">

     <style type="text/css">
     table, th, td {
		  border: 1px solid black;
		  border-collapse: collapse;
		}
       .textAlignVer{
       font-size:12px;
       }
       .textAlignVerRotate{
       display:block;
       -webkit-transform: rotate(-90deg);
       -moz-transform: rotate(-90deg);
       font-size:12px;
       }
       a:hover{
       text-decoration: none;
       }
     </style>

     <style>
       .highcharts-container {
           overflow: visible !important;
       }
       .MyChartTooltip {
           position: relative;
           z-index: 50;
           border-radius: 5px;
           background-color: #ffffff;
           padding: 5px;
           font-size: 9pt;
           y: -1;
           overflow: auto;

       }
       .highcharts-tooltip {
         pointer-events: all !important;
       }
    </style>
</head>

<script src="js/jquery-3.1.1.min.js"></script>
<script src="code/highcharts.js"></script>
<script src="code/highcharts-3d.js"></script>
<script src="code/modules/exporting.js"></script>
<body>

<?php 
  date_default_timezone_set('Asia/Bangkok');
  include("menu_top.php");
  include "connect208.php";
?>

<?php
  function space($cnt){
    $space='';
    for ($i=0;$i<$cnt;$i++){
      $space=$space.'&nbsp;';
    }
    return $space;
  }

  // PERIOD //
  $dropdown_name='';
  if(isset($_GET['duration'])){
      if($_GET['duration']=='thisyear'){
        $dropdown_name='This Year';
        $start_month = date('Y-01');
        $end_month = date('Y-m');
      }
      if($_GET['duration']=='lastyear'){
        $dropdown_name='Last Year';
        $start_month = date('Y-m',strtotime(date("Y-m-d")."-1 year -1 month"));
        $end_month =date("Y-m",strtotime('-1 month'));
      }
  }
  else{
      $dropdown_name='This Year';
      $start_month = date('Y-01');
      $end_month = date('Y-m');
  }

  if(isset($_GET['start_month'])&&isset($_GET['end_month'])){
    $dropdown_name = 'Custom';
    $start_month = $_GET['start_month'];
    $end_month = $_GET['end_month'];
  }?>

<div class="container">
<div class="col-md-12">
      <div style="line-height: 10px;"><font color="blue">Count HWDN</font></div>
    </div></div><br>

<div class="container">
  <form method='get'>
  <div class="row">
  <div align="right" class="col-md-2"><b>Start Month</b></div>
  <div class="input-group date form_datetime col-md-2" data-date="" data-date-format="yyyy-mm" data-link-field="dtp_input1">
   <input name='start_month' id='start_month' class="form-control" size="10" type="text" value="<?php echo $start_month;?>" readonly>
    <span class="input-group-addon"><span class="glyphicon glyphicon-calendar"><i class="fa fa-th" aria-hidden="true"></i></span></span></div>

  <div align="right" class="col-md-2"><b>End Month</b></div>
    <div class="input-group date form_datetime col-md-2" data-date="" data-date-format="yyyy-mm" data-link-field="dtp_input1">
   <input name='end_month' id='end_month' class="form-control" size="10" type="text" value="<?php echo $end_month;?>" readonly>
    <span class="input-group-addon"><span class="glyphicon glyphicon-calendar"><i class="fa fa-th" aria-hidden="true"></i></span></span></div>


<div class="col-md-3">
    <div class="btn-group">
    <button type="button" class="btn btn-secondary"><?php echo $dropdown_name; ?></button> 
    <button type="button" class="btn btn-danger dropdown-toggle dropdown-toggle-split" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
    <span class="sr-only">Toggle Dropdown</span></button>
    <div class="dropdown-menu">
    <a class="dropdown-item" href="cnt_hwdn.php?duration=thisyear">This Year</a>
    <a class="dropdown-item" href="cnt_hwdn.php?duration=lastyear">Last Year</a>
</div>

  <div align="right" class="col-md-2"><button type="submit" class="btn btn-default">Submit</button></div>
  </div></form>
</div><br>


<?php
  if(strtotime($end_month) - strtotime($start_month) < 0){
    echo"<script language=\"JavaScript\">";
    echo"alert('เลือกช่วงเวลาไม่ถูกต้อง')";
    echo"</script>";    
  }
  else{





	// DATA //
	$data=array();
	$sql=mysqli_query($con, "SELECT * FROM cnt_hwdn WHERE fdate BETWEEN '".date('Y-m-01',strtotime($start_month))."'
    AND '".date('Y-m-01',strtotime($end_month))."' ORDER BY fdate ASC;");
	while ($result=mysqli_fetch_array($sql)) {
		$data[date('Y-m',strtotime($result['fdate']))][$result['domain']][$result['hwdn']]=$result['cnt'];

	}


  

?>




<div class="container">
<div class="row" align="center">
  <div class="col-md-12 col-sm-12">
  </div>
</div><br>


<div class="row" align="center">
  <div class="col-md-11 col-sm-11">
			<table id="t01" width='40%'>
				<tr>
          <td></td>
          <td colspan=8 bgcolor='#8cff66' align='center'>Domain indy ราคา >= 900</td>
          <td colspan=9 bgcolor='#66b3ff' align='center'>Domain fttx ราคา < 900</td></tr>
				<tr>
          <td><?php echo space(18);?></td>
          <td align='center' bgcolor='#8cff66'>&nbsp;&nbsp;TOTAL&nbsp;&nbsp;</td>
          <td align='center' bgcolor='#8cff66'>&nbsp;&nbsp;3bbfttx&nbsp;&nbsp;</td>
					<td align='center' bgcolor='#8cff66'>&nbsp;&nbsp;3bbnex&nbsp;&nbsp;</td>
          <td align='center' bgcolor='#8cff66'>&nbsp;&nbsp;indy6&nbsp;&nbsp;</td>
          <td align='center' bgcolor='#8cff66'>&nbsp;&nbsp;nex6&nbsp;&nbsp;</td>
          <td align='center' bgcolor='#8cff66'>&nbsp;&nbsp;nat444&nbsp;&nbsp;</td>
          <td align='center' bgcolor='#8cff66'>&nbsp;&nbsp;nat444v6&nbsp;&nbsp;</td>
          <td align='center' bgcolor='#8cff66'>&nbsp;&nbsp;fixip&nbsp;&nbsp;</td>
          <td align='center' bgcolor='#66b3ff'>&nbsp;&nbsp;TOTAL&nbsp;&nbsp;</td>
          <td align='center' bgcolor='#66b3ff'>&nbsp;&nbsp;3bb&nbsp;&nbsp;</td>
          <td align='center' bgcolor='#66b3ff'>&nbsp;&nbsp;3bbfttx&nbsp;&nbsp;</td>
          <td align='center' bgcolor='#66b3ff'>&nbsp;&nbsp;3bbnex&nbsp;&nbsp;</td>
          <td align='center' bgcolor='#66b3ff'>&nbsp;&nbsp;indy6&nbsp;&nbsp;</td>
          <td align='center' bgcolor='#66b3ff'>&nbsp;&nbsp;nex6&nbsp;&nbsp;</td>
          <td align='center' bgcolor='#66b3ff'>&nbsp;&nbsp;nat444&nbsp;&nbsp;</td>
          <td align='center' bgcolor='#66b3ff'>&nbsp;&nbsp;nat444v6&nbsp;&nbsp;</td>
          <td align='center' bgcolor='#66b3ff'>&nbsp;&nbsp;fixip&nbsp;&nbsp;</td>
				</tr>
        <?php
            $month_tmp=$start_month;
            while(date("Y-m",strtotime($month_tmp))!=date("Y-m",strtotime($end_month." +1 month"))){
        ?>
				<tr>
          <td align='right' bgcolor='#d9d9d9'><?php echo date('M-y',strtotime($month_tmp));?>&nbsp;&nbsp;</td>
					<td align='right'>
            <?php if($data[$month_tmp]['3bb']['all']!=0) echo number_format($data[$month_tmp]['3bb']['all']);?>&nbsp;&nbsp;</td>
          <td align='right'>
            <?php if($data[$month_tmp]['3bb']['3bbfttx']!=0) echo number_format($data[$month_tmp]['3bb']['3bbfttx']);?>&nbsp;&nbsp;</td>
          <td align='right'>
            <?php if($data[$month_tmp]['3bb']['3bbnex']!=0) echo number_format($data[$month_tmp]['3bb']['3bbnex']);?>&nbsp;&nbsp;</td>
          <td align='right'>
            <?php if($data[$month_tmp]['3bb']['indy6']!=0) echo number_format($data[$month_tmp]['3bb']['indy6']);?>&nbsp;&nbsp;</td>
          <td align='right'>
            <?php if($data[$month_tmp]['3bb']['nex6']!=0) echo number_format($data[$month_tmp]['3bb']['nex6']);?>&nbsp;&nbsp;</td>
          <td align='right'>
            <?php if($data[$month_tmp]['3bb']['nat444']!=0) echo number_format($data[$month_tmp]['3bb']['nat444']);?>&nbsp;&nbsp;</td>
          <td align='right'>
            <?php if($data[$month_tmp]['3bb']['nat444v6']!=0) echo number_format($data[$month_tmp]['3bb']['nat444v6']);?>&nbsp;&nbsp;</td>
          <td align='right'>
            <?php if($data[$month_tmp]['3bb']['fixip']!=0) echo number_format($data[$month_tmp]['3bb']['fixip']);?>&nbsp;&nbsp;</td>
          <td align='right'>
            <?php if($data[$month_tmp]['3bbfttx']['all']!=0) echo number_format($data[$month_tmp]['3bbfttx']['all']);?>&nbsp;&nbsp;</td>
          <td align='right'>
            <?php if($data[$month_tmp]['3bbfttx']['3bb']!=0) echo number_format($data[$month_tmp]['3bbfttx']['3bb']);?>&nbsp;&nbsp;</td>
          <td align='right'>
            <?php if($data[$month_tmp]['3bbfttx']['3bbfttx']!=0) echo number_format($data[$month_tmp]['3bbfttx']['3bbfttx']);?>&nbsp;&nbsp;</td>
          <td align='right'>
            <?php if($data[$month_tmp]['3bbfttx']['3bbnex']!=0) echo number_format($data[$month_tmp]['3bbfttx']['3bbnex']);?>&nbsp;&nbsp;</td>
          <td align='right'>
            <?php if($data[$month_tmp]['3bbfttx']['indy6']!=0) echo number_format($data[$month_tmp]['3bbfttx']['indy6']);?>&nbsp;&nbsp;</td>
          <td align='right'>
            <?php if($data[$month_tmp]['3bbfttx']['nex6']!=0) echo number_format($data[$month_tmp]['3bbfttx']['nex6']);?>&nbsp;&nbsp;</td>
          <td align='right'>
            <?php if($data[$month_tmp]['3bbfttx']['nat444']!=0) echo number_format($data[$month_tmp]['3bbfttx']['nat444']);?>&nbsp;&nbsp;</td>
          <td align='right'>
            <?php if($data[$month_tmp]['3bbfttx']['nat444v6']!=0) echo number_format($data[$month_tmp]['3bbfttx']['nat444v6']);?>&nbsp;&nbsp;</td>
          <td align='right'>
            <?php if($data[$month_tmp]['3bbfttx']['fixip']!=0) echo number_format($data[$month_tmp]['3bbfttx']['fixip']);?>&nbsp;&nbsp;</td>
				</tr>
        <?php
            $month_tmp=date("Y-m",strtotime( "+1 month", strtotime($month_tmp)));
            }
        ?>
			</table>
  </div>
</div><br>
</body>

<div class="container">
<div class="row" align="left">
  <div class="col-md-12 col-sm-12"><br>
    <?php echo space(8);?><b>*หมายเหตุ*</b><br>
    <?php echo space(15);?>1. Domain indy ราคา >= 900 ที่มี fix ip คือ packet + 1 fix ip<br>
    <?php echo space(15);?>2. Domain fttx ราคา < 900 ที่มี fix ip คือ พวกที่แถม LL & cust type = Government, Business, Internal Operation ที่ราคา = 0
  </div>
</div><br>

<?php } // END CHECK DATE CORRECT? ?>


<!-- jQuery first, then Tether, then Bootstrap JS. -->
<script src="js/bootstrap.min2.js" integrity="sha384-vBWWzlZJ8ea9aCX4pEW3rVHjgjt7zpkNpZk+02D9phzyeVkE+jo0ieGizqPLForn" crossorigin="anonymous"></script>

<script type="text/javascript" src="js/bootstrap-datetimepicker.js" charset="UTF-8"></script>
<script type="text/javascript">
    $('.form_datetime').datetimepicker({
      todayBtn:  1,
  		autoclose: 1,
  		todayHighlight: 1,
  		startView: 3,
  		minView: 3,
  		forceParse: 0,
      	showMeridian: 1,
    });

</script>
</html>