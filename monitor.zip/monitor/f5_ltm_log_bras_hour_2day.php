
<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta name="description" content="">
    <meta name="author" content="">
    <link rel="icon" href="../../favicon.ico">

    <title>Radius-Monitor</title>

    <?php include("import_lib.php"); ?>
    <link href="css/navbar-top-fixed.css" rel="stylesheet">


<!-- _____________________________________________ Oat _______________________________________ -->
 <script language="javascript">
 function js_popup(theURL,width,height) { //v2.0
 leftpos = (screen.availWidth - width) / 2;
     toppos = (screen.availHeight - height) / 2;
   window.open(theURL, "viewdetails","width=" + width + ",height=" + height + ",left=" + leftpos + ",top=" + toppos);
 }
 </script>

 <style type="text/css">
 .textAlignVer{
 font-size:12px;
 }
 .textAlignVerRotate{
 display:block;
 -webkit-transform: rotate(-90deg);
 -moz-transform: rotate(-90deg);
 font-size:12px;
 }
 .data113 a{
   color: red;
   text-decoration: none;
 }
 .data114 a{
   color: blue;
   text-decoration: none;
 }
 a:hover{
 text-decoration: none;
 }
 </style>
<!-- _____________________________________________ Oat _______________________________________ -->


 <style>
 .highcharts-container {
     overflow: visible !important;
 }
 .MyChartTooltip {
     position: relative;
     z-index: 50;
     /*border: 2px solid rgb(0, 108, 169);  ไว้ใส่กรอบ*/
     border-radius: 5px;
     background-color: #ffffff;
     padding: 5px;
     font-size: 9pt;
     overflow: auto;
     height: 250px; /* กำหนดความสูง */
 }
 .highcharts-tooltip {
   pointer-events: all !important;
 }
 </style>

  </head>


<!-- start chart ltm log -->
<?php
  date_default_timezone_set('Asia/Bangkok');
  include "connect208.php";
  $duration='';
  $name_dropdown = 'Last 2 Days';

//if($_GET['date'] != ""){
if(isset($_GET['date'])){
	$date_from = $_GET['date'];
  $date_from = date('Y-m-d H:00',strtotime($date_from)); // แปลงให้เหลือ แต่ ปี วัน เดือน
	// $day = $_GET['date'];
  $today = date("Y-m-d H:00");  // Edit
  // $time_from = $_GET['time'];
  $time_from = date('H:i',strtotime($date_from)); // แปลงให้เหลือแต่ ชั่วโมง:นาที
  $startdate_hour = date("Y-m-d",strtotime($date_from)).' '.date("H",strtotime($time_from)).':00';
  $name_dropdown = 'Custom';
}else{
  if(isset($_GET['duration'])){ //NO CUSTOM => CHECK DROPDOWN ITEM
    switch($_GET['duration']){
      case "lastday": //DROPDOWN = LASTMONTH
        $today = date("Y-m-d H:00");
        //$startdate_hour = date('Y-m-d H:i',strtotime($startdate_hour . "+0 hour"));
        //$today2 = date("Y-m-d H:i");
        //$time_from = date("H:i");
        //$today2 = date('Y-m-d H:i',strtotime($today2 . "-1 hour"));
        $date_from = date('Y-m-d H:00',strtotime($today . "-24 hour"));
        // $time_from = $_GET['time'];
        $time_from = date('H:i',strtotime($date_from));
        $startdate_hour = date("Y-m-d",strtotime(date("Y-m-d"). "-24 hour")).' '.$time_from;
        //$date_from = date('Y-m-d',strtotime($today . "first day of previous month")); // วันแรกของเดือนก่อนหน้า
        //$date_from = date('Y-m-d',strtotime($today . "first day of this month")); // วันแรกของเดือนนี้
        // $day = date("Y-m-d");
        $name_dropdown = 'Last Day';
        break;

      case "today": // today
        $today = date("Y-m-d H:00");

        $startdate_hour = date("Y-m-d",strtotime(date("Y-m-d"))).' 00:00';
        //$startdate_hour = date('Y-m-d H:i',strtotime($startdate_hour . "+0 hour"));
        //$today2 = date("Y-m-d H:i");
        //$time_from = date("H:i");
        $time_from = '00:00';
        //$today2 = date('Y-m-d H:i',strtotime($today2 . "-1 hour"));
        $date_from = date('Y-m-d 00:00',strtotime($today));
        //$date_from = date('Y-m-d',strtotime($today . "first day of previous month")); // วันแรกของเดือนก่อนหน้า
        //$date_from = date('Y-m-d',strtotime($today . "first day of this month")); // วันแรกของเดือนนี้
        // $day = date("Y-m-d");
        $name_dropdown = 'Today';
        break;

      default: // นอกจากนั้น
        $today = date("Y-m-d H:00");
        $startdate_hour = date("Y-m-d",strtotime(date("Y-m-d"). "-48 hour")).' '.date("H",strtotime(date("H:i"). "-48 hour")).':00';
        //$startdate_hour = date('Y-m-d H:i',strtotime($startdate_hour . "+0 hour"));
        //$today2 = date("Y-m-d H:i");
        //$time_from = date("H:i");
        $time_from = date("H",strtotime(date("H:i"). "-48 hour")).':00';
        //$today2 = date('Y-m-d H:i',strtotime($today2 . "-1 hour"));
        $date_from = date('Y-m-d H:00',strtotime($today . "-48 hour"));
        //$date_from = date('Y-m-d',strtotime($today . "first day of previous month")); // วันแรกของเดือนก่อนหน้า
        //$date_from = date('Y-m-d',strtotime($today . "first day of this month")); // วันแรกของเดือนนี้
        // $day = date("Y-m-d");
        break;
    }
  }
  else { // duration เมื่อไม่มีค่า หรือ last 2 day
    $today = date("Y-m-d H:00");
    $startdate_hour = date("Y-m-d",strtotime(date("Y-m-d"). "-48 hour")).' '.date("H",strtotime(date("H:i"). "-48 hour")).':00';
    //$startdate_hour = date('Y-m-d H:i',strtotime($startdate_hour . "+0 hour"));
    //$today2 = date("Y-m-d H:i");
    //$time_from = date("H:i");
    $startdate_hour = date("Y-m-d",strtotime(date("Y-m-d"). "-48 hour")).' '.date("H",strtotime(date("H:i"). "-48 hour")).':00';
    $time_from = date("H",strtotime(date("H:i"). "-48 hour")).':00';
    //$today2 = date('Y-m-d H:i',strtotime($today2 . "-1 hour"));
  	$date_from = date('Y-m-d H:00',strtotime($today . "-48 hour"));
    //$date_from = date('Y-m-d',strtotime($today . "first day of previous month")); // วันแรกของเดือนก่อนหน้า
    //$date_from = date('Y-m-d',strtotime($today . "first day of this month")); // วันแรกของเดือนนี้
  	// $day = date("Y-m-d");
  }
}

if(isset($_GET['date2'])){
	$date_to = $_GET['date2'];
  $date_to = date('Y-m-d H:00',strtotime($date_to)); // แปลงให้เหลือ แต่ ปี วัน เดือน
	$day2 = $_GET['date2'];
  // $time_to= $_GET['time'];
  $time_to = date('H:i',strtotime($date_to)); // แปลงให้เหลือแต่ ชั่วโมง:นาที

  $enddate_hour = date('Y-m-d',strtotime($date_to)).' '.date("H",strtotime($time_to)).':00';

  $name_dropdown = 'Custom';
  $date_ptrfixdate_to = date('D',strtotime($date_to));
}else{
  if(isset($_GET['duration'])){ //NO CUSTOM => CHECK DROPDOWN ITEM
    switch($_GET['duration']){
      case "lastday": //DROPDOWN = LASTMONTH
        $date_to = date("Y-m-d H:00");
        $enddate_hour = date('Y-m-d',strtotime($date_to)).' '.date("H",strtotime(date("H:i"))).':00';
        //$enddate_hour = $enddate_hour.' 23:00';
        //$time_to = date("H:i");
        $time_to= date("H",strtotime(date("H:i"). "-24 hour")).':00';
        $date_ptrfixdate_to = date("D");
        //$date_to = date('Y-m-d',strtotime($today . "last day of previous month")); // วันสุดท้ายเดือนก่อนหน้า
        //$date_to = date('Y-m-d',strtotime($today . "last day of this month")); // วันสุดท้ายเดือนนี้
        $day2 = date("Y-m-d H:00");
        break;

      case "today": //DROPDOWN = LASTMONTH
        $date_to = date("Y-m-d H:00");
        $enddate_hour = date('Y-m-d',strtotime($date_to)).' '.date("H",strtotime(date("H:i"))).':00';
        $time_to= date("H").':00';
        //$enddate_hour = $enddate_hour.' 23:00';
        //$time_to = date("H:i");
        $date_ptrfixdate_to = date("D");
        //$date_to = date('Y-m-d',strtotime($today . "last day of previous month")); // วันสุดท้ายเดือนก่อนหน้า
        //$date_to = date('Y-m-d',strtotime($today . "last day of this month")); // วันสุดท้ายเดือนนี้
        $day2 = date("Y-m-d H:00");
        break;

      default: //DROPDOWN = last2days
        $date_to = date("Y-m-d H:00");
        $enddate_hour = date('Y-m-d',strtotime($date_to)).' '.date("H",strtotime(date("H:i"))).':00';
        //$enddate_hour = $enddate_hour.' 23:00';
        //$time_to = date("H:i");
        $time_to= date("H",strtotime(date("H:i"). "-48 hour")).':00';
        $date_ptrfixdate_to = date("D");
        //$date_to = date('Y-m-d',strtotime($today . "last day of previous month")); // วันสุดท้ายเดือนก่อนหน้า
        //$date_to = date('Y-m-d',strtotime($today . "last day of this month")); // วันสุดท้ายเดือนนี้
        $day2 = date("Y-m-d H:00");
        break;
    }
  }
  else { // duration เมื่อไม่มีค่า
    $date_to = date("Y-m-d H:00");
    //$enddate_hour = $enddate_hour.' 23:00';
    //$time_to = date("H:i");
    $time_to= date("H",strtotime(date("H:i"). "-48 hour")).':00';
    $enddate_hour = date('Y-m-d',strtotime($date_to)).' '.date("H",strtotime(date("H:i"))).':00';
    $date_ptrfixdate_to = date("D");
    //$date_to = date('Y-m-d',strtotime($today . "last day of previous month")); // วันสุดท้ายเดือนก่อนหน้า
    //$date_to = date('Y-m-d',strtotime($today . "last day of this month")); // วันสุดท้ายเดือนนี้
  	$day2 = date("Y-m-d H:00");
  }
}


$full_date_from = $date_from;
$full_date_to =$date_to;
$date_from = date('Y-m-d',strtotime($date_from));
$date_to = date('Y-m-d',strtotime($date_to));


isset($time) ? : $time = ''; //Edit

     // การนับวันที่ และ เวลา
     function DateDiff($strDate1,$strDate2) // นับระยะห่างของวัน
     {
          return (strtotime($strDate2) - strtotime($strDate1))/  ( 60 * 60 * 24 );  // 1 day = 60*60*24
     }
     function TimeDiff($strTime1,$strTime2) // นับระยะห่างของเวลา
     {
          return (strtotime($strTime2) - strtotime($strTime1))/  ( 60 * 60 ); // 1 Hour =  60*60
     }
     function DateTimeDiff($strDateTime1,$strDateTime2) // นับระยะห่างของวันที่และเวลา
     {
          return (strtotime($strDateTime2) - strtotime($strDateTime1))/  ( 60 * 60 ); // 1 Hour =  60*60
     }

     $datecnt=DateDiff($date_from,$date_to)."<br>";
     $intcnt=intval($datecnt); // แปลงค่า String เป็น Int

//echo $startdate_hour;

     $datecnt_hour=DateTimeDiff($startdate_hour,$enddate_hour)."<br>";
     $intcnt_hour=intval($datecnt_hour); // แปลงค่า String เป็น Int
     //echo $intcnt_hour;

     $datecnt_time=TimeDiff($time_from,$time_to)."<br>";
     $intcnt_time=intval($datecnt_time); // แปลงค่า String เป็น Int

     // เช็คว่า วันห่างกันกี่วัน ถ้าน้อยกว่า 0 ให้แจ้งเตือนแล้วไม่ทำงานส่วนต่าง ๆ
     if ($intcnt < 0) {
       echo"<script language=\"JavaScript\">";
       echo"alert('กรอกข้อมูลไม่วันที่ไม่ถูกต้อง')";
       echo"</script>";
     }
     else { // กรณีกรอกวันที่ถูกต้อง ก็เริ่มทำงานปกติ
       //echo '<br>'.$intcnt;



       for($i=$intcnt_hour; $i >= 0; $i--)
       {
         $a_date_start_stop[]=date('Y-m-d H:i',strtotime($enddate_hour . "-".$i." hour")); // อันนี้ลบจากวัน $date_to วันที่กำหนดเองได้
         $date_ptrfixdate[]=date("D",strtotime(date('Y-m-d H:i',strtotime($enddate_hour . "-".$i." hour"))));
       }
       // เอาค่าที่อยู่ใน Date มาใส่

       // ------------------------------------ เริมการค้นหาวันที่ของทั้ง 2 ip -----------------------------------------------------
       /*
       $sql=mysqli_query($con,"SELECT f5_data.date , f5_data.bras_name , ro_bras_name , f5_data.nasipaddress , f5_data.ip_host , f5_data.cnt , SUM(cnt)
        FROM (SELECT date_format(datetime,'%Y-%m-%d %H:%m') as date, bras.bras_name as bras_name , bras.nasipaddress as nasipaddress ,bras.radius_host as ip_host, COUNT(bras.nasipaddress) as cnt
        from ( SELECT *
        , SUBSTRING(SUBSTRING_INDEX(ltmlog,':',4),-11,11) AS ltmlog_strIP
        , TRIM(REPLACE(SUBSTRING(SUBSTRING_INDEX(ltmlog,':',-1),1,5),':','')) as ltmlog_strPort
        FROM f5_ltm_log as f5_log
        WHERE ltmlog like '%down%'
  				and (date_format(datetime,'%Y-%m-%d') between '$date_from' and '$date_to')
  				and (date_format(datetime,'%H:%m') between '$time_from' and '$time_to')
        ) as f5_log JOIN f5_radius_port as bras
        on (f5_log.ltmlog_strPort = bras.radius_port and f5_log.ltmlog_strIP = bras.radius_host)
        GROUP BY date , bras.nasipaddress
  			) as f5_data join f5_ro
  			on (f5_data.nasipaddress = f5_ro.ro_bras_ip)
  			group by date_format(f5_data.date,'%Y-%m-%d %H:%m')
  			ORDER BY f5_data.date,f5_ro.ro_id");

       while ($result=mysqli_fetch_array($sql)) {
          $a_date_start_stop[] = $result["date"];
          //echo $result["date"].'<br>';
       }
       */
       // ------------------------------------ จบการค้นหาวันที่ของทั้ง 2 ip -----------------------------------------------------




       isset($a_date_start_stop) ? : $a_date_start_stop[] = ''; //Edit // กัน $date ว่าง
       for ($d=0; $d < COUNT($a_date_start_stop); $d++) {
         $time .= "'".$date_ptrfixdate[$d]." ".$a_date_start_stop[$d]."',"; // $time เก็บวันที่ [แบบสะสมต่อกันไปเรื่อยๆ ] นำไปใช้งานจริง
       }
       //echo $time.'<br>';

    $time_from_query = date('H',strtotime($time_from));
    $time_to_query = date('H',strtotime($time_to));

    // Query หา nasip ของ 10.11.11.86
    $sql=mysqli_query($con,"SELECT f5_data.date , f5_data.bras_name , ro_bras_name , f5_data.nasipaddress , f5_data.ip_host , f5_data.cnt
      FROM (SELECT date_format(datetime,'%Y-%m-%d %H:00') as date, bras.bras_name as bras_name , bras.nasipaddress as nasipaddress ,bras.radius_host as ip_host, COUNT(bras.nasipaddress) as cnt
      from ( SELECT *
      , SUBSTRING(SUBSTRING_INDEX(ltmlog,':',4),-11,11) AS ltmlog_strIP
      , TRIM(REPLACE(SUBSTRING(SUBSTRING_INDEX(ltmlog,':',-1),1,5),':','')) as ltmlog_strPort
      FROM f5_ltm_log as f5_log
      WHERE ltmlog like '%down%'
        and (date_format(datetime,'%Y-%m-%d %H') between '$date_from $time_from_query' and '$date_to $time_to_query')
      ) as f5_log JOIN f5_radius_port as bras
      on (f5_log.ltmlog_strPort = bras.radius_port and f5_log.ltmlog_strIP = bras.radius_host)
			where bras.radius_host = '10.11.11.86'
      GROUP BY date , bras.nasipaddress
			) as f5_data join f5_ro
			on (f5_data.nasipaddress = f5_ro.ro_bras_ip)
			group by f5_ro.ro_bras_ip
			ORDER BY f5_ro.ro_id");

    while ($result=mysqli_fetch_array($sql)) {
      $a_nasip_array[] = $result["nasipaddress"];
    }
    // จบคำสั่ง Query nasip ของ 10.11.11.86

    // Query หา nasip ของ 10.11.11.88
    $sql=mysqli_query($con,"SELECT f5_data.date , f5_data.bras_name , ro_bras_name , f5_data.nasipaddress , f5_data.ip_host , f5_data.cnt
      FROM (SELECT date_format(datetime,'%Y-%m-%d %H:00') as date, bras.bras_name as bras_name , bras.nasipaddress as nasipaddress ,bras.radius_host as ip_host, COUNT(bras.nasipaddress) as cnt
      from ( SELECT *
      , SUBSTRING(SUBSTRING_INDEX(ltmlog,':',4),-11,11) AS ltmlog_strIP
      , TRIM(REPLACE(SUBSTRING(SUBSTRING_INDEX(ltmlog,':',-1),1,5),':','')) as ltmlog_strPort
      FROM f5_ltm_log as f5_log
      WHERE ltmlog like '%down%'
        and (date_format(datetime,'%Y-%m-%d %H') between '$date_from $time_from_query' and '$date_to $time_to_query')
      ) as f5_log JOIN f5_radius_port as bras
      on (f5_log.ltmlog_strPort = bras.radius_port and f5_log.ltmlog_strIP = bras.radius_host)
			where bras.radius_host = '10.11.11.88'
      GROUP BY date , bras.nasipaddress
			) as f5_data join f5_ro
			on (f5_data.nasipaddress = f5_ro.ro_bras_ip)
			group by f5_ro.ro_bras_ip
			ORDER BY f5_ro.ro_id");

    while ($result=mysqli_fetch_array($sql)) {
      $a_nasip_array_88[] = $result["nasipaddress"];
      //echo $result["nasipaddress"].'<br>';
    }
    // จบคำสั่ง Query nasip ของ 10.11.11.88

  // start query bras

      // start Query color
      $sql=mysqli_query($con,"select ro_bras_ip as ip_bras ,ro_color from f5_ro");

      while ($result=mysqli_fetch_array($sql)) {
        $a_ipbras = $result["ip_bras"];
        $a_bras_color[$a_ipbras] = $result["ro_color"]; // $data_final[$a_date] เก็บค่า cnt เป็นอ Array [ชี้ตำแหน่งด้วยวันที่]์
      }
      // End Query color

      // start query bras ข้อมูลหลัก

      // ------------------------------------ เริมการทำงานงาน Host 10.11.11.86 -----------------------------------------------------
      $sql=mysqli_query($con,"SELECT f5_data.date , f5_data.bras_name , ro_bras_name , f5_data.nasipaddress , f5_data.ip_host , f5_data.cnt
      FROM (SELECT date_format(datetime,'%Y-%m-%d %H:00') as date, bras.bras_name as bras_name , bras.nasipaddress as nasipaddress ,bras.radius_host as ip_host, COUNT(bras.nasipaddress) as cnt
      from ( SELECT *
      , SUBSTRING(SUBSTRING_INDEX(ltmlog,':',4),-11,11) AS ltmlog_strIP
      , TRIM(REPLACE(SUBSTRING(SUBSTRING_INDEX(ltmlog,':',-1),1,5),':','')) as ltmlog_strPort
      FROM f5_ltm_log as f5_log
      WHERE ltmlog like '%down%'
        and (date_format(datetime,'%Y-%m-%d %H') between '$date_from $time_from_query' and '$date_to $time_to_query')
      ) as f5_log JOIN f5_radius_port as bras
      on (f5_log.ltmlog_strPort = bras.radius_port and f5_log.ltmlog_strIP = bras.radius_host)
			where bras.radius_host = '10.11.11.86'
      GROUP BY date , bras.nasipaddress
			) as f5_data join f5_ro
			on (f5_data.nasipaddress = f5_ro.ro_bras_ip)
			#group by date_format(f5_data.date,'%Y-%m-%d %H:%m')
			ORDER BY f5_data.date,f5_ro.ro_id");

      while ($result=mysqli_fetch_array($sql)) {
        $a_date = $result["date"]; // $a_date เก็บวันที่
        $a_nasip = $result["nasipaddress"];
      	$a_value[$a_date][$a_nasip] = $result["cnt"]; // $data_final[$a_date] เก็บค่า cnt เป็นอ Array [ชี้ตำแหน่งด้วยวันที่]์
        $a_bras_name[$a_nasip] = $result["ro_bras_name"]; // $data_final[$a_date] เก็บค่า cnt เป็นอ Array [ชี้ตำแหน่งด้วยวันที่]์
      }

      isset($a_nasip_array) ? : $a_nasip_array[] = ''; //Edit // กัน ipnas ว่าง
      for($d=0; $d<COUNT($a_date_start_stop); $d++) {
        //echo COUNT($a_date_start_stop);

        for($n=0; $n<COUNT($a_nasip_array); $n++) {
          //echo $a_nasip_array[$n].'<br>';
          isset($a_value[$a_date_start_stop[$d]][$a_nasip_array[$n]]) ? : $a_value[$a_date_start_stop[$d]][$a_nasip_array[$n]] = ''; //Edit
          if($a_value[$a_date_start_stop[$d]][$a_nasip_array[$n]] != '') {
            isset($data_value[$a_nasip_array[$n]]) ? : $data_value[$a_nasip_array[$n]] = ''; //Edit
            $data_value[$a_nasip_array[$n]] .= $a_value[$a_date_start_stop[$d]][$a_nasip_array[$n]].",";
          }
          else {
            isset($data_value[$a_nasip_array[$n]]) ? : $data_value[$a_nasip_array[$n]] = ''; //Edit
            $data_value[$a_nasip_array[$n]] .= "null,";
          }
        }
      }

      isset($show_data) ? : $show_data = ''; //Edit
      isset($show_color) ? : $show_color = ''; //Edit

      for ($i=0; $i < count($data_value); $i++) {
            isset($show_color) ? : $show_color = ''; //Edit
            if ($a_nasip_array[$i] != '') {
              $show_data .= " { id: '".TRIM($a_bras_name[$a_nasip_array[$i]])."', name: '".TRIM($a_bras_name[$a_nasip_array[$i]])."', data: [".$data_value[$a_nasip_array[$i]]."], stack: '10.11.11.86' },";
              $show_color .= "'".$a_bras_color[$a_nasip_array[$i]]."', ";
            }
            else { // กรณีไม่มีข้อมูลเลย
              //$show_data .= " { name: '', data: [".$data_value[$a_nasip_array[$i]]."] },";
              //$show_color .= "'red', ";
            }
      }
      // ------------------------------------ จบการทำงานงาน Host 10.11.11.86 -----------------------------------------------------

      // ------------------------------------ เริมการทำงานงาน Host 10.11.11.88 -----------------------------------------------------
      $sql=mysqli_query($con,"SELECT f5_data.date , f5_data.bras_name , ro_bras_name , f5_data.nasipaddress , f5_data.ip_host , f5_data.cnt
      FROM (SELECT date_format(datetime,'%Y-%m-%d %H:00') as date, bras.bras_name as bras_name , bras.nasipaddress as nasipaddress ,bras.radius_host as ip_host, COUNT(bras.nasipaddress) as cnt
      from ( SELECT *
      , SUBSTRING(SUBSTRING_INDEX(ltmlog,':',4),-11,11) AS ltmlog_strIP
      , TRIM(REPLACE(SUBSTRING(SUBSTRING_INDEX(ltmlog,':',-1),1,5),':','')) as ltmlog_strPort
      FROM f5_ltm_log as f5_log
      WHERE ltmlog like '%down%'
        and (date_format(datetime,'%Y-%m-%d %H') between '$date_from $time_from_query' and '$date_to $time_to_query')
      ) as f5_log JOIN f5_radius_port as bras
      on (f5_log.ltmlog_strPort = bras.radius_port and f5_log.ltmlog_strIP = bras.radius_host)
			where bras.radius_host = '10.11.11.88'
      GROUP BY date , bras.nasipaddress
			) as f5_data join f5_ro
			on (f5_data.nasipaddress = f5_ro.ro_bras_ip)
			#group by date_format(f5_data.date,'%Y-%m-%d %H:%m')
			ORDER BY f5_data.date,f5_ro.ro_id");

      while ($result=mysqli_fetch_array($sql)) {
        $a_date = $result["date"]; // $a_date เก็บวันที่
        $a_nasip = $result["nasipaddress"];
      	$a_value_88[$a_date][$a_nasip] = $result["cnt"]; // $data_final[$a_date] เก็บค่า cnt เป็นอ Array [ชี้ตำแหน่งด้วยวันที่]์
        $a_bras_name[$a_nasip] = $result["ro_bras_name"]; // $data_final[$a_date] เก็บค่า cnt เป็นอ Array [ชี้ตำแหน่งด้วยวันที่]์

      }

      isset($a_nasip_array_88) ? : $a_nasip_array_88[] = ''; //Edit // กัน ipnas ว่าง
      for($d=0; $d<COUNT($a_date_start_stop); $d++) {
        //echo COUNT($a_date_start_stop);

        for($n=0; $n<COUNT($a_nasip_array_88); $n++) {
          isset($a_value_88[$a_date_start_stop[$d]][$a_nasip_array_88[$n]]) ? : $a_value_88[$a_date_start_stop[$d]][$a_nasip_array_88[$n]] = ''; //Edit
          if($a_value_88[$a_date_start_stop[$d]][$a_nasip_array_88[$n]] != '') {
            isset($data_value_88[$a_nasip_array_88[$n]]) ? : $data_value_88[$a_nasip_array_88[$n]] = ''; //Edit
            $data_value_88[$a_nasip_array_88[$n]] .= $a_value_88[$a_date_start_stop[$d]][$a_nasip_array_88[$n]].",";
          }
          else {
            isset($data_value_88[$a_nasip_array_88[$n]]) ? : $data_value_88[$a_nasip_array_88[$n]] = ''; //Edit
            $data_value_88[$a_nasip_array_88[$n]] .= "null,";
          }
        }
      }

      isset($show_data_88) ? : $show_data_88 = ''; //Edit
      isset($show_color_88) ? : $show_color_88 = ''; //Edit

      for ($i=0; $i < count($data_value_88); $i++) {
          if ($a_nasip_array_88[$i] != '') {

            $ck_name = 0;
            $msg_linkto = "";
            for ($j=0; $j < count($data_value); $j++) {
              isset($a_bras_name[$a_nasip_array[$j]]) ? : $a_bras_name[$a_nasip_array[$j]] = ''; //Edit // กัน $a_bras_name[$a_nasip_array[$j]] ว่าง
              if (TRIM($a_bras_name[$a_nasip_array_88[$i]]) == TRIM($a_bras_name[$a_nasip_array[$j]])) {
                $msg_linkto = "linkedTo: '".TRIM($a_bras_name[$a_nasip_array_88[$i]])."',  ";
              }
            }

            $show_data_88 .= " { ".$msg_linkto."name: '".TRIM($a_bras_name[$a_nasip_array_88[$i]])."', data: [".$data_value_88[$a_nasip_array_88[$i]]."], stack: '10.11.11.88' },";
            $show_color_88 .= "'".$a_bras_color[$a_nasip_array_88[$i]]."', ";
          }
          else { // กรณีไม่มีข้อมูลเลย
            //$show_data_88 .= " { name: '', data: [".$data_value_88[$a_nasip_array_88[$i]]."] },";
            //$show_color_88 .= "'red', ";
          }
      }
      // ------------------------------------ จบการทำงานงาน Host 10.11.11.88 -----------------------------------------------------

      //echo strlen($show_data_88); // strlen(ตัวแปรสตริง) เช็คว่า String นี้มีข้อความกี่ตัวอักษร
      // หากไม่มีข้อมูลทั้ง 2 เครื่อง ให้แสดงค่าว่าง
      if ( (strlen($show_data) == 0) and (strlen($show_data_88) == 0) ) {
        for ($i=0; $i < count($data_value); $i++) {
          $show_data .= " { name: '', data: [".$data_value[$a_nasip_array[$i]]."] },";
          $show_color .= "'red', ";
          $show_data_88 .= " { name: '', data: [".$data_value_88[$a_nasip_array_88[$i]]."] },";
          $show_color_88 .= "'red', ";
        }
      }

      // ------------------------------------ หาค่า Max ไปใช้้ใน Graph -----------------------------------------------------
      $sql=mysqli_query($con,"SELECT max(f5_data.cnt) as max_value
      FROM (SELECT date_format(datetime,'%Y-%m-%d %H:00') as date, bras.bras_name as bras_name ,
      bras.nasipaddress as nasipaddress ,bras.radius_host as ip_host, COUNT(bras.nasipaddress) as cnt
      from ( SELECT *
      , SUBSTRING(SUBSTRING_INDEX(ltmlog,':',4),-11,11) AS ltmlog_strIP
      , TRIM(REPLACE(SUBSTRING(SUBSTRING_INDEX(ltmlog,':',-1),1,5),':','')) as ltmlog_strPort
      FROM f5_ltm_log as f5_log
      WHERE ltmlog like '%down%'
      ) as f5_log JOIN f5_radius_port as bras
      on (f5_log.ltmlog_strPort = bras.radius_port and f5_log.ltmlog_strIP = bras.radius_host)
      where bras.radius_host IN  ('10.11.11.86','10.11.11.88')
      GROUP BY date,bras.radius_host
      ) as f5_data join f5_ro
      on (f5_data.nasipaddress = f5_ro.ro_bras_ip)
      where f5_data.date between '$date_from $time_from_query' and '$date_to $time_to_query'
      ORDER BY f5_data.date,f5_ro.ro_id;");

      while ($result=mysqli_fetch_array($sql)) {
        $graph_max = $result["max_value"]; // $a_date เก็บวันที่
      }
      isset($graph_max) ? : $graph_max = 50; //Edit
      ($graph_max > 50) ? : $graph_max = 50; //Edit

      // ------------------------------------ หาค่า Max ไปใช้้ใน Graph -----------------------------------------------------


  // End query bras
  }

 ?>

<script src="js/jquery-3.1.1.min.js"></script>
<script src="code/highcharts.js"></script>
<script src="code/highcharts-3d.js"></script>
<script src="code/modules/exporting.js"></script>
<!-- end chart ltm log  -->
  <body>


<?php include("menu_top.php");?>

<?php include("menu_date_time_hour_2day.php");?>

<!-- jQuery first, then Tether, then Bootstrap JS. -->
<script src="js/bootstrap.min2.js" integrity="sha384-vBWWzlZJ8ea9aCX4pEW3rVHjgjt7zpkNpZk+02D9phzyeVkE+jo0ieGizqPLForn" crossorigin="anonymous"></script>

<!-- start chart ltm log -->
<script type="text/javascript">

Highcharts.chart('container', {
    chart: {
        type: 'column',
        borderColor: "#000000",
        borderWidth: 1
        // ทำเป็นกราฟ 3D

        /*options3d: {
            enabled: true,
            alpha: 0,
            beta: 0,
            viewDistance: 30,
            depth: 25
        }*/
    },
    colors: [<?php echo $show_color ?> <?php echo $show_color_88 ?>], // เปลี่ยนแท่งกราฟ
    title: {
        text: 'F5 - 113 LTM LOG (HOURLY) : Status Down , Host : 10.11.11.86 , 10.11.11.88'
    },
    subtitle: {
        text: '<?php echo 'Date: '.$date_from.' '.$time_from.' to '.$date_to.' '.$time_to; ?>',
        align: 'center',
        x: -20
    },
    xAxis: {
        /*categories: ['Apples', 'Oranges', 'Pears', 'Grapes', 'Bananas']*/
        categories: [<?php echo $time; ?>],
    },
    yAxis: {
        min: 0,
        max: <?php echo $graph_max; ?>,
        title: {
            text: 'Total Status Down'
        },
        stackLabels: {
            enabled: true,
            rotation: -50,
            x: 0,
            y: -10,
            style: {
                fontWeight: 'bold',
                color: (Highcharts.theme && Highcharts.theme.textColor) || 'gray',
            },

        }
    },
    legend: { // แถบแต่ล่ะ Bras ด้านล่าง
        // align: 'right',
        // x: -30,
        // verticalAlign: 'top',
        // y: 20,
        // floating: true,
        // backgroundColor: (Highcharts.theme && Highcharts.theme.background2) || 'white',
        // borderColor: '#CCC',
        // borderWidth: 1,
        // shadow: false
        enabled : true, //เปิดให้แถบแต่ล่ะ Bras มาอยู่ข้างล่าง
        itemWidth: 140 // กำหนดระยะห่างการแสดงข้อความ (จัดเรียงให้ตรงกัน)


    },
    tooltip: {
      //backgroundColor: '#e6ffff',
      useHTML: true,
      //headerFormat: '<b>{point.x}</b><br/>', // headerFormat การแสดงข้อมูลส่วนหัว
      //pointFormat: '{series.name}: {point.y}<br/>Total: {point.stackTotal}', // pointFormat การแสดงข้อความส่วนข้อมูลแต่ล่ะจุด
      formatter: function () {
        var s = '<b><u>' + this.x + '</u></b></br> <table>';
        var total_1 = 0 , total_2 = 0 , total = 0;
        var text_1 = [] , text_2 = [];
        var i_1 = 0 , i_2 = 0;
        var sum_text = '<div class="MyChartTooltip">';

         $.each(this.points, function () {
             //s += '<br/><b><font color="'+this.series.color+'">' + this.series.name + ': </font>' + this.y + '</b>';
             if(this.series.options.stack == '10.11.11.86') {
               text_1[i_1] = '<td><b><font color="'+this.series.color+'">' + this.series.name + ': </font>' + this.y + '</td>';
               i_1++;
               total_1 += this.y;
             }
             else if(this.series.options.stack == '10.11.11.88') {
               text_2[i_2] = '<td><b><font color="'+this.series.color+'">' + this.series.name + ': </font>' + this.y + '</td>';
               i_2++;
               total_2 += this.y;
             }

             total += this.y;
         });

         sum_text += s; // ใส่หัว Title
         var cnt_loop

         if (text_1.length >= text_2.length) {
           var cnt_loop = text_1.length;
         }
         else {
           var cnt_loop = text_2.length;
         }

         for (var j = 0; j < cnt_loop; j++) {
           sum_text += '<tr>';

           if ( text_1[j] != null) {
             sum_text += text_1[j];
           }
           else {
             sum_text += '<td></td>';
           }
           if ( text_2[j] != null) {
             sum_text += text_2[j];
           }
           else {
             sum_text += '<td></td>';
           }
           //sum_text += '</br>';
           sum_text += '</tr>';
         }

         if( total_1 != 0 ) {
           total_1 = '<td> <b><u>Total 86 : ' + total_1 + '<u></b> </td>';
         }
         else {
             total_1 = '<td></td>';
         }
         if( total_2 != 0 ) {
           total_2 = '<td> <b><u>Total 88 : ' + total_2 + '<u></b> </td>';
         }
         else {
             total_2 = '<td></td>';
         }
         sum_text += '<tr>' + total_1 + total_2 + '</tr>';
         sum_text += '</table>';
         sum_text += '<b><u>Total All: ' + total + '<u></b>';

         //alert(text_1[0]);
         //alert(this.series.options.stack);
         //s += '<br/><b><u>Total: ' + total + '<u></b>';


         sum_text += '<div>';
         return sum_text;
      },
      shared: true,/*, //เปิดแสดงข้อมูลแบบรวม รวมทุกอันในแท่งนั้น
      followPointer: true*/ //แถบมันจะเลื่อนตามเมาส์
      crosshairs: true
    },
    plotOptions: {
        column: {
            stacking: 'normal'/*,
            dataLabels: { ปิดการแสดงตัวเลข
                enabled: true,
                color: (Highcharts.theme && Highcharts.theme.dataLabelsColor) || 'white'
            }*/
        }
    },
    series: [ <?php echo $show_data; ?> <?php echo $show_data_88; ?> ]
});


</script>
<!-- end chart ltm log -->

<script type="text/javascript" src="js/bootstrap-datetimepicker.js" charset="UTF-8"></script>

<script type="text/javascript">
    $('.form_datetime').datetimepicker({
        //language:  'fr',
      format: 'yyyy-mm-dd hh:00',
      weekStart: 1,
      todayBtn:  1,
  		autoclose: 1,
  		todayHighlight: 1,
  		startView: 2,
  		minView: 1,
  		forceParse: 0,
      showMeridian: 0, // ตัวแบ่ง AM และ PM
    });

    $(function () {
      $('#datetimepicker1').datetimepicker({
        startDate: '<?php echo $date_to.' 00:00'; ?>',
        minuteStep: 5, // ช่วงนาทีที่จะแสดง
        format: 'hh:ii',
        language:  'fr',
        weekStart: 1,
        todayBtn:  1,
    		autoclose: 1,
    		todayHighlight: 1,
    		startView: 1, // แก้ส่วนรับค่า startView: number เช่น ใส่ 0 รับค่าเวลา ณ ชั่วโมงปัจจุบัน หรือ ใส่ 1 รับค่าเวลา หรือ ใส่ 2 รับค่าวันที่และเวลา หรือ ใส่ 3 รับค่าเดือน หรือ ใส่ 4 รับค่าปี
    		minView: 1,
    		maxView: 1,
    		forceParse: 0,
      });
      $('#datetimepicker2').datetimepicker({
        startDate: '<?php echo $date_to.' 00:00'; ?>',
        minuteStep: 5, // ช่วงนาทีที่จะแสดง
        format: 'hh:ii',
        language:  'fr',
        weekStart: 1,
        todayBtn:  1,
    		autoclose: 1,
    		todayHighlight: 1,
    		startView: 1, // แก้ส่วนรับค่า startView: number เช่น ใส่ 0 รับค่าเวลา ณ ชั่วโมงปัจจุบัน หรือ ใส่ 1 รับค่าเวลา หรือ ใส่ 2 รับค่าวันที่และเวลา หรือ ใส่ 3 รับค่าเดือน หรือ ใส่ 4 รับค่าปี
    		minView: 0,
    		maxView: 1,
    		forceParse: 0
      });
    });

</script>

<!-- _____________________________________ Code Oat __________________________________________________ -->
<br>
<?php
$colorcode = array("Sun" => "#FF0000","Mon" => "#FFFF00","Tue" => "PINK","Wed" => "#00FF00","Thu" => "#FF8000","Fri" => "#00FFFF","Sat" => "#D358F7",);

$timehour = array(
  "00" => "00:00-00:59",
  "01" => "01:00-01:59",
  "02" => "02:00-02:59",
  "03" => "03:00-03:59",
  "04" => "04:00-04:59",
  "05" => "05:00-05:59",
  "06" => "06:00-06:59",
  "07" => "07:00-07:59",
  "08" => "08:00-08:59",
  "09" => "09:00-09:59",
  "10" => "10:00-10:59",
  "11" => "11:00-11:59",
  "12" => "12:00-12:59",
  "13" => "13:00-13:59",
  "14" => "14:00-14:59",
  "15" => "15:00-15:59",
  "16" => "16:00-16:59",
  "17" => "17:00-17:59",
  "18" => "18:00-18:59",
  "19" => "19:00-19:59",
  "20" => "20:00-20:59",
  "21" => "21:00-21:59",
  "22" => "22:00-22:59",
  "23" => "23:00-23:59"
  );
?>

<?php
$name_dropdown="Last Week";
 $dstart=$date_from;
 $dendd=$date_to;
 $lastday=DateDiff("".$dstart."","".$dendd."")+1;
 $j=0;
?>


<div class="container">
<div class="row" align="center">
  <div class="col-md-12 col-sm-12">
    <h5>F5 LTM LOG 113 - 114</h5>
    Date <?php echo ": ".$date_from." to ".$date_to;?>
  </div>
  <div class="col-md-12 col-sm-12" align="right">
    <table border="0" style="width: 15%">
    <tr>
      <td width="5%">
        <button style="background-color: blue;" type="button" class="btn"></button>
      </td>
      <td>
        <font size="-1"> Status : Packet rejected</font>
      </td>
    </tr>
    </table>

  </div>
   <div class="col-md-12 col-sm-12" align="right">
    <table border="0" style="width: 15%">
    <tr>
      <td width="5%">
        <button style="background-color: red;" type="button" class="btn"></button>
      </td>
      <td>
        <font size="-1"> Status : Down</font>
      </td>
    </tr>
    </table>
  </div>
</div>
<table border="1" width="100%" style="margin-top: 1%;">
  <tr bgcolor="#eaeae1">
    <td height="90px;" width="100px;" align="center" colspan="2">
    <span class="textAlignVer">
    <strong>Date/Time</strong>
    </span></td>
    <td height="90px;" width="40px;" align="center"></td>
<?php
foreach($timehour as $value)
{
  ?>
<td height="90px;" width="30px;">
    <div style="width:30px;height:90px;">
       <svg>
          <text transform="rotate(270, 12, 0) translate(-75,5)"><?php echo $value?></text>
      </svg>
    </div>
</td>
  <?
}
   ?>
    <td height="90px;" align="center"><span class="textAlignVer"><strong>Remark</strong></span></td>
  </tr>

  <?php

for($i=$lastday;$i>=1;$i--)
{
    if(!empty($_GET['date_form']))
    {
      if($_GET['date_to']>date('Y-m-d'))
      {
        $dato=date('Y-m-d');
      }
      else
      {
        $dato=$_GET['date_to'];
      }
          $DAYENG=date("D", strtotime('-'.$j.' days',strtotime($dato)));
          $datestart=date("Y-m-d", strtotime('-'.$j.' days',strtotime($dato)));
          $dateview=date("d-m-Y", strtotime('-'.$j.' days',strtotime($dato)));
          $j++;
    }
    elseif(!empty($_GET['type_dropdown']))
    {
      if($_GET['type_dropdown']=="previousmonth")
      {
          $premonth=date("Y-m", strtotime('-1 month'));
          // date("Y-m-d", strtotime($premonth.'-'.$i));
          $DAYENG=date("D", strtotime($premonth.'-'.$i));
          $datestart=date("Y-m-d", strtotime($premonth.'-'.$i));
          $dateview=date("d-m-Y", strtotime($premonth.'-'.$i));
      }
      else
      {
          $DAYENG=date("D", strtotime('-'.$j.' days'));
          $datestart=date("Y-m-d", strtotime('-'.$j.' days'));
          $dateview=date("d-m-Y", strtotime('-'.$j.' days'));
          $j++;
      }
    }
    elseif(empty($_GET['date_form']) and empty($_GET['type_dropdown']))
    {
          $DAYENG=date("D", strtotime('-'.$j.' days'));
          $datestart=date("Y-m-d", strtotime('-'.$j.' days'));
          $dateview=date("d-m-Y", strtotime('-'.$j.' days'));
         $j++;
    }


?>
<tr>
<td width="50px;" rowspan="2" bgcolor="<?php echo $colorcode[$DAYENG];?>" align="center"><span class="textAlignVer"><strong>
    <?php echo $DAYENG;?></strong></span></td>
</td>
<td width="80px;" rowspan="2" align="center"><span class="textAlignVer"><?php echo $dateview;?></span></td>
<td align="center"><span class="textAlignVer">113</span></td>
 <?php
    // for($j=0;$j<count($timehour);$j++)
    foreach($timehour as $valuehour => $valuekey)
    {
$countchk=mysqli_query($con,"select count(*) as cntlog from (SELECT TIME_FORMAT(datetime, '%H:%i') AS time_str
  FROM f5_ltm_log
 WHERE     date_format(datetime, '%Y-%m-%d') = '".$datestart."'
       AND ltmlog LIKE '%down%'
       AND TIME_FORMAT(datetime, '%H')='".$valuehour."'
       AND host='10.11.11.113'
GROUP BY TIME_FORMAT(datetime, '%H:%i')) aa");
$rowcountchk=mysqli_fetch_array($countchk);
if($rowcountchk[0]==0)
{
$data113="";
$data113_show="";
}
elseif($rowcountchk[0]>1)
{
$query_time_str_113=mysqli_query($con,"SELECT TIME_FORMAT(datetime, '%H:%i') AS time_str
                      FROM f5_ltm_log
                     WHERE     date_format(datetime, '%Y-%m-%d') = '".$datestart."'
                           AND ltmlog LIKE '%down%'
                           AND TIME_FORMAT(datetime, '%H')='".$valuehour."'
                           AND host='10.11.11.113'
                    GROUP BY TIME_FORMAT(datetime, '%H:%i')
                     LIMIT 1");
$row_time_str_113=mysqli_fetch_array($query_time_str_113);
$query_time_end_113=mysqli_query($con,"SELECT TIME_FORMAT(datetime, '%H:%i') AS time_end
                        FROM f5_ltm_log
                       WHERE     date_format(datetime, '%Y-%m-%d') = '".$datestart."'
                             AND ltmlog LIKE '%down%'
                             AND TIME_FORMAT(datetime, '%H')='".$valuehour."'
                             AND host='10.11.11.113'
                      GROUP BY TIME_FORMAT(datetime, '%H:%i')
                      ORDER BY TIME_FORMAT(datetime, '%H:%i') DESC
                       LIMIT 1");
$row_time_end_113=mysqli_fetch_array($query_time_end_113);

$data113=$row_time_str_113[0]."-<br/>".$row_time_end_113[0];
$data113_show=$row_time_str_113[0]."-".$row_time_end_113[0];
}
else
{

  $query_time_str_113=mysqli_query($con,"SELECT TIME_FORMAT(datetime, '%H:%i') AS time_str
                      FROM f5_ltm_log
                     WHERE     date_format(datetime, '%Y-%m-%d') = '".$datestart."'
                           AND ltmlog LIKE '%down%'
                           AND TIME_FORMAT(datetime, '%H')='".$valuehour."'
                           AND host='10.11.11.113'
                    GROUP BY TIME_FORMAT(datetime, '%H:%i')
                     LIMIT 1");
$row_time_str_113=mysqli_fetch_array($query_time_str_113);
$data113=$row_time_str_113[0];
$data113_show=$row_time_str_113[0];
}

      ?>
        <td>
          <span class="textAlignVer">
            <font class="data113 a">
              <a href="#" onClick="js_popup('f5_ltm_log_detail_edit.php?date=<?php echo $datestart;?>&timehour=<?php echo $data113_show;?>&hour=<?php echo $valuehour;?>&host=113&status=down',1300,600); return false;" title="Code PHP Popup"><?php echo $data113;?></a>
            </font>
          </span>
        </td>
      <?
    }

$query_re_113=mysqli_query($con,"select concat(time_hour,'_',data_remark) as detailremark,status from f5_ltm_log_remark where date_remark='".$datestart."' and host='10.11.11.113' order by time_hour");
    ?>
    <td><span class="textAlignVer">
    <?php
    $data_re_113='';
    while($row_re_113=mysqli_fetch_array($query_re_113))
    {
        if($row_re_113[1]=="down")
       {
        echo " <font color=\"red\">".$row_re_113[0]."</font><br/>";
       }
       elseif($row_re_113[1]=="reject")
       {
        echo " <font color=\"blue\">".$row_re_113[0]."</font><br/>";
       }
    }

    ?>
    </span></td>
  </tr>
<tr>
  <td align="center"><span class="textAlignVer">114</span></td>
<?php
    // for($j=0;$j<count($timehour);$j++)
    foreach($timehour as $valuehour => $valuekey) // ดึงค่าจาก array $timehour มาเป็น $valuehour = "00" แล้ว $valuekey ตำแหน่ง "00" ="00:00-00:59"
    {

// LOG DOWN
$countchkdown=mysqli_query($con,"select count(*) as cntlog from (SELECT TIME_FORMAT(datetime, '%H:%i') AS time_str
  FROM f5_ltm_log
 WHERE     date_format(datetime, '%Y-%m-%d') = '".$datestart."'
       AND ltmlog LIKE '%down%'
       AND TIME_FORMAT(datetime, '%H')='".$valuehour."'
       AND host='10.11.11.114'
GROUP BY TIME_FORMAT(datetime, '%H:%i')) aa");
$rowcountchkdown=mysqli_fetch_array($countchkdown);
if($rowcountchkdown[0]==0)
{
$data114_down="";
}
elseif($rowcountchkdown[0]>1)
{
$query_timedown_str_114=mysqli_query($con,"SELECT TIME_FORMAT(datetime, '%H:%i') AS time_str
                      FROM f5_ltm_log
                     WHERE     date_format(datetime, '%Y-%m-%d') = '".$datestart."'
                           AND ltmlog LIKE '%down%'
                           AND TIME_FORMAT(datetime, '%H')='".$valuehour."'
                           AND host='10.11.11.114'
                    GROUP BY TIME_FORMAT(datetime, '%H:%i')
                     LIMIT 1");
$row_timedown_str_114=mysqli_fetch_array($query_timedown_str_114);
$query_timedown_end_114=mysqli_query($con,"SELECT TIME_FORMAT(datetime, '%H:%i') AS time_end
                        FROM f5_ltm_log
                       WHERE     date_format(datetime, '%Y-%m-%d') = '".$datestart."'
                             AND ltmlog LIKE '%down%'
                             AND TIME_FORMAT(datetime, '%H')='".$valuehour."'
                             AND host='10.11.11.114'
                      GROUP BY TIME_FORMAT(datetime, '%H:%i')
                      ORDER BY TIME_FORMAT(datetime, '%H:%i') DESC
                       LIMIT 1");
$row_timedown_end_114=mysqli_fetch_array($query_timedown_end_114);

$data114_down=$row_timedown_str_114[0]."-<br/>".$row_timedown_end_114[0];
$data114down_show=$row_timedown_str_114[0]."-".$row_timedown_end_114[0];
}
else
{

  $query_timedown_str_114=mysqli_query($con,"SELECT TIME_FORMAT(datetime, '%H:%i') AS time_str
                      FROM f5_ltm_log
                     WHERE     date_format(datetime, '%Y-%m-%d') = '".$datestart."'
                           AND ltmlog LIKE '%down%'
                           AND TIME_FORMAT(datetime, '%H')='".$valuehour."'
                           AND host='10.11.11.114'
                    GROUP BY TIME_FORMAT(datetime, '%H:%i')
                     LIMIT 1");
$row_timedown_str_114=mysqli_fetch_array($query_timedown_str_114);
$data114_down=$row_timedown_str_114[0];
$data114down_show=$row_timedown_str_114[0];
}
// LOG DOWN


$countchk=mysqli_query($con,"select count(*) as cntlog from (SELECT TIME_FORMAT(datetime, '%H:%i') AS time_str
  FROM f5_ltm_log
 WHERE     date_format(datetime, '%Y-%m-%d') = '".$datestart."'
       AND ltmlog LIKE '%Packet rejected%'
       AND TIME_FORMAT(datetime, '%H')='".$valuehour."'
       AND host='10.11.11.114'
GROUP BY TIME_FORMAT(datetime, '%H:%i')) aa");
$rowcountchk=mysqli_fetch_array($countchk);
if($rowcountchk[0]==0)
{
$data114="";
$data114_show="";
}
elseif($rowcountchk[0]>1)
{
$query_time_str_114=mysqli_query($con,"SELECT TIME_FORMAT(datetime, '%H:%i') AS time_str
                      FROM f5_ltm_log
                     WHERE     date_format(datetime, '%Y-%m-%d') = '".$datestart."'
                           AND ltmlog LIKE '%Packet rejected%'
                           AND TIME_FORMAT(datetime, '%H')='".$valuehour."'
                           AND host='10.11.11.114'
                    GROUP BY TIME_FORMAT(datetime, '%H:%i')
                     LIMIT 1");
$row_time_str_114=mysqli_fetch_array($query_time_str_114);
$query_time_end_114=mysqli_query($con,"SELECT TIME_FORMAT(datetime, '%H:%i') AS time_end
                        FROM f5_ltm_log
                       WHERE     date_format(datetime, '%Y-%m-%d') = '".$datestart."'
                             AND ltmlog LIKE '%Packet rejected%'
                             AND TIME_FORMAT(datetime, '%H')='".$valuehour."'
                             AND host='10.11.11.114'
                      GROUP BY TIME_FORMAT(datetime, '%H:%i')
                      ORDER BY TIME_FORMAT(datetime, '%H:%i') DESC
                       LIMIT 1");
$row_time_end_114=mysqli_fetch_array($query_time_end_114);

$data114=$row_time_str_114[0]."-<br/>".$row_time_end_114[0];
$data114_show=$row_time_str_114[0]."-".$row_time_end_114[0];
}
else
{

  $query_time_str_114=mysqli_query($con,"SELECT TIME_FORMAT(datetime, '%H:%i') AS time_str
                      FROM f5_ltm_log
                     WHERE     date_format(datetime, '%Y-%m-%d') = '".$datestart."'
                           AND ltmlog LIKE '%Packet rejected%'
                           AND TIME_FORMAT(datetime, '%H')='".$valuehour."'
                           AND host='10.11.11.114'
                    GROUP BY TIME_FORMAT(datetime, '%H:%i')
                     LIMIT 1");
$row_time_str_114=mysqli_fetch_array($query_time_str_114);
$data114=$row_time_str_114[0];
$data114_show=$row_time_str_114[0];

}
      ?>
        <td>
         <span class="textAlignVer">
          <?php if(!empty($data114_down)){?>
             <font class="data113 a">
              <a href="#" onClick="js_popup('f5_ltm_log_detail_edit.php?date=<?php echo $datestart;?>&timehour=<?php echo $data114down_show;?>&hour=<?php echo $valuehour;?>&host=114&status=down',1300,580); return false;" title="Code PHP Popup"><?php echo $data114_down;?></a>
            </font>
            <br/>
          <?php } ?>
            <font class="data114 a">
              <a href="#" onClick="js_popup('f5_ltm_log_detail_edit.php?date=<?php echo $datestart;?>&timehour=<?php echo $data114_show;?>&hour=<?php echo $valuehour;?>&host=114&status=reject',1300,580); return false;" title="Code PHP Popup"><?php echo $data114;?></a>
            </font>
          </span>
        </td>
      <?
    }
$query_re_114=mysqli_query($con,"select concat(time_hour,'_',data_remark) as detailremark,status  from f5_ltm_log_remark where date_remark='".$datestart."' and host='10.11.11.114' order by time_hour");
    ?>
     <td>
     <span class="textAlignVer">
        <?php
    $data_re_114='';
    while($row_re_114=mysqli_fetch_array($query_re_114))
    {

       if($row_re_114[1]=="down")
       {
         echo " <font color=\"red\">".$row_re_114[0]."</font><br/>";
       }
       elseif($row_re_114[1]=="reject")
       {
         echo " <font color=\"blue\">".$row_re_114[0]."</font><br/>";
       }
    }
     // echo substr($data_re_114,0,-2);
    ?>
     </span>
     </td>
  </tr>
<?php
}
  ?>
  </table>
  <br>
</div>

<!-- _____________________________________ Code Oat __________________________________________________ -->


<!--_____________________________________ Get Time _____________________________________-->
<script type="text/javascript">
    function last2days() {
      // var text_time = document.getElementsByName('time')[0].value
      // var time= 'time='+text_time;
      //alert(time);
      // window.location.href = 'f5_ltm_log_bras_hour_2day.php?'+time;
      window.location.href = 'f5_ltm_log_bras_hour_2day.php';
    }
    function lastday() {
      // var text_time = document.getElementsByName('time')[0].value
      // var time= 'time='+text_time;
      //alert(time);
      // window.location.href = 'f5_ltm_log_bras_hour_2day.php?duration=lastday&'+time;
      window.location.href = 'f5_ltm_log_bras_hour_2day.php?duration=lastday';
    }
    function today() {
      // var text_time = document.getElementsByName('time')[0].value
      // var time= 'time='+text_time;
      //alert(time);
      // window.location.href = 'f5_ltm_log_bras_hour_2day.php?duration=today&'+time;
      window.location.href = 'f5_ltm_log_bras_hour_2day.php?duration=today';
    }
</script>
<!--_____________________________________ Get Time _____________________________________-->


  </body>
</html>
